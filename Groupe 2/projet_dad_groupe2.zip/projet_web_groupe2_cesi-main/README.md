# Breezy

Projet web DAD / CESI compose d'un backend Go et d'un frontend Angular.

## Stack actuelle

Backend :

- Go
- Gin pour les routes HTTP
- GORM pour l'acces PostgreSQL
- PostgreSQL avec schemas separes par domaine
- JWT HMAC pour l'authentification
- bcrypt pour le hash des mots de passe
- Docker Compose pour l'environnement de dev

Frontend :

- Angular
- TypeScript
- CSS

## Architecture backend

Le backend est organise comme un monorepo Go avec plusieurs executables :

- `backend/cmd/api-gateway` : point d'entree HTTP public
- `backend/cmd/auth-service` : inscription, connexion, sessions, refresh tokens
- `backend/cmd/user-service` : relations sociales et notifications
- `backend/cmd/profile-service` : profils et preferences
- `backend/cmd/post-service` : posts, medias, likes et tags

Le code partage et le code metier vivent dans `backend/internal` :

- `internal/auth` : domaine auth, routes, handlers, service et repository
- `internal/config` : lecture de configuration
- `internal/db` : connexion PostgreSQL/GORM
- `internal/middleware` : middlewares HTTP partages, par exemple verification JWT
- `internal/models` : modeles GORM separes par domaine
- `internal/security` : signature et verification des JWT
- `internal/server` : demarrage HTTP commun

Quand un service gagne de la logique metier, il doit avoir son package dedie
dans `internal`, sur le meme modele que `internal/auth`. Par exemple :
`internal/posts`, `internal/profiles`, `internal/users`.

## Demarrer le backend

```bash
cd backend
copy .env.example .env
docker compose up --build
```

Interfaces utiles :

- API gateway : http://localhost:8080
- Healthcheck gateway : http://localhost:8080/health
- Adminer PostgreSQL : http://localhost:8081

Les services internes ne sont pas exposes directement sur la machine. Ils
communiquent via le reseau Docker `breezy-net`.

## Commandes backend utiles

```bash
cd backend
go run ./cmd/api-gateway
go run ./cmd/auth-service
go run ./cmd/user-service
go run ./cmd/profile-service
go run ./cmd/post-service
go test ./...
```

## Demarrer le frontend

```bash
cd frontend
npm install
npm run start
```
