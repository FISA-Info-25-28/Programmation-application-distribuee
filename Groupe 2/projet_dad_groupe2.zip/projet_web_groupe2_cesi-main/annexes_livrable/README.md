# Annexes du livrable — Breezy (DAD / CESI)

Ce dossier contient toutes les annexes techniques complémentaires au rapport principal.

| Fichier | Contenu |
|---------|---------|
| [annexe_A_endpoints.md](annexe_A_endpoints.md) | Liste exhaustive des endpoints REST par service (9 services, ~60 routes) |
| [annexe_B_schema_SQL.md](annexe_B_schema_SQL.md) | Schéma SQL complet : DDL PostgreSQL, ENUMs, FK, index, triggers, ERD |
| [annexe_C_captures.md](annexe_C_captures.md) | Captures d'écran commentées des 11 pages principales de l'application |
| [annexe_D_configuration.md](annexe_D_configuration.md) | Extraits de configuration : docker-compose.yml, .env.example, nginx.conf, ci-cd.yml |
| [annexe_E_frontend.md](annexe_E_frontend.md) | Détail du frontend Angular : 16 pages, 25 composants, 18 services |
| [annexe_F_glossaire.md](annexe_F_glossaire.md) | Glossaire technique (30 termes) et métadonnées du dépôt (272 fichiers, 416 commits) |
| [captures/](captures/) | Images PNG — 11 captures plein écran (1440×900, Chromium headless) |

