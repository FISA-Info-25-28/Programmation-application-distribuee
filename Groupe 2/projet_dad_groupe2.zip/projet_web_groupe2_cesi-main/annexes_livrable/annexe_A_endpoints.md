# Annexe A — Liste exhaustive des endpoints par service

> Tous les endpoints sont accessibles via le gateway (`http://localhost:8080/api/…`).
> Les routes protégées exigent un header `Authorization: Bearer <access_token>` (JWT HS256, TTL 5 min).
> RBAC : USER(1) < MODERATOR(2) < ADMIN(3).

---

## A.1 — auth-service (port 4001)

| Méthode | Route | Auth requise | Rôle min. | Description |
|---------|-------|-------------|-----------|-------------|
| POST | `/api/auth/register` | Non | — | Création de compte (email + password) |
| POST | `/api/auth/login` | Non | — | Login → access token (5 min) + refresh token (30 j) |
| POST | `/api/auth/refresh` | Non | — | Rotation du refresh token → nouveau pair |
| POST | `/api/auth/logout` | Oui | USER | Révocation de la session courante |
| GET | `/api/auth/me` | Oui | USER | Informations du compte courant (id, email, rôle) |
| POST | `/api/auth/verify-email` | Non | — | Validation de l'adresse e-mail via token |
| GET | `/api/auth/health` | Non | — | Health check du service |

---

## A.2 — user-service (port 4002)

| Méthode | Route | Auth requise | Rôle min. | Description |
|---------|-------|-------------|-----------|-------------|
| POST | `/api/users/{id}/follow` | Oui | USER | Suivre un utilisateur (ou envoyer une demande si profil privé) |
| DELETE | `/api/users/{id}/follow` | Oui | USER | Se désabonner |
| GET | `/api/users/{id}/followers` | Oui | USER | Liste des abonnés |
| GET | `/api/users/{id}/following` | Oui | USER | Liste des abonnements |
| GET | `/api/users/{id}/follow-status` | Oui | USER | Statut de la relation (none / following / requested) |
| GET | `/api/users/follow-requests` | Oui | USER | Demandes de suivi reçues |
| POST | `/api/users/follow-requests/{id}/accept` | Oui | USER | Accepter une demande de suivi |
| DELETE | `/api/users/follow-requests/{id}` | Oui | USER | Refuser / annuler une demande |
| GET | `/api/users/notifications` | Oui | USER | Notifications de l'utilisateur connecté |
| PATCH | `/api/users/notifications/{id}/read` | Oui | USER | Marquer une notification comme lue |
| POST | `/api/users/notifications/read-all` | Oui | USER | Tout marquer comme lu |
| GET | `/api/users/health` | Non | — | Health check |

---

## A.3 — profile-service (port 4003)

| Méthode | Route | Auth requise | Rôle min. | Description |
|---------|-------|-------------|-----------|-------------|
| GET | `/api/profiles/{username}` | Non | — | Profil public par username |
| GET | `/api/profiles/me` | Oui | USER | Profil de l'utilisateur connecté |
| PATCH | `/api/profiles/me` | Oui | USER | Mise à jour du profil (bio, display_name, avatar, banner) |
| PUT | `/api/profiles/me/public-key` | Oui | USER | Enregistrement de la clé publique X25519 (base64, 32 octets) |
| GET | `/api/profiles/{username}/public-key` | Oui | USER | Clé publique d'un utilisateur (pour chiffrement E2E) |
| PATCH | `/api/profiles/me/preferences` | Oui | USER | Mise à jour des préférences (locale, thème) |
| GET | `/api/profiles/me/preferences` | Oui | USER | Lecture des préférences |
| PATCH | `/api/profiles/me/privacy` | Oui | USER | Basculer profil public / privé |
| GET | `/api/profiles/search` | Non | — | Recherche de profils par username (query param `q`) |
| GET | `/api/profiles/health` | Non | — | Health check |

---

## A.4 — post-service (port 4004)

| Méthode | Route | Auth requise | Rôle min. | Description |
|---------|-------|-------------|-----------|-------------|
| POST | `/api/posts` | Oui | USER | Créer un post (max 280 car.) ou une réponse (`parent_id`) |
| GET | `/api/posts/feed` | Oui | USER | Fil des abonnements (posts des comptes suivis) |
| GET | `/api/posts/explore` | Non | — | Posts publics récents (découverte) |
| GET | `/api/posts/{id}` | Non | — | Détail d'un post (avec thread de réponses) |
| DELETE | `/api/posts/{id}` | Oui | USER | Supprimer son post (soft delete) |
| POST | `/api/posts/{id}/like` | Oui | USER | Liker un post |
| DELETE | `/api/posts/{id}/like` | Oui | USER | Retirer son like |
| POST | `/api/posts/{id}/repost` | Oui | USER | Reposter |
| DELETE | `/api/posts/{id}/repost` | Oui | USER | Annuler un repost |
| GET | `/api/posts/{id}/replies` | Non | — | Réponses directes à un post |
| GET | `/api/posts/user/{username}` | Non | — | Posts publics d'un utilisateur |
| GET | `/api/posts/tags/{tag}` | Non | — | Posts par hashtag |
| GET | `/api/posts/search` | Non | — | Recherche full-text dans les posts |
| GET | `/api/posts/bookmarks` | Oui | USER | Posts sauvegardés (marque-pages) |
| POST | `/api/posts/{id}/bookmark` | Oui | USER | Ajouter aux marque-pages |
| DELETE | `/api/posts/{id}/bookmark` | Oui | USER | Retirer des marque-pages |
| GET | `/api/posts/health` | Non | — | Health check |

---

## A.5 — media-service (port 4005)

| Méthode | Route | Auth requise | Rôle min. | Description |
|---------|-------|-------------|-----------|-------------|
| POST | `/api/media/upload` | Oui | USER | Upload d'image / vidéo (multipart/form-data), retourne l'URL |
| GET | `/api/media/{id}` | Non | — | Accès à un média par identifiant |
| DELETE | `/api/media/{id}` | Oui | USER | Suppression d'un média (propriétaire ou admin) |
| GET | `/api/media/health` | Non | — | Health check |

---

## A.6 — messages-service (port 4006)

| Méthode | Route | Auth requise | Rôle min. | Description |
|---------|-------|-------------|-----------|-------------|
| GET | `/api/messages/conversations` | Oui | USER | Liste des conversations de l'utilisateur |
| POST | `/api/messages/conversations` | Oui | USER | Créer / récupérer une conversation avec un utilisateur |
| GET | `/api/messages/conversations/{id}/messages` | Oui | USER | Messages d'une conversation (chiffrés, opaques au serveur) |
| POST | `/api/messages/conversations/{id}/messages` | Oui | USER | Envoyer un message chiffré (content + nonce en base64) |
| DELETE | `/api/messages/messages/{id}` | Oui | USER | Supprimer un message (soft delete) |
| PATCH | `/api/messages/conversations/{id}/read` | Oui | USER | Marquer la conversation comme lue |
| POST | `/api/messages/messages/{id}/react` | Oui | USER | Réagir à un message (emoji HEART) |
| GET | `/api/messages/health` | Non | — | Health check |

---

## A.7 — moderation-service (port 4007)

| Méthode | Route | Auth requise | Rôle min. | Description |
|---------|-------|-------------|-----------|-------------|
| POST | `/api/moderation/reports` | Oui | USER | Signaler un post ou un utilisateur |
| GET | `/api/moderation/reports` | Oui | MODERATOR | Liste des signalements (filtrable par statut) |
| PATCH | `/api/moderation/reports/{id}` | Oui | MODERATOR | Mettre à jour le statut d'un signalement |
| POST | `/api/moderation/users/{id}/suspend` | Oui | MODERATOR | Suspendre un compte temporairement |
| POST | `/api/moderation/users/{id}/ban` | Oui | ADMIN | Bannir définitivement un compte |
| POST | `/api/moderation/users/{id}/unsuspend` | Oui | MODERATOR | Lever une suspension |
| POST | `/api/moderation/posts/{id}/hide` | Oui | MODERATOR | Forcer un post en PRIVATE |
| POST | `/api/moderation/posts/{id}/restore` | Oui | MODERATOR | Restaurer la visibilité d'origine |
| GET | `/api/moderation/health` | Non | — | Health check |

---

## A.8 — social-service (port 4008)

| Méthode | Route | Auth requise | Rôle min. | Description |
|---------|-------|-------------|-----------|-------------|
| GET | `/api/social/suggestions` | Oui | USER | Suggestions de comptes à suivre |
| GET | `/api/social/trending` | Non | — | Tags et posts tendances |
| GET | `/api/social/health` | Non | — | Health check |

---

## A.9 — api-gateway (port 8080)

| Route | Description |
|-------|-------------|
| `/api/**` | Reverse-proxy vers le service compétent (basé sur le préfixe) |
| `/health` | Health check global du gateway |

**Rate limiting (Token Bucket) :**

| Scope | Limite | Fenêtre | Code retour |
|-------|--------|---------|-------------|
| Global (toutes routes) | 100 req | 1 min / IP | HTTP 429 |
| Auth (`/api/auth/*`) | 10 req | 1 min / IP | HTTP 429 |
