# Annexe B — Schéma SQL / ERD complet

> PostgreSQL 16 · 6 schémas logiques · 1 instance unique
> Migrations appliquées dans l'ordre : 001 → 007

---

## B.1 — ERD (diagramme entité-relation)

![ERD Breezy](../docs/erd_breezy.png)

> Le diagramme a été généré depuis `schema.dbml` via [dbdiagram.io](https://dbdiagram.io).
> Il est reproduit à la page 39 du livrable principal.

---

## B.2 — Extensions et schémas

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto; -- gen_random_uuid() natif PG13+

CREATE SCHEMA IF NOT EXISTS auth;
CREATE SCHEMA IF NOT EXISTS profiles;
CREATE SCHEMA IF NOT EXISTS social;
CREATE SCHEMA IF NOT EXISTS posts;
CREATE SCHEMA IF NOT EXISTS messages;
CREATE SCHEMA IF NOT EXISTS moderation;
```

---

## B.3 — Types ENUM

```sql
CREATE TYPE auth.user_role           AS ENUM ('USER', 'MODERATOR', 'ADMIN');
CREATE TYPE auth.account_status      AS ENUM ('ACTIVE', 'SUSPENDED', 'BANNED');
CREATE TYPE social.notification_type AS ENUM (
  'LIKE', 'FOLLOW', 'FOLLOW_REQUEST', 'REPLY', 'MENTION', 'MODERATION_REPORT'
);
CREATE TYPE posts.media_type         AS ENUM ('IMAGE', 'VIDEO');
CREATE TYPE posts.post_visibility    AS ENUM ('PUBLIC', 'FOLLOWERS', 'PRIVATE');
CREATE TYPE moderation.report_status AS ENUM ('PENDING', 'REVIEWED', 'RESOLVED', 'REJECTED');
```

---

## B.4 — Tables par schéma

### Schéma `auth`

```sql
CREATE TABLE auth.accounts (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  email             text        NOT NULL UNIQUE,
  password_hash     text        NOT NULL,               -- bcrypt DefaultCost
  role              auth.user_role NOT NULL DEFAULT 'USER',
  status            auth.account_status NOT NULL DEFAULT 'ACTIVE',
  suspended_until   timestamptz,
  email_verified_at timestamptz,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE auth.sessions (
  id                 uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id         uuid        NOT NULL REFERENCES auth.accounts(id) ON DELETE CASCADE,
  refresh_token_hash text        NOT NULL,               -- SHA-256 du refresh token
  expires_at         timestamptz NOT NULL,               -- now() + 30 jours
  revoked_at         timestamptz,
  created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE auth.email_verification_tokens (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id  uuid        NOT NULL REFERENCES auth.accounts(id) ON DELETE CASCADE,
  token_hash  text        NOT NULL,
  expires_at  timestamptz NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
```

### Schéma `profiles`

```sql
CREATE TABLE profiles.profiles (
  id                    uuid    PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id            uuid    NOT NULL UNIQUE REFERENCES auth.accounts(id) ON DELETE CASCADE,
  username              text    NOT NULL UNIQUE,
  display_name          text,
  bio                   text,
  avatar_url            text,
  banner_url            text,                            -- migration 002
  is_private            boolean NOT NULL DEFAULT false,  -- migration 003
  public_key            text,                            -- migration 006 : X25519 base64 32 octets
  original_username     text,                            -- mémorisé pendant anonymisation sanction
  original_display_name text,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE profiles.preferences (
  profile_id uuid PRIMARY KEY REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  locale     text NOT NULL DEFAULT 'fr'   CHECK (locale IN ('fr', 'en')),
  theme      text NOT NULL DEFAULT 'light' CHECK (theme IN ('system', 'light', 'dark')),
  updated_at timestamptz NOT NULL DEFAULT now()
);
```

### Schéma `social`

```sql
CREATE TABLE social.follows (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid        NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  followed_id uuid        NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  created_at  timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT follows_no_self CHECK (follower_id <> followed_id),
  CONSTRAINT follows_unique  UNIQUE (follower_id, followed_id)
);
CREATE INDEX idx_follows_followed ON social.follows (followed_id);

CREATE TABLE social.follow_requests (                   -- migration 004
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid        NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  target_id    uuid        NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  created_at   timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT follow_requests_no_self   CHECK (requester_id <> target_id),
  CONSTRAINT follow_requests_unique    UNIQUE (requester_id, target_id)
);
CREATE INDEX idx_follow_requests_target ON social.follow_requests (target_id);

CREATE TABLE social.notifications (
  id           uuid                     PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id uuid                     NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  actor_id     uuid                     NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  type         social.notification_type NOT NULL,
  post_id      uuid                     REFERENCES posts.posts(id) ON DELETE CASCADE,
  is_read      boolean                  NOT NULL DEFAULT false,
  created_at   timestamptz              NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_recipient ON social.notifications (recipient_id, created_at);
```

### Schéma `posts`

```sql
CREATE TABLE posts.posts (
  id                  uuid                   PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id           uuid                   NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  content             varchar(280)           NOT NULL,
  parent_id           uuid                   REFERENCES posts.posts(id) ON DELETE CASCADE,
  visibility          posts.post_visibility  NOT NULL DEFAULT 'PUBLIC',
  original_visibility text,                             -- mémorisé pendant masquage par modération
  created_at          timestamptz            NOT NULL DEFAULT now(),
  updated_at          timestamptz            NOT NULL DEFAULT now(),
  deleted_at          timestamptz                       -- soft delete
);
CREATE INDEX idx_posts_author_created ON posts.posts (author_id, created_at);
CREATE INDEX idx_posts_parent         ON posts.posts (parent_id);

CREATE TABLE posts.media (
  id         uuid            PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    uuid            NOT NULL REFERENCES posts.posts(id) ON DELETE CASCADE,
  media_type posts.media_type NOT NULL,
  url        text            NOT NULL,
  created_at timestamptz     NOT NULL DEFAULT now()
);

CREATE TABLE posts.likes (
  id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    uuid        NOT NULL REFERENCES posts.posts(id) ON DELETE CASCADE,
  user_id    uuid        NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT likes_unique UNIQUE (post_id, user_id)
);
CREATE INDEX idx_likes_user ON posts.likes (user_id);

CREATE TABLE posts.reposts (                            -- migration 002_add_reposts
  id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    uuid        NOT NULL REFERENCES posts.posts(id) ON DELETE CASCADE,
  user_id    uuid        NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT reposts_unique UNIQUE (post_id, user_id)
);
CREATE INDEX idx_reposts_user ON posts.reposts (user_id);

CREATE TABLE posts.tags (
  id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text        NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE posts.post_tags (
  post_id uuid NOT NULL REFERENCES posts.posts(id) ON DELETE CASCADE,
  tag_id  uuid NOT NULL REFERENCES posts.tags(id) ON DELETE CASCADE,
  PRIMARY KEY (post_id, tag_id)
);
```

### Schéma `messages`

```sql
CREATE TABLE messages.conversations (
  id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE messages.members (
  conversation_id uuid        NOT NULL REFERENCES messages.conversations(id) ON DELETE CASCADE,
  profile_id      uuid        NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  last_read_at    timestamptz,
  PRIMARY KEY (conversation_id, profile_id)
);

CREATE TABLE messages.private_messages (
  id              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid        NOT NULL REFERENCES messages.conversations(id) ON DELETE CASCADE,
  sender_id       uuid        NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  content         text        NOT NULL,    -- ciphertext NaCl box (base64), opaque au serveur
  nonce           text        NOT NULL DEFAULT '', -- migration 007 : nonce NaCl (base64)
  kind            text        NOT NULL DEFAULT 'TEXT', -- migration 007 : 'TEXT' | 'IMAGE' | ...
  media_url       text,
  media_type      text        CHECK (media_type IN ('IMAGE', 'VIDEO')),
  reply_to_id     uuid        REFERENCES messages.private_messages(id) ON DELETE SET NULL,
  created_at      timestamptz NOT NULL DEFAULT now(),
  edited_at       timestamptz,
  deleted_at      timestamptz
);
CREATE INDEX idx_pm_conversation_created ON messages.private_messages (conversation_id, created_at);
CREATE INDEX idx_pm_deleted              ON messages.private_messages (deleted_at);

CREATE TABLE messages.message_likes (                   -- migration 005
  message_id uuid        NOT NULL REFERENCES messages.private_messages(id) ON DELETE CASCADE,
  user_id    uuid        NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  reaction   text        NOT NULL DEFAULT 'HEART',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, user_id)
);

CREATE TABLE messages.message_preferences (             -- migration 005
  profile_id uuid        PRIMARY KEY REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  retention  text        NOT NULL DEFAULT 'forever'
             CHECK (retention IN ('forever','1h','2h','3h','1d','7d','30d')),
  updated_at timestamptz NOT NULL DEFAULT now()
);
```

### Schéma `moderation`

```sql
CREATE TABLE moderation.reports (
  id               uuid                      PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id      uuid                      NOT NULL REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  reported_post_id uuid                      REFERENCES posts.posts(id) ON DELETE SET NULL,
  reported_user_id uuid                      REFERENCES profiles.profiles(id) ON DELETE SET NULL,
  reason           text                      NOT NULL,
  status           moderation.report_status  NOT NULL DEFAULT 'PENDING',
  reviewed_by      uuid                      REFERENCES profiles.profiles(id) ON DELETE SET NULL,
  reviewed_at      timestamptz,
  created_at       timestamptz               NOT NULL DEFAULT now(),
  CONSTRAINT reports_target_check CHECK (reported_post_id IS NOT NULL OR reported_user_id IS NOT NULL)
);
```

---

## B.5 — Trigger `set_updated_at()`

```sql
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Déclencheurs appliqués automatiquement sur toutes les tables avec updated_at
CREATE TRIGGER trg_accounts_updated
  BEFORE UPDATE ON auth.accounts FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_profiles_updated
  BEFORE UPDATE ON profiles.profiles FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_preferences_updated
  BEFORE UPDATE ON profiles.preferences FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_posts_updated
  BEFORE UPDATE ON posts.posts FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_conversations_updated
  BEFORE UPDATE ON messages.conversations FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_message_preferences_updated
  BEFORE UPDATE ON messages.message_preferences FOR EACH ROW EXECUTE FUNCTION set_updated_at();
```

---

## B.6 — Récapitulatif des migrations

| Fichier | Contenu |
|---------|---------|
| `001_init.sql` | Création complète de tous les schémas, ENUMs, tables, FK, index et trigger |
| `002_profile_banner.sql` | Ajout de `banner_url` dans `profiles.profiles` |
| `002_add_reposts.sql` | Création de la table `posts.reposts` |
| `003_profile_privacy.sql` | Ajout de `is_private` dans `profiles.profiles` |
| `003_add_sanction_columns.sql` | Colonnes `original_username`, `original_display_name`, `original_visibility` pour le masquage de modération |
| `004_follow_requests.sql` | Table `social.follow_requests` + valeur ENUM `FOLLOW_REQUEST` |
| `005_message_interactions.sql` | Tables `message_likes` et `message_preferences` |
| `006_profile_public_key.sql` | Colonne `public_key` (X25519 base64) dans `profiles.profiles` |
| `007_messages_e2e.sql` | Colonnes `nonce` et `kind` dans `messages.private_messages` |
