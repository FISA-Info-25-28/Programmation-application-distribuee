# Annexe C — Captures d'écran de l'application

> Toutes les captures ont été prises via Playwright (Chromium headless 1440×900)
> sur le stack Docker en fonctionnement (`docker compose up`).
> Compte utilisé : `admin@breezy.demo` / `Demo1234!` (rôle ADMIN).

---

## C.1 — Page d'authentification

![Page d'authentification](captures/01_auth.png)

Page de connexion / inscription. Formulaire email + mot de passe avec validation côté client (Angular Reactive Forms). Lien de bascule inscription ↔ connexion. Design épuré, fond clair avec le logo Breezy.

---

## C.2 — Fil d'actualité (Feed)

![Feed principal](captures/02_feed.png)

Fil des abonnements de l'utilisateur connecté. Affiche les posts des comptes suivis par ordre chronologique inversé. Chaque carte de post indique : avatar, nom d'affichage, username, horodatage, contenu (max 280 car.), compteurs like / réponse / repost, actions rapides.

---

## C.3 — Détail d'un post

![Détail d'un post](captures/03_post_detail.png)

Vue détaillée d'un post avec son thread de réponses imbriquées. Permet de répondre directement depuis la page. Les réponses aux réponses sont affichées de manière récursive (arbre de commentaires).

---

## C.4 — Page de profil

![Page profil](captures/04_profil.png)

Profil d'un utilisateur : photo de couverture (banner), avatar, nom d'affichage, username, bio, compteurs abonnés / abonnements. Onglets : Posts / Réponses / Médias / Marque-pages (si profil propre). Bouton Suivre / Suivi / Demande envoyée selon le statut de la relation.

---

## C.5 — Messagerie privée

![Messagerie](captures/05_messagerie.png)

Interface de messagerie privée end-to-end chiffrée. Liste des conversations à gauche, messages de la conversation sélectionnée à droite. Les messages sont chiffrés côté client (NaCl box, Curve25519) avant envoi ; le serveur stocke uniquement le ciphertext et le nonce.

---

## C.6 — Notifications

![Notifications](captures/06_notifications.png)

Centre de notifications : likes, nouveaux abonnés, demandes de suivi (comptes privés), réponses à ses posts, mentions. Chaque notification indique l'acteur, le type d'événement et l'horodatage. Bouton « Tout marquer comme lu ».

---

## C.7 — Marque-pages

![Marque-pages](captures/07_bookmarks.png)

Liste des posts sauvegardés par l'utilisateur (marque-pages). Fonctionnement identique au feed mais limité aux posts épinglés. Suppression individuelle possible.

---

## C.8 — Modération

![Panneau de modération](captures/08_moderation.png)

Panneau de modération (accessible aux rôles MODERATOR et ADMIN). Liste des signalements avec filtres par statut (PENDING / REVIEWED / RESOLVED / REJECTED). Actions disponibles : examiner, résoudre, rejeter, suspendre l'utilisateur ou masquer le post.

---

## C.9 — Administration

![Panneau d'administration](captures/09_administration.png)

Panneau d'administration (rôle ADMIN uniquement). Gestion des comptes : liste de tous les utilisateurs, modification de rôle (USER → MODERATOR → ADMIN), bannissement définitif, levée de sanctions.

---

## C.10 — Paramètres

![Paramètres](captures/10_settings.png)

Page de paramètres de l'utilisateur connecté : mise à jour du profil (bio, display_name, avatar, bannière), préférences (thème clair/sombre/système, langue fr/en), confidentialité du compte (public / privé), gestion de la clé de chiffrement E2E.

---

## C.11 — Recherche

![Recherche](captures/11_search.png)

Page de recherche globale. Onglets : Utilisateurs (recherche par username) / Posts (recherche full-text dans le contenu) / Tags (hashtags). Résultats paginés, affichage de cartes identiques au feed.
