# Annexe D — Extraits de configuration

> Fichiers présentés dans leur intégralité ou légèrement annotés.
> Tous les secrets sont remplacés par `CHANGE_ME_*` dans `.env.example`.
> Le `.env` réel n'est jamais commité (listé dans `.gitignore`).

---

## D.1 — `docker-compose.yml`

Architecture de déploiement local : 11 services, 1 réseau `breezy-net`, 2 volumes persistants.

```yaml
# docker-compose.yml — Breezy (racine du repo)
# Usage : cp .env.example .env && docker compose up --build
#
# Ports publiés :
#   http://localhost       → frontend Angular  (port 80)
#   https://localhost:8080 → api-gateway        (API REST)
#   http://localhost:8081  → Adminer            (GUI Postgres)
#   http://localhost:8025  → Mailpit            (SMTP de dev)
#
# NE PAS publier les ports internes (4001-4007).
# Les services se parlent par nom Docker : auth-service:4001, etc.

services:

  # ── Base de données ──────────────────────────────────────────
  postgres:
    image: postgres:16-alpine
    container_name: breezy-postgres
    restart: unless-stopped
    environment:
      POSTGRES_USER: ${POSTGRES_USER}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: ${POSTGRES_DB}
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./backend/migrations:/docker-entrypoint-initdb.d:ro  # migrations auto au 1er démarrage
    networks:
      - breezy-net
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}"]
      interval: 10s
      timeout: 5s
      retries: 5

  adminer:
    image: adminer:latest
    container_name: breezy-adminer
    restart: unless-stopped
    depends_on:
      postgres:
        condition: service_healthy
    ports:
      - "8081:8080"
    networks:
      - breezy-net

  mailpit:                          # Serveur SMTP de dev — capture les e-mails sans les envoyer
    image: axllent/mailpit:latest
    container_name: breezy-mailpit
    restart: unless-stopped
    ports:
      - "8025:8025"                 # UI web Mailpit
    expose:
      - "1025"                      # SMTP interne (réseau Docker uniquement)
    networks:
      - breezy-net

  # ── Services Go — image partagée breezy-backend:latest ──────
  # Docker Compose construit l'image une seule fois et la réutilise.
  # Chaque service se distingue uniquement par la valeur de `command`.

  auth-service:
    build:
      context: ./backend
      dockerfile: Dockerfile
    image: breezy-backend:latest
    container_name: breezy-auth-service
    command: ./auth-service
    restart: unless-stopped
    depends_on:
      postgres:
        condition: service_healthy
    environment:
      PORT: "4001"
      DATABASE_URL: "postgres://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres:5432/${POSTGRES_DB}?search_path=auth&sslmode=disable"
      JWT_SECRET: ${JWT_SECRET}
      CORS_ORIGIN: ${CORS_ORIGIN}
      SEED_DEMO_ACCOUNTS: ${SEED_DEMO_ACCOUNTS:-true}
      SMTP_HOST: ${SMTP_HOST:-mailpit}
      SMTP_PORT: ${SMTP_PORT:-1025}
      SMTP_FROM: ${SMTP_FROM:-no-reply@breezy.local}
    expose:
      - "4001"
    networks:
      - breezy-net
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:4001/health"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 15s

  # user-service, profile-service, post-service, messages-service,
  # social-service, moderation-service : même structure, ports 4002–4007,
  # DATABASE_URL avec search_path propre à chaque schéma.

  media-service:
    build:
      context: ./backend
      dockerfile: Dockerfile
    image: breezy-backend:latest
    container_name: breezy-media-service
    command: ./media-service
    restart: unless-stopped
    environment:
      PORT: "4005"
      JWT_SECRET: ${JWT_SECRET}
      UPLOAD_DIR: /data/uploads
      MEDIA_BASE_URL: ${MEDIA_BASE_URL:-http://localhost:8080/api/media}
    volumes:
      - uploads:/data/uploads       # Pas de DB : stockage sur volume Docker
    expose:
      - "4005"
    networks:
      - breezy-net
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:4005/health"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 15s

  api-gateway:
    build:
      context: ./backend
      dockerfile: Dockerfile
    image: breezy-backend:latest
    container_name: breezy-api-gateway
    command: ./api-gateway
    restart: unless-stopped
    depends_on:                     # Attend que TOUS les services soient healthy
      auth-service:      { condition: service_healthy }
      user-service:      { condition: service_healthy }
      profile-service:   { condition: service_healthy }
      post-service:      { condition: service_healthy }
      media-service:     { condition: service_healthy }
      moderation-service:{ condition: service_healthy }
      messages-service:  { condition: service_healthy }
      social-service:    { condition: service_healthy }
    environment:
      PORT: "8080"
      JWT_SECRET: ${JWT_SECRET}
      CORS_ORIGIN: ${CORS_ORIGIN}
      AUTH_SERVICE_URL:       http://auth-service:4001
      USER_SERVICE_URL:       http://user-service:4002
      PROFILE_SERVICE_URL:    http://profile-service:4003
      POST_SERVICE_URL:       http://post-service:4004
      MEDIA_SERVICE_URL:      http://media-service:4005
      MODERATION_SERVICE_URL: http://moderation-service:4005
      MESSAGES_SERVICE_URL:   http://messages-service:4006
      SOCIAL_SERVICE_URL:     http://social-service:4007
      TLS_CERT_FILE: ${TLS_CERT_FILE:-}   # Optionnel — laisser vide en dev local
      TLS_KEY_FILE:  ${TLS_KEY_FILE:-}
    volumes:
      - ./certs:/certs:ro
    ports:
      - "8080:8080"
    networks:
      - breezy-net
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:8080/health"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 20s

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: breezy-frontend
    restart: unless-stopped
    depends_on:
      api-gateway:
        condition: service_healthy
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - /etc/letsencrypt:/etc/letsencrypt:ro
    networks:
      - breezy-net

# ── Volumes persistants ────────────────────────────────────────
volumes:
  pgdata:    # Données PostgreSQL
  uploads:   # Photos de profil et médias de posts

# ── Réseau interne ─────────────────────────────────────────────
networks:
  breezy-net:
    driver: bridge
```

---

## D.2 — `.env.example`

```bash
# ──────────────────────────────────────────────────────────────
# Breezy — variables d'environnement
# Usage : cp .env.example .env  puis éditer les valeurs CHANGE_ME
# ──────────────────────────────────────────────────────────────

# Base de données PostgreSQL
POSTGRES_DB=breezy
POSTGRES_USER=breezy_user
POSTGRES_PASSWORD=CHANGE_ME_strong_password

# JWT — clé de signature HS256 (min. 32 caractères, garder secrète)
JWT_SECRET=CHANGE_ME_at_least_32_random_characters_here

# CORS — URL publique du frontend vue depuis le navigateur
# En dev Docker local : http://localhost
# En prod / VPS       : https://mondomaine.fr
CORS_ORIGIN=http://localhost

# Comptes de démo seedés au démarrage de auth-service
# true  → crée admin@breezy.demo / moderator@breezy.demo / user@breezy.demo (mot de passe : Demo1234!)
# false → aucun seed (recommandé en production)
SEED_DEMO_ACCOUNTS=true

# URL publique de base pour les fichiers uploadés
# En dev Docker local : http://localhost:8080/api/media
MEDIA_BASE_URL=http://localhost:8080/api/media

# URL publique du frontend utilisée dans les liens d'e-mail
FRONTEND_PUBLIC_URL=http://localhost

# SMTP de développement (Mailpit capte les e-mails sans les envoyer)
SMTP_ENABLED=true
SMTP_HOST=mailpit
SMTP_PORT=1025
SMTP_USERNAME=
SMTP_PASSWORD=
SMTP_FROM=no-reply@breezy.local
SUPPORT_EMAIL=supportbreezy@googlegroups.com

# TLS de l'api-gateway (optionnel — laisser vide en dev local)
# En dev local, nginx parle à la gateway en HTTP interne → laisser vide.
# Pour tester https://localhost:8080 directement : générer les certs
# (./certs/generate-dev-cert.sh) puis décommenter :
# TLS_CERT_FILE=/certs/gateway.crt
# TLS_KEY_FILE=/certs/gateway.key

# OAuth Google (optionnel — laisser vide pour désactiver)
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_REDIRECT_URL=http://localhost:8080/api/auth/google/callback

# OAuth GitHub (optionnel — laisser vide pour désactiver)
GITHUB_CLIENT_ID=
GITHUB_CLIENT_SECRET=
```

---

## D.3 — `frontend/nginx.conf` (production)

Nginx sert le frontend Angular et proxifie `/api/*` vers le gateway sur le réseau Docker interne.
En production, il écoute sur le port 443 avec un certificat Let's Encrypt.

```nginx
# Redirection HTTP → HTTPS
server {
    listen 80;
    server_name breezy.allanbouhamed.fr;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name breezy.allanbouhamed.fr;
    client_max_body_size 101m;
    root /usr/share/nginx/html;
    index index.csr.html;
    resolver 127.0.0.11 valid=10s ipv6=off;   # Résolveur DNS interne Docker

    # TLS Let's Encrypt
    ssl_certificate     /etc/letsencrypt/live/breezy.allanbouhamed.fr/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/breezy.allanbouhamed.fr/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;

    # Reverse-proxy vers l'api-gateway (HTTP interne, réseau Docker)
    location ^~ /api/ {
        set $api_gateway http://api-gateway:8080;
        proxy_pass $api_gateway$request_uri;
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-Proto https;
    }

    # SPA fallback — toutes les routes inconnues → Angular router
    location / {
        try_files $uri $uri/ /index.csr.html;
    }

    # Pas de cache sur le point d'entrée (évite de servir un ancien JS)
    location = /index.csr.html {
        add_header Cache-Control "no-cache, no-store, must-revalidate";
    }

    # Cache agressif sur les assets hachés (JS/CSS/fonts/images)
    location ~* \.(js|css|woff2?|ttf|eot|svg|png|ico|webp)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

### `frontend/nginx.local.conf` (développement local)

Version sans TLS, utilisée par `docker-compose.override.yml` en local.

```nginx
server {
    listen 80;
    client_max_body_size 101m;
    root /usr/share/nginx/html;
    index index.csr.html;
    resolver 127.0.0.11 valid=10s ipv6=off;

    location ^~ /api/ {
        set $api_gateway http://api-gateway:8080;
        proxy_pass $api_gateway$request_uri;
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-Proto http;
    }

    location / {
        try_files $uri $uri/ /index.csr.html;
    }

    location = /index.csr.html {
        add_header Cache-Control "no-cache, no-store, must-revalidate";
    }

    location ~* \.(js|css|woff2?|ttf|eot|svg|png|gif|ico|webp)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

---

## D.4 — `.github/workflows/ci-cd.yml`

Pipeline GitHub Actions en 5 phases, déclenchée sur chaque PR et push vers `develop`.

```yaml
name: CI/CD — Breezy

on:
  pull_request:
    branches: [develop]
  push:
    branches: [develop]

jobs:

  # ── Phase 1 : Qualité du code ──────────────────────────────
  go-format:
    name: "① gofmt + go vet"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-go@v5
        with:
          go-version-file: backend/go.mod
          cache-dependency-path: backend/go.sum
      - name: gofmt
        working-directory: backend
        run: |
          unformatted=$(gofmt -l .)
          if [ -n "$unformatted" ]; then echo "$unformatted"; exit 1; fi
      - name: go vet
        working-directory: backend
        run: go vet ./...

  lint-go:
    name: "① golangci-lint"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-go@v5
        with:
          go-version-file: backend/go.mod
      - uses: golangci/golangci-lint-action@v9
        with:
          version: v2.12
          working-directory: backend

  lint-angular:
    name: "① Lint Angular"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: "22", cache: npm, cache-dependency-path: frontend/package-lock.json }
      - run: npm ci
        working-directory: frontend
      - run: npm run lint
        working-directory: frontend

  # ── Phase 2 : Build ────────────────────────────────────────
  build-go:
    name: "② Build Go"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-go@v5
        with: { go-version-file: backend/go.mod }
      - run: go build ./...
        working-directory: backend

  build-angular:
    name: "② Build Angular"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: "22", cache: npm, cache-dependency-path: frontend/package-lock.json }
      - run: npm ci
        working-directory: frontend
      - run: npm run build -- --configuration production
        working-directory: frontend

  build-docker:
    name: "② Build images Docker"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: docker build ./backend  -t breezy-backend:ci
      - run: docker build ./frontend -t breezy-frontend:ci

  # ── Phase 3 : Tests ────────────────────────────────────────
  test-go:
    name: "③ Tests Go"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-go@v5
        with: { go-version-file: backend/go.mod }
      - run: go test ./... -v
        working-directory: backend

  test-angular:
    name: "③ Tests Angular"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: "22", cache: npm, cache-dependency-path: frontend/package-lock.json }
      - run: npm ci
        working-directory: frontend
      - run: npm run test -- --watch=false
        working-directory: frontend

  # ── Phase 4 : Sécurité ─────────────────────────────────────
  secrets-scan:
    name: "④ Scan secrets (gitleaks)"
    runs-on: ubuntu-latest
    permissions: { contents: read, pull-requests: read }
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - uses: gitleaks/gitleaks-action@v2
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          GITLEAKS_CONFIG: .gitleaks.toml

  npm-audit:
    name: "④ npm audit"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: "22", cache: npm, cache-dependency-path: frontend/package-lock.json }
      - run: npm ci
        working-directory: frontend
      - run: npm audit --audit-level=critical --omit=dev
        working-directory: frontend

  # ── Phase 5 : Push images (merge sur develop uniquement) ───
  docker-push:
    name: "⑤ Build & Push → GHCR"
    needs:
      - go-format
      - lint-go
      - lint-angular
      - build-go
      - build-angular
      - build-docker
      - test-go
      - test-angular
      - secrets-scan
      - npm-audit
    if: github.event_name == 'push' && github.ref == 'refs/heads/develop'
    runs-on: ubuntu-latest
    permissions: { contents: read, packages: write }
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with:
          registry: ghcr.io
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}
      - uses: docker/build-push-action@v5
        with:
          context: ./backend
          push: true
          tags: ghcr.io/${{ github.repository_owner }}/breezy-backend:latest
      - uses: docker/build-push-action@v5
        with:
          context: ./frontend
          push: true
          tags: ghcr.io/${{ github.repository_owner }}/breezy-frontend:latest
```

---

## D.5 — Récapitulatif des choix de configuration

| Choix | Valeur | Justification |
|-------|--------|---------------|
| Image Go | `golang:1.26-alpine` | Alpine = image minimale (~5 Mo), multi-stage build |
| Image Postgres | `postgres:16-alpine` | Version LTS, driver GORM stable |
| Réseau Docker | `bridge` nommé `breezy-net` | Isolation des conteneurs, résolution DNS par nom de service |
| Ports publiés | 80 (frontend), 8080 (gateway), 8081 (Adminer), 8025 (Mailpit) | Ports internes (4001-4007) jamais exposés |
| Health checks | `wget -qO- http://localhost:<port>/health` | Dépendances Docker en cascade (gateway attend tous les services) |
| Migrations | Montées en volume `docker-entrypoint-initdb.d` | Exécution automatique au 1er `docker compose up` |
| JWT TTL | Access : 5 min / Refresh : 30 jours | Compromis sécurité / UX (rotation transparente côté Angular) |
| Rate limiting | 100 req/min (global) · 10 req/min (`/api/auth/*`) | Protection brute-force sur l'auth, DoS léger sur les routes publiques |
| SMTP de dev | Mailpit | Capture les e-mails localement sans configuration externe |
| TLS en dev | Désactivé par défaut | Nginx (HTTP interne) → gateway ; TLS optionnel si test direct sur :8080 |
