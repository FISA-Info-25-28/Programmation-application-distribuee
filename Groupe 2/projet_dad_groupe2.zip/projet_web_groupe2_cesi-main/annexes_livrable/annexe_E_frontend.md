# Annexe E — Détail du frontend : pages, composants, services

> Framework : Angular 21 · Styles : Tailwind CSS · Rendu : SSR (Angular Universal)
> Internationalisation : i18n Angular (6 langues) · Tests E2E : Playwright

---

## E.1 — Pages (routes Angular)

| # | Route | Garde | Description |
|---|-------|-------|-------------|
| 1 | `/auth` | (public) | Page de connexion et d'inscription (toggle) |
| 2 | `/home/feed` | AuthGuard | Fil des abonnements |
| 3 | `/home/explore` | (public) | Posts publics – découverte |
| 4 | `/home/post/:id` | (public) | Détail d'un post + thread de réponses |
| 5 | `/home/profile/:username` | (public) | Profil public d'un utilisateur |
| 6 | `/home/messages` | AuthGuard | Liste des conversations |
| 7 | `/home/messages/:conversationId` | AuthGuard | Conversation E2E chiffrée |
| 8 | `/home/notifications` | AuthGuard | Centre de notifications |
| 9 | `/home/bookmarks` | AuthGuard | Posts sauvegardés (marque-pages) |
| 10 | `/home/search` | (public) | Recherche utilisateurs / posts / tags |
| 11 | `/home/settings` | AuthGuard | Paramètres du compte et du profil |
| 12 | `/home/settings/privacy` | AuthGuard | Confidentialité + clé E2E |
| 13 | `/home/settings/preferences` | AuthGuard | Thème et langue |
| 14 | `/home/moderation` | ModeratorGuard | Panneau de modération |
| 15 | `/home/administration` | AdminGuard | Gestion des utilisateurs (ADMIN) |
| 16 | `/404` | (public) | Page introuvable |

---

## E.2 — Composants

| # | Composant | Répertoire | Description |
|---|-----------|------------|-------------|
| 1 | `AppComponent` | `app/` | Racine Angular, gestion du thème global |
| 2 | `AuthComponent` | `pages/auth/` | Formulaire connexion/inscription avec bascule |
| 3 | `LoginFormComponent` | `pages/auth/components/` | Sous-formulaire connexion (email + password) |
| 4 | `RegisterFormComponent` | `pages/auth/components/` | Sous-formulaire inscription |
| 5 | `FeedComponent` | `pages/feed/` | Conteneur du fil d'actualité |
| 6 | `PostCardComponent` | `shared/post-card/` | Carte de post réutilisable (like, réponse, repost) |
| 7 | `PostDetailComponent` | `pages/post-detail/` | Vue détaillée + thread de réponses |
| 8 | `ReplyFormComponent` | `pages/post-detail/components/` | Formulaire de réponse à un post |
| 9 | `ProfileComponent` | `pages/profile/` | Page profil avec onglets |
| 10 | `ProfileHeaderComponent` | `pages/profile/components/` | Avatar, banner, bio, compteurs |
| 11 | `FollowButtonComponent` | `shared/follow-button/` | Bouton Suivre / Suivi / Demande envoyée |
| 12 | `MessagesListComponent` | `pages/messages/` | Liste des conversations |
| 13 | `ConversationComponent` | `pages/messages/conversation/` | Vue conversation + envoi de message chiffré |
| 14 | `NotificationsComponent` | `pages/notifications/` | Centre de notifications |
| 15 | `BookmarksComponent` | `pages/bookmarks/` | Liste des posts sauvegardés |
| 16 | `SearchComponent` | `pages/search/` | Barre de recherche + onglets résultats |
| 17 | `SettingsComponent` | `pages/settings/` | Formulaire édition profil |
| 18 | `PrivacySettingsComponent` | `pages/settings/privacy/` | Confidentialité + génération clé E2E |
| 19 | `ModerationComponent` | `pages/moderation/` | Tableau de signalements |
| 20 | `AdminComponent` | `pages/administration/` | Gestion des comptes |
| 21 | `NavbarComponent` | `layout/navbar/` | Barre de navigation latérale |
| 22 | `ToastComponent` | `shared/toast/` | Notifications flash (succès / erreur) |
| 23 | `AvatarComponent` | `shared/avatar/` | Affichage d'avatar avec fallback initiales |
| 24 | `CreatePostComponent` | `shared/create-post/` | Zone de saisie d'un nouveau post |
| 25 | `ExploreComponent` | `pages/explore/` | Posts publics – découverte |

---

## E.3 — Services Angular

| # | Service | Répertoire | Dépendance API | Description |
|---|---------|------------|----------------|-------------|
| 1 | `AuthService` | `core/auth/` | `POST /api/auth/*` | Login, register, refresh token, logout, état connecté |
| 2 | `TokenService` | `core/auth/` | — | Stockage / lecture / décodage du JWT en localStorage |
| 3 | `ProfileService` | `core/profile/` | `GET/PATCH /api/profiles/*` | Profil courant, mise à jour, clé publique E2E |
| 4 | `PostService` | `core/post/` | `GET/POST/DELETE /api/posts/*` | CRUD posts, like, repost, marque-pages |
| 5 | `FeedService` | `core/feed/` | `GET /api/posts/feed` | Fil des abonnements paginé |
| 6 | `UserService` | `core/user/` | `POST/DELETE /api/users/*` | Follow / unfollow, listes abonnés/abonnements |
| 7 | `NotificationService` | `core/notification/` | `GET/PATCH /api/users/notifications` | Polling notifications, marquer comme lu |
| 8 | `MessageService` | `core/message/` | `GET/POST /api/messages/*` | Conversations, envoi / réception de messages |
| 9 | `CryptoService` | `core/crypto/` | — | Génération clé X25519, chiffrement NaCl box, déchiffrement |
| 10 | `ModerationService` | `core/moderation/` | `GET/PATCH/POST /api/moderation/*` | Signalements, suspensions, masquage de posts |
| 11 | `AdminService` | `core/admin/` | `GET/POST /api/moderation/users/*` | Gestion des comptes (ban, rôle) |
| 12 | `SearchService` | `core/search/` | `GET /api/profiles/search`, `/api/posts/search` | Recherche multi-type |
| 13 | `MediaService` | `core/media/` | `POST /api/media/upload` | Upload de fichiers image/vidéo |
| 14 | `ThemeService` | `core/theme/` | — | Gestion thème clair/sombre/système (CSS class sur `<body>`) |
| 15 | `I18nService` | `core/i18n/` | — | Sélection de langue, chargement des fichiers de traduction |
| 16 | `ToastService` | `core/toast/` | — | File de notifications flash, auto-dismiss |
| 17 | `AuthGuard` | `core/guards/` | — | Redirige vers `/auth` si non connecté |
| 18 | `RoleGuard` | `core/guards/` | — | Vérifie le rôle JWT (MODERATOR/ADMIN) avant l'activation de la route |

---

## E.4 — Modules et organisation

```
frontend/src/
├── app/
│   ├── core/           # Services singleton (AuthService, CryptoService, …)
│   ├── layout/         # NavbarComponent, structure globale
│   ├── pages/          # Un répertoire par page (lazy-loaded)
│   └── shared/         # Composants réutilisables (PostCard, Avatar, Toast, …)
├── assets/
│   └── i18n/           # Fichiers de traduction JSON (fr, en, de, es, it, pt)
└── environments/       # environment.ts / environment.prod.ts
```

**Lazy loading** : chaque page est chargée à la demande via `loadComponent` (standalone components Angular 17+). Cela réduit le bundle initial et améliore le temps de chargement, particulièrement utile sur connexions lentes (environnements à faibles ressources).

---

## E.5 — Sécurité côté client

| Mécanisme | Implémentation |
|-----------|----------------|
| Stockage du JWT | `localStorage` (access token 5 min + refresh token 30 j) |
| Intercepteur HTTP | `AuthInterceptor` injecte `Authorization: Bearer …` sur chaque requête |
| Expiration | `TokenService.isExpired()` vérifie `exp` du payload JWT avant chaque requête |
| Refresh automatique | `AuthInterceptor` intercepte HTTP 401, appelle `POST /api/auth/refresh`, rejoue la requête |
| Chiffrement E2E | `CryptoService` utilise `tweetnacl` (NaCl box) — la clé privée reste en mémoire, jamais envoyée |
| XSS | Angular échappe automatiquement les interpolations `{{ }}` — pas de `innerHTML` non sanitisé |
| RBAC frontend | `RoleGuard` + directives structurelles `*ngIf="role >= MODERATOR"` masquent les éléments non autorisés |
