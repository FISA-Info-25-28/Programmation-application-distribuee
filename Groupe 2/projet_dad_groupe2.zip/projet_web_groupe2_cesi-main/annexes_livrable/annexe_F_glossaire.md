# Annexe F — Glossaire technique et métadonnées du dépôt

---

## F.1 — Glossaire technique

| Terme | Définition |
|-------|-----------|
| **Access Token** | JWT de courte durée (5 min, HS256) transportant `sub` (account UUID), `role` et `exp`. Signé côté serveur avec `JWT_SECRET`. |
| **Angular 21** | Framework frontend SPA/SSR de Google. Utilisé avec les standalone components (Angular 17+) et le lazy loading par route. |
| **AutoMigrate** | Fonctionnalité GORM qui crée ou met à jour les colonnes manquantes au démarrage du service, sans supprimer les données existantes. |
| **bcrypt** | Algorithme de hachage adaptatif pour les mots de passe. Utilisé à `DefaultCost` (facteur 10). Implémenté via `golang.org/x/crypto/bcrypt`. |
| **Ciphertext** | Donnée chiffrée résultant de l'application de l'algorithme NaCl box sur un message clair. Stockée en base64 dans `messages.private_messages.content`. |
| **Curve25519** | Courbe elliptique utilisée pour l'échange de clés Diffie-Hellman dans le protocole X25519. Base de NaCl box. |
| **Docker Compose** | Outil d'orchestration locale définissant l'ensemble des services dans `docker-compose.yml`. Point d'entrée : `docker compose up`. |
| **E2E Encryption** | Chiffrement de bout en bout : le contenu est chiffré sur le client de l'expéditeur et déchiffré sur le client du destinataire. Le serveur ne voit jamais le clair. |
| **GORM** | ORM Go (`gorm.io/gorm`). Gère les modèles, les migrations (`AutoMigrate`), les associations et les requêtes paramétrées. |
| **HS256** | HMAC-SHA256. Algorithme de signature symétrique utilisé pour les JWT. Nécessite un secret partagé (`JWT_SECRET`). |
| **JWT** | JSON Web Token. Standard RFC 7519 de transport d'identité sous forme de token signé (header.payload.signature). |
| **Microservice** | Architecture où chaque fonctionnalité métier est un binaire Go indépendant avec sa propre base de données (schéma PostgreSQL) et son propre port réseau. |
| **NaCl box** | Primitive cryptographique de libsodium/NaCl combinant : échange DH (X25519), chiffrement symétrique (XSalsa20), authentification (Poly1305-MAC). |
| **net/http** | Package de la bibliothèque standard Go fournissant un serveur HTTP. Utilisé à la place d'un framework externe (Gin, Echo). Le `ServeMux` de Go 1.22+ supporte le routage par méthode + chemin. |
| **Nonce** | Nombre aléatoire à usage unique (24 octets pour XSalsa20). Fourni par l'expéditeur, stocké en base64 avec le message, nécessaire au déchiffrement. |
| **Poly1305** | MAC (Message Authentication Code) utilisé conjointement avec XSalsa20 dans NaCl box pour garantir l'intégrité et l'authenticité du message. |
| **PostgreSQL** | SGBDR relationnel open-source. Utilisé avec 6 schémas logiques isolés dans une seule instance. Version 16. |
| **RBAC** | Role-Based Access Control. Contrôle d'accès par rôle : USER(1) < MODERATOR(2) < ADMIN(3). Vérifié par middleware Go côté back, par `RoleGuard` côté Angular. |
| **Refresh Token** | Token de longue durée (30 jours) échangé contre un nouvel access token. Haché en SHA-256 avant stockage en base (`auth.sessions.refresh_token_hash`). Rotatif à chaque usage. |
| **Reverse-proxy** | Rôle de l'api-gateway : il reçoit toutes les requêtes du client et les redirige vers le microservice compétent, de manière transparente. |
| **Search_path** | Paramètre PostgreSQL définissant le schéma par défaut d'une connexion. Chaque service positionne son `search_path` via la `DATABASE_URL`. |
| **Soft delete** | Suppression logique : un champ `deleted_at` est rempli au lieu de supprimer la ligne. Les requêtes filtrent `WHERE deleted_at IS NULL`. Utilisé sur `posts.posts` et `messages.private_messages`. |
| **SSR** | Server-Side Rendering. Angular Universal génère le HTML initial côté serveur pour améliorer le SEO et le temps de premier affichage. |
| **Tailwind CSS** | Framework CSS utilitaire. Classes appliquées directement dans les templates Angular. |
| **Token Bucket** | Algorithme de limitation de débit. Un seau se remplit à vitesse fixe ; chaque requête consomme un jeton. Si le seau est vide : HTTP 429. |
| **TweetNaCl** | Implémentation JavaScript de NaCl (`tweetnacl` npm). Utilisée côté Angular pour le chiffrement/déchiffrement E2E sans dépendance native. |
| **X25519** | Protocole d'échange de clés Diffie-Hellman sur Curve25519. Chaque utilisateur génère une paire (clé privée 32 octets, clé publique 32 octets). La clé publique est stockée en base64 dans `profiles.profiles.public_key`. |
| **XSalsa20** | Chiffrement par flot (stream cipher) dérivé de Salsa20 avec nonce étendu (192 bits). Composant de NaCl box. |

---

## F.2 — Métadonnées du dépôt

| Métrique | Valeur |
|----------|--------|
| Nombre total de fichiers | 272 |
| Nombre de commits | 416 |
| Durée du projet | ~2 semaines |
| Branches principales | `main`, `develop` |
| Convention de commits | Conventional Commits (`type(scope): description`) |
| Workflow Git | Gitflow (feature/* → develop → main, PR + 1 review) |

### Répartition des fichiers par type

| Type | Nombre approximatif |
|------|---------------------|
| Fichiers Go (`.go`) | ~110 |
| Fichiers TypeScript / Angular (`.ts`) | ~85 |
| Templates HTML Angular (`.html`) | ~25 |
| Fichiers SQL (migrations) | 9 |
| Fichiers de configuration (YAML, JSON, `.env.example`) | ~20 |
| Fichiers CSS / Tailwind | ~8 |
| Documentation (`.md`) | ~15 |

### Contributeurs

| Nom | Rôle principal |
|-----|----------------|
| Lisa ACHOUR | Backend Go (auth, profile, messages E2E, sécurité) |
| Allan Bouhamed | Backend Go (gateway, post, moderation, rate limiting) |
| Thaïs | Frontend Angular (composants, services, UI/UX) |
| Maeva | Frontend Angular (pages, internationalisation, tests) |

---

## F.3 — Structure du dépôt

```
projet_web_groupe2_cesi/
├── backend/
│   ├── cmd/
│   │   ├── api-gateway/       # Binaire gateway (rate limiting, reverse-proxy, CORS)
│   │   ├── auth-service/      # Binaire auth (JWT, bcrypt, sessions)
│   │   ├── user-service/      # Binaire follow/notifications
│   │   ├── profile-service/   # Binaire profil + clé E2E
│   │   ├── post-service/      # Binaire posts/likes/reposts/tags
│   │   ├── media-service/     # Binaire upload médias
│   │   ├── messages-service/  # Binaire messagerie E2E
│   │   ├── moderation-service/# Binaire signalements/sanctions
│   │   └── social-service/    # Binaire suggestions/trending
│   ├── internal/
│   │   ├── middleware/        # rate_limit.go, auth.go, cors.go
│   │   ├── models/            # Modèles GORM (Account, Profile, Post, …)
│   │   ├── security/          # access_token.go, refresh_token.go
│   │   └── <service>/         # handler.go, service.go, repository.go, dto.go par service
│   └── migrations/            # 001_init.sql → 007_messages_e2e.sql
├── frontend/
│   └── src/
│       ├── app/
│       │   ├── core/          # Services, guards, intercepteurs
│       │   ├── layout/        # NavbarComponent
│       │   ├── pages/         # 16 pages lazy-loaded
│       │   └── shared/        # PostCard, Avatar, Toast, CreatePost
│       └── assets/i18n/       # Traductions JSON (fr, en, de, es, it, pt)
├── docker-compose.yml
├── .env.example
└── annexes_livrable/          # Ce dossier
```
