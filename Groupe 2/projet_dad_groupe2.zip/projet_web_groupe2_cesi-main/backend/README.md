# Breezy - backend Go

Projet DAD / CESI.

Stack backend actuelle : Go, Gin, GORM, PostgreSQL, JWT, bcrypt, Docker Compose.

Architecture Docker :

- `breezy-api-gateway` - point d'entree API / gateway, expose sur `localhost:8080`
- `breezy-auth-service` - service interne auth, port Docker `4001`
- `breezy-user-service` - service interne utilisateurs, port Docker `4002`
- `breezy-profile-service` - service interne profils, port Docker `4003`
- `breezy-post-service` - service interne posts, port Docker `4004`
- `breezy-moderation-service` - service interne moderation, port Docker `4005`
- `breezy-postgres` - base PostgreSQL partagee
- `breezy-adminer` - interface de dev pour PostgreSQL

## Demarrer avec Docker

1. Copier `.env.example` vers `.env` et ajuster les valeurs si besoin.
2. Lancer les conteneurs :

```bash
docker compose up --build
```

Interfaces utiles :

- API gateway : http://localhost:8080
- Healthcheck gateway : http://localhost:8080/health
- Adminer PostgreSQL : http://localhost:8081

Comptes de demo crees automatiquement au demarrage de `auth-service` :

```txt
ADMIN     admin@breezy.demo      Demo1234!
MODERATOR moderator@breezy.demo  Demo1234!
USER      user@breezy.demo       Demo1234!
```

Les services internes ne sont pas exposes sur la machine. Ils communiquent via
le reseau Docker `breezy-net`.

## PostgreSQL avec Adminer

```txt
Systeme : PostgreSQL
Serveur : postgres
Port : 5432
Base de donnees : cesi_app
Utilisateur : cesi_user
Mot de passe : cesi_password
```

Les schemas PostgreSQL sont initialises par `migrations/001_init.sql` au premier
demarrage du volume Docker :

```txt
auth-service -> schema auth
user-service -> schema social
profile-service -> schema profiles
post-service -> schema posts
moderation-service -> schema moderation
```

## Scripts utiles

```bash
go run ./cmd/api-gateway
go run ./cmd/auth-service
go run ./cmd/user-service
go run ./cmd/post-service
go run ./cmd/moderation-service
go test ./...
go test ./... "-coverprofile=coverage.out"
go tool cover "-func=coverage.out"
go tool cover "-html=coverage.out" -o coverage.html
go run ./scripts/coverage.go
go run ./scripts/coverage.go -open
```

## Structure

- `cmd/api-gateway` - executable du gateway
- `cmd/auth-service` - executable du service auth
- `cmd/user-service` - executable du service utilisateurs
- `cmd/post-service` - executable du service posts
- `cmd/moderation-service` - executable du service moderation
- `internal/auth` - domaine auth, routes, handlers, service et repository
- `internal/config` - lecture de la configuration
- `internal/db` - connexion PostgreSQL/GORM
- `internal/middleware` - middlewares HTTP partages, par exemple verification JWT
- `internal/models` - modeles GORM separes par domaine
- `internal/moderation` - domaine moderation, routes, handlers, repository et DTO
- `internal/security` - signature et verification des JWT
- `internal/server` - demarrage HTTP commun

Quand un service gagne de la logique metier, creer un package dedie dans
`internal` sur le meme modele que `internal/auth` : routes, handler, service,
repository et DTO.
- `migrations/` - initialisation SQL PostgreSQL
