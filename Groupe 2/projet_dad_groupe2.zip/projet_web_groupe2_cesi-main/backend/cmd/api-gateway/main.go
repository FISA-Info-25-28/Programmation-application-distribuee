package main

import (
	"log"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"strings"
	"time"

	"breezy/backend/internal/config"
	"breezy/backend/internal/middleware"
	"breezy/backend/internal/server"
	"github.com/gin-gonic/gin"
)

// newRouter construit le routeur Gin de l'API gateway en enregistrant
// l'endpoint /health et l'ensemble des routes proxy vers les microservices.
// Entree : aucune entree directe (lit les URLs de services via les variables
// d'environnement).
// Sortie : valeur retour de type *gin.Engine.
func newRouter() *gin.Engine {
	router := server.NewRouter()
	router.GET("/health", health) // Endpoint de santé pour l'API Gateway

	// Limite generale : 100 requetes/minute par IP sur l'ensemble de l'API.
	router.Use(middleware.NewRateLimiter(100, time.Minute).Middleware())

	// Limite stricte sur les routes d'authentification sensibles aux abus
	// (brute-force login, spam d'inscription, enumeration de comptes).
	authRateLimiter := middleware.NewRateLimiter(10, time.Minute).Middleware()

	router.Any("/api/auth/*path", authRateLimiter, gin.WrapH(http.StripPrefix("/api/auth", proxy(config.Env("AUTH_SERVICE_URL", "http://auth-service:4001")))))
	router.Any("/api/users/*path", usersRoutesProxy())
	router.Any("/api/notifications", gin.WrapH(http.StripPrefix("/api", proxy(config.Env("USER_SERVICE_URL", "http://user-service:4002")))))
	router.Any("/api/notifications/*path", gin.WrapH(http.StripPrefix("/api", proxy(config.Env("USER_SERVICE_URL", "http://user-service:4002")))))
	router.Any("/api/profiles/*path", gin.WrapH(http.StripPrefix("/api/profiles", proxy(config.Env("PROFILE_SERVICE_URL", "http://profile-service:4003")))))
	router.Any("/api/posts/*path", postRoutesProxy())
	router.Any("/api/tags/*path", gin.WrapH(http.StripPrefix("/api", proxy(config.Env("POST_SERVICE_URL", "http://post-service:4004")))))
	router.Any("/api/media/*path", gin.WrapH(http.StripPrefix("/api/media", proxy(config.Env("MEDIA_SERVICE_URL", "http://media-service:4005")))))
	router.Any("/api/moderation/*path", gin.WrapH(http.StripPrefix("/api/moderation", proxy(config.Env("MODERATION_SERVICE_URL", "http://moderation-service:4005")))))
	router.Any("/api/conversations", gin.WrapH(http.StripPrefix("/api", proxy(config.Env("MESSAGES_SERVICE_URL", "http://messages-service:4006")))))
	router.Any("/api/conversations/*path", gin.WrapH(http.StripPrefix("/api", proxy(config.Env("MESSAGES_SERVICE_URL", "http://messages-service:4006")))))
	router.Any("/api/messages/*path", gin.WrapH(http.StripPrefix("/api", proxy(config.Env("MESSAGES_SERVICE_URL", "http://messages-service:4006")))))

	return router
}

func main() {
	router := newRouter()
	handler := middleware.CORS(router)
	if err := runGateway(handler); err != nil {
		log.Fatal(err)
	}
}

// runGateway demarre la gateway en HTTPS si TLS_CERT_FILE/TLS_KEY_FILE
// pointent vers des fichiers existants, sinon en HTTP simple (ex: derriere
// un reverse proxy qui termine deja le TLS, comme en production avec nginx).
// Entree : handler.
// Sortie : erreur eventuelle.
func runGateway(handler http.Handler) error {
	certFile := config.Env("TLS_CERT_FILE", "")
	keyFile := config.Env("TLS_KEY_FILE", "")
	if certFile != "" && keyFile != "" {
		if _, err := os.Stat(certFile); err == nil {
			if _, err := os.Stat(keyFile); err == nil {
				return server.RunTLS(config.Port("8080"), handler, certFile, keyFile)
			}
		}
		log.Printf("TLS_CERT_FILE/TLS_KEY_FILE configures mais introuvables, demarrage en HTTP")
	}
	return server.Run(config.Port("8080"), handler)
}

// proxy construit un reverse proxy HTTP vers l'URL du service cible.
// Entree : target.
// Sortie : valeur retour de type http.Handler.
func proxy(target string) http.Handler {
	u, err := url.Parse(target)
	if err != nil {
		log.Fatalf("invalid service URL %s: %v", target, err)
	}
	proxy := httputil.NewSingleHostReverseProxy(u)
	proxy.ErrorHandler = func(w http.ResponseWriter, r *http.Request, err error) {
		log.Printf("proxy error for %s: %v", r.URL.Path, err)
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		w.WriteHeader(http.StatusBadGateway)
		_, _ = w.Write([]byte(`{"error":"upstream service unavailable"}`))
	}
	return proxy
}

func postRoutesProxy() gin.HandlerFunc {
	postService := http.StripPrefix("/api/posts", proxy(config.Env("POST_SERVICE_URL", "http://post-service:4004")))
	moderationService := http.StripPrefix("/api", proxy(config.Env("MODERATION_SERVICE_URL", "http://moderation-service:4005")))

	return func(c *gin.Context) {
		if c.Request.Method == http.MethodPost && strings.HasSuffix(c.Request.URL.Path, "/report") {
			moderationService.ServeHTTP(c.Writer, c.Request)
			return
		}

		postService.ServeHTTP(c.Writer, c.Request)
	}
}

func usersRoutesProxy() gin.HandlerFunc {
	userService := http.StripPrefix("/api/users", proxy(config.Env("USER_SERVICE_URL", "http://user-service:4002")))
	socialService := http.StripPrefix("/api/users", proxy(config.Env("SOCIAL_SERVICE_URL", "http://social-service:4007")))

	return func(c *gin.Context) {
		path := c.Request.URL.Path
		if strings.Contains(path, "/follow/") || strings.Contains(path, "/follow-requests/") || strings.Contains(path, "/block/") || strings.HasSuffix(path, "/blocked") || strings.HasSuffix(path, "/followers") || strings.HasSuffix(path, "/following") {
			socialService.ServeHTTP(c.Writer, c.Request)
			return
		}

		userService.ServeHTTP(c.Writer, c.Request)
	}
}

// health expose un point de controle simple pour verifier que la gateway
// repond correctement.
// Entree : c.
// Sortie HTTP : JSON contenant service=api-gateway et status=ok.
func health(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"service": "api-gateway",
		"status":  "ok",
	})
}
