package main

import (
	"io"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
)

func TestNewRouterRegistersHealthAndProxyRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)

	// On force toutes les URLs de services vers un port local ferme afin que
	// l'echec de connexion soit immediat (au lieu d'une resolution DNS lente
	// vers les noms d'hote Docker par defaut, absents hors conteneur).
	for _, env := range []string{
		"AUTH_SERVICE_URL", "USER_SERVICE_URL", "SOCIAL_SERVICE_URL",
		"PROFILE_SERVICE_URL", "POST_SERVICE_URL", "MODERATION_SERVICE_URL",
		"MEDIA_SERVICE_URL", "MESSAGES_SERVICE_URL",
	} {
		t.Setenv(env, "http://127.0.0.1:1")
	}

	router := newRouter()

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200", rec.Code)
	}
	if body := rec.Body.String(); !containsAll(body, "api-gateway", "ok") {
		t.Fatalf("GET /health body = %q, want service/status", body)
	}

	// Les routes proxy ciblent des services indisponibles pendant le test ;
	// on utilise un vrai serveur HTTP (et non httptest.Recorder) pour que le
	// reverse proxy puisse fonctionner normalement (CloseNotifier requis).
	gateway := httptest.NewServer(router)
	defer gateway.Close()

	for _, path := range []string{
		"/api/auth/login",
		"/api/users/abc",
		"/api/notifications",
		"/api/notifications/abc",
		"/api/profiles/abc",
		"/api/posts/abc",
		"/api/tags/trending",
		"/api/media/abc",
		"/api/moderation/abc",
		"/api/conversations",
		"/api/conversations/abc",
		"/api/messages/abc",
	} {
		resp, err := http.Get(gateway.URL + path)
		if err != nil {
			t.Fatalf("GET %s unexpected error: %v", path, err)
		}
		resp.Body.Close()
		if resp.StatusCode == http.StatusNotFound {
			t.Fatalf("GET %s status = %d, want route to be registered (not 404)", path, resp.StatusCode)
		}
	}
}

func TestHealth(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.GET("/health", health)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if body := rec.Body.String(); body == "" || !containsAll(body, "api-gateway", "ok") {
		t.Fatalf("body = %q, want service/status", body)
	}
}

func TestProxyReturnsBadGatewayWhenUpstreamFails(t *testing.T) {
	handler := proxy("http://127.0.0.1:1")
	rec := httptest.NewRecorder()

	handler.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusBadGateway {
		t.Fatalf("status = %d, want 502", rec.Code)
	}
	if body := rec.Body.String(); !containsAll(body, "upstream service unavailable") {
		t.Fatalf("body = %q, want upstream error", body)
	}
}

func TestUsersRoutesProxy(t *testing.T) {
	gin.SetMode(gin.TestMode)
	userServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte("user:" + r.URL.Path))
	}))
	defer userServer.Close()
	socialServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte("social:" + r.URL.Path))
	}))
	defer socialServer.Close()

	t.Setenv("USER_SERVICE_URL", userServer.URL)
	t.Setenv("SOCIAL_SERVICE_URL", socialServer.URL)

	router := gin.New()
	router.Any("/api/users/*path", usersRoutesProxy())

	tests := map[string]string{
		"/api/users/search":               "user:/search",
		"/api/users/abc/follow/def":       "social:/abc/follow/def",
		"/api/users/abc/followers":        "social:/abc/followers",
		"/api/users/follow-requests/list": "social:/follow-requests/list",
	}
	gateway := httptest.NewServer(router)
	defer gateway.Close()

	for path, want := range tests {
		resp, err := http.Get(gateway.URL + path)
		if err != nil {
			t.Fatalf("GET %s unexpected error: %v", path, err)
		}
		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		if string(body) != want {
			t.Fatalf("usersRoutesProxy(%s) = %q, want %q", path, string(body), want)
		}
	}
}

func TestPostRoutesProxy(t *testing.T) {
	gin.SetMode(gin.TestMode)
	postServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte("post:" + r.URL.Path))
	}))
	defer postServer.Close()
	moderationServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte("moderation:" + r.URL.Path))
	}))
	defer moderationServer.Close()

	t.Setenv("POST_SERVICE_URL", postServer.URL)
	t.Setenv("MODERATION_SERVICE_URL", moderationServer.URL)

	router := gin.New()
	router.Any("/api/posts/*path", postRoutesProxy())
	gateway := httptest.NewServer(router)
	defer gateway.Close()

	tests := []struct {
		method string
		path   string
		want   string
	}{
		{method: http.MethodGet, path: "/api/posts/1", want: "post:/1"},
		{method: http.MethodPost, path: "/api/posts/1/report", want: "moderation:/posts/1/report"},
		{method: http.MethodGet, path: "/api/posts/1/report", want: "post:/1/report"},
	}
	for _, tt := range tests {
		req, err := http.NewRequest(tt.method, gateway.URL+tt.path, nil)
		if err != nil {
			t.Fatalf("NewRequest() unexpected error: %v", err)
		}
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("%s %s unexpected error: %v", tt.method, tt.path, err)
		}
		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		if string(body) != tt.want {
			t.Fatalf("postRoutesProxy(%s %s) = %q, want %q", tt.method, tt.path, string(body), tt.want)
		}
	}
}

func containsAll(value string, parts ...string) bool {
	for _, part := range parts {
		if !contains(value, part) {
			return false
		}
	}
	return true
}

func contains(value, part string) bool {
	for i := 0; i+len(part) <= len(value); i++ {
		if value[i:i+len(part)] == part {
			return true
		}
	}
	return part == ""
}
