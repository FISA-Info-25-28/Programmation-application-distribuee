package main

import (
	"context"
	"log"

	"breezy/backend/internal/auth"
	"breezy/backend/internal/config"
	"breezy/backend/internal/db"
	"breezy/backend/internal/models"
	"breezy/backend/internal/server"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// newRouter construit le routeur Gin du service auth en enregistrant les
// routes d'authentification sur la base de donnees fournie.
// Entree : gdb (connexion GORM, peut etre nil pour les tests de routage).
// Sortie : valeur retour de type *gin.Engine.
func newRouter(gdb *gorm.DB) *gin.Engine {
	router := server.NewRouter()
	auth.RegisterRoutes(router, auth.NewHandler(gdb))
	return router
}

// main initialise le service d'authentification, connecte la base de donnees,
// execute les migrations GORM et enregistre les routes HTTP d'authentification.
// Entree : aucune entree directe.
// DATABASE_URL, PORT, JWT_SECRET et options de seed.
// Sortie : aucune valeur.
// echoue.
func main() {
	gdb, err := db.Connect(config.Env("DATABASE_URL", ""))
	if err != nil {
		log.Fatalf("db connection failed: %v", err)
	}
	if err := gdb.AutoMigrate(&models.Account{}, &models.Session{}, &models.EmailVerificationToken{}); err != nil {
		log.Printf("warn: db migration failed: %v", err)
	}
	// Appel separe pour que les nouvelles tables soient creees meme si les
	// tables existantes echouent a cause de contraintes renommees par Postgres.
	if err := gdb.AutoMigrate(&models.PasswordResetToken{}); err != nil {
		log.Printf("warn: password_reset_tokens migration failed: %v", err)
	}
	if config.Env("SEED_DEMO_ACCOUNTS", "false") == "true" {
		if err := auth.SeedDemoAccounts(context.Background(), gdb); err != nil {
			log.Printf("warn: demo account seed failed: %v", err)
		}
	}

	router := newRouter(gdb)

	if err := server.Run(config.Port("4001"), router); err != nil {
		log.Fatal(err)
	}
}
