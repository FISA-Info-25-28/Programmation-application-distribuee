package main

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// newAuthMockDB cree un *gorm.DB adosse a un sqlmock, pour exercer newRouter()
// avec une connexion DB "reelle" sans toucher a une vraie base Postgres.
func newAuthMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })

	db, err := gorm.Open(postgres.New(postgres.Config{
		Conn:                 sqlDB,
		PreferSimpleProtocol: true,
	}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

func TestNewRouterWithNilDB(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := newRouter(nil)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestNewRouterWithMockDBHealth(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newAuthMockDB(t)
	router := newRouter(db)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestNewRouterRegistersExpectedRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newAuthMockDB(t)
	router := newRouter(db)

	t.Run("me without auth is unauthorized", func(t *testing.T) {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/me", nil))
		if rec.Code != http.StatusUnauthorized {
			t.Fatalf("GET /me status = %d, want 401: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("register with invalid body returns 400", func(t *testing.T) {
		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/register", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("POST /register status = %d, want 400: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unknown route returns 404", func(t *testing.T) {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/does-not-exist", nil))
		if rec.Code != http.StatusNotFound {
			t.Fatalf("GET /does-not-exist status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("accounts status without auth is unauthorized", func(t *testing.T) {
		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/accounts/00000000-0000-0000-0000-000000000000/status", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusUnauthorized {
			t.Fatalf("PATCH /accounts/:id/status status = %d, want 401: %s", rec.Code, rec.Body.String())
		}
	})
}
