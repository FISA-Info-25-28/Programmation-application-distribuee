package main

import (
	"log"
	"os"

	"breezy/backend/internal/config"
	"breezy/backend/internal/media"
	"breezy/backend/internal/server"
	"github.com/gin-gonic/gin"
)

// newRouter construit le routeur Gin du service media en enregistrant les
// routes de gestion des fichiers sur le repertoire et l'URL de base fournis.
// Entree : uploadDir, baseURL.
// Sortie : valeur retour de type *gin.Engine.
func newRouter(uploadDir, baseURL string) *gin.Engine {
	router := server.NewRouter()
	media.RegisterRoutes(router, media.NewHandler(uploadDir, baseURL))
	return router
}

func main() {
	uploadDir := config.Env("UPLOAD_DIR", "/data/uploads")
	if err := os.MkdirAll(uploadDir, 0755); err != nil {
		log.Fatalf("media: impossible de créer le répertoire d'upload : %v", err)
	}
	baseURL := config.Env("MEDIA_BASE_URL", "http://localhost:8080/api/media")

	router := newRouter(uploadDir, baseURL)

	if err := server.Run(config.Port("4005"), router); err != nil {
		log.Fatal(err)
	}
}
