package main

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
)

func TestNewRouterRegistersExpectedRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := newRouter(t.TempDir(), "http://media.test/api/media")

	t.Run("health returns 200", func(t *testing.T) {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("GET /health status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("upload without auth is unauthorized", func(t *testing.T) {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/upload", nil))
		if rec.Code != http.StatusUnauthorized {
			t.Fatalf("POST /upload status = %d, want 401: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unknown route returns 404", func(t *testing.T) {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/does-not-exist", nil))
		if rec.Code != http.StatusNotFound {
			t.Fatalf("GET /does-not-exist status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})
}
