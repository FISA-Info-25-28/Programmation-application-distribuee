package main

import (
	"log"

	"breezy/backend/internal/config"
	"breezy/backend/internal/db"
	"breezy/backend/internal/messages"
	"breezy/backend/internal/models"
	"breezy/backend/internal/server"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

var gdb *gorm.DB

// newRouter construit le routeur Gin du service messages en enregistrant les
// routes de messagerie sur la base de donnees fournie.
// Entree : gdb (connexion GORM, peut etre nil pour les tests de routage).
// Sortie : valeur retour de type *gin.Engine.
func newRouter(gdb *gorm.DB) *gin.Engine {
	router := server.NewRouter()
	messages.RegisterRoutes(router, messages.NewHandler(gdb))
	return router
}

func main() {
	var err error
	gdb, err = db.Connect(config.Env("DATABASE_URL", ""))
	if err != nil {
		log.Fatalf("db connection failed: %v", err)
	}
	if err := gdb.AutoMigrate(
		&models.Conversation{},
		&models.ConversationMember{},
		&models.PrivateMessage{},
		&models.MessagePreference{},
		&models.MessageLike{},
	); err != nil {
		log.Printf("warn: db migration failed: %v", err)
	}

	router := newRouter(gdb)

	if err := server.Run(config.Port("4006"), router); err != nil {
		log.Fatal(err)
	}
}
