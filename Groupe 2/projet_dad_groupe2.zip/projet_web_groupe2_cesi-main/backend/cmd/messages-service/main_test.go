package main

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// newMessagesMockDB cree un *gorm.DB adosse a un sqlmock, pour exercer
// newRouter() avec une connexion DB "reelle" sans vraie base Postgres.
func newMessagesMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })

	db, err := gorm.Open(postgres.New(postgres.Config{
		Conn:                 sqlDB,
		PreferSimpleProtocol: true,
	}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

func TestNewRouterWithNilDB(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := newRouter(nil)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestNewRouterWithMockDBHealth(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newMessagesMockDB(t)
	router := newRouter(db)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestNewRouterRegistersExpectedRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newMessagesMockDB(t)
	router := newRouter(db)

	t.Run("conversations without auth is unauthorized", func(t *testing.T) {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/conversations", nil))
		if rec.Code != http.StatusUnauthorized {
			t.Fatalf("GET /conversations status = %d, want 401: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("send message without auth is unauthorized", func(t *testing.T) {
		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/conversations/00000000-0000-0000-0000-000000000000/messages", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusUnauthorized {
			t.Fatalf("POST /conversations/:id/messages status = %d, want 401: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unknown route returns 404", func(t *testing.T) {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/does-not-exist", nil))
		if rec.Code != http.StatusNotFound {
			t.Fatalf("GET /does-not-exist status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})
}
