package main

import (
	"log"

	"breezy/backend/internal/config"
	"breezy/backend/internal/db"
	"breezy/backend/internal/models"
	"breezy/backend/internal/moderation"
	"breezy/backend/internal/sanction"
	"breezy/backend/internal/server"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

var gdb *gorm.DB

// newRouter construit le routeur Gin du service moderation a partir d'une
// connexion GORM deja etablie : il enregistre les routes via
// moderation.RegisterRoutes/moderation.NewHandler. Extrait de main() pour
// pouvoir etre teste sans vraie base Postgres (gdb peut etre un mock sqlmock).
func newRouter(gdb *gorm.DB) *gin.Engine {
	router := server.NewRouter()
	moderation.RegisterRoutes(router, moderation.NewHandler(gdb))
	return router
}

func main() {
	var err error
	gdb, err = db.Connect(config.Env("DATABASE_URL", ""))
	if err != nil {
		log.Fatalf("db connection failed: %v", err)
	}
	if err := gdb.AutoMigrate(&models.Report{}); err != nil {
		log.Printf("warn: db migration failed: %v", err)
	}
	if err := sanction.EnsureColumns(gdb); err != nil {
		log.Printf("warn: sanction columns migration failed: %v", err)
	}

	router := newRouter(gdb)

	if err := server.Run(config.Port("4005"), router); err != nil {
		log.Fatal(err)
	}
}
