package main

import (
	"log"
	"net/http"

	"breezy/backend/internal/config"
	"breezy/backend/internal/db"
	"breezy/backend/internal/models"
	"breezy/backend/internal/post"
	"breezy/backend/internal/server"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// gdb conserve la connexion GORM partagee par le service posts.
var gdb *gorm.DB

// main initialise le service posts, connecte la base de donnees,
// cree les tables de publication et demarre le serveur HTTP.
// Entree : aucune entree directe.
// PORT.
// Sortie : aucune valeur.
// echoue.
func main() {
	var err error

	gdb, err = db.Connect(config.Env("DATABASE_URL", ""))
	if err != nil {
		log.Fatalf("db connection failed: %v", err)
	}
	if err := gdb.AutoMigrate(
		&models.Post{},
		&models.Like{},
		&models.Repost{},
		&models.Tag{},
		&models.PostTag{},
		&models.Media{},
		&models.Poll{},
		&models.PollOption{},
		&models.PollVote{},
		&models.Bookmark{},
	); err != nil {
		log.Printf("warn: db migration failed: %v", err)
	}

	router := newRouter(gdb)

	if err := server.Run(config.Port("4004"), router); err != nil {
		log.Fatal(err)
	}
}

// newRouter construit le routeur Gin du service posts en enregistrant les
// routes metier exposees par le paquet post.
// Entree : gdb, la connexion GORM deja etablie.
// Sortie : valeur retour de type *gin.Engine.
func newRouter(gdb *gorm.DB) *gin.Engine {
	router := server.NewRouter()

	post.RegisterRoutes(router, post.NewHandler(gdb))

	return router
}

// health indique l'etat du service posts et de sa connexion PostgreSQL.
// Entree : c.
// Sortie HTTP : JSON contenant le nom du service, status=ok et l'etat db.
func health(c *gin.Context) {
	dbStatus := "ok"

	if gdb == nil {
		dbStatus = "unavailable"
	} else if sqlDB, err := gdb.DB(); err != nil || sqlDB.PingContext(c.Request.Context()) != nil {
		dbStatus = "error"
	}

	c.JSON(http.StatusOK, gin.H{
		"service": config.Env("SERVICE_NAME", "post-service"),
		"status":  "ok",
		"db":      dbStatus,
	})
}

func getPosts(c *gin.Context) {
	if gdb == nil {
		c.JSON(http.StatusServiceUnavailable, gin.H{
			"error": "database unavailable",
		})
		return
	}

	var posts []models.Post

	err := gdb.
		Order("created_at DESC").
		Find(&posts).Error

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to fetch posts",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"posts": posts,
	})
}
