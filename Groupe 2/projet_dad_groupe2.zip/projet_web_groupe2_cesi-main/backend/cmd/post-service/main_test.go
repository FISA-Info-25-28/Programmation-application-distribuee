package main

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var errPingFailed = errors.New("ping failed")

// newMockDB cree une connexion GORM adossee a sqlmock pour exercer newRouter()
// sans dependre d'une vraie base Postgres. Le monitoring des pings est
// active pour pouvoir simuler un succes/echec de ExpectPing().
func newMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New(sqlmock.MonitorPingsOption(true))
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })

	gdb, err := gorm.Open(postgres.New(postgres.Config{
		Conn:                 sqlDB,
		PreferSimpleProtocol: true,
	}), &gorm.Config{
		Logger:               logger.Default.LogMode(logger.Silent),
		DisableAutomaticPing: true,
	})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return gdb, mock
}

func TestHealthWithoutDatabase(t *testing.T) {
	gin.SetMode(gin.TestMode)
	previous := gdb
	gdb = nil
	defer func() { gdb = previous }()

	router := gin.New()
	router.GET("/health", health)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if body := rec.Body.String(); !containsAll(body, "post-service", "unavailable") {
		t.Fatalf("body = %q, want service/db status", body)
	}
}

func TestHealthDirectPingError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	previous := gdb
	mockDB, mock := newMockDB(t)
	gdb = mockDB
	defer func() { gdb = previous }()

	mock.ExpectPing().WillReturnError(errPingFailed)

	router := gin.New()
	router.GET("/health", health)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if body := rec.Body.String(); !containsAll(body, "post-service", `"db":"error"`) {
		t.Fatalf("body = %q, want db error", body)
	}
}

func TestHealthDirectPingOk(t *testing.T) {
	gin.SetMode(gin.TestMode)
	previous := gdb
	mockDB, mock := newMockDB(t)
	gdb = mockDB
	defer func() { gdb = previous }()

	mock.ExpectPing()

	router := gin.New()
	router.GET("/health", health)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if body := rec.Body.String(); !containsAll(body, "post-service", `"db":"ok"`) {
		t.Fatalf("body = %q, want db ok", body)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations: %v", err)
	}
}

func TestGetPostsWithoutDatabase(t *testing.T) {
	gin.SetMode(gin.TestMode)
	previous := gdb
	gdb = nil
	defer func() { gdb = previous }()

	router := gin.New()
	router.GET("/posts", getPosts)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/posts", nil))

	if rec.Code != http.StatusServiceUnavailable {
		t.Fatalf("status = %d, want 503", rec.Code)
	}
}

func TestGetPostsSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	previous := gdb
	mockDB, mock := newMockDB(t)
	gdb = mockDB
	defer func() { gdb = previous }()

	mock.ExpectQuery(`SELECT \* FROM "posts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "content"}))

	router := gin.New()
	router.GET("/posts", getPosts)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/posts", nil))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200, body=%s", rec.Code, rec.Body.String())
	}
	if body := rec.Body.String(); !containsAll(body, `"posts"`) {
		t.Fatalf("body = %q, want posts key", body)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations: %v", err)
	}
}

func TestGetPostsDBError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	previous := gdb
	mockDB, mock := newMockDB(t)
	gdb = mockDB
	defer func() { gdb = previous }()

	mock.ExpectQuery(`SELECT \* FROM "posts"`).
		WillReturnError(errors.New("query failed"))

	router := gin.New()
	router.GET("/posts", getPosts)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/posts", nil))

	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("status = %d, want 500, body=%s", rec.Code, rec.Body.String())
	}
	if body := rec.Body.String(); !containsAll(body, "failed to fetch posts") {
		t.Fatalf("body = %q, want error message", body)
	}
}

func TestNewRouterHealthDBOk(t *testing.T) {
	gin.SetMode(gin.TestMode)
	gdb, mock := newMockDB(t)
	mock.ExpectPing()

	router := newRouter(gdb)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if body := rec.Body.String(); !containsAll(body, "post-service", `"db":"ok"`) {
		t.Fatalf("body = %q, want db ok", body)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations: %v", err)
	}
}

func TestNewRouterHealthDBError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	gdb, mock := newMockDB(t)
	mock.ExpectPing().WillReturnError(errPingFailed)

	router := newRouter(gdb)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if body := rec.Body.String(); !containsAll(body, "post-service", `"db":"error"`) {
		t.Fatalf("body = %q, want db error", body)
	}
}

func TestNewRouterRegistersPublicRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	gdb, mock := newMockDB(t)
	mock.MatchExpectationsInOrder(false)
	mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"id"}))

	router := newRouter(gdb)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/feed", nil))

	if rec.Code == http.StatusNotFound {
		t.Fatalf("status = %d, want route to be registered (not 404)", rec.Code)
	}
}

func TestNewRouterRegistersProtectedRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	gdb, _ := newMockDB(t)

	router := newRouter(gdb)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/", nil))

	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status = %d, want 401 (route exists but requires auth)", rec.Code)
	}
}

func containsAll(value string, parts ...string) bool {
	for _, part := range parts {
		if !contains(value, part) {
			return false
		}
	}
	return true
}

func contains(value, part string) bool {
	for i := 0; i+len(part) <= len(value); i++ {
		if value[i:i+len(part)] == part {
			return true
		}
	}
	return part == ""
}
