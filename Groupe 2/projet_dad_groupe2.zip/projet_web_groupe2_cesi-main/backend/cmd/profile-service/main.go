package main

import (
	"log"

	"breezy/backend/internal/config"
	"breezy/backend/internal/db"
	"breezy/backend/internal/models"
	"breezy/backend/internal/profile"
	"breezy/backend/internal/server"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// gdb conserve la connexion GORM partagee par le service profils.
var gdb *gorm.DB

// newRouter construit le routeur Gin du service profils a partir d'une
// connexion GORM deja etablie : il enregistre les routes via
// profile.RegisterRoutes/profile.NewHandler. Extrait de main() pour pouvoir
// etre teste sans vraie base Postgres (gdb peut etre un mock sqlmock).
func newRouter(gdb *gorm.DB) *gin.Engine {
	router := server.NewRouter()
	profile.RegisterRoutes(router, profile.NewHandler(gdb))
	return router
}

// main initialise le service profils, connecte la base de donnees,
// cree les tables de profils/preferences et demarre le serveur HTTP.
// Entree : aucune entree directe.
// PORT.
// Sortie : aucune valeur.
// echoue.
func main() {
	gdb, err := db.Connect(config.Env("DATABASE_URL", ""))
	if err != nil {
		log.Fatalf("db connection failed: %v", err)
	}
	if gdb != nil {
		// AutoMigrate synchronise les modèles utilisés par le service profil.
		// La migration SQL reste la référence principale, mais cela garde le service cohérent en développement.
		if err := gdb.AutoMigrate(&models.Profile{}, &models.UserPreference{}); err != nil {
			log.Printf("warn: db migration failed: %v", err)
		}
	}

	router := newRouter(gdb)

	if err := server.Run(config.Port("4003"), router); err != nil {
		log.Fatal(err)
	}
}
