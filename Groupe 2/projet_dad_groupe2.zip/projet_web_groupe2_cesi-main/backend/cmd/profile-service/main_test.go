package main

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// newProfileMainMockDB cree un *gorm.DB adosse a un sqlmock, pour pouvoir
// construire newRouter(gdb) sans vraie connexion Postgres.
func newProfileMainMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })

	db, err := gorm.Open(postgres.New(postgres.Config{
		Conn:                 sqlDB,
		PreferSimpleProtocol: true,
	}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

func TestNewRouterRegistersHealthRoute(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newProfileMainMockDB(t)
	router := newRouter(db)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200", rec.Code)
	}
}

func TestNewRouterWithNilDB(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := newRouter(nil)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200", rec.Code)
	}
}

func TestNewRouterProtectedRoutesRequireAuth(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newProfileMainMockDB(t)
	router := newRouter(db)

	cases := []struct {
		name   string
		method string
		path   string
	}{
		{"me", http.MethodGet, "/me"},
		{"update me", http.MethodPatch, "/me"},
		{"pin post", http.MethodPost, "/me/pin/00000000-0000-0000-0000-000000000000"},
		{"unpin post", http.MethodDelete, "/me/pin"},
		{"preferences", http.MethodGet, "/preferences"},
		{"update preferences", http.MethodPatch, "/preferences"},
		{"show user", http.MethodGet, "/someusername"},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			rec := httptest.NewRecorder()
			router.ServeHTTP(rec, httptest.NewRequest(tc.method, tc.path, nil))
			// Sans authentification, ces routes doivent refuser l'acces (401/403),
			// jamais retourner 404 (ce qui prouverait que la route est bien enregistree).
			if rec.Code == http.StatusNotFound {
				t.Fatalf("%s %s status = %d, route not registered", tc.method, tc.path, rec.Code)
			}
		})
	}
}
