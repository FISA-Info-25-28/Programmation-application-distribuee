package main

import (
	"log"
	"net/http"

	"breezy/backend/internal/config"
	"breezy/backend/internal/db"
	"breezy/backend/internal/models"
	"breezy/backend/internal/notifications"
	"breezy/backend/internal/server"
	"breezy/backend/internal/users"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// gdb conserve la connexion GORM partagee par le service utilisateurs.
var gdb *gorm.DB

// main initialise le service utilisateurs, connecte la base de donnees,
// cree les tables sociales necessaires et demarre le serveur HTTP.
// Entree : aucune entree directe.
// PORT.
// Sortie : aucune valeur.
// echoue.
func main() {
	var err error
	gdb, err = db.Connect(config.Env("DATABASE_URL", ""))
	if err != nil {
		log.Fatalf("db connection failed: %v", err)
	}
	gdb.AutoMigrate(&models.Follow{}, &models.Notification{})

	router := newRouter(gdb)

	if err := server.Run(config.Port("4002"), router); err != nil {
		log.Fatal(err)
	}
}

// newRouter construit le routeur Gin du service utilisateurs en enregistrant
// l'endpoint /health et les routes metier des paquets users et notifications.
// Entree : gdb, la connexion GORM deja etablie.
// Sortie : valeur retour de type *gin.Engine.
func newRouter(gdb *gorm.DB) *gin.Engine {
	router := server.NewRouter()
	router.GET("/health", health)
	users.RegisterRoutes(router, users.NewHandler(gdb))
	notifications.RegisterRoutes(router, notifications.NewHandler(gdb))

	return router
}

// health indique l'etat du service utilisateurs et de sa connexion PostgreSQL.
// Entree : c.
// Sortie HTTP : JSON contenant le nom du service, status=ok et l'etat db.
func health(c *gin.Context) {
	dbStatus := "ok"
	if gdb == nil {
		dbStatus = "unavailable"
	} else if sqlDB, err := gdb.DB(); err != nil || sqlDB.PingContext(c.Request.Context()) != nil {
		dbStatus = "error"
	}

	c.JSON(http.StatusOK, gin.H{
		"service": config.Env("SERVICE_NAME", "user-service"),
		"status":  "ok",
		"db":      dbStatus,
	})
}
