package main

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var errPingFailed = errors.New("ping failed")

// newMockDB cree une connexion GORM adossee a sqlmock pour exercer newRouter()
// sans dependre d'une vraie base Postgres. Le monitoring des pings est
// active pour pouvoir simuler un succes/echec de ExpectPing().
func newMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New(sqlmock.MonitorPingsOption(true))
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })

	gdb, err := gorm.Open(postgres.New(postgres.Config{
		Conn:                 sqlDB,
		PreferSimpleProtocol: true,
	}), &gorm.Config{
		Logger:               logger.Default.LogMode(logger.Silent),
		DisableAutomaticPing: true,
	})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return gdb, mock
}

func TestNewRouterHealthDBOk(t *testing.T) {
	gin.SetMode(gin.TestMode)
	mockDB, mock := newMockDB(t)
	mock.ExpectPing()
	previous := gdb
	gdb = mockDB
	defer func() { gdb = previous }()

	router := newRouter(mockDB)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if body := rec.Body.String(); !containsAll(body, "user-service", `"db":"ok"`) {
		t.Fatalf("body = %q, want db ok", body)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations: %v", err)
	}
}

func TestNewRouterHealthDBError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	mockDB, mock := newMockDB(t)
	mock.ExpectPing().WillReturnError(errPingFailed)
	previous := gdb
	gdb = mockDB
	defer func() { gdb = previous }()

	router := newRouter(mockDB)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if body := rec.Body.String(); !containsAll(body, "user-service", `"db":"error"`) {
		t.Fatalf("body = %q, want db error", body)
	}
}

func TestNewRouterRegistersUsersRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	mockDB, _ := newMockDB(t)

	router := newRouter(mockDB)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/suggestions", nil))

	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status = %d, want 401 (route exists but requires auth)", rec.Code)
	}
}

func TestNewRouterRegistersNotificationsRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	mockDB, _ := newMockDB(t)

	router := newRouter(mockDB)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/notifications", nil))

	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status = %d, want 401 (route exists but requires auth)", rec.Code)
	}
}

func TestHealthWithoutDatabase(t *testing.T) {
	gin.SetMode(gin.TestMode)
	previous := gdb
	gdb = nil
	defer func() { gdb = previous }()

	router := gin.New()
	router.GET("/health", health)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", rec.Code)
	}
	if body := rec.Body.String(); !containsAll(body, "user-service", "unavailable") {
		t.Fatalf("body = %q, want service/db status", body)
	}
}

func containsAll(value string, parts ...string) bool {
	for _, part := range parts {
		if !contains(value, part) {
			return false
		}
	}
	return true
}

func contains(value, part string) bool {
	for i := 0; i+len(part) <= len(value); i++ {
		if value[i:i+len(part)] == part {
			return true
		}
	}
	return part == ""
}
