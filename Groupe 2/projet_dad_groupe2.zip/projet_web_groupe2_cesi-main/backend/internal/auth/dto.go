package auth

import (
	"errors"
	"strings"
	"time"

	"breezy/backend/internal/validation"
	"github.com/google/uuid"
)

// loginRequest represente l'entree JSON de connexion.
// Champs attendus : email valide et password non vide.
type loginRequest struct {
	Email    string `json:"email" binding:"required,email"`
	Password string `json:"password" binding:"required"`
}

func (r loginRequest) Validate() error {
	if len(strings.TrimSpace(r.Email)) > 254 {
		return errors.New("email is too long")
	}
	if len(strings.TrimSpace(r.Password)) > 256 {
		return errors.New("password is too long")
	}
	return nil
}

// registerRequest represente l'entree JSON d'inscription.
// Champs attendus : email valide et password d'au moins 8 caracteres.
type registerRequest struct {
	Email       string `json:"email" binding:"required,email"`
	Password    string `json:"password" binding:"required,min=12"`
	Username    string `json:"username" binding:"required,min=3,max=30"`
	DisplayName string `json:"displayName" binding:"required,min=1,max=80"`
}

func (r registerRequest) Validate() error {
	if len(strings.TrimSpace(r.Email)) > 254 {
		return errors.New("email is too long")
	}
	if err := validation.Username(r.Username); err != nil {
		return err
	}
	if _, err := validation.TrimmedRequired(r.DisplayName, 80, "displayName"); err != nil {
		return err
	}
	if len(strings.TrimSpace(r.Password)) > 256 {
		return errors.New("password is too long")
	}
	if err := validation.Password(r.Password, r.Username, r.Email, r.DisplayName); err != nil {
		return err
	}
	return nil
}

type resendVerificationRequest struct {
	Email string `json:"email" binding:"required,email"`
}

func (r resendVerificationRequest) Validate() error {
	if len(strings.TrimSpace(r.Email)) > 254 {
		return errors.New("email is too long")
	}
	return nil
}

// logoutRequest represente l'entree JSON de deconnexion.
// Champ optionnel : refreshToken, car le handler accepte aussi le header Bearer.
type logoutRequest struct {
	RefreshToken string `json:"refreshToken"`
}

func (r logoutRequest) Validate() error {
	if len(strings.TrimSpace(r.RefreshToken)) > 4096 {
		return errors.New("refreshToken is too long")
	}
	return nil
}

// refreshRequest represente l'entree JSON de renouvellement de session.
// Champ attendu : refreshToken obligatoire.
type refreshRequest struct {
	RefreshToken string `json:"refreshToken"`
}

func (r refreshRequest) Validate() error {
	if len(strings.TrimSpace(r.RefreshToken)) > 4096 {
		return errors.New("refreshToken is too long")
	}
	return nil
}

// authResponse represente la sortie JSON apres authentification.
// Champs retournes : accessToken, refreshToken, type de token, duree de vie et
// utilisateur public.
type authResponse struct {
	AccessToken  string          `json:"accessToken,omitempty"`
	RefreshToken string          `json:"refreshToken,omitempty"`
	TokenType    string          `json:"tokenType,omitempty"`
	ExpiresIn    int64           `json:"expiresIn"`
	User         accountResponse `json:"user"`
}

type registerResponse struct {
	Message                   string          `json:"message"`
	RequiresEmailVerification bool            `json:"requiresEmailVerification"`
	VerificationEmailSent     bool            `json:"verificationEmailSent"`
	User                      accountResponse `json:"user"`
}

type messageResponse struct {
	Message string `json:"message"`
}

// accountResponse represente la sortie JSON publique d'un compte.
// Champs retournes : id, email, role et status, sans hash de mot de passe.
type accountResponse struct {
	ID          uuid.UUID  `json:"id"`
	ProfileID   *uuid.UUID `json:"profileId,omitempty"`
	Username    string     `json:"username,omitempty"`
	DisplayName string     `json:"displayName,omitempty"`
	Email       string     `json:"email"`
	Role        string     `json:"role"`
	Status      string     `json:"status"`
	LastLoginAt *time.Time `json:"lastLoginAt,omitempty"`
}

type updateAccountStatusRequest struct {
	Status string `json:"status" binding:"required"`
}

func (r updateAccountStatusRequest) Validate() error {
	return validation.OneOf(r.Status, "ACTIVE", "SUSPENDED", "BANNED")
}

// changePasswordRequest represente l'entree JSON de changement de mot de passe.
// Champs attendus : currentPassword non vide et newPassword d'au moins 8 caracteres.
type changePasswordRequest struct {
	CurrentPassword string `json:"currentPassword" binding:"required"`
	NewPassword     string `json:"newPassword" binding:"required,min=8"`
}

func (r changePasswordRequest) Validate() error {
	if len(strings.TrimSpace(r.CurrentPassword)) > 256 || len(strings.TrimSpace(r.NewPassword)) > 256 {
		return errors.New("password is too long")
	}
	return nil
}

// forgotPasswordRequest represente l'entree JSON de demande de reinitialisation.
// Champ attendu : email valide.
type forgotPasswordRequest struct {
	Email string `json:"email" binding:"required,email"`
}

func (r forgotPasswordRequest) Validate() error {
	if len(strings.TrimSpace(r.Email)) > 254 {
		return errors.New("email is too long")
	}
	return nil
}

// resetPasswordRequest represente l'entree JSON de reinitialisation de mot de passe.
// Champs attendus : token brut recu par e-mail et newPassword d'au moins 8 caracteres.
type resetPasswordRequest struct {
	Token       string `json:"token" binding:"required"`
	NewPassword string `json:"newPassword" binding:"required,min=8"`
}

func (r resetPasswordRequest) Validate() error {
	if _, err := validation.TrimmedRequired(r.Token, 4096, "token"); err != nil {
		return err
	}
	if len(strings.TrimSpace(r.NewPassword)) > 256 {
		return errors.New("password is too long")
	}
	return nil
}
