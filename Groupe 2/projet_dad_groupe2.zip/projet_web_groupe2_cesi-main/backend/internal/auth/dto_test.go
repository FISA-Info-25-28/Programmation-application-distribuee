package auth

import (
	"strings"
	"testing"
)

func TestLoginRequestValidate(t *testing.T) {
	if err := (loginRequest{Email: "user@example.com", Password: "secret"}).Validate(); err != nil {
		t.Fatalf("loginRequest.Validate() unexpected error: %v", err)
	}
	if err := (loginRequest{Email: strings.Repeat("a", 255), Password: "secret"}).Validate(); err == nil {
		t.Fatal("loginRequest.Validate() expected email length error")
	}
	if err := (loginRequest{Email: "user@example.com", Password: strings.Repeat("x", 257)}).Validate(); err == nil {
		t.Fatal("loginRequest.Validate() expected password length error")
	}
}

func TestPasswordLifecycleRequestValidate(t *testing.T) {
	if err := (resendVerificationRequest{Email: "user@example.com"}).Validate(); err != nil {
		t.Fatalf("resendVerificationRequest.Validate() unexpected error: %v", err)
	}
	if err := (forgotPasswordRequest{Email: "user@example.com"}).Validate(); err != nil {
		t.Fatalf("forgotPasswordRequest.Validate() unexpected error: %v", err)
	}
	if err := (changePasswordRequest{CurrentPassword: "old", NewPassword: "new"}).Validate(); err != nil {
		t.Fatalf("changePasswordRequest.Validate() unexpected error: %v", err)
	}
	if err := (resetPasswordRequest{Token: "token", NewPassword: "new"}).Validate(); err != nil {
		t.Fatalf("resetPasswordRequest.Validate() unexpected error: %v", err)
	}

	if err := (resendVerificationRequest{Email: strings.Repeat("a", 255)}).Validate(); err == nil {
		t.Fatal("resendVerificationRequest.Validate() expected long email error")
	}
	if err := (forgotPasswordRequest{Email: strings.Repeat("a", 255)}).Validate(); err == nil {
		t.Fatal("forgotPasswordRequest.Validate() expected long email error")
	}
	if err := (changePasswordRequest{CurrentPassword: strings.Repeat("a", 257)}).Validate(); err == nil {
		t.Fatal("changePasswordRequest.Validate() expected long password error")
	}
	if err := (resetPasswordRequest{Token: "", NewPassword: "new"}).Validate(); err == nil {
		t.Fatal("resetPasswordRequest.Validate() expected empty token error")
	}
}

func TestRegisterRequestValidate(t *testing.T) {
	valid := registerRequest{
		Email:       "new@example.com",
		Password:    "StrongPass1!",
		Username:    "new_user",
		DisplayName: "New User",
	}
	if err := valid.Validate(); err != nil {
		t.Fatalf("registerRequest.Validate() unexpected error: %v", err)
	}

	tests := []registerRequest{
		{Email: strings.Repeat("a", 255), Password: "StrongPass1!", Username: "new_user", DisplayName: "New User"},
		{Email: "new@example.com", Password: "StrongPass1!", Username: "no-dash", DisplayName: "New User"},
		{Email: "new@example.com", Password: "StrongPass1!", Username: "new_user", DisplayName: ""},
		{Email: "new@example.com", Password: "weak", Username: "new_user", DisplayName: "New User"},
		{Email: "new@example.com", Password: "Aa1!" + strings.Repeat("x", 254), Username: "new_user", DisplayName: "New User"},
	}
	for _, req := range tests {
		if err := req.Validate(); err == nil {
			t.Fatalf("registerRequest.Validate(%+v) expected error", req)
		}
	}
}

func TestTokenRequestValidation(t *testing.T) {
	if err := (logoutRequest{RefreshToken: strings.Repeat("x", 4097)}).Validate(); err == nil {
		t.Fatal("logoutRequest.Validate() expected token length error")
	}
	if err := (refreshRequest{RefreshToken: strings.Repeat("x", 4097)}).Validate(); err == nil {
		t.Fatal("refreshRequest.Validate() expected token length error")
	}
	if err := (resetPasswordRequest{Token: " token ", NewPassword: "StrongPass1!"}).Validate(); err != nil {
		t.Fatalf("resetPasswordRequest.Validate() unexpected error: %v", err)
	}
	if err := (resetPasswordRequest{Token: " ", NewPassword: "StrongPass1!"}).Validate(); err == nil {
		t.Fatal("resetPasswordRequest.Validate() expected token required error")
	}
	if err := (resetPasswordRequest{Token: "token", NewPassword: strings.Repeat("x", 257)}).Validate(); err == nil {
		t.Fatal("resetPasswordRequest.Validate() expected new password length error")
	}
}

func TestAccountStatusValidation(t *testing.T) {
	for _, status := range []string{"ACTIVE", "suspended", " BANNED "} {
		if err := (updateAccountStatusRequest{Status: status}).Validate(); err != nil {
			t.Fatalf("updateAccountStatusRequest.Validate(%q) unexpected error: %v", status, err)
		}
	}
	if err := (updateAccountStatusRequest{Status: "DELETED"}).Validate(); err == nil {
		t.Fatal("updateAccountStatusRequest.Validate() expected invalid status error")
	}
}
