package auth

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"breezy/backend/internal/config"
	"breezy/backend/internal/models"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// Types GitHub OAuth

type githubTokenResp struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
}

type githubUser struct {
	ID    int64  `json:"id"`
	Login string `json:"login"`
	Name  string `json:"name"`
	Email string `json:"email"`
}

type githubEmail struct {
	Email    string `json:"email"`
	Primary  bool   `json:"primary"`
	Verified bool   `json:"verified"`
}

// Handlers HTTP

// GitHubLogin redirige vers la page d'authentification GitHub.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) GitHubLogin(c *gin.Context) {
	clientID := config.Env("GITHUB_CLIENT_ID", "")
	if clientID == "" {
		c.JSON(http.StatusNotImplemented, gin.H{"error": "github oauth not configured"})
		return
	}

	state, err := randomToken(16)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "oauth state generation failed"})
		return
	}

	secure := strings.EqualFold(config.Env("COOKIE_SECURE", "false"), "true")
	http.SetCookie(c.Writer, &http.Cookie{
		Name:     "breezy_gh_state",
		Value:    state,
		Path:     "/",
		MaxAge:   600,
		HttpOnly: true,
		Secure:   secure,
		SameSite: http.SameSiteLaxMode,
	})

	authURL := "https://github.com/login/oauth/authorize?" + url.Values{
		"client_id": {clientID},
		"scope":     {"user:email"},
		"state":     {state},
	}.Encode()

	c.Redirect(http.StatusFound, authURL)
}

// GitHubCallback traite le retour GitHub apres que l'utilisateur a autorise l'acces.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) GitHubCallback(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	clientID := config.Env("GITHUB_CLIENT_ID", "")
	if clientID == "" {
		c.JSON(http.StatusNotImplemented, gin.H{"error": "github oauth not configured"})
		return
	}

	frontendURL := strings.TrimRight(config.Env("FRONTEND_PUBLIC_URL", "http://localhost"), "/")

	// Verifie le state CSRF
	stateCookie := cookieValue(c, "breezy_gh_state")
	if stateCookie == "" || stateCookie != c.Query("state") {
		c.Redirect(http.StatusFound, frontendURL+"/auth?githubError=state")
		return
	}

	// Efface le cookie d'etat
	http.SetCookie(c.Writer, &http.Cookie{
		Name:     "breezy_gh_state",
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		HttpOnly: true,
	})

	code := c.Query("code")
	if code == "" {
		c.Redirect(http.StatusFound, frontendURL+"/auth?githubError=cancelled")
		return
	}

	token, err := exchangeGitHubCode(code, clientID, config.Env("GITHUB_CLIENT_SECRET", ""))
	if err != nil {
		c.Redirect(http.StatusFound, frontendURL+"/auth?githubError=token")
		return
	}

	ghUser, err := fetchGitHubUser(token.AccessToken)
	if err != nil {
		c.Redirect(http.StatusFound, frontendURL+"/auth?githubError=userinfo")
		return
	}

	// L'email peut etre prive sur GitHub - on le recupere via /user/emails
	email := strings.TrimSpace(ghUser.Email)
	if email == "" {
		email, err = fetchGitHubPrimaryEmail(token.AccessToken)
		if err != nil {
			c.Redirect(http.StatusFound, frontendURL+"/auth?githubError=email")
			return
		}
	}

	displayName := strings.TrimSpace(ghUser.Name)
	if displayName == "" {
		displayName = ghUser.Login
	}

	response, err := h.service.FindOrCreateGitHubAccount(c.Request.Context(), email, displayName, ghUser.Login)
	if err != nil {
		c.Redirect(http.StatusFound, frontendURL+"/auth?githubError=account")
		return
	}

	h.setAuthCookies(c, response)
	c.Redirect(http.StatusFound, frontendURL+"/auth?github=1")
}

// Appels API GitHub

func exchangeGitHubCode(code, clientID, clientSecret string) (githubTokenResp, error) {
	req, err := http.NewRequest(http.MethodPost, "https://github.com/login/oauth/access_token",
		strings.NewReader(url.Values{
			"code":          {code},
			"client_id":     {clientID},
			"client_secret": {clientSecret},
		}.Encode()))
	if err != nil {
		return githubTokenResp{}, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Accept", "application/json")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return githubTokenResp{}, err
	}
	defer resp.Body.Close()

	var result githubTokenResp
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return githubTokenResp{}, err
	}
	if result.AccessToken == "" {
		return githubTokenResp{}, errors.New("no access token in github response")
	}
	return result, nil
}

func fetchGitHubUser(accessToken string) (githubUser, error) {
	req, err := http.NewRequest(http.MethodGet, "https://api.github.com/user", nil)
	if err != nil {
		return githubUser{}, err
	}
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("Accept", "application/vnd.github+json")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return githubUser{}, err
	}
	defer resp.Body.Close()

	var user githubUser
	if err := json.NewDecoder(resp.Body).Decode(&user); err != nil {
		return githubUser{}, err
	}
	return user, nil
}

func fetchGitHubPrimaryEmail(accessToken string) (string, error) {
	req, err := http.NewRequest(http.MethodGet, "https://api.github.com/user/emails", nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("Accept", "application/vnd.github+json")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	var emails []githubEmail
	if err := json.NewDecoder(resp.Body).Decode(&emails); err != nil {
		return "", err
	}

	for _, e := range emails {
		if e.Primary && e.Verified {
			return e.Email, nil
		}
	}
	for _, e := range emails {
		if e.Verified {
			return e.Email, nil
		}
	}
	return "", errors.New("no verified email found on github account")
}

// Logique metier GitHub

// FindOrCreateGitHubAccount connecte un utilisateur GitHub ou cree un nouveau compte.
// Entree : ctx, email, displayName, githubLogin.
// Sortie : valeurs retour de la fonction.
func (s *Service) FindOrCreateGitHubAccount(ctx context.Context, email, displayName, githubLogin string) (authResponse, error) {
	email = strings.ToLower(strings.TrimSpace(email))
	displayName = strings.TrimSpace(displayName)

	account, err := s.repo.FindAccountByEmail(ctx, email)
	if err == nil {
		if account.Status != "ACTIVE" {
			return authResponse{}, ErrInactiveAccount
		}
		if account.EmailVerifiedAt == nil {
			now := time.Now().UTC()
			account.EmailVerifiedAt = &now
			_ = s.repo.UpdateAccount(ctx, &account)
		}
		return createAuthResponse(ctx, s.repo, account)
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return authResponse{}, err
	}

	username, err := s.generateGitHubUsername(ctx, githubLogin, email, displayName)
	if err != nil {
		return authResponse{}, err
	}

	now := time.Now().UTC()
	account = models.Account{
		Email:           email,
		PasswordHash:    "$github$",
		Role:            "USER",
		Status:          "ACTIVE",
		EmailVerifiedAt: &now,
	}

	var response authResponse
	err = s.repo.Transaction(ctx, func(txRepo *Repository) error {
		if err := txRepo.CreateAccount(ctx, &account); err != nil {
			return err
		}

		profile := models.Profile{
			AccountID:   account.ID,
			Username:    username,
			DisplayName: &displayName,
		}
		if err := txRepo.CreateProfile(ctx, &profile); err != nil {
			return err
		}

		var txErr error
		response, txErr = createAuthResponse(ctx, txRepo, account)
		return txErr
	})

	return response, err
}

// generateGitHubUsername cree un username unique en privilegiant le login GitHub.
// Entree : ctx, githubLogin, email, displayName.
// Sortie : valeurs retour de la fonction.
func (s *Service) generateGitHubUsername(ctx context.Context, githubLogin, email, displayName string) (string, error) {
	var candidates []string

	// Le login GitHub est souvent deja un bon username
	loginBase := nonAlphaNumRe.ReplaceAllString(strings.ToLower(githubLogin), "")
	if len(loginBase) >= 3 {
		if len(loginBase) > 30 {
			loginBase = loginBase[:30]
		}
		candidates = append(candidates, loginBase)
	}

	nameBase := nonAlphaNumRe.ReplaceAllString(strings.ToLower(displayName), "")
	if len(nameBase) >= 3 {
		if len(nameBase) > 30 {
			nameBase = nameBase[:30]
		}
		candidates = append(candidates, nameBase)
	}

	emailBase := nonAlphaNumRe.ReplaceAllString(strings.ToLower(strings.Split(email, "@")[0]), "")
	if len(emailBase) >= 3 {
		if len(emailBase) > 30 {
			emailBase = emailBase[:30]
		}
		candidates = append(candidates, emailBase)
	}

	for _, base := range candidates {
		if ok, _ := s.UsernameAvailable(ctx, base); ok {
			return base, nil
		}
		for i := 1; i <= 99; i++ {
			candidate := fmt.Sprintf("%s%d", base, i)
			if len(candidate) > 30 {
				candidate = fmt.Sprintf("%s%d", base[:28], i)
			}
			if ok, _ := s.UsernameAvailable(ctx, candidate); ok {
				return candidate, nil
			}
		}
	}

	tok, err := randomToken(8)
	if err != nil {
		return "", err
	}
	return "user" + tok[:8], nil
}
