package auth

import (
	"context"
	"errors"
	"strings"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

func TestFindOrCreateGitHubAccountExistingActiveVerified(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "$github$", "USER", "ACTIVE", &now, nil))
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))

	resp, err := service.FindOrCreateGitHubAccount(ctx, "Alice@Example.com", "Alice", "alice-gh")
	if err != nil || resp.AccessToken == "" {
		t.Fatalf("FindOrCreateGitHubAccount(existing) = %+v, %v", resp, err)
	}
}

func TestFindOrCreateGitHubAccountExistingUnverifiedAutoVerifies(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "$github$", "USER", "ACTIVE", nil, nil))
	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))

	resp, err := service.FindOrCreateGitHubAccount(ctx, "alice@example.com", "Alice", "alice-gh")
	if err != nil || resp.AccessToken == "" {
		t.Fatalf("FindOrCreateGitHubAccount(unverified) = %+v, %v", resp, err)
	}
}

func TestFindOrCreateGitHubAccountExistingInactive(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "$github$", "USER", "BANNED", &now, nil))

	if _, err := service.FindOrCreateGitHubAccount(ctx, "alice@example.com", "Alice", "alice-gh"); !errors.Is(err, ErrInactiveAccount) {
		t.Fatalf("FindOrCreateGitHubAccount(inactive) error = %v", err)
	}
}

func TestFindOrCreateGitHubAccountLookupError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	dbErr := errors.New("db down")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(dbErr)

	if _, err := service.FindOrCreateGitHubAccount(ctx, "alice@example.com", "Alice", "alice-gh"); !errors.Is(err, dbErr) {
		t.Fatalf("FindOrCreateGitHubAccount(lookup error) error = %v, want %v", err, dbErr)
	}
}

func TestFindOrCreateGitHubAccountNewAccount(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectQuery(`INSERT INTO "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice-gh", nil))
	mock.ExpectCommit()

	resp, err := service.FindOrCreateGitHubAccount(ctx, "newuser@example.com", "New User", "alice-gh")
	if err != nil || resp.AccessToken == "" {
		t.Fatalf("FindOrCreateGitHubAccount(new) = %+v, %v", resp, err)
	}
}

func TestFindOrCreateGitHubAccountUsernameGenerationErrorIgnoredAndRetried(t *testing.T) {
	// UsernameAvailable() avale les erreurs DB autres que RecordNotFound dans
	// generateGitHubUsername (boucle "_, _ := ..."), donc le flux continue avec
	// le candidat suivant plutot que de faire echouer la creation de compte.
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	dbErr := errors.New("db down")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	// Premier candidat (login "newusergh") : erreur DB avalee par UsernameAvailable.
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(dbErr)
	// Les 99 suffixes du meme candidat echouent aussi de la meme facon.
	for i := 1; i <= 99; i++ {
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnError(dbErr)
	}
	// Candidat suivant (displayName "newusergh") : meme nom, donc identique.
	for i := 0; i < 100; i++ {
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnError(dbErr)
	}
	// Candidat email "newuser" : libre.
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectQuery(`INSERT INTO "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "newuser", nil))
	mock.ExpectCommit()

	resp, err := service.FindOrCreateGitHubAccount(ctx, "newuser@example.com", "newusergh", "newusergh")
	if err != nil || resp.AccessToken == "" {
		t.Fatalf("FindOrCreateGitHubAccount(username gen db error ignored) = %+v, %v", resp, err)
	}
}

func TestFindOrCreateGitHubAccountCreateProfileError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	dbErr := errors.New("profile insert failed")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectQuery(`INSERT INTO "profiles"\."profiles"`).WillReturnError(dbErr)
	mock.ExpectRollback()

	if _, err := service.FindOrCreateGitHubAccount(ctx, "newuser@example.com", "New User", "newuser-gh"); !errors.Is(err, dbErr) {
		t.Fatalf("FindOrCreateGitHubAccount(create profile error) error = %v, want %v", err, dbErr)
	}
}

func TestFindOrCreateGitHubAccountTransactionError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	dbErr := errors.New("insert failed")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).WillReturnError(dbErr)
	mock.ExpectRollback()

	if _, err := service.FindOrCreateGitHubAccount(ctx, "newuser@example.com", "New User", "newuser-gh"); !errors.Is(err, dbErr) {
		t.Fatalf("FindOrCreateGitHubAccount(transaction error) error = %v, want %v", err, dbErr)
	}
}

// --- generateGitHubUsername ---

func TestGenerateGitHubUsernamePrefersLogin(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)

	username, err := service.generateGitHubUsername(ctx, "Alice-GH!!", "alice@example.com", "Alice Example")
	if err != nil || username != "alicegh" {
		t.Fatalf("generateGitHubUsername() = %q, %v, want alicegh", username, err)
	}
}

func TestGenerateGitHubUsernameCollisionIncrementsSuffix(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	// "alicegh" deja pris, "alicegh1" aussi, "alicegh2" libre.
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnRows(profileRows(uuid.New(), uuid.New(), "alicegh", nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnRows(profileRows(uuid.New(), uuid.New(), "alicegh1", nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)

	username, err := service.generateGitHubUsername(ctx, "alice-gh", "alice@example.com", "Alice Example")
	if err != nil || username != "alicegh2" {
		t.Fatalf("generateGitHubUsername(collision) = %q, %v, want alicegh2", username, err)
	}
}

func TestGenerateGitHubUsernameFallsBackToDisplayNameThenEmail(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	// login vide -> ignore, displayName "Alice Example" -> "aliceexample" pris,
	// puis tous les suffixes 1..99 pris, fallback sur l'email.
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnRows(profileRows(uuid.New(), uuid.New(), "aliceexample", nil))
	for i := 1; i <= 99; i++ {
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnRows(profileRows(uuid.New(), uuid.New(), "taken", nil))
	}
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)

	username, err := service.generateGitHubUsername(ctx, "", "alice@example.com", "Alice Example")
	if err != nil || username != "alice" {
		t.Fatalf("generateGitHubUsername(fallback to email) = %q, %v, want alice", username, err)
	}
}

func TestGenerateGitHubUsernameTruncatesLongCandidates(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	// Login de 35 caracteres -> tronque a 30 avant la requete.
	longLogin := strings.Repeat("a", 35)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)

	username, err := service.generateGitHubUsername(ctx, longLogin, "x@example.com", "")
	if err != nil || len(username) != 30 {
		t.Fatalf("generateGitHubUsername(long login) = %q (len %d), %v, want 30-char truncated username", username, len(username), err)
	}
}

func TestGenerateGitHubUsernameTruncatesLongDisplayNameAndEmail(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	longName := strings.Repeat("b", 35)
	longEmailLocal := strings.Repeat("c", 35)

	// login vide -> ignore; displayName tronque a 30 -> pris (collision) -> tous
	// les suffixes pris -> email tronque a 30 -> libre.
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnRows(profileRows(uuid.New(), uuid.New(), strings.Repeat("b", 30), nil))
	for i := 1; i <= 99; i++ {
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnRows(profileRows(uuid.New(), uuid.New(), "taken", nil))
	}
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)

	username, err := service.generateGitHubUsername(ctx, "", longEmailLocal+"@example.com", longName)
	if err != nil || len(username) != 30 {
		t.Fatalf("generateGitHubUsername(long name/email) = %q (len %d), %v, want 30-char truncated email-based username", username, len(username), err)
	}
}

func TestGenerateGitHubUsernameTruncatesLongCandidateSuffix(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	// Login de 30 caracteres : "base" est deja pris, donc le candidat suivant
	// "base"+"1" depasse 30 caracteres et doit etre tronque a base[:28]+"1".
	base := strings.Repeat("d", 30)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnRows(profileRows(uuid.New(), uuid.New(), base, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)

	username, err := service.generateGitHubUsername(ctx, base, "x@example.com", "")
	wantPrefix := base[:28]
	if err != nil || username != wantPrefix+"1" {
		t.Fatalf("generateGitHubUsername(long candidate suffix) = %q, %v, want %q", username, err, wantPrefix+"1")
	}
}

func TestGenerateGitHubUsernameFallsBackToRandomToken(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	// Tous les candidats (login, nom, email) ont moins de 3 caracteres utiles ->
	// aucune requete n'est emise, fallback direct sur un token aleatoire.
	username, err := service.generateGitHubUsername(ctx, "", "a@b.com", "")
	if err != nil || len(username) < 4 || username[:4] != "user" {
		t.Fatalf("generateGitHubUsername(no candidates) = %q, %v, want user-prefixed token", username, err)
	}
	if mock.ExpectationsWereMet() != nil {
		t.Fatal("no SQL query expected when no candidate is long enough")
	}
}
