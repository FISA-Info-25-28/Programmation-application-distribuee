package auth

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
)

func TestGitHubLoginNotConfigured(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GITHUB_CLIENT_ID", "")

	router := gin.New()
	router.GET("/github", NewHandler(nil).GitHubLogin)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/github", nil))

	if rec.Code != http.StatusNotImplemented {
		t.Fatalf("GitHubLogin status = %d, want 501", rec.Code)
	}
}

func TestGitHubCallbackDatabaseUnavailable(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.GET("/github/callback", NewHandler(nil).GitHubCallback)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/github/callback", nil))

	if rec.Code != http.StatusServiceUnavailable {
		t.Fatalf("GitHubCallback status = %d, want 503", rec.Code)
	}
}

func TestGitHubAccountServiceDryRun(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	service := NewService(NewRepository(authDryRunDB(t)), noopVerificationMailer{})

	_, _ = service.FindOrCreateGitHubAccount(context.Background(), "alice@example.com", "Alice Example", "alice-gh")
	_, _ = service.generateGitHubUsername(context.Background(), "alice-gh", "alice@example.com", "Alice Example")
	_, _ = service.generateGitHubUsername(context.Background(), "", "bad", "")
}

func TestGitHubLoginRedirectsWhenConfigured(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GITHUB_CLIENT_ID", "client-id")

	router := gin.New()
	router.GET("/github", NewHandler(nil).GitHubLogin)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/github", nil))

	location := rec.Header().Get("Location")
	if rec.Code != http.StatusFound || !strings.Contains(location, "github.com/login/oauth/authorize") || !strings.Contains(location, "client_id=client-id") {
		t.Fatalf("GitHubLogin redirect status/location = %d/%q", rec.Code, location)
	}
	if cookie := rec.Result().Cookies(); len(cookie) == 0 {
		t.Fatal("GitHubLogin should set oauth state cookie")
	}
}
