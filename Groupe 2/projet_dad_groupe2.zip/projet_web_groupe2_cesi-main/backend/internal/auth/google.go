package auth

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"

	"breezy/backend/internal/config"
	"breezy/backend/internal/models"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// nonAlphaNumRe supprime tout ce qui n'est pas lettre, chiffre ou underscore.
var nonAlphaNumRe = regexp.MustCompile(`[^A-Za-z0-9_]`)

// Types Google OAuth

type googleTokenResp struct {
	AccessToken string `json:"access_token"`
}

type googleUserInfo struct {
	Sub           string `json:"sub"`
	Email         string `json:"email"`
	EmailVerified bool   `json:"email_verified"`
	Name          string `json:"name"`
	GivenName     string `json:"given_name"`
}

// Handlers HTTP

// GoogleLogin redirige le navigateur vers la page d'authentification Google.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) GoogleLogin(c *gin.Context) {
	clientID := config.Env("GOOGLE_CLIENT_ID", "")
	if clientID == "" {
		c.JSON(http.StatusNotImplemented, gin.H{"error": "google oauth not configured"})
		return
	}

	state, err := randomToken(16)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "oauth state generation failed"})
		return
	}

	secure := strings.EqualFold(config.Env("COOKIE_SECURE", "false"), "true")
	http.SetCookie(c.Writer, &http.Cookie{
		Name:     "breezy_oauth_state",
		Value:    state,
		Path:     "/",
		MaxAge:   600,
		HttpOnly: true,
		Secure:   secure,
		SameSite: http.SameSiteLaxMode,
	})

	redirectURI := config.Env("GOOGLE_REDIRECT_URL", "http://localhost:8080/api/auth/google/callback")
	authURL := "https://accounts.google.com/o/oauth2/v2/auth?" + url.Values{
		"client_id":     {clientID},
		"redirect_uri":  {redirectURI},
		"response_type": {"code"},
		"scope":         {"email profile"},
		"state":         {state},
		"prompt":        {"select_account"},
	}.Encode()

	c.Redirect(http.StatusFound, authURL)
}

// GoogleCallback traite le retour Google apres que l'utilisateur a accorde l'acces.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) GoogleCallback(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	clientID := config.Env("GOOGLE_CLIENT_ID", "")
	if clientID == "" {
		c.JSON(http.StatusNotImplemented, gin.H{"error": "google oauth not configured"})
		return
	}

	frontendURL := strings.TrimRight(config.Env("FRONTEND_PUBLIC_URL", "http://localhost"), "/")

	// Verifie le state CSRF
	stateCookie := cookieValue(c, "breezy_oauth_state")
	if stateCookie == "" || stateCookie != c.Query("state") {
		c.Redirect(http.StatusFound, frontendURL+"/auth?googleError=state")
		return
	}

	// Efface le cookie d'etat apres verification
	http.SetCookie(c.Writer, &http.Cookie{
		Name:     "breezy_oauth_state",
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		HttpOnly: true,
	})

	code := c.Query("code")
	if code == "" {
		c.Redirect(http.StatusFound, frontendURL+"/auth?googleError=cancelled")
		return
	}

	redirectURI := config.Env("GOOGLE_REDIRECT_URL", "http://localhost:8080/api/auth/google/callback")
	token, err := exchangeGoogleCode(code, clientID, config.Env("GOOGLE_CLIENT_SECRET", ""), redirectURI)
	if err != nil {
		c.Redirect(http.StatusFound, frontendURL+"/auth?googleError=token")
		return
	}

	info, err := fetchGoogleUserInfo(token.AccessToken)
	if err != nil {
		c.Redirect(http.StatusFound, frontendURL+"/auth?googleError=userinfo")
		return
	}

	response, err := h.service.FindOrCreateGoogleAccount(c.Request.Context(), info.Email, info.Name)
	if err != nil {
		c.Redirect(http.StatusFound, frontendURL+"/auth?googleError=account")
		return
	}

	h.setAuthCookies(c, response)
	c.Redirect(http.StatusFound, frontendURL+"/auth?google=1")
}

// Appels API Google

func exchangeGoogleCode(code, clientID, clientSecret, redirectURI string) (googleTokenResp, error) {
	resp, err := http.PostForm("https://oauth2.googleapis.com/token", url.Values{
		"code":          {code},
		"client_id":     {clientID},
		"client_secret": {clientSecret},
		"redirect_uri":  {redirectURI},
		"grant_type":    {"authorization_code"},
	})
	if err != nil {
		return googleTokenResp{}, err
	}
	defer resp.Body.Close()

	var result googleTokenResp
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return googleTokenResp{}, err
	}
	if result.AccessToken == "" {
		return googleTokenResp{}, errors.New("no access token in google response")
	}
	return result, nil
}

func fetchGoogleUserInfo(accessToken string) (googleUserInfo, error) {
	req, err := http.NewRequest(http.MethodGet, "https://www.googleapis.com/oauth2/v3/userinfo", nil)
	if err != nil {
		return googleUserInfo{}, err
	}
	req.Header.Set("Authorization", "Bearer "+accessToken)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return googleUserInfo{}, err
	}
	defer resp.Body.Close()

	var info googleUserInfo
	if err := json.NewDecoder(resp.Body).Decode(&info); err != nil {
		return googleUserInfo{}, err
	}
	if info.Email == "" {
		return googleUserInfo{}, errors.New("no email in google user info")
	}
	return info, nil
}

// Logique metier Google

// FindOrCreateGoogleAccount connecte un utilisateur Google existant ou cree un
// nouveau compte sans mot de passe, avec l'email auto-verifie.
// Entree : ctx, email, displayName.
// Sortie : valeurs retour de la fonction.
func (s *Service) FindOrCreateGoogleAccount(ctx context.Context, email, displayName string) (authResponse, error) {
	email = strings.ToLower(strings.TrimSpace(email))
	displayName = strings.TrimSpace(displayName)

	account, err := s.repo.FindAccountByEmail(ctx, email)
	if err == nil {
		// Compte existant
		if account.Status != "ACTIVE" {
			return authResponse{}, ErrInactiveAccount
		}
		// Auto-verifie si ce n'etait pas encore fait
		if account.EmailVerifiedAt == nil {
			now := time.Now().UTC()
			account.EmailVerifiedAt = &now
			_ = s.repo.UpdateAccount(ctx, &account)
		}
		return createAuthResponse(ctx, s.repo, account)
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return authResponse{}, err
	}

	// Nouveau compte Google
	username, err := s.generateGoogleUsername(ctx, email, displayName)
	if err != nil {
		return authResponse{}, err
	}

	now := time.Now().UTC()
	account = models.Account{
		Email:           email,
		PasswordHash:    "$google$",
		Role:            "USER",
		Status:          "ACTIVE",
		EmailVerifiedAt: &now,
	}

	var response authResponse
	err = s.repo.Transaction(ctx, func(txRepo *Repository) error {
		if err := txRepo.CreateAccount(ctx, &account); err != nil {
			return err
		}

		profile := models.Profile{
			AccountID:   account.ID,
			Username:    username,
			DisplayName: &displayName,
		}
		if err := txRepo.CreateProfile(ctx, &profile); err != nil {
			return err
		}

		var txErr error
		response, txErr = createAuthResponse(ctx, txRepo, account)
		return txErr
	})

	return response, err
}

// generateGoogleUsername cree un username unique a partir du nom ou de l'email Google.
// Entree : ctx, email, displayName.
// Sortie : valeurs retour de la fonction.
func (s *Service) generateGoogleUsername(ctx context.Context, email, displayName string) (string, error) {
	var candidates []string

	// A partir du nom d'affichage Google
	nameBase := nonAlphaNumRe.ReplaceAllString(strings.ToLower(displayName), "")
	if len(nameBase) >= 3 {
		if len(nameBase) > 30 {
			nameBase = nameBase[:30]
		}
		candidates = append(candidates, nameBase)
	}

	// A partir du prefixe de l'email
	emailBase := nonAlphaNumRe.ReplaceAllString(strings.ToLower(strings.Split(email, "@")[0]), "")
	if len(emailBase) >= 3 {
		if len(emailBase) > 30 {
			emailBase = emailBase[:30]
		}
		candidates = append(candidates, emailBase)
	}

	for _, base := range candidates {
		if ok, _ := s.UsernameAvailable(ctx, base); ok {
			return base, nil
		}
		for i := 1; i <= 99; i++ {
			candidate := fmt.Sprintf("%s%d", base, i)
			if len(candidate) > 30 {
				candidate = fmt.Sprintf("%s%d", base[:28], i)
			}
			if ok, _ := s.UsernameAvailable(ctx, candidate); ok {
				return candidate, nil
			}
		}
	}

	// Fallback sur un token court garanti unique
	tok, err := randomToken(8)
	if err != nil {
		return "", err
	}
	return "user" + tok[:8], nil
}
