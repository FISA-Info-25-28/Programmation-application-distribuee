package auth

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
)

func TestGoogleLoginNotConfigured(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GOOGLE_CLIENT_ID", "")

	router := gin.New()
	router.GET("/google", NewHandler(nil).GoogleLogin)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/google", nil))

	if rec.Code != http.StatusNotImplemented {
		t.Fatalf("GoogleLogin status = %d, want 501", rec.Code)
	}
}

func TestGoogleCallbackDatabaseUnavailable(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.GET("/google/callback", NewHandler(nil).GoogleCallback)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/google/callback", nil))

	if rec.Code != http.StatusServiceUnavailable {
		t.Fatalf("GoogleCallback status = %d, want 503", rec.Code)
	}
}

func TestGoogleAccountServiceDryRun(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	service := NewService(NewRepository(authDryRunDB(t)), noopVerificationMailer{})

	_, _ = service.FindOrCreateGoogleAccount(context.Background(), "alice@example.com", "Alice Example")
	_, _ = service.generateGoogleUsername(context.Background(), "alice@example.com", "Alice Example")
	_, _ = service.generateGoogleUsername(context.Background(), "bad", "")
}

func TestGoogleLoginRedirectsWhenConfigured(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GOOGLE_CLIENT_ID", "client-id")
	t.Setenv("GOOGLE_REDIRECT_URL", "http://app.test/google/callback")

	router := gin.New()
	router.GET("/google", NewHandler(nil).GoogleLogin)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/google", nil))

	location := rec.Header().Get("Location")
	if rec.Code != http.StatusFound || !strings.Contains(location, "accounts.google.com") || !strings.Contains(location, "client_id=client-id") {
		t.Fatalf("GoogleLogin redirect status/location = %d/%q", rec.Code, location)
	}
	if cookie := rec.Result().Cookies(); len(cookie) == 0 {
		t.Fatal("GoogleLogin should set oauth state cookie")
	}
}
