package auth

import (
	"errors"
	"io"
	"net/http"
	"strings"
	"time"

	"breezy/backend/internal/config"
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

const (
	accessTokenCookieName  = "breezy_access_token"
	refreshTokenCookieName = "breezy_refresh_token"
)

// Handler regroupe les dependances HTTP du domaine auth et delegue la logique
// metier au Service.
type Handler struct {
	db      *gorm.DB
	service *Service
}

// NewHandler cree un handler d'authentification.
// Entree : db.
// Sortie : valeur retour de type *Handler.
func NewHandler(db *gorm.DB) *Handler {
	repo := NewRepository(db)
	return &Handler{
		db:      db,
		service: NewService(repo, newVerificationMailerFromEnv()),
	}
}

// Health expose l'etat du service auth.
// Entree : c.
// Sortie HTTP : JSON avec le nom du service, le statut applicatif et l'etat de
// la base.
func (h *Handler) Health(c *gin.Context) {
	dbStatus := "ok"
	if h.db == nil {
		dbStatus = "unavailable"
	} else if sqlDB, err := h.db.DB(); err != nil || sqlDB.PingContext(c.Request.Context()) != nil {
		dbStatus = "error"
	}

	c.JSON(http.StatusOK, gin.H{
		"service": config.Env("SERVICE_NAME", "auth-service"),
		"status":  "ok",
		"db":      dbStatus,
	})
}

// CheckUsername indique si un nom d'utilisateur peut etre utilise a l'inscription.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) CheckUsername(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	available, err := h.service.UsernameAvailable(c.Request.Context(), c.Query("username"))
	if err != nil {
		if errors.Is(err, ErrInvalidUsername) {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid username"})
			return
		}

		c.JSON(http.StatusInternalServerError, gin.H{"error": "username lookup failed"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"available": available})
}

// CheckEmail indique si une adresse e-mail peut etre utilisee a l'inscription.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) CheckEmail(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	available, err := h.service.EmailAvailable(c.Request.Context(), c.Query("email"))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "email lookup failed"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"available": available})
}

// Register traite une inscription.
// Entree HTTP : JSON registerRequest contenant email et password.
// Sortie HTTP : 201 avec authResponse, 400 si le payload est invalide, 409 si
// l'e-mail existe deja, 500/503 en cas d'erreur serveur ou base indisponible.
func (h *Handler) Register(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	var req registerRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid register payload"})
		return
	}

	response, err := h.service.Register(c.Request.Context(), req.Email, req.Password, req.Username, req.DisplayName)
	if err != nil {
		switch {
		case errors.Is(err, ErrEmailAlreadyRegistered):
			c.JSON(http.StatusConflict, gin.H{"error": "email already registered"})
		case errors.Is(err, ErrUsernameAlreadyRegistered):
			c.JSON(http.StatusConflict, gin.H{"error": "username already registered"})
		case errors.Is(err, ErrInvalidUsername):
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid username"})
		case errors.Is(err, ErrVerificationEmailFailed):
			c.JSON(http.StatusInternalServerError, gin.H{"error": "verification email failed"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "register failed"})
		}
		return
	}

	c.JSON(http.StatusCreated, response)
}

// Login traite une connexion.
// Entree HTTP : JSON loginRequest contenant email et password.
// Sortie HTTP : 200 avec authResponse, 400 si le payload est invalide, 401 si
// les identifiants sont faux, 403 si le compte est inactif, 500/503 sinon.
func (h *Handler) Login(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	var req loginRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid login payload"})
		return
	}

	response, err := h.service.Login(c.Request.Context(), req.Email, req.Password)
	if err != nil {
		var suspendedErr *AccountSuspendedError
		switch {
		case errors.As(err, &suspendedErr):
			c.JSON(http.StatusForbidden, gin.H{
				"error":          "account suspended",
				"suspendedUntil": suspendedErr.SuspendedUntil.UTC().Format(time.RFC3339),
			})
		case errors.Is(err, ErrAccountBanned):
			c.JSON(http.StatusForbidden, gin.H{"error": "account banned"})
		case errors.Is(err, ErrInvalidCredentials):
			c.JSON(http.StatusUnauthorized, gin.H{"error": "invalid credentials"})
		case errors.Is(err, ErrEmailNotVerified):
			c.JSON(http.StatusForbidden, gin.H{"error": "email not verified"})
		case errors.Is(err, ErrInactiveAccount):
			c.JSON(http.StatusForbidden, gin.H{"error": "account is not active"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "login failed"})
		}
		return
	}

	h.setAuthCookies(c, response)
	response = response.withoutTokens()
	c.JSON(http.StatusOK, response)
}

func (h *Handler) VerifyEmail(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	response, err := h.service.VerifyEmail(c.Request.Context(), c.Query("token"))
	if err != nil {
		switch {
		case errors.Is(err, ErrInvalidVerificationToken):
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid verification token"})
		case errors.Is(err, ErrExpiredVerificationToken):
			c.JSON(http.StatusBadRequest, gin.H{"error": "expired verification token"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "email verification failed"})
		}
		return
	}

	c.JSON(http.StatusOK, response)
}

func (h *Handler) ResendVerificationEmail(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	var req resendVerificationRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid resend verification payload"})
		return
	}

	response, err := h.service.ResendVerificationEmail(c.Request.Context(), req.Email)
	if err != nil {
		switch {
		case errors.Is(err, gorm.ErrRecordNotFound):
			c.JSON(http.StatusNotFound, gin.H{"error": "account not found"})
		case errors.Is(err, ErrEmailAlreadyVerified):
			c.JSON(http.StatusConflict, gin.H{"error": "email already verified"})
		case errors.Is(err, ErrVerificationEmailFailed):
			c.JSON(http.StatusInternalServerError, gin.H{"error": "verification email failed"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "resend verification failed"})
		}
		return
	}

	c.JSON(http.StatusOK, response)
}

// Logout traite une deconnexion.
// Entree HTTP : refreshToken dans le JSON logoutRequest ou token Bearer dans le
// header Authorization.
// Sortie HTTP : 204 si la session est revoquee, 400 si aucun token n'est
// fourni, 500/503 si l'operation echoue.
func (h *Handler) Logout(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	var req logoutRequest
	if err := c.ShouldBindJSON(&req); (err != nil && !errors.Is(err, io.EOF)) || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid logout payload"})
		return
	}

	refreshToken := strings.TrimSpace(req.RefreshToken)
	if refreshToken == "" {
		refreshToken = bearerToken(c.GetHeader("Authorization"))
	}
	if refreshToken == "" {
		refreshToken = cookieValue(c, refreshTokenCookieName)
	}
	if refreshToken == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "refresh token is required"})
		return
	}

	if err := h.service.Logout(c.Request.Context(), refreshToken); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "logout failed"})
		return
	}

	h.clearAuthCookies(c)
	c.Status(http.StatusNoContent)
}

// Refresh renouvelle une session.
// Entree HTTP : JSON refreshRequest contenant refreshToken.
// Sortie HTTP : 200 avec authResponse, 400 si le payload est invalide, 401 si
// le refresh token est invalide, 403 si le compte est inactif, 500/503 sinon.
func (h *Handler) Refresh(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	var req refreshRequest
	if err := c.ShouldBindJSON(&req); (err != nil && !errors.Is(err, io.EOF)) || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid refresh payload"})
		return
	}

	refreshToken := strings.TrimSpace(req.RefreshToken)
	if refreshToken == "" {
		refreshToken = cookieValue(c, refreshTokenCookieName)
	}
	if refreshToken == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "refresh token is required"})
		return
	}

	response, err := h.service.Refresh(c.Request.Context(), refreshToken)
	if err != nil {
		switch {
		case errors.Is(err, ErrInvalidRefreshToken):
			c.JSON(http.StatusUnauthorized, gin.H{"error": "invalid refresh token"})
		case errors.Is(err, ErrInactiveAccount):
			c.JSON(http.StatusForbidden, gin.H{"error": "account is not active"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "refresh failed"})
		}
		return
	}

	h.setAuthCookies(c, response)
	response = response.withoutTokens()
	c.JSON(http.StatusOK, response)
}

// Me retourne le compte courant.
// Entree HTTP : contexte Gin contenant accountID, place par AuthRequired.
// Sortie HTTP : 200 avec accountResponse, 401 si le compte n'existe plus,
// 500/503 en cas d'erreur interne.
func (h *Handler) Me(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	response, err := h.service.Me(c.Request.Context(), accountID)
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, gorm.ErrRecordNotFound) {
			status = http.StatusUnauthorized
		}
		c.JSON(status, gin.H{"error": "account lookup failed"})
		return
	}

	c.JSON(http.StatusOK, response)
}

// ChangePassword met a jour le mot de passe du compte authentifie.
// Entree HTTP : JSON changePasswordRequest contenant currentPassword et
// newPassword.
// Sortie HTTP : 204 si le mot de passe est change, 400 si le payload est
// invalide, 401 si currentPassword est incorrect, 500/503 sinon.
func (h *Handler) ChangePassword(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	var req changePasswordRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid change password payload"})
		return
	}

	err := h.service.ChangePassword(c.Request.Context(), accountID, req.CurrentPassword, req.NewPassword)
	if err != nil {
		switch {
		case errors.Is(err, ErrInvalidCredentials), errors.Is(err, gorm.ErrRecordNotFound):
			c.JSON(http.StatusUnauthorized, gin.H{"error": "current password is incorrect"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "change password failed"})
		}
		return
	}

	c.Status(http.StatusNoContent)
}

// ForgotPassword envoie un lien de reinitialisation de mot de passe.
// Toujours 200 pour eviter l'enumeration d'e-mails.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) ForgotPassword(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	var req forgotPasswordRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid forgot password payload"})
		return
	}

	_ = h.service.ForgotPassword(c.Request.Context(), req.Email)
	c.JSON(http.StatusOK, gin.H{"message": "if this email exists, a reset link has been sent"})
}

// ResetPassword reinitialise le mot de passe avec le token recu par e-mail.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) ResetPassword(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	var req resetPasswordRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid reset password payload"})
		return
	}

	err := h.service.ResetPassword(c.Request.Context(), req.Token, req.NewPassword)
	if err != nil {
		switch {
		case errors.Is(err, ErrInvalidResetToken):
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid reset token"})
		case errors.Is(err, ErrExpiredResetToken):
			c.JSON(http.StatusBadRequest, gin.H{"error": "expired reset token"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "reset password failed"})
		}
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "password reset successfully"})
}

func (h *Handler) UpdateAccountStatus(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid account id"})
		return
	}

	var req updateAccountStatusRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid account status payload"})
		return
	}

	status := strings.ToUpper(strings.TrimSpace(req.Status))
	if !validAccountStatus(status) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid account status"})
		return
	}

	account, err := h.service.UpdateAccountStatus(c.Request.Context(), accountID, status)
	if err != nil {
		statusCode := http.StatusInternalServerError
		if errors.Is(err, gorm.ErrRecordNotFound) {
			statusCode = http.StatusNotFound
		}
		c.JSON(statusCode, gin.H{"error": "account status update failed"})
		return
	}

	c.JSON(http.StatusOK, account)
}

// databaseAvailable verifie que la base est disponible avant une action auth.
// Entree : c.
// Sortie : valeur retour de type bool.
func (h *Handler) databaseAvailable(c *gin.Context) bool {
	if h.db != nil {
		return true
	}

	c.JSON(http.StatusServiceUnavailable, gin.H{"error": "database unavailable"})
	return false
}

func validAccountStatus(status string) bool {
	switch status {
	case "ACTIVE", "SUSPENDED", "BANNED":
		return true
	default:
		return false
	}
}

func (h *Handler) setAuthCookies(c *gin.Context, response authResponse) {
	secure := strings.EqualFold(config.Env("COOKIE_SECURE", "false"), "true")
	sameSite := http.SameSiteLaxMode
	if strings.EqualFold(config.Env("COOKIE_SAMESITE", "lax"), "none") {
		sameSite = http.SameSiteNoneMode
	}

	setCookie(c, accessTokenCookieName, response.AccessToken, int(accessTokenTTL.Seconds()), secure, sameSite)
	setCookie(c, refreshTokenCookieName, response.RefreshToken, int(refreshTokenTTL.Seconds()), secure, sameSite)
}

func (h *Handler) clearAuthCookies(c *gin.Context) {
	secure := strings.EqualFold(config.Env("COOKIE_SECURE", "false"), "true")
	sameSite := http.SameSiteLaxMode
	if strings.EqualFold(config.Env("COOKIE_SAMESITE", "lax"), "none") {
		sameSite = http.SameSiteNoneMode
	}

	setCookie(c, accessTokenCookieName, "", -1, secure, sameSite)
	setCookie(c, refreshTokenCookieName, "", -1, secure, sameSite)
}

func setCookie(c *gin.Context, name, value string, maxAge int, secure bool, sameSite http.SameSite) {
	http.SetCookie(c.Writer, &http.Cookie{
		Name:     name,
		Value:    value,
		Path:     "/",
		MaxAge:   maxAge,
		Expires:  time.Now().Add(time.Duration(maxAge) * time.Second),
		HttpOnly: true,
		Secure:   secure,
		SameSite: sameSite,
	})
}

func cookieValue(c *gin.Context, name string) string {
	value, err := c.Cookie(name)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(value)
}

func (r authResponse) withoutTokens() authResponse {
	r.AccessToken = ""
	r.RefreshToken = ""
	r.TokenType = ""
	return r
}
