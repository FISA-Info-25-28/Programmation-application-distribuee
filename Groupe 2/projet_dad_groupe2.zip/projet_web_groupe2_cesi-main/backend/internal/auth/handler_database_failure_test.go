package auth

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"breezy/backend/internal/middleware"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func TestAuthHandlerDatabaseFailures(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(closedAuthDB(t))
	accountID := uuid.New()

	tests := []struct {
		name   string
		method string
		path   string
		body   string
		want   int
		setup  func(*gin.Engine)
	}{
		{name: "username", method: http.MethodGet, path: "/check-username?username=valid_user", want: 500, setup: func(r *gin.Engine) { r.GET("/check-username", handler.CheckUsername) }},
		{name: "email", method: http.MethodGet, path: "/check-email?email=user@example.com", want: 500, setup: func(r *gin.Engine) { r.GET("/check-email", handler.CheckEmail) }},
		{name: "register", method: http.MethodPost, path: "/register", body: `{"email":"new@example.com","password":"StrongPass123!","username":"new_user","displayName":"New User"}`, want: 500, setup: func(r *gin.Engine) { r.POST("/register", handler.Register) }},
		{name: "login", method: http.MethodPost, path: "/login", body: `{"email":"user@example.com","password":"StrongPass123!"}`, want: 500, setup: func(r *gin.Engine) { r.POST("/login", handler.Login) }},
		{name: "verify", method: http.MethodGet, path: "/verify-email?token=valid-looking-token", want: 500, setup: func(r *gin.Engine) { r.GET("/verify-email", handler.VerifyEmail) }},
		{name: "resend", method: http.MethodPost, path: "/resend-verification", body: `{"email":"user@example.com"}`, want: 500, setup: func(r *gin.Engine) { r.POST("/resend-verification", handler.ResendVerificationEmail) }},
		{name: "forgot", method: http.MethodPost, path: "/forgot-password", body: `{"email":"user@example.com"}`, want: 200, setup: func(r *gin.Engine) { r.POST("/forgot-password", handler.ForgotPassword) }},
		{name: "reset", method: http.MethodPost, path: "/reset-password", body: `{"token":"valid-looking-token","newPassword":"StrongPass456!"}`, want: 500, setup: func(r *gin.Engine) { r.POST("/reset-password", handler.ResetPassword) }},
		{name: "logout", method: http.MethodPost, path: "/logout", body: `{"refreshToken":"valid-looking-token"}`, want: 500, setup: func(r *gin.Engine) { r.POST("/logout", handler.Logout) }},
		{name: "refresh", method: http.MethodPost, path: "/refresh", body: `{"refreshToken":"valid-looking-token"}`, want: 500, setup: func(r *gin.Engine) { r.POST("/refresh", handler.Refresh) }},
		{name: "me", method: http.MethodGet, path: "/me", want: 500, setup: func(r *gin.Engine) { r.GET("/me", handler.Me) }},
		{name: "password", method: http.MethodPatch, path: "/me/password", body: `{"currentPassword":"StrongPass123!","newPassword":"StrongPass456!"}`, want: 500, setup: func(r *gin.Engine) { r.PATCH("/me/password", handler.ChangePassword) }},
		{name: "status", method: http.MethodPatch, path: "/accounts/" + uuid.NewString() + "/status", body: `{"status":"ACTIVE"}`, want: 500, setup: func(r *gin.Engine) { r.PATCH("/accounts/:id/status", handler.UpdateAccountStatus) }},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			router.Use(func(c *gin.Context) {
				c.Set(middleware.ContextAccountID, accountID)
				c.Next()
			})
			tt.setup(router)
			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			rec := httptest.NewRecorder()
			router.ServeHTTP(rec, req)
			if rec.Code != tt.want {
				t.Fatalf("status = %d, want %d: %s", rec.Code, tt.want, rec.Body.String())
			}
		})
	}
}

// TestHandlerHealthReportsDBError exerce la branche d'erreur de Health quand
// la connexion existe mais que le ping echoue (base fermee), ce que les
// tests "db nil" et "happy path" existants ne couvraient pas.
func TestHandlerHealthReportsDBError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(closedAuthDB(t))

	router := gin.New()
	router.GET("/health", handler.Health)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))

	if rec.Code != http.StatusOK || !strings.Contains(rec.Body.String(), `"db":"error"`) {
		t.Fatalf("Health(closed db) = %d/%s, want 200 with db error", rec.Code, rec.Body.String())
	}
}

func closedAuthDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	mock.ExpectClose()
	if err := sqlDB.Close(); err != nil {
		t.Fatalf("Close() unexpected error: %v", err)
	}
	return db
}
