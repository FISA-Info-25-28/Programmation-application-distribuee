package auth

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// TestHandlerRegisterUsernameAlreadyRegistered couvre la branche
// ErrUsernameAlreadyRegistered → 409 "username already registered".
func TestHandlerRegisterUsernameAlreadyRegistered(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/register", handler.Register)

	// email libre, mais username déjà pris
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnRows(profileRows(uuid.New(), uuid.New(), "existing_user", nil))

	body := `{"email":"new@example.com","password":"StrongPass123!","username":"existing_user","displayName":"New User"}`
	req := httptest.NewRequest(http.MethodPost, "/register", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusConflict || !strings.Contains(rec.Body.String(), "username already registered") {
		t.Fatalf("Register(dup username) status/body = %d/%s, want 409 username already registered", rec.Code, rec.Body.String())
	}
}

// TestHandlerLoginInvalidCredentials couvre la branche ErrInvalidCredentials → 401.
func TestHandlerLoginInvalidCredentials(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/login", handler.Login)

	passwordHash := hashedPassword(t, "CorrectPass123!")
	now := time.Now().UTC()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "ACTIVE", &now, nil))

	body := `{"email":"alice@example.com","password":"WrongPass999!"}`
	req := httptest.NewRequest(http.MethodPost, "/login", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("Login(wrong password) status = %d, want 401: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerLoginEmailNotVerified couvre la branche ErrEmailNotVerified → 403.
func TestHandlerLoginEmailNotVerified(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/login", handler.Login)

	passwordHash := hashedPassword(t, "StrongPass123!")
	accountID := uuid.New()

	// emailVerifiedAt = nil → ErrEmailNotVerified
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "ACTIVE", nil, nil))

	body := `{"email":"alice@example.com","password":"StrongPass123!"}`
	req := httptest.NewRequest(http.MethodPost, "/login", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusForbidden || !strings.Contains(rec.Body.String(), "email not verified") {
		t.Fatalf("Login(unverified) status/body = %d/%s, want 403 email not verified", rec.Code, rec.Body.String())
	}
}

// TestHandlerLoginAccountBanned couvre la branche ErrAccountBanned → 403.
func TestHandlerLoginAccountBanned(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/login", handler.Login)

	passwordHash := hashedPassword(t, "StrongPass123!")
	accountID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "BANNED", &now, nil))

	body := `{"email":"alice@example.com","password":"StrongPass123!"}`
	req := httptest.NewRequest(http.MethodPost, "/login", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusForbidden || !strings.Contains(rec.Body.String(), "account banned") {
		t.Fatalf("Login(banned) status/body = %d/%s, want 403 account banned", rec.Code, rec.Body.String())
	}
}

// TestHandlerLoginInactiveAccount couvre la branche ErrInactiveAccount → 403.
func TestHandlerLoginInactiveAccount(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/login", handler.Login)

	passwordHash := hashedPassword(t, "StrongPass123!")
	accountID := uuid.New()
	now := time.Now().UTC()

	// Statut inconnu → default du switch → ErrInactiveAccount
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "PENDING", &now, nil))

	body := `{"email":"alice@example.com","password":"StrongPass123!"}`
	req := httptest.NewRequest(http.MethodPost, "/login", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusForbidden || !strings.Contains(rec.Body.String(), "account is not active") {
		t.Fatalf("Login(inactive) status/body = %d/%s, want 403 account is not active", rec.Code, rec.Body.String())
	}
}

// TestHandlerResendVerificationEmailMailerFailure couvre la branche
// ErrVerificationEmailFailed → 500 dans ResendVerificationEmail.
func TestHandlerResendVerificationEmailMailerFailure(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	// failingMailer retourne une erreur SMTP → service retourne ErrVerificationEmailFailed
	handler := &Handler{db: db, service: NewService(NewRepository(db), failingMailer{})}
	router := gin.New()
	router.POST("/resend-verification", handler.ResendVerificationEmail)

	accountID := uuid.New()
	// emailVerifiedAt = nil → compte non vérifié → on tente de renvoyer
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))
	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "email_verification_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	req := httptest.NewRequest(http.MethodPost, "/resend-verification", strings.NewReader(`{"email":"alice@example.com"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusInternalServerError || !strings.Contains(rec.Body.String(), "verification email failed") {
		t.Fatalf("ResendVerificationEmail(mailer fail) status/body = %d/%s, want 500 verification email failed", rec.Code, rec.Body.String())
	}
}

// TestHandlerRefreshInactiveAccountForbidden couvre la branche
// ErrInactiveAccount → 403 dans Refresh.
func TestHandlerRefreshInactiveAccountForbidden(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")

	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/refresh", handler.Refresh)

	accountID := uuid.New()
	sessionID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "refresh_token_hash", "expires_at", "revoked_at", "created_at"}).
			AddRow(sessionID, accountID, hashToken("inactive-token"), now.Add(time.Hour), nil, now))
	// compte BANNED → ErrInactiveAccount dans Refresh (check account.Status != "ACTIVE")
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "BANNED", &now, nil))
	mock.ExpectRollback()

	body := `{"refreshToken":"inactive-token"}`
	req := httptest.NewRequest(http.MethodPost, "/refresh", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusForbidden {
		t.Fatalf("Refresh(inactive account) status = %d, want 403: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerRefreshNoTokenBadRequest couvre la branche "refresh token is required"
// quand aucun token n'est fourni (ni body, ni cookie).
func TestHandlerRefreshNoTokenBadRequest(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/refresh", handler.Refresh)

	req := httptest.NewRequest(http.MethodPost, "/refresh", strings.NewReader("{}"))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusBadRequest {
		t.Fatalf("Refresh(no token) status = %d, want 400: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerLogoutNoTokenBadRequest couvre la branche "refresh token is required"
// quand aucun token n'est fourni (ni body, ni header, ni cookie).
func TestHandlerLogoutNoTokenBadRequest(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/logout", handler.Logout)

	req := httptest.NewRequest(http.MethodPost, "/logout", strings.NewReader("{}"))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusBadRequest {
		t.Fatalf("Logout(no token) status = %d, want 400: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerMeInternalErrorNoAccountID couvre la branche "authenticated account missing"
// quand le middleware n'a pas positionné l'accountID dans le contexte.
func TestHandlerMeInternalErrorNoAccountID(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	// pas de middleware qui set middleware.ContextAccountID
	router.GET("/me", handler.Me)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/me", nil))

	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("Me(no account id) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerChangePasswordNoAccountID couvre la branche "authenticated account missing"
// dans ChangePassword quand le middleware n'a pas positionné l'accountID.
func TestHandlerChangePasswordNoAccountID(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.PATCH("/me/password", handler.ChangePassword)

	req := httptest.NewRequest(http.MethodPatch, "/me/password", strings.NewReader(`{"currentPassword":"old","newPassword":"NewPass456!"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("ChangePassword(no account id) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerUpdateAccountStatusInvalidUUID couvre la branche "invalid account id" → 400.
func TestHandlerUpdateAccountStatusInvalidUUID(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.PATCH("/accounts/:id/status", handler.UpdateAccountStatus)

	req := httptest.NewRequest(http.MethodPatch, "/accounts/not-a-uuid/status", strings.NewReader(`{"status":"ACTIVE"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusBadRequest || !strings.Contains(rec.Body.String(), "invalid account id") {
		t.Fatalf("UpdateAccountStatus(invalid uuid) status/body = %d/%s, want 400 invalid account id", rec.Code, rec.Body.String())
	}
}
