package auth

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// TestHandlerRegisterGenericErrorReturns500 exerce la branche "default" du
// switch d'erreurs de Register, qui n'etait visitee par aucun autre test
// (les autres tests utilisent soit la base indisponible, soit un payload
// invalide, soit des erreurs connues comme ErrEmailAlreadyRegistered).
func TestHandlerRegisterGenericErrorReturns500(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/register", handler.Register)

	dbErr := errors.New("db down")
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).WillReturnError(dbErr)

	body := `{"email":"new@example.com","password":"StrongPass123!","username":"new_user","displayName":"New User"}`
	req := httptest.NewRequest(http.MethodPost, "/register", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("Register(generic error) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerLoginGenericErrorReturns500(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/login", handler.Login)

	dbErr := errors.New("db down")
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).WillReturnError(dbErr)

	body := `{"email":"alice@example.com","password":"StrongPass123!"}`
	req := httptest.NewRequest(http.MethodPost, "/login", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("Login(generic error) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerVerifyEmailGenericErrorReturns500(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/verify-email", handler.VerifyEmail)

	dbErr := errors.New("db down")
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "email_verification_tokens" WHERE token_hash`).WillReturnError(dbErr)
	mock.ExpectRollback()

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/verify-email?token=sometoken", nil))
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("VerifyEmail(generic error) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerResendVerificationEmailGenericErrorReturns500(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/resend-verification", handler.ResendVerificationEmail)

	dbErr := errors.New("db down")
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).WillReturnError(dbErr)

	req := httptest.NewRequest(http.MethodPost, "/resend-verification", strings.NewReader(`{"email":"alice@example.com"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("ResendVerificationEmail(generic error) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerRefreshGenericErrorReturns500(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/refresh", handler.Refresh)

	dbErr := errors.New("db down")
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).WillReturnError(dbErr)
	mock.ExpectRollback()

	body := `{"refreshToken":"sometoken"}`
	req := httptest.NewRequest(http.MethodPost, "/refresh", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("Refresh(generic error) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerMeUnauthorizedWhenAccountMissing(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	accountID := uuid.New()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	router.GET("/me", handler.Me)

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).WillReturnError(gorm.ErrRecordNotFound)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/me", nil))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("Me(missing account) status = %d, want 401: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerChangePasswordGenericErrorReturns500(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	accountID := uuid.New()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	router.PATCH("/me/password", handler.ChangePassword)

	dbErr := errors.New("db down")
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).WillReturnError(dbErr)

	req := httptest.NewRequest(http.MethodPatch, "/me/password", strings.NewReader(`{"currentPassword":"old","newPassword":"NewPass456!"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("ChangePassword(generic error) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerResetPasswordGenericErrorReturns500(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/reset-password", handler.ResetPassword)

	dbErr := errors.New("db down")
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "password_reset_tokens" WHERE token_hash`).WillReturnError(dbErr)
	mock.ExpectRollback()

	req := httptest.NewRequest(http.MethodPost, "/reset-password", strings.NewReader(`{"token":"sometoken","newPassword":"NewPass456!"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("ResetPassword(generic error) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerUpdateAccountStatusGenericErrorReturns500(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.PATCH("/accounts/:id/status", handler.UpdateAccountStatus)

	dbErr := errors.New("db down")
	accountID := uuid.New()
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).WillReturnError(dbErr)
	mock.ExpectRollback()

	req := httptest.NewRequest(http.MethodPatch, "/accounts/"+accountID.String()+"/status", strings.NewReader(`{"status":"BANNED"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("UpdateAccountStatus(generic error) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerLogoutGenericErrorReturns500(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/logout", handler.Logout)

	dbErr := errors.New("db down")
	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "sessions"`).WillReturnError(dbErr)
	mock.ExpectRollback()

	req := httptest.NewRequest(http.MethodPost, "/logout", strings.NewReader(`{"refreshToken":"sometoken"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("Logout(generic error) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}
