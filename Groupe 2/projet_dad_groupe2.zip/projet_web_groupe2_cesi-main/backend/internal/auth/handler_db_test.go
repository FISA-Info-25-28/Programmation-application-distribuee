package auth

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"breezy/backend/internal/middleware"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// TestHandlerRegisterLoginRefreshSuccess exerce les chemins de succes HTTP des
// handlers les plus utilises, avec une base mockee via sqlmock, pour couvrir
// les branches "happy path" de handler.go non visitees par les tests
// d'indisponibilite de base ou de payload invalide.
func TestHandlerRegisterLoginRefreshSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")

	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}

	router := gin.New()
	router.POST("/register", handler.Register)

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`INSERT INTO "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "email_verification_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	body := `{"email":"new@example.com","password":"StrongPass123!","username":"new_user","displayName":"New User"}`
	req := httptest.NewRequest(http.MethodPost, "/register", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusCreated {
		t.Fatalf("Register() status = %d, want 201: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerLoginSuccessSetsAuthCookies(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")

	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/login", handler.Login)

	accountID := uuid.New()
	now := time.Now().UTC()
	passwordHash := hashedPassword(t, "StrongPass123!")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "ACTIVE", &now, nil))
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))

	body := `{"email":"alice@example.com","password":"StrongPass123!"}`
	req := httptest.NewRequest(http.MethodPost, "/login", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("Login() status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
	if len(rec.Result().Cookies()) == 0 {
		t.Fatal("Login() should set auth cookies")
	}
	if strings.Contains(rec.Body.String(), "accessToken") {
		t.Fatal("Login() response body should not expose tokens")
	}
}

func TestHandlerLoginSuspendedReturnsForbiddenWithDate(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/login", handler.Login)

	accountID := uuid.New()
	now := time.Now().UTC()
	future := now.Add(time.Hour)
	passwordHash := hashedPassword(t, "StrongPass123!")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "SUSPENDED", &now, &future))

	body := `{"email":"alice@example.com","password":"StrongPass123!"}`
	req := httptest.NewRequest(http.MethodPost, "/login", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusForbidden || !strings.Contains(rec.Body.String(), "suspendedUntil") {
		t.Fatalf("Login(suspended) status/body = %d/%s, want 403 with suspendedUntil", rec.Code, rec.Body.String())
	}
}

func TestHandlerRefreshSuccessFromCookie(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")

	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/refresh", handler.Refresh)

	accountID := uuid.New()
	sessionID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "refresh_token_hash", "expires_at", "revoked_at", "created_at"}).
			AddRow(sessionID, accountID, hashToken("cookie-token"), now.Add(time.Hour), nil, now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", &now, nil))
	mock.ExpectExec(`UPDATE "sessions" SET`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))
	mock.ExpectCommit()

	req := httptest.NewRequest(http.MethodPost, "/refresh", strings.NewReader(""))
	req.AddCookie(&http.Cookie{Name: refreshTokenCookieName, Value: "cookie-token"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("Refresh() status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerRefreshInvalidTokenUnauthorized(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/refresh", handler.Refresh)

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectRollback()

	body := `{"refreshToken":"bad-token"}`
	req := httptest.NewRequest(http.MethodPost, "/refresh", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("Refresh(invalid) status = %d, want 401: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerVerifyEmailSuccessAndExpired(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/verify-email", handler.VerifyEmail)

	accountID := uuid.New()
	tokenID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "email_verification_tokens" WHERE token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "token_hash", "expires_at", "created_at"}).
			AddRow(tokenID, accountID, hashToken("good-token"), now.Add(time.Hour), now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/verify-email?token=good-token", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("VerifyEmail() status = %d, want 200: %s", rec.Code, rec.Body.String())
	}

	past := now.Add(-time.Hour)
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "email_verification_tokens" WHERE token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "token_hash", "expires_at", "created_at"}).
			AddRow(tokenID, accountID, hashToken("expired-token"), past, past))
	mock.ExpectRollback()

	rec2 := httptest.NewRecorder()
	router.ServeHTTP(rec2, httptest.NewRequest(http.MethodGet, "/verify-email?token=expired-token", nil))
	if rec2.Code != http.StatusBadRequest {
		t.Fatalf("VerifyEmail(expired) status = %d, want 400: %s", rec2.Code, rec2.Body.String())
	}
}

func TestHandlerResendVerificationEmailSuccessAndConflict(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/resend-verification", handler.ResendVerificationEmail)

	accountID := uuid.New()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))
	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "email_verification_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/resend-verification", strings.NewReader(`{"email":"alice@example.com"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("ResendVerificationEmail() status = %d, want 200: %s", rec.Code, rec.Body.String())
	}

	now := time.Now().UTC()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", &now, nil))

	rec2 := httptest.NewRecorder()
	req2 := httptest.NewRequest(http.MethodPost, "/resend-verification", strings.NewReader(`{"email":"alice@example.com"}`))
	req2.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec2, req2)
	if rec2.Code != http.StatusConflict {
		t.Fatalf("ResendVerificationEmail(verified) status = %d, want 409: %s", rec2.Code, rec2.Body.String())
	}
}

func TestHandlerLogoutSuccessClearsAuthCookies(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/logout", handler.Logout)

	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "sessions"`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	body := `{"refreshToken":"some-token"}`
	req := httptest.NewRequest(http.MethodPost, "/logout", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusNoContent {
		t.Fatalf("Logout() status = %d, want 204: %s", rec.Code, rec.Body.String())
	}
	if len(rec.Result().Cookies()) == 0 {
		t.Fatal("Logout() should clear auth cookies")
	}
}

func TestHandlerLogoutUsesBearerHeaderThenCookie(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/logout", handler.Logout)

	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "sessions"`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	req := httptest.NewRequest(http.MethodPost, "/logout", strings.NewReader(""))
	req.Header.Set("Authorization", "Bearer header-token")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusNoContent {
		t.Fatalf("Logout(bearer) status = %d, want 204: %s", rec.Code, rec.Body.String())
	}

	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "sessions"`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()
	req2 := httptest.NewRequest(http.MethodPost, "/logout", strings.NewReader(""))
	req2.AddCookie(&http.Cookie{Name: refreshTokenCookieName, Value: "cookie-token"})
	rec2 := httptest.NewRecorder()
	router.ServeHTTP(rec2, req2)
	if rec2.Code != http.StatusNoContent {
		t.Fatalf("Logout(cookie) status = %d, want 204: %s", rec2.Code, rec2.Body.String())
	}
}

func TestHandlerMeSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	accountID := uuid.New()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	router.GET("/me", handler.Me)

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/me", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("Me() status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerChangePasswordSuccessAndWrongCurrent(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	accountID := uuid.New()
	passwordHash := hashedPassword(t, "OldPass123!")

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	router.PATCH("/me/password", handler.ChangePassword)

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "ACTIVE", nil, nil))
	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	req := httptest.NewRequest(http.MethodPatch, "/me/password", strings.NewReader(`{"currentPassword":"OldPass123!","newPassword":"NewPass456!"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusNoContent {
		t.Fatalf("ChangePassword() status = %d, want 204: %s", rec.Code, rec.Body.String())
	}

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "ACTIVE", nil, nil))
	req2 := httptest.NewRequest(http.MethodPatch, "/me/password", strings.NewReader(`{"currentPassword":"WrongPass!","newPassword":"NewPass456!"}`))
	req2.Header.Set("Content-Type", "application/json")
	rec2 := httptest.NewRecorder()
	router.ServeHTTP(rec2, req2)
	if rec2.Code != http.StatusUnauthorized {
		t.Fatalf("ChangePassword(wrong) status = %d, want 401: %s", rec2.Code, rec2.Body.String())
	}
}

func TestHandlerResetPasswordSuccessAndExpired(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.POST("/reset-password", handler.ResetPassword)

	accountID := uuid.New()
	tokenID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "password_reset_tokens" WHERE token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "token_hash", "expires_at", "created_at"}).
			AddRow(tokenID, accountID, hashToken("reset-token"), now.Add(time.Hour), now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "old-hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectExec(`DELETE FROM "password_reset_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	req := httptest.NewRequest(http.MethodPost, "/reset-password", strings.NewReader(`{"token":"reset-token","newPassword":"NewPass456!"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("ResetPassword() status = %d, want 200: %s", rec.Code, rec.Body.String())
	}

	past := now.Add(-time.Hour)
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "password_reset_tokens" WHERE token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "token_hash", "expires_at", "created_at"}).
			AddRow(tokenID, accountID, hashToken("expired-token"), past, past))
	mock.ExpectRollback()

	req2 := httptest.NewRequest(http.MethodPost, "/reset-password", strings.NewReader(`{"token":"expired-token","newPassword":"NewPass456!"}`))
	req2.Header.Set("Content-Type", "application/json")
	rec2 := httptest.NewRecorder()
	router.ServeHTTP(rec2, req2)
	if rec2.Code != http.StatusBadRequest {
		t.Fatalf("ResetPassword(expired) status = %d, want 400: %s", rec2.Code, rec2.Body.String())
	}
}

func TestHandlerUpdateAccountStatusSuccessAndNotFound(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.PATCH("/accounts/:id/status", handler.UpdateAccountStatus)

	accountID := uuid.New()
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))

	req := httptest.NewRequest(http.MethodPatch, "/accounts/"+accountID.String()+"/status", strings.NewReader(`{"status":"SUSPENDED"}`))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("UpdateAccountStatus() status = %d, want 200: %s", rec.Code, rec.Body.String())
	}

	missingID := uuid.New()
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectRollback()

	req2 := httptest.NewRequest(http.MethodPatch, "/accounts/"+missingID.String()+"/status", strings.NewReader(`{"status":"BANNED"}`))
	req2.Header.Set("Content-Type", "application/json")
	rec2 := httptest.NewRecorder()
	router.ServeHTTP(rec2, req2)
	if rec2.Code != http.StatusNotFound {
		t.Fatalf("UpdateAccountStatus(missing) status = %d, want 404: %s", rec2.Code, rec2.Body.String())
	}
}

func TestHandlerCheckUsernameAndEmailSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/check-username", handler.CheckUsername)
	router.GET("/check-email", handler.CheckEmail)

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/check-username?username=valid_user", nil))
	if rec.Code != http.StatusOK || !strings.Contains(rec.Body.String(), `"available":true`) {
		t.Fatalf("CheckUsername() = %d/%s, want 200 available=true", rec.Code, rec.Body.String())
	}

	rec2 := httptest.NewRecorder()
	router.ServeHTTP(rec2, httptest.NewRequest(http.MethodGet, "/check-username?username=a", nil))
	if rec2.Code != http.StatusBadRequest {
		t.Fatalf("CheckUsername(invalid) status = %d, want 400: %s", rec2.Code, rec2.Body.String())
	}

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	rec3 := httptest.NewRecorder()
	router.ServeHTTP(rec3, httptest.NewRequest(http.MethodGet, "/check-email?email=new@example.com", nil))
	if rec3.Code != http.StatusOK || !strings.Contains(rec3.Body.String(), `"available":true`) {
		t.Fatalf("CheckEmail() = %d/%s, want 200 available=true", rec3.Code, rec3.Body.String())
	}
}
