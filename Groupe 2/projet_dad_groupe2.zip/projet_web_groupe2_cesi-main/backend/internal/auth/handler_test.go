package auth

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func TestHandlerHealthAndDatabaseUnavailable(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(nil)

	tests := []struct {
		name   string
		method string
		path   string
		setup  func(*gin.Engine)
		want   int
	}{
		{name: "health", method: http.MethodGet, path: "/health", setup: func(r *gin.Engine) { r.GET("/health", handler.Health) }, want: http.StatusOK},
		{name: "check username", method: http.MethodGet, path: "/check-username", setup: func(r *gin.Engine) { r.GET("/check-username", handler.CheckUsername) }, want: http.StatusServiceUnavailable},
		{name: "check email", method: http.MethodGet, path: "/check-email", setup: func(r *gin.Engine) { r.GET("/check-email", handler.CheckEmail) }, want: http.StatusServiceUnavailable},
		{name: "register", method: http.MethodPost, path: "/register", setup: func(r *gin.Engine) { r.POST("/register", handler.Register) }, want: http.StatusServiceUnavailable},
		{name: "login", method: http.MethodPost, path: "/login", setup: func(r *gin.Engine) { r.POST("/login", handler.Login) }, want: http.StatusServiceUnavailable},
		{name: "logout", method: http.MethodPost, path: "/logout", setup: func(r *gin.Engine) { r.POST("/logout", handler.Logout) }, want: http.StatusServiceUnavailable},
		{name: "refresh", method: http.MethodPost, path: "/refresh", setup: func(r *gin.Engine) { r.POST("/refresh", handler.Refresh) }, want: http.StatusServiceUnavailable},
		{name: "verify email", method: http.MethodGet, path: "/verify-email", setup: func(r *gin.Engine) { r.GET("/verify-email", handler.VerifyEmail) }, want: http.StatusServiceUnavailable},
		{name: "forgot password", method: http.MethodPost, path: "/forgot-password", setup: func(r *gin.Engine) { r.POST("/forgot-password", handler.ForgotPassword) }, want: http.StatusServiceUnavailable},
		{name: "reset password", method: http.MethodPost, path: "/reset-password", setup: func(r *gin.Engine) { r.POST("/reset-password", handler.ResetPassword) }, want: http.StatusServiceUnavailable},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			tt.setup(router)
			rec := httptest.NewRecorder()
			router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
			if rec.Code != tt.want {
				t.Fatalf("status = %d, want %d", rec.Code, tt.want)
			}
		})
	}
}

func TestAuthCookieHelpers(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("COOKIE_SECURE", "true")
	t.Setenv("COOKIE_SAMESITE", "none")

	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	handler := &Handler{}
	handler.setAuthCookies(c, authResponse{AccessToken: "access", RefreshToken: "refresh"})
	handler.clearAuthCookies(c)

	c.Request = httptest.NewRequest(http.MethodGet, "/", nil)
	c.Request.AddCookie(&http.Cookie{Name: refreshTokenCookieName, Value: " refresh "})
	if got := cookieValue(c, refreshTokenCookieName); got != "refresh" {
		t.Fatalf("cookieValue() = %q, want refresh", got)
	}

	if withTokens := (authResponse{AccessToken: "a", RefreshToken: "r", TokenType: "Bearer"}); withTokens.withoutTokens().AccessToken != "" {
		t.Fatal("withoutTokens() should clear token fields")
	}
}

func TestValidAccountStatus(t *testing.T) {
	if !validAccountStatus("ACTIVE") || !validAccountStatus("SUSPENDED") || !validAccountStatus("BANNED") {
		t.Fatal("validAccountStatus() should accept known statuses")
	}
	if validAccountStatus("LOCKED") {
		t.Fatal("validAccountStatus() should reject unknown status")
	}
}

func TestRegisterRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	RegisterRoutes(router, NewHandler(nil))

	tests := []struct {
		method string
		path   string
		want   int
	}{
		{method: http.MethodGet, path: "/health", want: http.StatusOK},
		{method: http.MethodGet, path: "/google", want: http.StatusNotImplemented},
		{method: http.MethodGet, path: "/github", want: http.StatusNotImplemented},
		{method: http.MethodGet, path: "/me", want: http.StatusUnauthorized},
	}

	for _, tt := range tests {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != tt.want {
			t.Fatalf("%s %s status = %d, want %d", tt.method, tt.path, rec.Code, tt.want)
		}
	}
}

func TestAuthHandlerInvalidInputsWithDatabase(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(&gorm.DB{})

	tests := []struct {
		name   string
		method string
		path   string
		body   string
		setup  func(*gin.Engine)
		want   int
	}{
		{name: "register invalid json", method: http.MethodPost, path: "/register", body: "{", setup: func(r *gin.Engine) { r.POST("/register", handler.Register) }, want: http.StatusBadRequest},
		{name: "login invalid json", method: http.MethodPost, path: "/login", body: "{", setup: func(r *gin.Engine) { r.POST("/login", handler.Login) }, want: http.StatusBadRequest},
		{name: "resend invalid json", method: http.MethodPost, path: "/resend-verification", body: "{", setup: func(r *gin.Engine) { r.POST("/resend-verification", handler.ResendVerificationEmail) }, want: http.StatusBadRequest},
		{name: "forgot invalid json", method: http.MethodPost, path: "/forgot-password", body: "{", setup: func(r *gin.Engine) { r.POST("/forgot-password", handler.ForgotPassword) }, want: http.StatusBadRequest},
		{name: "reset invalid token", method: http.MethodPost, path: "/reset-password", body: `{"token":"","newPassword":"x"}`, setup: func(r *gin.Engine) { r.POST("/reset-password", handler.ResetPassword) }, want: http.StatusBadRequest},
		{name: "logout missing token", method: http.MethodPost, path: "/logout", body: "", setup: func(r *gin.Engine) { r.POST("/logout", handler.Logout) }, want: http.StatusBadRequest},
		{name: "refresh missing token", method: http.MethodPost, path: "/refresh", body: "", setup: func(r *gin.Engine) { r.POST("/refresh", handler.Refresh) }, want: http.StatusBadRequest},
		{name: "me missing account", method: http.MethodGet, path: "/me", setup: func(r *gin.Engine) { r.GET("/me", handler.Me) }, want: http.StatusInternalServerError},
		{name: "change password missing account", method: http.MethodPatch, path: "/me/password", body: `{"currentPassword":"old","newPassword":"new"}`, setup: func(r *gin.Engine) { r.PATCH("/me/password", handler.ChangePassword) }, want: http.StatusInternalServerError},
		{name: "update status invalid id", method: http.MethodPatch, path: "/accounts/bad/status", body: `{"status":"ACTIVE"}`, setup: func(r *gin.Engine) { r.PATCH("/accounts/:id/status", handler.UpdateAccountStatus) }, want: http.StatusBadRequest},
		{name: "update status invalid payload", method: http.MethodPatch, path: "/accounts/00000000-0000-0000-0000-000000000001/status", body: `{"status":"LOCKED"}`, setup: func(r *gin.Engine) { r.PATCH("/accounts/:id/status", handler.UpdateAccountStatus) }, want: http.StatusBadRequest},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			tt.setup(router)
			rec := httptest.NewRecorder()
			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			router.ServeHTTP(rec, req)
			if rec.Code != tt.want {
				t.Fatalf("status = %d, want %d: %s", rec.Code, tt.want, rec.Body.String())
			}
		})
	}
}
