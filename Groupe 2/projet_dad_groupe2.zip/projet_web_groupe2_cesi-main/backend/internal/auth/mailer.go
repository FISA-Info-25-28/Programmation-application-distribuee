package auth

import (
	"fmt"
	"net/smtp"
	"strconv"
	"strings"

	"breezy/backend/internal/config"
)

type verificationMailer interface {
	SendVerificationEmail(to, displayName, verificationURL string) error
	SendPasswordResetEmail(to, displayName, resetURL string) error
}

type smtpMailer struct {
	host     string
	port     int
	username string
	password string
	from     string
}

func newVerificationMailerFromEnv() verificationMailer {
	if strings.EqualFold(config.Env("SMTP_ENABLED", "true"), "false") {
		return nil
	}

	port, err := strconv.Atoi(config.Env("SMTP_PORT", "1025"))
	if err != nil {
		port = 1025
	}

	return &smtpMailer{
		host:     config.Env("SMTP_HOST", "mailpit"),
		port:     port,
		username: config.Env("SMTP_USERNAME", ""),
		password: config.Env("SMTP_PASSWORD", ""),
		from:     config.Env("SMTP_FROM", "no-reply@breezy.local"),
	}
}

func (m *smtpMailer) SendVerificationEmail(to, displayName, verificationURL string) error {
	name := strings.TrimSpace(displayName)
	if name == "" {
		name = "cher utilisateur"
	}

	boundary := "breezy-boundary-2026"

	plain := strings.Join([]string{
		fmt.Sprintf("Bonjour %s,", name),
		"",
		"Bienvenue sur Breezy !",
		"Clique sur ce lien pour activer ton compte (valable 24h) :",
		verificationURL,
		"",
		"Si tu n'es pas à l'origine de cette inscription, ignore cet e-mail.",
		"",
		"L'équipe Breezy",
	}, "\r\n")

	html := buildVerificationEmailHTML(name, verificationURL)

	msg := strings.Join([]string{
		fmt.Sprintf("From: Breezy <%s>", m.from),
		fmt.Sprintf("To: %s", to),
		"Subject: Confirme ton adresse e-mail Breezy",
		"MIME-Version: 1.0",
		fmt.Sprintf("Content-Type: multipart/alternative; boundary=%q", boundary),
		"",
		"--" + boundary,
		`Content-Type: text/plain; charset="UTF-8"`,
		"",
		plain,
		"",
		"--" + boundary,
		`Content-Type: text/html; charset="UTF-8"`,
		"",
		html,
		"",
		"--" + boundary + "--",
	}, "\r\n")

	addr := fmt.Sprintf("%s:%d", m.host, m.port)
	var auth smtp.Auth
	if m.username != "" {
		auth = smtp.PlainAuth("", m.username, m.password, m.host)
	}

	return smtp.SendMail(addr, auth, m.from, []string{to}, []byte(msg))
}

func (m *smtpMailer) SendPasswordResetEmail(to, displayName, resetURL string) error {
	name := strings.TrimSpace(displayName)
	if name == "" {
		name = "cher utilisateur"
	}

	boundary := "breezy-boundary-reset-2026"

	plain := strings.Join([]string{
		fmt.Sprintf("Bonjour %s,", name),
		"",
		"Tu as demande la reinitialisation de ton mot de passe Breezy.",
		"Clique sur ce lien pour choisir un nouveau mot de passe (valable 1h) :",
		resetURL,
		"",
		"Si tu n'as pas fait cette demande, ignore cet e-mail.",
		"",
		"L'equipe Breezy",
	}, "\r\n")

	html := buildPasswordResetEmailHTML(name, resetURL)

	msg := strings.Join([]string{
		fmt.Sprintf("From: Breezy <%s>", m.from),
		fmt.Sprintf("To: %s", to),
		"Subject: Reinitialise ton mot de passe Breezy",
		"MIME-Version: 1.0",
		fmt.Sprintf("Content-Type: multipart/alternative; boundary=%q", boundary),
		"",
		"--" + boundary,
		`Content-Type: text/plain; charset="UTF-8"`,
		"",
		plain,
		"",
		"--" + boundary,
		`Content-Type: text/html; charset="UTF-8"`,
		"",
		html,
		"",
		"--" + boundary + "--",
	}, "\r\n")

	addr := fmt.Sprintf("%s:%d", m.host, m.port)
	var auth smtp.Auth
	if m.username != "" {
		auth = smtp.PlainAuth("", m.username, m.password, m.host)
	}

	return smtp.SendMail(addr, auth, m.from, []string{to}, []byte(msg))
}

func buildPasswordResetEmailHTML(name, resetURL string) string {
	return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reinitialise ton mot de passe</title>
</head>
<body style="margin:0;padding:0;background:#edf6f7;font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:antialiased;">
<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background:#edf6f7;padding:48px 16px;">
  <tr><td align="center">
    <table width="560" cellpadding="0" cellspacing="0" role="presentation" style="max-width:560px;width:100%;">
      <tr>
        <td align="center" style="padding-bottom:28px;">
          <span style="font-size:32px;font-weight:900;color:#00a9c0;letter-spacing:-1px;font-family:Arial,sans-serif;">Breezy</span>
        </td>
      </tr>
      <tr>
        <td style="background:#ffffff;border-radius:24px;padding:48px;box-shadow:0 4px 24px rgba(0,169,192,0.12);">
          <h1 style="margin:0 0 8px;font-size:24px;font-weight:700;color:#0e2a2f;line-height:1.3;">
            Reinitialisation du mot de passe
          </h1>
          <p style="margin:0 0 28px;font-size:15px;color:#5a8a96;line-height:1.7;">
            Bonjour <strong style="color:#0e2a2f;">` + name + `</strong>,<br>
            Tu as demande a reinitialiser ton mot de passe. Clique sur le bouton ci-dessous (valable 1h).
          </p>
          <table cellpadding="0" cellspacing="0" role="presentation" style="margin:0 auto 36px;">
            <tr>
              <td align="center" style="border-radius:100px;background:#00a9c0;">
                <a href="` + resetURL + `"
                   target="_blank"
                   style="display:inline-block;padding:16px 44px;font-size:15px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:100px;letter-spacing:0.3px;font-family:Arial,sans-serif;">
                  Choisir un nouveau mot de passe
                </a>
              </td>
            </tr>
          </table>
          <p style="margin:0 0 6px;font-size:12px;color:#91aab0;line-height:1.5;">
            Bouton qui ne fonctionne pas ? Copie ce lien :
          </p>
          <p style="margin:0 0 28px;font-size:12px;color:#00a9c0;word-break:break-all;line-height:1.6;">
            ` + resetURL + `
          </p>
          <hr style="border:none;border-top:1px solid #e4eef0;margin:0 0 24px;">
          <p style="margin:0;font-size:12px;color:#a8bfc4;line-height:1.7;">
            Ce lien expire dans <strong style="color:#0e2a2f;">1 heure</strong>.<br>
            Si tu n'as pas fait cette demande, ignore cet e-mail - ton mot de passe reste inchange.
          </p>
        </td>
      </tr>
      <tr>
        <td align="center" style="padding:24px 0 0;">
          <p style="margin:0;font-size:12px;color:#a8bfc4;">
            © 2026 Breezy · Reseau social leger
          </p>
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`
}

func buildVerificationEmailHTML(name, verificationURL string) string {
	return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Confirme ton adresse e-mail</title>
</head>
<body style="margin:0;padding:0;background:#edf6f7;font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:antialiased;">
<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background:#edf6f7;padding:48px 16px;">
  <tr><td align="center">
    <table width="560" cellpadding="0" cellspacing="0" role="presentation" style="max-width:560px;width:100%;">

      <!-- Logo -->
      <tr>
        <td align="center" style="padding-bottom:28px;">
          <span style="font-size:32px;font-weight:900;color:#00a9c0;letter-spacing:-1px;font-family:Arial,sans-serif;">Breezy</span>
        </td>
      </tr>

      <!-- Card -->
      <tr>
        <td style="background:#ffffff;border-radius:24px;padding:48px;box-shadow:0 4px 24px rgba(0,169,192,0.12);">

          <h1 style="margin:0 0 8px;font-size:24px;font-weight:700;color:#0e2a2f;line-height:1.3;">
            Bienvenue sur Breezy&nbsp;!
          </h1>
          <p style="margin:0 0 28px;font-size:15px;color:#5a8a96;line-height:1.7;">
            Bonjour <strong style="color:#0e2a2f;">` + name + `</strong>, ton compte a bien été créé.<br>
            Il te reste une étape : confirme ton adresse e-mail pour commencer à poster.
          </p>

          <!-- CTA Button -->
          <table cellpadding="0" cellspacing="0" role="presentation" style="margin:0 auto 36px;">
            <tr>
              <td align="center" style="border-radius:100px;background:#00a9c0;">
                <a href="` + verificationURL + `"
                   target="_blank"
                   style="display:inline-block;padding:16px 44px;font-size:15px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:100px;letter-spacing:0.3px;font-family:Arial,sans-serif;">
                  Confirmer mon adresse e-mail
                </a>
              </td>
            </tr>
          </table>

          <!-- Fallback link -->
          <p style="margin:0 0 6px;font-size:12px;color:#91aab0;line-height:1.5;">
            Bouton qui ne fonctionne pas ? Copie ce lien :
          </p>
          <p style="margin:0 0 28px;font-size:12px;color:#00a9c0;word-break:break-all;line-height:1.6;">
            ` + verificationURL + `
          </p>

          <hr style="border:none;border-top:1px solid #e4eef0;margin:0 0 24px;">

          <p style="margin:0;font-size:12px;color:#a8bfc4;line-height:1.7;">
            Ce lien expire dans <strong style="color:#0e2a2f;">24 heures</strong>.<br>
            Si tu n'es pas à l'origine de cette inscription, ignore simplement cet e-mail.
          </p>
        </td>
      </tr>

      <!-- Footer -->
      <tr>
        <td align="center" style="padding:24px 0 0;">
          <p style="margin:0;font-size:12px;color:#a8bfc4;">
            © 2026 Breezy · Réseau social léger
          </p>
        </td>
      </tr>

    </table>
  </td></tr>
</table>
</body>
</html>`
}
