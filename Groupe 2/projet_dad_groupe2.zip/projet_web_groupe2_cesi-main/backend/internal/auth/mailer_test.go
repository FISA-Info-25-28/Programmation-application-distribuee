package auth

import (
	"strings"
	"testing"
)

func TestNewVerificationMailerFromEnv(t *testing.T) {
	t.Setenv("SMTP_ENABLED", "false")
	if got := newVerificationMailerFromEnv(); got != nil {
		t.Fatalf("newVerificationMailerFromEnv(disabled) = %T, want nil", got)
	}

	t.Setenv("SMTP_ENABLED", "true")
	t.Setenv("SMTP_PORT", "bad")
	t.Setenv("SMTP_HOST", "localhost")
	t.Setenv("SMTP_FROM", "no-reply@example.com")
	got := newVerificationMailerFromEnv()
	mailer, ok := got.(*smtpMailer)
	if !ok {
		t.Fatalf("newVerificationMailerFromEnv() = %T, want *smtpMailer", got)
	}
	if mailer.port != 1025 || mailer.host != "localhost" || mailer.from != "no-reply@example.com" {
		t.Fatalf("mailer config = %+v, want fallback port and env host/from", mailer)
	}
}

func TestBuildAuthEmailHTML(t *testing.T) {
	verification := buildVerificationEmailHTML("Alice", "https://app.test/verify")
	if !strings.Contains(verification, "Alice") || !strings.Contains(verification, "https://app.test/verify") || !strings.Contains(verification, "Confirmer") {
		t.Fatalf("buildVerificationEmailHTML() missing expected content")
	}

	reset := buildPasswordResetEmailHTML("Bob", "https://app.test/reset")
	if !strings.Contains(reset, "Bob") || !strings.Contains(reset, "https://app.test/reset") || !strings.Contains(reset, "nouveau mot de passe") {
		t.Fatalf("buildPasswordResetEmailHTML() missing expected content")
	}
}

func TestSMTPMailerSendFailures(t *testing.T) {
	mailer := &smtpMailer{host: "127.0.0.1", port: 1, from: "no-reply@example.com"}

	if err := mailer.SendVerificationEmail("to@example.com", "", "https://app.test/verify"); err == nil {
		t.Fatal("SendVerificationEmail() expected SMTP connection error")
	}
	if err := mailer.SendPasswordResetEmail("to@example.com", "", "https://app.test/reset"); err == nil {
		t.Fatal("SendPasswordResetEmail() expected SMTP connection error")
	}

	authMailer := &smtpMailer{host: "127.0.0.1", port: 1, username: "user", password: "pass", from: "no-reply@example.com"}
	if err := authMailer.SendVerificationEmail("to@example.com", "Alice", "https://app.test/verify"); err == nil {
		t.Fatal("SendVerificationEmail(auth) expected SMTP connection error")
	}
}

func TestAccountSuspendedError(t *testing.T) {
	if got := (&AccountSuspendedError{}).Error(); got != "account suspended" {
		t.Fatalf("AccountSuspendedError.Error() = %q", got)
	}
}
