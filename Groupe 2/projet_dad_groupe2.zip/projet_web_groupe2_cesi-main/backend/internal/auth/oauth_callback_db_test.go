package auth

import (
	"context"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// TestGitHubCallbackFullFlowSuccess exerce le chemin complet de GitHubCallback :
// verification du state CSRF, echange du code, recuperation du profil GitHub
// et creation/connexion du compte via une base mockee, jusqu'a la redirection
// finale. C'est le scenario qui manquait pour couvrir github.go:GitHubCallback,
// reste a 5% de couverture car seuls les handlers "BD indisponible" et "non
// configure" etaient testes auparavant.
func TestGitHubCallbackFullFlowSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	t.Setenv("GITHUB_CLIENT_ID", "client-id")
	t.Setenv("GITHUB_CLIENT_SECRET", "client-secret")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")

	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		switch req.URL.Host + req.URL.Path {
		case "github.com/login/oauth/access_token":
			return jsonResponse(`{"access_token":"gh-token","token_type":"bearer"}`), nil
		case "api.github.com/user":
			return jsonResponse(`{"id":42,"login":"octo","name":"Octo Cat","email":""}`), nil
		case "api.github.com/user/emails":
			return jsonResponse(`[{"email":"octo@example.com","primary":true,"verified":true}]`), nil
		default:
			t.Fatalf("unexpected request: %s", req.URL.String())
			return nil, nil
		}
	})

	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/github/callback", handler.GitHubCallback)

	accountID := uuid.New()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectQuery(`INSERT INTO "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "octo", nil))
	mock.ExpectCommit()

	req := httptest.NewRequest(http.MethodGet, "/github/callback?state=good-state&code=auth-code", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_gh_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound {
		t.Fatalf("GitHubCallback() status = %d, want 302: %s", rec.Code, rec.Body.String())
	}
	location := rec.Header().Get("Location")
	if !strings.Contains(location, "github=1") {
		t.Fatalf("GitHubCallback() Location = %q, want github=1", location)
	}
	if len(rec.Result().Cookies()) == 0 {
		t.Fatal("GitHubCallback() should set auth cookies on success")
	}
}

func TestGitHubCallbackNotConfigured(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GITHUB_CLIENT_ID", "")
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/github/callback", handler.GitHubCallback)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/github/callback", nil))
	if rec.Code != http.StatusNotImplemented {
		t.Fatalf("GitHubCallback(not configured) status = %d, want 501", rec.Code)
	}
}

func TestGitHubCallbackStateMismatchRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GITHUB_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/github/callback", handler.GitHubCallback)

	req := httptest.NewRequest(http.MethodGet, "/github/callback?state=mismatch", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_gh_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "githubError=state") {
		t.Fatalf("GitHubCallback(state mismatch) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

func TestGitHubCallbackMissingCodeRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GITHUB_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/github/callback", handler.GitHubCallback)

	req := httptest.NewRequest(http.MethodGet, "/github/callback?state=good-state", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_gh_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "githubError=cancelled") {
		t.Fatalf("GitHubCallback(missing code) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

func TestGitHubCallbackTokenExchangeFailureRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GITHUB_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")

	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		return jsonResponse(`{}`), nil
	})

	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/github/callback", handler.GitHubCallback)

	req := httptest.NewRequest(http.MethodGet, "/github/callback?state=good-state&code=auth-code", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_gh_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "githubError=token") {
		t.Fatalf("GitHubCallback(token failure) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

func TestGitHubCallbackUserInfoFailureRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GITHUB_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")

	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		switch req.URL.Host + req.URL.Path {
		case "github.com/login/oauth/access_token":
			return jsonResponse(`{"access_token":"gh-token"}`), nil
		case "api.github.com/user":
			return &http.Response{StatusCode: 500, Header: make(http.Header), Body: io.NopCloser(strings.NewReader("not json"))}, nil
		default:
			t.Fatalf("unexpected request: %s", req.URL.String())
			return nil, nil
		}
	})

	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/github/callback", handler.GitHubCallback)

	req := httptest.NewRequest(http.MethodGet, "/github/callback?state=good-state&code=auth-code", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_gh_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "githubError=userinfo") {
		t.Fatalf("GitHubCallback(userinfo failure) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

func TestGitHubCallbackPrivateEmailFailureRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GITHUB_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")

	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		switch req.URL.Host + req.URL.Path {
		case "github.com/login/oauth/access_token":
			return jsonResponse(`{"access_token":"gh-token"}`), nil
		case "api.github.com/user":
			return jsonResponse(`{"id":42,"login":"octo","name":"Octo","email":""}`), nil
		case "api.github.com/user/emails":
			return jsonResponse(`[{"email":"unverified@example.com","primary":true,"verified":false}]`), nil
		default:
			t.Fatalf("unexpected request: %s", req.URL.String())
			return nil, nil
		}
	})

	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/github/callback", handler.GitHubCallback)

	req := httptest.NewRequest(http.MethodGet, "/github/callback?state=good-state&code=auth-code", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_gh_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "githubError=email") {
		t.Fatalf("GitHubCallback(email failure) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

func TestGitHubCallbackAccountCreationFailureRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GITHUB_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")

	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		switch req.URL.Host + req.URL.Path {
		case "github.com/login/oauth/access_token":
			return jsonResponse(`{"access_token":"gh-token"}`), nil
		case "api.github.com/user":
			return jsonResponse(`{"id":42,"login":"octo","name":"Octo","email":"octo@example.com"}`), nil
		default:
			t.Fatalf("unexpected request: %s", req.URL.String())
			return nil, nil
		}
	})

	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/github/callback", handler.GitHubCallback)

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).WillReturnError(gorm.ErrInvalidData)
	mock.ExpectRollback()

	req := httptest.NewRequest(http.MethodGet, "/github/callback?state=good-state&code=auth-code", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_gh_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "githubError=account") {
		t.Fatalf("GitHubCallback(account failure) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

// --- Google ---

func TestGoogleCallbackFullFlowSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	t.Setenv("GOOGLE_CLIENT_ID", "client-id")
	t.Setenv("GOOGLE_CLIENT_SECRET", "client-secret")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")

	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		switch req.URL.Host + req.URL.Path {
		case "oauth2.googleapis.com/token":
			return jsonResponse(`{"access_token":"g-token"}`), nil
		case "www.googleapis.com/oauth2/v3/userinfo":
			return jsonResponse(`{"sub":"1","email":"gina@example.com","email_verified":true,"name":"Gina"}`), nil
		default:
			t.Fatalf("unexpected request: %s", req.URL.String())
			return nil, nil
		}
	})

	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/google/callback", handler.GoogleCallback)

	accountID := uuid.New()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectQuery(`INSERT INTO "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "gina", nil))
	mock.ExpectCommit()

	req := httptest.NewRequest(http.MethodGet, "/google/callback?state=good-state&code=auth-code", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_oauth_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound {
		t.Fatalf("GoogleCallback() status = %d, want 302: %s", rec.Code, rec.Body.String())
	}
	if location := rec.Header().Get("Location"); !strings.Contains(location, "google=1") {
		t.Fatalf("GoogleCallback() Location = %q, want google=1", location)
	}
	if len(rec.Result().Cookies()) == 0 {
		t.Fatal("GoogleCallback() should set auth cookies on success")
	}
}

func TestGoogleCallbackNotConfigured(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GOOGLE_CLIENT_ID", "")
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/google/callback", handler.GoogleCallback)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/google/callback", nil))
	if rec.Code != http.StatusNotImplemented {
		t.Fatalf("GoogleCallback(not configured) status = %d, want 501", rec.Code)
	}
}

func TestGoogleCallbackStateMismatchRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GOOGLE_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/google/callback", handler.GoogleCallback)

	req := httptest.NewRequest(http.MethodGet, "/google/callback?state=mismatch", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_oauth_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "googleError=state") {
		t.Fatalf("GoogleCallback(state mismatch) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

func TestGoogleCallbackMissingCodeRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GOOGLE_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/google/callback", handler.GoogleCallback)

	req := httptest.NewRequest(http.MethodGet, "/google/callback?state=good-state", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_oauth_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "googleError=cancelled") {
		t.Fatalf("GoogleCallback(missing code) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

func TestGoogleCallbackTokenExchangeFailureRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GOOGLE_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")

	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		return jsonResponse(`{}`), nil
	})

	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/google/callback", handler.GoogleCallback)

	req := httptest.NewRequest(http.MethodGet, "/google/callback?state=good-state&code=auth-code", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_oauth_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "googleError=token") {
		t.Fatalf("GoogleCallback(token failure) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

func TestGoogleCallbackUserInfoFailureRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GOOGLE_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")

	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		switch req.URL.Host + req.URL.Path {
		case "oauth2.googleapis.com/token":
			return jsonResponse(`{"access_token":"g-token"}`), nil
		case "www.googleapis.com/oauth2/v3/userinfo":
			return jsonResponse(`{"name":"NoEmail"}`), nil
		default:
			t.Fatalf("unexpected request: %s", req.URL.String())
			return nil, nil
		}
	})

	db, _ := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/google/callback", handler.GoogleCallback)

	req := httptest.NewRequest(http.MethodGet, "/google/callback?state=good-state&code=auth-code", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_oauth_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "googleError=userinfo") {
		t.Fatalf("GoogleCallback(userinfo failure) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

func TestGoogleCallbackAccountCreationFailureRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("GOOGLE_CLIENT_ID", "client-id")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")

	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		switch req.URL.Host + req.URL.Path {
		case "oauth2.googleapis.com/token":
			return jsonResponse(`{"access_token":"g-token"}`), nil
		case "www.googleapis.com/oauth2/v3/userinfo":
			return jsonResponse(`{"sub":"1","email":"gina@example.com","email_verified":true,"name":"Gina"}`), nil
		default:
			t.Fatalf("unexpected request: %s", req.URL.String())
			return nil, nil
		}
	})

	db, mock := newMockAuthDB(t)
	handler := &Handler{db: db, service: NewService(NewRepository(db), noopVerificationMailer{})}
	router := gin.New()
	router.GET("/google/callback", handler.GoogleCallback)

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).WillReturnError(gorm.ErrInvalidData)
	mock.ExpectRollback()

	req := httptest.NewRequest(http.MethodGet, "/google/callback?state=good-state&code=auth-code", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_oauth_state", Value: "good-state"})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), "googleError=account") {
		t.Fatalf("GoogleCallback(account failure) = %d/%q", rec.Code, rec.Header().Get("Location"))
	}
}

// --- FindOrCreateGoogleAccount direct unit coverage (transaction error,
// existing-unverified auto-verify path) ---

func TestFindOrCreateGoogleAccountTransactionError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	dbErr := errors.New("insert failed")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).WillReturnError(dbErr)
	mock.ExpectRollback()

	if _, err := service.FindOrCreateGoogleAccount(ctx, "newuser@example.com", "New User"); !errors.Is(err, dbErr) {
		t.Fatalf("FindOrCreateGoogleAccount(transaction error) error = %v, want %v", err, dbErr)
	}
}

func TestFindOrCreateGoogleAccountExistingUnverifiedAutoVerifies(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "gina@example.com", "$google$", "USER", "ACTIVE", nil, nil))
	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "gina", nil))

	resp, err := service.FindOrCreateGoogleAccount(ctx, "gina@example.com", "Gina")
	if err != nil || resp.AccessToken == "" {
		t.Fatalf("FindOrCreateGoogleAccount(unverified) = %+v, %v", resp, err)
	}
}

func TestFindOrCreateGoogleAccountInactiveExisting(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "gina@example.com", "$google$", "USER", "BANNED", &now, nil))

	if _, err := service.FindOrCreateGoogleAccount(ctx, "gina@example.com", "Gina"); !errors.Is(err, ErrInactiveAccount) {
		t.Fatalf("FindOrCreateGoogleAccount(inactive) error = %v", err)
	}
}

func TestFindOrCreateGoogleAccountLookupError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	dbErr := errors.New("db down")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(dbErr)

	if _, err := service.FindOrCreateGoogleAccount(ctx, "gina@example.com", "Gina"); !errors.Is(err, dbErr) {
		t.Fatalf("FindOrCreateGoogleAccount(lookup error) error = %v, want %v", err, dbErr)
	}
}

// --- generateGoogleUsername ---

func TestGenerateGoogleUsernamePrefersDisplayName(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)

	username, err := service.generateGoogleUsername(ctx, "gina@example.com", "Gina Stark!!")
	if err != nil || username != "ginastark" {
		t.Fatalf("generateGoogleUsername() = %q, %v, want ginastark", username, err)
	}
}

func TestGenerateGoogleUsernameCollisionThenEmailFallback(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	// "gina" pris, tous les suffixes 1..99 aussi -> fallback sur l'email.
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnRows(profileRows(uuid.New(), uuid.New(), "gina", nil))
	for i := 1; i <= 99; i++ {
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnRows(profileRows(uuid.New(), uuid.New(), "taken", nil))
	}
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)

	username, err := service.generateGoogleUsername(ctx, "gina@example.com", "Gina")
	if err != nil || username != "gina" {
		t.Fatalf("generateGoogleUsername(collision then email) = %q, %v, want gina", username, err)
	}
}

func TestGenerateGoogleUsernameFallsBackToRandomToken(t *testing.T) {
	db, _ := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	username, err := service.generateGoogleUsername(ctx, "a@b.com", "")
	if err != nil || len(username) < 4 || username[:4] != "user" {
		t.Fatalf("generateGoogleUsername(no candidates) = %q, %v, want user-prefixed token", username, err)
	}
}
