package auth

import (
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
)

type roundTripFunc func(*http.Request) (*http.Response, error)

func (f roundTripFunc) RoundTrip(req *http.Request) (*http.Response, error) {
	return f(req)
}

func withHTTPTransport(t *testing.T, fn roundTripFunc) {
	t.Helper()
	previous := http.DefaultClient
	http.DefaultClient = &http.Client{Transport: fn}
	t.Cleanup(func() { http.DefaultClient = previous })
}

func jsonResponse(body string) *http.Response {
	return &http.Response{
		StatusCode: http.StatusOK,
		Header:     make(http.Header),
		Body:       io.NopCloser(strings.NewReader(body)),
	}
}

func TestGoogleOAuthAPIHelpers(t *testing.T) {
	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		switch req.URL.Host + req.URL.Path {
		case "oauth2.googleapis.com/token":
			return jsonResponse(`{"access_token":"google-token"}`), nil
		case "www.googleapis.com/oauth2/v3/userinfo":
			if got := req.Header.Get("Authorization"); got != "Bearer google-token" {
				t.Fatalf("Authorization = %q, want bearer token", got)
			}
			return jsonResponse(`{"sub":"1","email":"user@example.com","email_verified":true,"name":"User","given_name":"U"}`), nil
		default:
			t.Fatalf("unexpected request: %s", req.URL.String())
			return nil, nil
		}
	})

	token, err := exchangeGoogleCode("code", "client", "secret", "http://redirect")
	if err != nil || token.AccessToken != "google-token" {
		t.Fatalf("exchangeGoogleCode() = %+v/%v, want token", token, err)
	}

	info, err := fetchGoogleUserInfo(token.AccessToken)
	if err != nil || info.Email != "user@example.com" || info.Name != "User" {
		t.Fatalf("fetchGoogleUserInfo() = %+v/%v, want user info", info, err)
	}
}

func TestGoogleOAuthAPIHelpersRejectMissingFields(t *testing.T) {
	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		switch req.URL.Host + req.URL.Path {
		case "oauth2.googleapis.com/token":
			return jsonResponse(`{}`), nil
		case "www.googleapis.com/oauth2/v3/userinfo":
			return jsonResponse(`{"name":"User"}`), nil
		default:
			t.Fatalf("unexpected request: %s", req.URL.String())
			return nil, nil
		}
	})

	if _, err := exchangeGoogleCode("code", "client", "secret", "http://redirect"); err == nil {
		t.Fatal("exchangeGoogleCode() expected missing access token error")
	}
	if _, err := fetchGoogleUserInfo("token"); err == nil {
		t.Fatal("fetchGoogleUserInfo() expected missing email error")
	}
}

func TestGitHubOAuthAPIHelpers(t *testing.T) {
	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		switch req.URL.Host + req.URL.Path {
		case "github.com/login/oauth/access_token":
			if got := req.Header.Get("Accept"); got != "application/json" {
				t.Fatalf("Accept = %q, want application/json", got)
			}
			return jsonResponse(`{"access_token":"github-token","token_type":"bearer"}`), nil
		case "api.github.com/user":
			return jsonResponse(`{"id":42,"login":"octo","name":"Octo","email":""}`), nil
		case "api.github.com/user/emails":
			return jsonResponse(`[{"email":"secondary@example.com","primary":false,"verified":true},{"email":"primary@example.com","primary":true,"verified":true}]`), nil
		default:
			t.Fatalf("unexpected request: %s", req.URL.String())
			return nil, nil
		}
	})

	token, err := exchangeGitHubCode("code", "client", "secret")
	if err != nil || token.AccessToken != "github-token" {
		t.Fatalf("exchangeGitHubCode() = %+v/%v, want token", token, err)
	}

	user, err := fetchGitHubUser(token.AccessToken)
	if err != nil || user.Login != "octo" || user.ID != 42 {
		t.Fatalf("fetchGitHubUser() = %+v/%v, want user", user, err)
	}

	email, err := fetchGitHubPrimaryEmail(token.AccessToken)
	if err != nil || email != "primary@example.com" {
		t.Fatalf("fetchGitHubPrimaryEmail() = %q/%v, want primary email", email, err)
	}
}

func TestGoogleOAuthAPIHelpersTransportError(t *testing.T) {
	transportErr := errors.New("network down")
	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		return nil, transportErr
	})

	if _, err := exchangeGoogleCode("code", "client", "secret", "http://redirect"); err == nil {
		t.Fatal("exchangeGoogleCode() expected transport error")
	}
	if _, err := fetchGoogleUserInfo("token"); err == nil {
		t.Fatal("fetchGoogleUserInfo() expected transport error")
	}
}

func TestGoogleOAuthAPIHelpersDecodeError(t *testing.T) {
	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: http.StatusOK, Header: make(http.Header), Body: io.NopCloser(strings.NewReader("not json"))}, nil
	})

	if _, err := exchangeGoogleCode("code", "client", "secret", "http://redirect"); err == nil {
		t.Fatal("exchangeGoogleCode() expected decode error")
	}
	if _, err := fetchGoogleUserInfo("token"); err == nil {
		t.Fatal("fetchGoogleUserInfo() expected decode error")
	}
}

func TestGitHubOAuthAPIHelpersTransportError(t *testing.T) {
	transportErr := errors.New("network down")
	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		return nil, transportErr
	})

	if _, err := exchangeGitHubCode("code", "client", "secret"); err == nil {
		t.Fatal("exchangeGitHubCode() expected transport error")
	}
	if _, err := fetchGitHubUser("token"); err == nil {
		t.Fatal("fetchGitHubUser() expected transport error")
	}
	if _, err := fetchGitHubPrimaryEmail("token"); err == nil {
		t.Fatal("fetchGitHubPrimaryEmail() expected transport error")
	}
}

func TestGitHubOAuthAPIHelpersDecodeError(t *testing.T) {
	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: http.StatusOK, Header: make(http.Header), Body: io.NopCloser(strings.NewReader("not json"))}, nil
	})

	if _, err := exchangeGitHubCode("code", "client", "secret"); err == nil {
		t.Fatal("exchangeGitHubCode() expected decode error")
	}
	if _, err := fetchGitHubUser("token"); err == nil {
		t.Fatal("fetchGitHubUser() expected decode error")
	}
	if _, err := fetchGitHubPrimaryEmail("token"); err == nil {
		t.Fatal("fetchGitHubPrimaryEmail() expected decode error")
	}
}

func TestGitHubPrimaryEmailFallbacks(t *testing.T) {
	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		return jsonResponse(`[{"email":"verified@example.com","primary":false,"verified":true}]`), nil
	})
	email, err := fetchGitHubPrimaryEmail("token")
	if err != nil || email != "verified@example.com" {
		t.Fatalf("fetchGitHubPrimaryEmail(fallback) = %q/%v", email, err)
	}

	withHTTPTransport(t, func(req *http.Request) (*http.Response, error) {
		return jsonResponse(`[{"email":"private@example.com","primary":true,"verified":false}]`), nil
	})
	if _, err := fetchGitHubPrimaryEmail("token"); err == nil {
		t.Fatal("fetchGitHubPrimaryEmail() expected no verified email error")
	}
}

func TestOAuthLoginRedirects(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Setenv("GOOGLE_CLIENT_ID", "google-client")
	t.Setenv("GOOGLE_REDIRECT_URL", "http://localhost/google/callback")
	t.Setenv("GITHUB_CLIENT_ID", "github-client")
	t.Setenv("COOKIE_SECURE", "true")

	handler := NewHandler(nil)
	router := gin.New()
	router.GET("/google", handler.GoogleLogin)
	router.GET("/github", handler.GitHubLogin)

	tests := []struct {
		path     string
		contains string
		cookie   string
	}{
		{path: "/google", contains: "accounts.google.com/o/oauth2/v2/auth", cookie: "breezy_oauth_state"},
		{path: "/github", contains: "github.com/login/oauth/authorize", cookie: "breezy_gh_state"},
	}

	for _, tt := range tests {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, tt.path, nil))
		if rec.Code != http.StatusFound {
			t.Fatalf("%s status = %d, want 302", tt.path, rec.Code)
		}
		if location := rec.Header().Get("Location"); !strings.Contains(location, tt.contains) {
			t.Fatalf("%s Location = %q, want %q", tt.path, location, tt.contains)
		}
		if cookies := rec.Result().Cookies(); len(cookies) == 0 || cookies[0].Name != tt.cookie {
			t.Fatalf("%s cookies = %+v, want %s", tt.path, cookies, tt.cookie)
		}
	}
}
