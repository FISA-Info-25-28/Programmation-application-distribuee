package auth

import (
	"context"
	"time"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// Repository encapsule les acces GORM necessaires au domaine auth.
type Repository struct {
	db *gorm.DB
}

// NewRepository cree un repository auth.
// Entree : db.
// Sortie : valeur retour de type *Repository.
func NewRepository(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

// WithDB change la connexion GORM du repository.
// Entree : db.
// Sortie : valeur retour de type *Repository.
func (r *Repository) WithDB(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

// FindAccountByEmail recherche un compte par e-mail.
// Entree : ctx, email.
// casse.
// Sortie : valeurs retour de la fonction.
// gorm.ErrRecordNotFound.
func (r *Repository) FindAccountByEmail(ctx context.Context, email string) (models.Account, error) {
	var account models.Account
	err := r.db.WithContext(ctx).Where("lower(email) = lower(?)", email).First(&account).Error
	return account, err
}

// FindAccountByID recherche un compte par identifiant.
// Entree : ctx, id.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindAccountByID(ctx context.Context, id uuid.UUID) (models.Account, error) {
	var account models.Account
	err := r.db.WithContext(ctx).First(&account, "id = ?", id).Error
	return account, err
}

// CreateAccount insere un compte.
// Entree : ctx, account.
// Sortie : erreur eventuelle.
func (r *Repository) CreateAccount(ctx context.Context, account *models.Account) error {
	return r.db.WithContext(ctx).Create(account).Error
}

// FindProfileByUsername recherche un profil par username dans le schema profiles.
// Entree : ctx, username.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindProfileByUsername(ctx context.Context, username string) (models.Profile, error) {
	var profile models.Profile
	err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("lower(username) = lower(?)", username).
		First(&profile).
		Error
	return profile, err
}

func (r *Repository) FindProfileByAccountID(ctx context.Context, accountID uuid.UUID) (models.Profile, error) {
	var profile models.Profile
	err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("account_id = ?", accountID).
		First(&profile).
		Error
	return profile, err
}

// CreateProfile insere le profil public associe au compte cree.
// Entree : ctx, profile.
// Sortie : erreur eventuelle.
func (r *Repository) CreateProfile(ctx context.Context, profile *models.Profile) error {
	return r.db.WithContext(ctx).Table("profiles.profiles").Create(profile).Error
}

// UpdateAccount sauvegarde un compte.
// Entree : ctx, account.
// Sortie : erreur eventuelle.
func (r *Repository) UpdateAccount(ctx context.Context, account *models.Account) error {
	return r.db.WithContext(ctx).Save(account).Error
}

func (r *Repository) CreateEmailVerificationToken(ctx context.Context, token *models.EmailVerificationToken) error {
	return r.db.WithContext(ctx).Create(token).Error
}

func (r *Repository) FindEmailVerificationTokenByHash(ctx context.Context, tokenHash string) (models.EmailVerificationToken, error) {
	var token models.EmailVerificationToken
	err := r.db.WithContext(ctx).
		Where("token_hash = ?", tokenHash).
		First(&token).Error
	return token, err
}

func (r *Repository) DeleteEmailVerificationTokensByAccountID(ctx context.Context, accountID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Where("account_id = ?", accountID).
		Delete(&models.EmailVerificationToken{}).Error
}

func (r *Repository) CreatePasswordResetToken(ctx context.Context, token *models.PasswordResetToken) error {
	return r.db.WithContext(ctx).Create(token).Error
}

func (r *Repository) FindPasswordResetTokenByHash(ctx context.Context, tokenHash string) (models.PasswordResetToken, error) {
	var token models.PasswordResetToken
	err := r.db.WithContext(ctx).
		Where("token_hash = ?", tokenHash).
		First(&token).Error
	return token, err
}

func (r *Repository) DeletePasswordResetTokensByAccountID(ctx context.Context, accountID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Where("account_id = ?", accountID).
		Delete(&models.PasswordResetToken{}).Error
}

func (r *Repository) UpdateAccountStatus(ctx context.Context, id uuid.UUID, status string) (models.Account, error) {
	var account models.Account
	err := r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.First(&account, "id = ?", id).Error; err != nil {
			return err
		}

		account.Status = status
		return tx.Save(&account).Error
	})

	return account, err
}

// CreateSession enregistre une session.
// Entree : ctx, session.
// Sortie : erreur eventuelle.
func (r *Repository) CreateSession(ctx context.Context, session *models.Session) error {
	return r.db.WithContext(ctx).Create(session).Error
}

// FindValidSessionByRefreshHash recherche une session utilisable.
// Entree : ctx, refreshHash, now.
// l'expiration.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindValidSessionByRefreshHash(ctx context.Context, refreshHash string, now time.Time) (models.Session, error) {
	var session models.Session
	err := r.db.WithContext(ctx).
		Where("refresh_token_hash = ? AND revoked_at IS NULL AND expires_at > ?", refreshHash, now).
		First(&session).Error
	return session, err
}

// RevokeSession revoque une session par ID.
// Entree : ctx, sessionID, now.
// revocation.
// Sortie : erreur eventuelle.
func (r *Repository) RevokeSession(ctx context.Context, sessionID uuid.UUID, now time.Time) error {
	result := r.db.WithContext(ctx).
		Model(&models.Session{}).
		Where("id = ? AND revoked_at IS NULL", sessionID).
		Update("revoked_at", now)
	if result.Error != nil {
		return result.Error
	}
	if result.RowsAffected != 1 {
		return gorm.ErrRecordNotFound
	}
	return nil
}

// RevokeSessionByRefreshHash revoque une session par refresh token hashe.
// Entree : ctx, refreshHash, now.
// revocation.
// Sortie : erreur eventuelle.
func (r *Repository) RevokeSessionByRefreshHash(ctx context.Context, refreshHash string, now time.Time) error {
	return r.db.WithContext(ctx).
		Model(&models.Session{}).
		Where("refresh_token_hash = ? AND revoked_at IS NULL", refreshHash).
		Update("revoked_at", now).Error
}

// Transaction execute une operation atomique.
// Entree : ctx, fn.
// branche sur la transaction.
// Sortie : valeur retour de type error) error.
func (r *Repository) Transaction(ctx context.Context, fn func(txRepo *Repository) error) error {
	return r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		return fn(r.WithDB(tx))
	})
}
