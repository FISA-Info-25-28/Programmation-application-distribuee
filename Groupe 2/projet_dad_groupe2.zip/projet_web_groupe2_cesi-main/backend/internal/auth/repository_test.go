package auth

import (
	"context"
	"errors"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestRepositoryWithDB(t *testing.T) {
	repo := NewRepository(&gorm.DB{})
	nextDB := &gorm.DB{}
	next := repo.WithDB(nextDB)
	if next == repo {
		t.Fatal("WithDB() should return a new repository")
	}
	if next.db != nextDB {
		t.Fatal("WithDB() did not use provided DB")
	}
}

func TestAuthRepositoryQueriesDryRun(t *testing.T) {
	repo := NewRepository(authDryRunDB(t))
	ctx := context.Background()
	accountID := uuid.New()
	sessionID := uuid.New()
	now := time.Now()

	_, _ = repo.FindAccountByEmail(ctx, "a@example.com")
	_, _ = repo.FindAccountByID(ctx, accountID)
	_ = repo.CreateAccount(ctx, &models.Account{ID: accountID, Email: "a@example.com"})
	_, _ = repo.FindProfileByUsername(ctx, "alice")
	_, _ = repo.FindProfileByAccountID(ctx, accountID)
	_ = repo.CreateProfile(ctx, &models.Profile{AccountID: accountID, Username: "alice"})
	_ = repo.UpdateAccount(ctx, &models.Account{ID: accountID, Email: "a@example.com"})
	_ = repo.CreateEmailVerificationToken(ctx, &models.EmailVerificationToken{AccountID: accountID, TokenHash: "hash", ExpiresAt: now})
	_, _ = repo.FindEmailVerificationTokenByHash(ctx, "hash")
	_ = repo.DeleteEmailVerificationTokensByAccountID(ctx, accountID)
	_ = repo.CreatePasswordResetToken(ctx, &models.PasswordResetToken{AccountID: accountID, TokenHash: "hash", ExpiresAt: now})
	_, _ = repo.FindPasswordResetTokenByHash(ctx, "hash")
	_ = repo.DeletePasswordResetTokensByAccountID(ctx, accountID)
	_, _ = repo.UpdateAccountStatus(ctx, accountID, "SUSPENDED")
	_ = repo.CreateSession(ctx, &models.Session{ID: sessionID, AccountID: accountID, RefreshTokenHash: "hash", ExpiresAt: now})
	_, _ = repo.FindValidSessionByRefreshHash(ctx, "hash", now)
	_ = repo.RevokeSession(ctx, sessionID, now)
	_ = repo.RevokeSessionByRefreshHash(ctx, "hash", now)
	_ = repo.Transaction(ctx, func(txRepo *Repository) error { return nil })
}

// TestRepositoryRevokeSessionNotFoundAndError exerce les deux branches d'erreur
// de RevokeSession non couvertes par le DryRun : aucune ligne affectee (session
// deja revoquee ou inconnue) et une erreur SQL explicite.
func TestRepositoryRevokeSessionNotFoundAndError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	sessionID := uuid.New()
	now := time.Now()

	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "sessions"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectCommit()
	if err := repo.RevokeSession(context.Background(), sessionID, now); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("RevokeSession(no rows) error = %v, want ErrRecordNotFound", err)
	}

	dbErr := sqlmock.ErrCancelled
	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "sessions"`).WillReturnError(dbErr)
	mock.ExpectRollback()
	if err := repo.RevokeSession(context.Background(), sessionID, now); err == nil {
		t.Fatal("RevokeSession(db error) expected an error")
	}
}

func authDryRunDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{DryRun: true})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db
}
