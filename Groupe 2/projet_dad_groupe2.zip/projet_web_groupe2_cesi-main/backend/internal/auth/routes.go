package auth

import (
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
)

// RegisterRoutes declare les endpoints HTTP du service auth.
// Entree : router, handler.
// Sortie : aucune valeur.
func RegisterRoutes(router *gin.Engine, handler *Handler) {
	router.Use(middleware.JSONBody())

	router.GET("/health", handler.Health)
	router.GET("/check-username", handler.CheckUsername)
	router.GET("/check-email", handler.CheckEmail)
	router.POST("/register", handler.Register)
	router.GET("/verify-email", handler.VerifyEmail)
	router.POST("/resend-verification", handler.ResendVerificationEmail)
	router.POST("/forgot-password", handler.ForgotPassword)
	router.POST("/reset-password", handler.ResetPassword)
	router.POST("/login", handler.Login)
	router.POST("/logout", handler.Logout)
	router.POST("/refresh", handler.Refresh)
	router.GET("/me", middleware.AuthRequired(), handler.Me)
	router.PATCH("/me/password", middleware.AuthRequired(), handler.ChangePassword)
	router.GET("/google", handler.GoogleLogin)
	router.GET("/google/callback", handler.GoogleCallback)
	router.GET("/github", handler.GitHubLogin)
	router.GET("/github/callback", handler.GitHubCallback)
	router.PATCH(
		"/accounts/:id/status",
		middleware.AuthRequired(),
		middleware.RequireRole(middleware.RoleAdmin),
		handler.UpdateAccountStatus,
	)
}
