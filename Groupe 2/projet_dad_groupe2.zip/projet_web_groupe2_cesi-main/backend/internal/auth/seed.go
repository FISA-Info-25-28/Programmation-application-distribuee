package auth

import (
	"context"
	"errors"
	"strings"

	"breezy/backend/internal/models"

	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

// demoAccountSeed decrit un compte de demonstration a creer au demarrage.
type demoAccountSeed struct {
	Email       string
	Password    string
	Role        string
	Username    string
	DisplayName string
}

// demoAccounts liste les comptes de demonstration disponibles en developpement.
var demoAccounts = []demoAccountSeed{
	{Email: "admin@breezy.demo", Password: "Demo1234!", Role: "ADMIN", Username: "demo_admin_breezy", DisplayName: "Admin Breezy"},
	{Email: "moderator@breezy.demo", Password: "Demo1234!", Role: "MODERATOR", Username: "demo_mod_breezy", DisplayName: "Moderateur Breezy"},
	{Email: "user@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "demo_user_breezy", DisplayName: "User Breezy"},
	{Email: "maeva@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "maeva_dev", DisplayName: "Maeva Dev"},
	{Email: "thais@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "thais_design", DisplayName: "Thais Design"},
	{Email: "lisa@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "lisa_code", DisplayName: "Lisa Code"},
	{Email: "allan@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "allan_fullstack", DisplayName: "Allan Fullstack"},
	{Email: "nina@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "nina_product", DisplayName: "Nina Product"},
	{Email: "samir@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "samir_api", DisplayName: "Samir API"},
	{Email: "jade@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "jade_ui", DisplayName: "Jade UI"},
	{Email: "enzo@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "enzo_ops", DisplayName: "Enzo Ops"},
	{Email: "romane@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "romane_data", DisplayName: "Romane Data"},
	{Email: "yanis@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "yanis_mobile", DisplayName: "Yanis Mobile"},
	{Email: "clara@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "clara_ux", DisplayName: "Clara UX"},
	{Email: "noah@breezy.demo", Password: "Demo1234!", Role: "USER", Username: "noah_security", DisplayName: "Noah Security"},
}

// SeedDemoAccounts cree les comptes de demonstration manquants.
// Entree : ctx, db.
// Sortie : erreur eventuelle.
// nil. Les comptes existants ne sont pas modifies.
func SeedDemoAccounts(ctx context.Context, db *gorm.DB) error {
	repo := NewRepository(db)

	for _, seed := range demoAccounts {
		email := strings.ToLower(strings.TrimSpace(seed.Email))
		passwordHash, err := bcrypt.GenerateFromPassword([]byte(seed.Password), bcrypt.DefaultCost)
		if err != nil {
			return err
		}

		var account models.Account
		existing, err := repo.FindAccountByEmail(ctx, email)
		if err != nil {
			if !errors.Is(err, gorm.ErrRecordNotFound) {
				return err
			}
			account = models.Account{
				Email:        email,
				PasswordHash: string(passwordHash),
				Role:         seed.Role,
				Status:       "ACTIVE",
			}
			if err := repo.CreateAccount(ctx, &account); err != nil {
				return err
			}
		} else {
			account = existing
		}

		if err := ensureDemoProfile(ctx, repo, account.ID, seed); err != nil {
			return err
		}
	}

	return nil
}

func ensureDemoProfile(ctx context.Context, repo *Repository, accountID uuid.UUID, seed demoAccountSeed) error {
	if _, err := repo.FindProfileByAccountID(ctx, accountID); err == nil {
		return nil
	} else if !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}

	displayName := seed.DisplayName
	return repo.CreateProfile(ctx, &models.Profile{
		AccountID:   accountID,
		Username:    seed.Username,
		DisplayName: &displayName,
	})
}
