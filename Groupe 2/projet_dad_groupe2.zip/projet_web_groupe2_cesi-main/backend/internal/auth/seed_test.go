package auth

import (
	"context"
	"errors"
	"testing"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

func TestDemoAccountSeedsAreValid(t *testing.T) {
	if len(demoAccounts) == 0 {
		t.Fatal("demoAccounts should not be empty")
	}
	for _, seed := range demoAccounts {
		if seed.Email == "" || seed.Password == "" || seed.Role == "" || seed.Username == "" || seed.DisplayName == "" {
			t.Fatalf("demo account seed has empty required field: %+v", seed)
		}
	}
}

func TestSeedDemoAccountsDryRun(t *testing.T) {
	err := SeedDemoAccounts(context.Background(), authDryRunDB(t))
	if err != nil {
		t.Fatalf("SeedDemoAccounts() unexpected dry-run error: %v", err)
	}
}

// TestSeedDemoAccountsCreatesAccountAndProfileWhenMissing exerce la branche
// "compte absent -> creation" suivie de "profil absent -> creation" de
// SeedDemoAccounts/ensureDemoProfile, qui n'etait pas visitee en DryRun (le
// mode DryRun n'execute jamais la requete, donc ne retourne jamais
// ErrRecordNotFound).
func TestSeedDemoAccountsCreatesAccountAndProfileWhenMissing(t *testing.T) {
	db, mock := newMockAuthDB(t)
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	// On limite la liste aux 17 lignes attendues en isolant le test a un seul
	// compte via un repository direct plutot que SeedDemoAccounts (qui boucle
	// sur demoAccounts entier) pour garder le mock simple et deterministe.
	repo := NewRepository(db)
	seed := demoAccounts[0]

	existing, err := repo.FindAccountByEmail(context.Background(), seed.Email)
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("FindAccountByEmail() error = %v, want ErrRecordNotFound", err)
	}
	_ = existing

	account := models.Account{Email: seed.Email, PasswordHash: "hash", Role: seed.Role, Status: "ACTIVE"}
	if err := repo.CreateAccount(context.Background(), &account); err != nil {
		t.Fatalf("CreateAccount() unexpected error: %v", err)
	}

	if err := ensureDemoProfile(context.Background(), repo, account.ID, seed); err != nil {
		t.Fatalf("ensureDemoProfile() unexpected error: %v", err)
	}
}

func TestSeedDemoAccountsSkipsExistingAccountAndProfile(t *testing.T) {
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	accountID := uuid.New()
	seed := demoAccounts[0]

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, seed.Email, "hash", seed.Role, "ACTIVE", nil, nil))
	existing, err := repo.FindAccountByEmail(context.Background(), seed.Email)
	if err != nil {
		t.Fatalf("FindAccountByEmail() unexpected error: %v", err)
	}

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), existing.ID, seed.Username, nil))
	if err := ensureDemoProfile(context.Background(), repo, existing.ID, seed); err != nil {
		t.Fatalf("ensureDemoProfile(existing) unexpected error: %v", err)
	}
}

func TestEnsureDemoProfileLookupError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	dbErr := errors.New("db down")
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(dbErr)

	if err := ensureDemoProfile(context.Background(), repo, accountID, demoAccounts[0]); !errors.Is(err, dbErr) {
		t.Fatalf("ensureDemoProfile(lookup error) error = %v, want %v", err, dbErr)
	}
}

func TestSeedDemoAccountsBcryptAndAccountLookupErrorsPropagate(t *testing.T) {
	db, mock := newMockAuthDB(t)

	// Premiere iteration : erreur DB autre que RecordNotFound sur la recherche
	// de compte -> SeedDemoAccounts doit la propager immediatement.
	dbErr := errors.New("db down")
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(dbErr)

	if err := SeedDemoAccounts(context.Background(), db); !errors.Is(err, dbErr) {
		t.Fatalf("SeedDemoAccounts(lookup error) error = %v, want %v", err, dbErr)
	}
}

func TestSeedDemoAccountsCreateAccountErrorPropagates(t *testing.T) {
	db, mock := newMockAuthDB(t)
	dbErr := errors.New("insert failed")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).WillReturnError(dbErr)
	mock.ExpectRollback()

	if err := SeedDemoAccounts(context.Background(), db); !errors.Is(err, dbErr) {
		t.Fatalf("SeedDemoAccounts(create error) error = %v, want %v", err, dbErr)
	}
}
