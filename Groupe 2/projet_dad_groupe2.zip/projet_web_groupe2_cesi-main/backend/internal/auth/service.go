package auth

import (
	"context"
	"errors"
	"log"
	"regexp"
	"strings"
	"time"

	"breezy/backend/internal/config"
	"breezy/backend/internal/models"
	"breezy/backend/internal/sanction"
	"breezy/backend/internal/security"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

const (
	// accessTokenTTL definit la duree de validite courte du JWT d'acces.
	accessTokenTTL = 5 * time.Minute
	// refreshTokenTTL definit la duree de validite longue du refresh token.
	refreshTokenTTL = 30 * 24 * time.Hour
	// verificationTokenTTL definit la duree de validite d'un lien de verification.
	verificationTokenTTL = 24 * time.Hour
	// resetTokenTTL definit la duree de validite d'un lien de reinitialisation.
	resetTokenTTL = 1 * time.Hour
)

var usernamePattern = regexp.MustCompile(`^[A-Za-z0-9_]{3,30}$`)

var (
	// ErrEmailAlreadyRegistered signale qu'un compte utilise deja cet e-mail.
	ErrEmailAlreadyRegistered = errors.New("email already registered")
	// ErrUsernameAlreadyRegistered signale qu'un profil utilise deja ce nom.
	ErrUsernameAlreadyRegistered = errors.New("username already registered")
	// ErrInvalidUsername signale un nom d'utilisateur refuse par les regles.
	ErrInvalidUsername = errors.New("invalid username")
	// ErrInactiveAccount signale qu'un compte existe mais ne peut pas se connecter.
	ErrInactiveAccount = errors.New("account is not active")
	// ErrAccountBanned signale qu'un compte est banni definitivement.
	ErrAccountBanned = errors.New("account banned")
	// ErrInvalidCredentials signale une erreur d'e-mail ou de mot de passe.
	ErrInvalidCredentials = errors.New("invalid credentials")
	// ErrInvalidRefreshToken signale un refresh token inconnu, expire ou revoque.
	ErrInvalidRefreshToken = errors.New("invalid refresh token")
	// ErrEmailNotVerified signale qu'un compte doit confirmer son e-mail avant connexion.
	ErrEmailNotVerified = errors.New("email not verified")
	// ErrVerificationEmailFailed signale un echec d'envoi du mail de verification.
	ErrVerificationEmailFailed = errors.New("verification email failed")
	// ErrInvalidVerificationToken signale un token de verification inconnu.
	ErrInvalidVerificationToken = errors.New("invalid verification token")
	// ErrExpiredVerificationToken signale un token de verification expire.
	ErrExpiredVerificationToken = errors.New("expired verification token")
	// ErrEmailAlreadyVerified signale qu'aucune verification supplementaire n'est necessaire.
	ErrEmailAlreadyVerified = errors.New("email already verified")
	// ErrInvalidResetToken signale un token de reinitialisation inconnu ou deja utilise.
	ErrInvalidResetToken = errors.New("invalid reset token")
	// ErrExpiredResetToken signale un token de reinitialisation expire.
	ErrExpiredResetToken = errors.New("expired reset token")
)

// AccountSuspendedError signale qu'un compte est suspendu temporairement.
// Porte la date de fin pour que le handler puisse la renvoyer au client.
type AccountSuspendedError struct {
	SuspendedUntil time.Time
}

// Error retourne le message standard associe a une suspension de compte.
// Entree : aucune entree directe.
// Sortie : valeur retour de type string.
func (e *AccountSuspendedError) Error() string { return "account suspended" }

// Service porte la logique metier de l'authentification.
type Service struct {
	repo   *Repository
	mailer verificationMailer
}

// NewService cree un service auth.
// Entree : repo, mailer.
// Sortie : valeur retour de type *Service.
func NewService(repo *Repository, mailer verificationMailer) *Service {
	return &Service{repo: repo, mailer: mailer}
}

// UsernameAvailable verifie qu'un username respecte le format et n'existe pas deja.
// Entree : ctx, username.
// Sortie : valeurs retour de la fonction.
func (s *Service) UsernameAvailable(ctx context.Context, username string) (bool, error) {
	username = strings.TrimSpace(username)
	if !usernamePattern.MatchString(username) {
		return false, ErrInvalidUsername
	}

	if _, err := s.repo.FindProfileByUsername(ctx, username); err == nil {
		return false, nil
	} else if !errors.Is(err, gorm.ErrRecordNotFound) {
		return false, err
	}

	return true, nil
}

// EmailAvailable verifie qu'une adresse e-mail n'est pas deja rattachee a un compte.
// Entree : ctx, email.
// Sortie : valeurs retour de la fonction.
func (s *Service) EmailAvailable(ctx context.Context, email string) (bool, error) {
	email = strings.ToLower(strings.TrimSpace(email))

	if _, err := s.repo.FindAccountByEmail(ctx, email); err == nil {
		return false, nil
	} else if !errors.Is(err, gorm.ErrRecordNotFound) {
		return false, err
	}

	return true, nil
}

// Register inscrit un nouvel utilisateur.
// Entree : ctx, email, password, username, displayName.
// le client.
// Sortie : valeurs retour de la fonction.
// une erreur si l'e-mail existe deja, si le hash echoue ou si la base refuse
// l'operation.
func (s *Service) Register(ctx context.Context, email, password, username, displayName string) (registerResponse, error) {
	email = strings.ToLower(strings.TrimSpace(email))
	username = strings.TrimSpace(username)
	displayName = strings.TrimSpace(displayName)

	if !usernamePattern.MatchString(username) {
		return registerResponse{}, ErrInvalidUsername
	}

	if _, err := s.repo.FindAccountByEmail(ctx, email); err == nil {
		return registerResponse{}, ErrEmailAlreadyRegistered
	} else if !errors.Is(err, gorm.ErrRecordNotFound) {
		return registerResponse{}, err
	}

	if _, err := s.repo.FindProfileByUsername(ctx, username); err == nil {
		return registerResponse{}, ErrUsernameAlreadyRegistered
	} else if !errors.Is(err, gorm.ErrRecordNotFound) {
		return registerResponse{}, err
	}

	passwordHash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return registerResponse{}, err
	}

	account := models.Account{
		Email:        email,
		PasswordHash: string(passwordHash),
		Role:         "USER",
		Status:       "ACTIVE",
	}

	var (
		response          registerResponse
		verificationToken string
	)
	err = s.repo.Transaction(ctx, func(txRepo *Repository) error {
		if err := txRepo.CreateAccount(ctx, &account); err != nil {
			return err
		}

		profile := models.Profile{
			AccountID:   account.ID,
			Username:    username,
			DisplayName: &displayName,
		}
		if err := txRepo.CreateProfile(ctx, &profile); err != nil {
			return err
		}

		user, err := accountToResponse(ctx, txRepo, account)
		if err != nil {
			return err
		}

		verificationToken, err = createEmailVerificationToken(ctx, txRepo, account.ID)
		if err != nil {
			return err
		}

		response = registerResponse{
			Message:                   "account created, verification email sent",
			RequiresEmailVerification: true,
			VerificationEmailSent:     false,
			User:                      user,
		}
		return nil
	})
	if err != nil {
		return registerResponse{}, err
	}

	if err := s.sendVerificationEmail(account.Email, displayName, verificationToken); err != nil {
		log.Printf("[auth] SMTP error for %s: %v", account.Email, err)
		// SMTP inaccessible mais le compte est déjà persisté - on l'auto-vérifie
		// pour que l'utilisateur puisse se connecter sans passer par l'e-mail.
		now := time.Now().UTC()
		_ = s.repo.Transaction(ctx, func(txRepo *Repository) error {
			acc, err := txRepo.FindAccountByID(ctx, account.ID)
			if err != nil {
				return err
			}
			acc.EmailVerifiedAt = &now
			return txRepo.UpdateAccount(ctx, &acc)
		})
		return response, nil
	}

	response.VerificationEmailSent = true
	return response, nil
}

// Login connecte un utilisateur existant.
// Entree : ctx, email, password.
// Sortie : valeurs retour de la fonction.
// identifiants sont invalides, le compte inactif ou la base indisponible.
func (s *Service) Login(ctx context.Context, email, password string) (authResponse, error) {
	account, err := s.repo.FindAccountByEmail(ctx, strings.TrimSpace(email))
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return authResponse{}, ErrInvalidCredentials
		}
		return authResponse{}, err
	}

	if bcrypt.CompareHashAndPassword([]byte(account.PasswordHash), []byte(password)) != nil {
		return authResponse{}, ErrInvalidCredentials
	}
	if account.EmailVerifiedAt == nil {
		return authResponse{}, ErrEmailNotVerified
	}
	if err := reactivateIfExpired(ctx, s.repo, &account); err != nil {
		return authResponse{}, err
	}
	switch account.Status {
	case "SUSPENDED":
		until := time.Time{}
		if account.SuspendedUntil != nil {
			until = *account.SuspendedUntil
		}
		return authResponse{}, &AccountSuspendedError{SuspendedUntil: until}
	case "BANNED":
		return authResponse{}, ErrAccountBanned
	case "ACTIVE":
		// ok
	default:
		return authResponse{}, ErrInactiveAccount
	}

	return createAuthResponse(ctx, s.repo, account)
}

// Logout deconnecte une session.
// Entree : ctx, refreshToken.
// Sortie : erreur eventuelle.
func (s *Service) Logout(ctx context.Context, refreshToken string) error {
	return s.repo.RevokeSessionByRefreshHash(ctx, hashToken(strings.TrimSpace(refreshToken)), time.Now().UTC())
}

// Refresh renouvelle une session.
// Entree : ctx, refreshToken.
// Sortie : valeurs retour de la fonction.
// token, ou une erreur si le token est inconnu, expire, revoque ou si le compte
// n'est plus actif.
func (s *Service) Refresh(ctx context.Context, refreshToken string) (authResponse, error) {
	refreshToken = strings.TrimSpace(refreshToken)
	var response authResponse

	err := s.repo.Transaction(ctx, func(txRepo *Repository) error {
		now := time.Now().UTC()
		session, err := txRepo.FindValidSessionByRefreshHash(ctx, hashToken(refreshToken), now)
		if err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return ErrInvalidRefreshToken
			}
			return err
		}

		account, err := txRepo.FindAccountByID(ctx, session.AccountID)
		if err != nil {
			return err
		}
		if err := reactivateIfExpired(ctx, txRepo, &account); err != nil {
			return err
		}
		if account.Status != "ACTIVE" {
			return ErrInactiveAccount
		}

		accessToken, err := security.SignAccessToken(account.ID, account.Role, accessTokenTTL)
		if err != nil {
			return err
		}

		newRefreshToken, err := randomToken(32)
		if err != nil {
			return err
		}

		if err := txRepo.RevokeSession(ctx, session.ID, now); err != nil {
			return err
		}

		newSession := models.Session{
			AccountID:        account.ID,
			RefreshTokenHash: hashToken(newRefreshToken),
			ExpiresAt:        now.Add(refreshTokenTTL),
		}
		if err := txRepo.CreateSession(ctx, &newSession); err != nil {
			return err
		}

		user, err := accountToResponse(ctx, txRepo, account)
		if err != nil {
			return err
		}

		response = authResponse{
			AccessToken:  accessToken,
			RefreshToken: newRefreshToken,
			TokenType:    "Bearer",
			ExpiresIn:    int64(accessTokenTTL.Seconds()),
			User:         user,
		}
		return nil
	})

	if errors.Is(err, gorm.ErrRecordNotFound) {
		return authResponse{}, ErrInvalidRefreshToken
	}
	return response, err
}

// Me recupere le compte authentifie.
// Entree : ctx, accountID.
// Sortie : valeurs retour de la fonction.
func (s *Service) Me(ctx context.Context, accountID uuid.UUID) (accountResponse, error) {
	account, err := s.repo.FindAccountByID(ctx, accountID)
	if err != nil {
		return accountResponse{}, err
	}
	return accountToResponse(ctx, s.repo, account)
}

// VerifyEmail valide un token de confirmation et marque le compte comme verifie.
// Entree : ctx, token.
// Sortie : valeurs retour de la fonction.
func (s *Service) VerifyEmail(ctx context.Context, token string) (messageResponse, error) {
	token = strings.TrimSpace(token)
	if token == "" {
		return messageResponse{}, ErrInvalidVerificationToken
	}

	err := s.repo.Transaction(ctx, func(txRepo *Repository) error {
		record, err := txRepo.FindEmailVerificationTokenByHash(ctx, hashToken(token))
		if err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return ErrInvalidVerificationToken
			}
			return err
		}

		now := time.Now().UTC()
		if !record.ExpiresAt.After(now) {
			return ErrExpiredVerificationToken
		}

		account, err := txRepo.FindAccountByID(ctx, record.AccountID)
		if err != nil {
			return err
		}

		if account.EmailVerifiedAt == nil {
			account.EmailVerifiedAt = &now
			if err := txRepo.UpdateAccount(ctx, &account); err != nil {
				return err
			}
		}

		return txRepo.DeleteEmailVerificationTokensByAccountID(ctx, account.ID)
	})
	if err != nil {
		return messageResponse{}, err
	}

	return messageResponse{Message: "email verified successfully"}, nil
}

// ResendVerificationEmail regenere un token et renvoie le mail de verification.
// Entree : ctx, email.
// Sortie : valeurs retour de la fonction.
func (s *Service) ResendVerificationEmail(ctx context.Context, email string) (messageResponse, error) {
	email = strings.ToLower(strings.TrimSpace(email))

	account, err := s.repo.FindAccountByEmail(ctx, email)
	if err != nil {
		return messageResponse{}, err
	}
	if account.EmailVerifiedAt != nil {
		return messageResponse{}, ErrEmailAlreadyVerified
	}

	profile, err := s.repo.FindProfileByAccountID(ctx, account.ID)
	if err != nil {
		return messageResponse{}, err
	}

	var verificationToken string
	err = s.repo.Transaction(ctx, func(txRepo *Repository) error {
		var txErr error
		verificationToken, txErr = createEmailVerificationToken(ctx, txRepo, account.ID)
		return txErr
	})
	if err != nil {
		return messageResponse{}, err
	}

	if err := s.sendVerificationEmail(account.Email, profile.DisplayNameOrUsername(), verificationToken); err != nil {
		return messageResponse{}, ErrVerificationEmailFailed
	}

	return messageResponse{Message: "verification email sent"}, nil
}

// ChangePassword met a jour le mot de passe d'un compte authentifie.
// Entree : ctx, accountID, currentPassword, newPassword.
// verifier l'identite et newPassword a enregistrer.
// Sortie : erreur eventuelle.
// stocke, une erreur GORM si le compte n'existe pas ou si la sauvegarde
// echoue, sinon nil.
func (s *Service) ChangePassword(ctx context.Context, accountID uuid.UUID, currentPassword, newPassword string) error {
	account, err := s.repo.FindAccountByID(ctx, accountID)
	if err != nil {
		return err
	}

	if bcrypt.CompareHashAndPassword([]byte(account.PasswordHash), []byte(currentPassword)) != nil {
		return ErrInvalidCredentials
	}

	passwordHash, err := bcrypt.GenerateFromPassword([]byte(newPassword), bcrypt.DefaultCost)
	if err != nil {
		return err
	}

	account.PasswordHash = string(passwordHash)
	return s.repo.UpdateAccount(ctx, &account)
}

// UpdateAccountStatus change le statut d'un compte puis renvoie sa version publique.
// Entree : ctx, accountID, status.
// Sortie : valeurs retour de la fonction.
func (s *Service) UpdateAccountStatus(ctx context.Context, accountID uuid.UUID, status string) (accountResponse, error) {
	account, err := s.repo.UpdateAccountStatus(ctx, accountID, status)
	if err != nil {
		return accountResponse{}, err
	}
	return accountToResponse(ctx, s.repo, account)
}

// reactivateIfExpired leve automatiquement une suspension temporaire arrivee a
// echeance. Entree : ctx pour la requete, repo (ou repo de transaction) pour
// persister, account a inspecter et potentiellement modifier sur place. Sortie :
// nil si rien a faire ou si la reactivation reussit, sinon l'erreur de
// sauvegarde. Un bannissement (SuspendedUntil nil) n'est jamais leve ici.
// Entree : ctx, repo, account.
// Sortie : erreur eventuelle.
func reactivateIfExpired(ctx context.Context, repo *Repository, account *models.Account) error {
	if account.Status != "SUSPENDED" || account.SuspendedUntil == nil {
		return nil
	}
	if account.SuspendedUntil.After(time.Now().UTC()) {
		return nil
	}

	account.Status = "ACTIVE"
	account.SuspendedUntil = nil
	if err := repo.UpdateAccount(ctx, account); err != nil {
		return err
	}

	// La suspension est levee automatiquement : on restaure aussi l'identite du
	// profil et la visibilite des posts anonymises/masques pendant la sanction.
	return sanction.Lift(ctx, repo.db, account.ID)
}

// createAuthResponse construit la reponse de session.
// Entree : ctx, repo, account.
// Sortie : valeurs retour de la fonction.
// erreur si la signature, la generation du token ou la creation de session
// echoue.
func createAuthResponse(ctx context.Context, repo *Repository, account models.Account) (authResponse, error) {
	accessToken, err := security.SignAccessToken(account.ID, account.Role, accessTokenTTL)
	if err != nil {
		return authResponse{}, err
	}

	refreshToken, err := randomToken(32)
	if err != nil {
		return authResponse{}, err
	}

	session := models.Session{
		AccountID:        account.ID,
		RefreshTokenHash: hashToken(refreshToken),
		ExpiresAt:        time.Now().UTC().Add(refreshTokenTTL),
	}
	if err := repo.CreateSession(ctx, &session); err != nil {
		return authResponse{}, err
	}

	now := time.Now().UTC()
	account.LastLoginAt = &now
	// Erreur non bloquante : la colonne peut ne pas encore exister avant migration.
	_ = repo.UpdateAccount(ctx, &account)

	user, err := accountToResponse(ctx, repo, account)
	if err != nil {
		return authResponse{}, err
	}

	return authResponse{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		TokenType:    "Bearer",
		ExpiresIn:    int64(accessTokenTTL.Seconds()),
		User:         user,
	}, nil
}

// createEmailVerificationToken cree un token unique de verification d'e-mail.
// Entree : ctx, repo, accountID.
// Sortie : valeurs retour de la fonction.
func createEmailVerificationToken(ctx context.Context, repo *Repository, accountID uuid.UUID) (string, error) {
	token, err := randomToken(32)
	if err != nil {
		return "", err
	}

	if err := repo.DeleteEmailVerificationTokensByAccountID(ctx, accountID); err != nil {
		return "", err
	}

	record := models.EmailVerificationToken{
		AccountID: accountID,
		TokenHash: hashToken(token),
		ExpiresAt: time.Now().UTC().Add(verificationTokenTTL),
	}
	if err := repo.CreateEmailVerificationToken(ctx, &record); err != nil {
		return "", err
	}

	return token, nil
}

// accountToResponse convertit un compte interne en DTO public.
// Entree : ctx, repo, account.
// Sortie : valeurs retour de la fonction.
func accountToResponse(ctx context.Context, repo *Repository, account models.Account) (accountResponse, error) {
	response := accountResponse{
		ID:          account.ID,
		Email:       account.Email,
		Role:        account.Role,
		Status:      account.Status,
		LastLoginAt: account.LastLoginAt,
	}

	profile, err := repo.FindProfileByAccountID(ctx, account.ID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return response, nil
		}
		return accountResponse{}, err
	}

	response.ProfileID = &profile.ID
	response.Username = profile.Username
	if profile.DisplayName != nil {
		response.DisplayName = *profile.DisplayName
	}

	return response, nil
}

// sendVerificationEmail construit le lien front et envoie le mail de verification.
// Entree : email, displayName, token.
// Sortie : erreur eventuelle.
func (s *Service) sendVerificationEmail(email, displayName, token string) error {
	if s.mailer == nil {
		return ErrVerificationEmailFailed
	}

	baseURL := strings.TrimRight(config.Env("FRONTEND_PUBLIC_URL", config.Env("CORS_ORIGIN", "http://localhost")), "/")
	link := baseURL + "/auth?verifyEmailToken=" + token
	return s.mailer.SendVerificationEmail(email, displayName, link)
}

// ForgotPassword envoie un e-mail de reinitialisation si le compte existe.
// Ne revele jamais si l'e-mail est enregistre ou non (securite anti-enumeration).
// Entree : ctx, email.
// Sortie : erreur eventuelle.
func (s *Service) ForgotPassword(ctx context.Context, email string) error {
	email = strings.ToLower(strings.TrimSpace(email))

	account, err := s.repo.FindAccountByEmail(ctx, email)
	if err != nil {
		return nil // e-mail inconnu : reponse silencieuse
	}

	profile, err := s.repo.FindProfileByAccountID(ctx, account.ID)
	displayName := email
	if err == nil {
		displayName = profile.DisplayNameOrUsername()
	}

	var resetToken string
	err = s.repo.Transaction(ctx, func(txRepo *Repository) error {
		if err := txRepo.DeletePasswordResetTokensByAccountID(ctx, account.ID); err != nil {
			return err
		}
		token, err := randomToken(32)
		if err != nil {
			return err
		}
		resetToken = token
		record := models.PasswordResetToken{
			AccountID: account.ID,
			TokenHash: hashToken(token),
			ExpiresAt: time.Now().UTC().Add(resetTokenTTL),
		}
		return txRepo.CreatePasswordResetToken(ctx, &record)
	})
	if err != nil {
		return err
	}

	baseURL := strings.TrimRight(config.Env("FRONTEND_PUBLIC_URL", config.Env("CORS_ORIGIN", "http://localhost")), "/")
	link := baseURL + "/auth?resetToken=" + resetToken

	if s.mailer == nil {
		log.Printf("[auth] SMTP disabled - reset link for %s: %s", email, link)
		return nil
	}
	if err := s.mailer.SendPasswordResetEmail(email, displayName, link); err != nil {
		log.Printf("[auth] SMTP error sending reset to %s: %v - link: %s", email, err, link)
	}
	return nil
}

// ResetPassword valide le token et met a jour le mot de passe.
// Entree : ctx, tokenRaw, newPassword.
// Sortie : erreur eventuelle.
func (s *Service) ResetPassword(ctx context.Context, tokenRaw, newPassword string) error {
	tokenRaw = strings.TrimSpace(tokenRaw)
	if tokenRaw == "" {
		return ErrInvalidResetToken
	}

	return s.repo.Transaction(ctx, func(txRepo *Repository) error {
		record, err := txRepo.FindPasswordResetTokenByHash(ctx, hashToken(tokenRaw))
		if err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return ErrInvalidResetToken
			}
			return err
		}

		if !record.ExpiresAt.After(time.Now().UTC()) {
			return ErrExpiredResetToken
		}

		account, err := txRepo.FindAccountByID(ctx, record.AccountID)
		if err != nil {
			return err
		}

		passwordHash, err := bcrypt.GenerateFromPassword([]byte(newPassword), bcrypt.DefaultCost)
		if err != nil {
			return err
		}

		account.PasswordHash = string(passwordHash)
		if err := txRepo.UpdateAccount(ctx, &account); err != nil {
			return err
		}

		return txRepo.DeletePasswordResetTokensByAccountID(ctx, account.ID)
	})
}
