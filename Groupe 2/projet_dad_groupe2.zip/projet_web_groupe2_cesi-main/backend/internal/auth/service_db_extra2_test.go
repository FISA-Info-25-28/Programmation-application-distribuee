package auth

import (
	"context"
	"errors"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// --- Refresh transaction error paths ---

// TestServiceRefreshAccountNotFoundMapsToInvalidToken vérifie que quand
// FindAccountByID retourne ErrRecordNotFound dans la transaction Refresh,
// le résultat final est ErrInvalidRefreshToken (line 335 de service.go).
func TestServiceRefreshAccountNotFoundMapsToInvalidToken(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	sessionID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "refresh_token_hash", "expires_at", "revoked_at", "created_at"}).
			AddRow(sessionID, accountID, hashToken("orphan-token"), now.Add(time.Hour), nil, now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectRollback()

	_, err := service.Refresh(ctx, "orphan-token")
	if !errors.Is(err, ErrInvalidRefreshToken) {
		t.Fatalf("Refresh(account not found) error = %v, want ErrInvalidRefreshToken", err)
	}
}

// TestServiceRefreshAccountLookupErrorPropagates vérifie qu'une erreur DB
// générique sur FindAccountByID est renvoyée telle quelle.
func TestServiceRefreshAccountLookupErrorPropagates(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	sessionID := uuid.New()
	now := time.Now().UTC()
	dbErr := errors.New("account db error")

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "refresh_token_hash", "expires_at", "revoked_at", "created_at"}).
			AddRow(sessionID, accountID, hashToken("some-token"), now.Add(time.Hour), nil, now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnError(dbErr)
	mock.ExpectRollback()

	_, err := service.Refresh(ctx, "some-token")
	if !errors.Is(err, dbErr) {
		t.Fatalf("Refresh(account error) error = %v, want %v", err, dbErr)
	}
}

// TestServiceRefreshRevokeSessionErrorPropagates vérifie qu'une erreur sur
// RevokeSession est renvoyée correctement.
func TestServiceRefreshRevokeSessionErrorPropagates(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	sessionID := uuid.New()
	now := time.Now().UTC()
	dbErr := errors.New("revoke error")

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "refresh_token_hash", "expires_at", "revoked_at", "created_at"}).
			AddRow(sessionID, accountID, hashToken("valid-token"), now.Add(time.Hour), nil, now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", &now, nil))
	// RevokeSession : UPDATE sessions SET revoked_at
	mock.ExpectExec(`UPDATE "sessions" SET`).
		WillReturnError(dbErr)
	mock.ExpectRollback()

	_, err := service.Refresh(ctx, "valid-token")
	if !errors.Is(err, dbErr) {
		t.Fatalf("Refresh(revoke error) error = %v, want %v", err, dbErr)
	}
}

// TestServiceRefreshCreateSessionErrorPropagates vérifie qu'une erreur sur
// CreateSession (INSERT sessions) est renvoyée correctement.
func TestServiceRefreshCreateSessionErrorPropagates(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	sessionID := uuid.New()
	now := time.Now().UTC()
	dbErr := errors.New("create session error")

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "refresh_token_hash", "expires_at", "revoked_at", "created_at"}).
			AddRow(sessionID, accountID, hashToken("valid-token2"), now.Add(time.Hour), nil, now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", &now, nil))
	mock.ExpectExec(`UPDATE "sessions" SET`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnError(dbErr)
	mock.ExpectRollback()

	_, err := service.Refresh(ctx, "valid-token2")
	if !errors.Is(err, dbErr) {
		t.Fatalf("Refresh(create session error) error = %v, want %v", err, dbErr)
	}
}

// --- createAuthResponse additional paths ---

// TestCreateAuthResponseAccountToResponseError vérifie que l'erreur de
// accountToResponse (hors RecordNotFound) est propagée par createAuthResponse.
func TestCreateAuthResponseAccountToResponseError(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	ctx := context.Background()
	dbErr := errors.New("profile db down")
	account := models.Account{ID: uuid.New(), Email: "alice@example.com", Role: "USER"}

	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(dbErr)

	_, err := createAuthResponse(ctx, repo, account)
	if !errors.Is(err, dbErr) {
		t.Fatalf("createAuthResponse(profile error) error = %v, want %v", err, dbErr)
	}
}

// --- sendVerificationEmail nil mailer ---

// TestSendVerificationEmailNilMailerReturnsError vérifie que sendVerificationEmail
// retourne ErrVerificationEmailFailed quand le mailer est nil.
func TestSendVerificationEmailNilMailerReturnsError(t *testing.T) {
	service := &Service{mailer: nil}
	err := service.sendVerificationEmail("user@example.com", "User", "token123")
	if !errors.Is(err, ErrVerificationEmailFailed) {
		t.Fatalf("sendVerificationEmail(nil mailer) error = %v, want ErrVerificationEmailFailed", err)
	}
}

// --- Register with nil mailer (auto-verify path, nil-mailer branch) ---

// TestServiceRegisterNilMailerAutoVerifies vérifie que Register auto-vérifie
// le compte quand le mailer est nil (branche if s.mailer == nil dans sendVerificationEmail).
func TestServiceRegisterNilMailerAutoVerifies(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), nil) // mailer nil
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectQuery(`INSERT INTO "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "email_verification_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	// auto-verify transaction
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "nil@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	resp, err := service.Register(ctx, "nil@example.com", "StrongPass123!", "nil_user", "Nil User")
	if err != nil {
		t.Fatalf("Register(nil mailer) error = %v", err)
	}
	if resp.VerificationEmailSent {
		t.Fatal("Register(nil mailer) should report verificationEmailSent=false")
	}
}

// --- tokens ---

// TestRandomTokenReturnsNonEmptyString vérifie le chemin nominal de randomToken.
func TestRandomTokenReturnsNonEmptyString(t *testing.T) {
	tok, err := randomToken(16)
	if err != nil || len(tok) == 0 {
		t.Fatalf("randomToken(16) = %q, %v", tok, err)
	}
}

// TestRandomTokenDifferentLengths vérifie que randomToken produit des tokens
// de tailles différentes pour différents paramètres.
func TestRandomTokenDifferentLengths(t *testing.T) {
	tok32, err := randomToken(32)
	if err != nil || len(tok32) == 0 {
		t.Fatalf("randomToken(32) = %q, %v", tok32, err)
	}
	tok8, err := randomToken(8)
	if err != nil || len(tok8) == 0 {
		t.Fatalf("randomToken(8) = %q, %v", tok8, err)
	}
	if len(tok32) <= len(tok8) {
		t.Fatalf("randomToken(32) len=%d should be > randomToken(8) len=%d", len(tok32), len(tok8))
	}
}
