package auth

import (
	"context"
	"errors"
	"regexp"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// newMockAuthDB cree une connexion GORM adossee a sqlmock, avec le protocole
// simple pour que les arguments soient visibles dans les regex de requete.
func newMockAuthDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })

	gdb, err := gorm.Open(postgres.New(postgres.Config{
		Conn:                 sqlDB,
		PreferSimpleProtocol: true,
	}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return gdb, mock
}

type failingMailer struct{}

func (failingMailer) SendVerificationEmail(_, _, _ string) error  { return errors.New("smtp down") }
func (failingMailer) SendPasswordResetEmail(_, _, _ string) error { return errors.New("smtp down") }

func accountRows(id uuid.UUID, email, passwordHash, role, status string, emailVerifiedAt, suspendedUntil *time.Time) *sqlmock.Rows {
	return sqlmock.NewRows([]string{"id", "email", "password_hash", "role", "status", "suspended_until", "email_verified_at", "created_at", "updated_at"}).
		AddRow(id, email, passwordHash, role, status, suspendedUntil, emailVerifiedAt, time.Now(), time.Now())
}

func profileRows(id, accountID uuid.UUID, username string, displayName *string) *sqlmock.Rows {
	return sqlmock.NewRows([]string{"id", "account_id", "username", "display_name", "bio", "avatar_url", "banner_url", "is_private", "pinned_post_id", "original_username", "original_display_name", "created_at", "updated_at"}).
		AddRow(id, accountID, username, displayName, nil, nil, nil, false, nil, nil, nil, time.Now(), time.Now())
}

func hashedPassword(t *testing.T, password string) string {
	t.Helper()
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		t.Fatalf("bcrypt.GenerateFromPassword() unexpected error: %v", err)
	}
	return string(hash)
}

// --- Register ---

func TestServiceRegisterSuccessWithMailerSent(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`INSERT INTO "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "email_verification_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	resp, err := service.Register(ctx, "Alice@Example.com", "StrongPass123!", "alice_user", "Alice")
	if err != nil {
		t.Fatalf("Register() unexpected error: %v", err)
	}
	if !resp.RequiresEmailVerification || !resp.VerificationEmailSent {
		t.Fatalf("Register() = %+v, want verification email sent", resp)
	}
	if resp.User.Email != "alice@example.com" {
		t.Fatalf("Register() user email = %q, want lowercased", resp.User.Email)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestServiceRegisterMailerFailureAutoVerifies(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), failingMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectQuery(`INSERT INTO "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "email_verification_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	// Auto-verification apres echec SMTP : nouvelle transaction.
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "bob@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	resp, err := service.Register(ctx, "bob@example.com", "StrongPass123!", "bob_user", "Bob")
	if err != nil {
		t.Fatalf("Register() unexpected error: %v", err)
	}
	if resp.VerificationEmailSent {
		t.Fatal("Register() should report verification email not sent on SMTP failure")
	}
}

func TestServiceRegisterValidationAndConflictErrors(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	if _, err := service.Register(ctx, "a@example.com", "x", "bad username!", "A"); !errors.Is(err, ErrInvalidUsername) {
		t.Fatalf("Register(invalid username) error = %v", err)
	}

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(uuid.New(), "dup@example.com", "hash", "USER", "ACTIVE", nil, nil))
	if _, err := service.Register(ctx, "dup@example.com", "StrongPass123!", "dup_user", "Dup"); !errors.Is(err, ErrEmailAlreadyRegistered) {
		t.Fatalf("Register(dup email) error = %v", err)
	}

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnRows(profileRows(uuid.New(), uuid.New(), "dup_user", nil))
	if _, err := service.Register(ctx, "new@example.com", "StrongPass123!", "dup_user", "New"); !errors.Is(err, ErrUsernameAlreadyRegistered) {
		t.Fatalf("Register(dup username) error = %v", err)
	}
}

func TestServiceRegisterDatabaseErrorsPropagate(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	dbErr := errors.New("db down")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(dbErr)
	if _, err := service.Register(ctx, "a@example.com", "StrongPass123!", "a_user", "A"); !errors.Is(err, dbErr) {
		t.Fatalf("Register(email lookup error) error = %v, want %v", err, dbErr)
	}

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(dbErr)
	if _, err := service.Register(ctx, "a@example.com", "StrongPass123!", "a_user", "A"); !errors.Is(err, dbErr) {
		t.Fatalf("Register(username lookup error) error = %v, want %v", err, dbErr)
	}
}

// --- Login ---

func TestServiceLoginSuccess(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	now := time.Now().UTC()
	passwordHash := hashedPassword(t, "StrongPass123!")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "ACTIVE", &now, nil))
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))

	resp, err := service.Login(ctx, "alice@example.com", "StrongPass123!")
	if err != nil {
		t.Fatalf("Login() unexpected error: %v", err)
	}
	if resp.AccessToken == "" || resp.RefreshToken == "" || resp.User.Username != "alice" {
		t.Fatalf("Login() = %+v, want populated tokens and profile", resp)
	}
}

func TestServiceLoginInvalidCredentials(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	if _, err := service.Login(ctx, "missing@example.com", "whatever"); !errors.Is(err, ErrInvalidCredentials) {
		t.Fatalf("Login(missing account) error = %v", err)
	}

	accountID := uuid.New()
	passwordHash := hashedPassword(t, "CorrectPass123!")
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "ACTIVE", nil, nil))
	if _, err := service.Login(ctx, "alice@example.com", "WrongPass!"); !errors.Is(err, ErrInvalidCredentials) {
		t.Fatalf("Login(wrong password) error = %v", err)
	}
}

func TestServiceLoginEmailNotVerified(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	passwordHash := hashedPassword(t, "StrongPass123!")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "ACTIVE", nil, nil))
	if _, err := service.Login(ctx, "alice@example.com", "StrongPass123!"); !errors.Is(err, ErrEmailNotVerified) {
		t.Fatalf("Login(unverified) error = %v", err)
	}
}

func TestServiceLoginSuspendedAndBannedAndInactive(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	now := time.Now().UTC()
	passwordHash := hashedPassword(t, "StrongPass123!")
	future := now.Add(time.Hour)

	accountID := uuid.New()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "SUSPENDED", &now, &future))
	_, err := service.Login(ctx, "alice@example.com", "StrongPass123!")
	var suspendedErr *AccountSuspendedError
	if !errors.As(err, &suspendedErr) || !suspendedErr.SuspendedUntil.Equal(future) {
		t.Fatalf("Login(suspended) error = %v, want AccountSuspendedError", err)
	}

	accountID2 := uuid.New()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID2, "bob@example.com", passwordHash, "USER", "BANNED", &now, nil))
	if _, err := service.Login(ctx, "bob@example.com", "StrongPass123!"); !errors.Is(err, ErrAccountBanned) {
		t.Fatalf("Login(banned) error = %v", err)
	}

	accountID3 := uuid.New()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID3, "carol@example.com", passwordHash, "USER", "PENDING", &now, nil))
	if _, err := service.Login(ctx, "carol@example.com", "StrongPass123!"); !errors.Is(err, ErrInactiveAccount) {
		t.Fatalf("Login(pending/inactive) error = %v", err)
	}
}

func TestServiceLoginReactivatesExpiredSuspension(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	now := time.Now().UTC()
	past := now.Add(-time.Hour)
	passwordHash := hashedPassword(t, "StrongPass123!")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "SUSPENDED", &now, &past))
	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()
	mock.ExpectExec(`UPDATE posts\.posts`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectExec(`UPDATE profiles\.profiles`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(gorm.ErrRecordNotFound)

	resp, err := service.Login(ctx, "alice@example.com", "StrongPass123!")
	if err != nil {
		t.Fatalf("Login(expired suspension) unexpected error: %v", err)
	}
	if resp.AccessToken == "" {
		t.Fatal("Login(expired suspension) should issue tokens after reactivation")
	}
}

// --- Refresh ---

func TestServiceRefreshSuccess(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	sessionID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "refresh_token_hash", "expires_at", "revoked_at", "created_at"}).
			AddRow(sessionID, accountID, hashToken("old-token"), now.Add(time.Hour), nil, now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", &now, nil))
	mock.ExpectExec(`UPDATE "sessions" SET`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))
	mock.ExpectCommit()

	resp, err := service.Refresh(ctx, "old-token")
	if err != nil {
		t.Fatalf("Refresh() unexpected error: %v", err)
	}
	if resp.AccessToken == "" || resp.RefreshToken == "" {
		t.Fatalf("Refresh() = %+v, want populated tokens", resp)
	}
}

func TestServiceRefreshInvalidToken(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectRollback()

	if _, err := service.Refresh(ctx, "unknown-token"); !errors.Is(err, ErrInvalidRefreshToken) {
		t.Fatalf("Refresh(unknown token) error = %v", err)
	}
}

func TestServiceRefreshInactiveAccount(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	sessionID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "sessions" WHERE refresh_token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "refresh_token_hash", "expires_at", "revoked_at", "created_at"}).
			AddRow(sessionID, accountID, hashToken("old-token"), now.Add(time.Hour), nil, now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "BANNED", &now, nil))
	mock.ExpectRollback()

	if _, err := service.Refresh(ctx, "old-token"); !errors.Is(err, ErrInactiveAccount) {
		t.Fatalf("Refresh(inactive account) error = %v", err)
	}
}

// --- VerifyEmail ---

func TestServiceVerifyEmailSuccess(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	tokenID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "email_verification_tokens" WHERE token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "token_hash", "expires_at", "created_at"}).
			AddRow(tokenID, accountID, hashToken("good-token"), now.Add(time.Hour), now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	resp, err := service.VerifyEmail(ctx, " good-token ")
	if err != nil || resp.Message == "" {
		t.Fatalf("VerifyEmail() = %+v, %v", resp, err)
	}
}

func TestServiceVerifyEmailAlreadyVerifiedSkipsUpdate(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	tokenID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "email_verification_tokens" WHERE token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "token_hash", "expires_at", "created_at"}).
			AddRow(tokenID, accountID, hashToken("good-token"), now.Add(time.Hour), now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", &now, nil))
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	if _, err := service.VerifyEmail(ctx, "good-token"); err != nil {
		t.Fatalf("VerifyEmail(already verified) unexpected error: %v", err)
	}
}

func TestServiceVerifyEmailErrors(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	if _, err := service.VerifyEmail(ctx, "  "); !errors.Is(err, ErrInvalidVerificationToken) {
		t.Fatalf("VerifyEmail(blank) error = %v", err)
	}

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "email_verification_tokens" WHERE token_hash`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectRollback()
	if _, err := service.VerifyEmail(ctx, "missing-token"); !errors.Is(err, ErrInvalidVerificationToken) {
		t.Fatalf("VerifyEmail(missing) error = %v", err)
	}

	accountID := uuid.New()
	tokenID := uuid.New()
	past := time.Now().UTC().Add(-time.Hour)
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "email_verification_tokens" WHERE token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "token_hash", "expires_at", "created_at"}).
			AddRow(tokenID, accountID, hashToken("expired-token"), past, past))
	mock.ExpectRollback()
	if _, err := service.VerifyEmail(ctx, "expired-token"); !errors.Is(err, ErrExpiredVerificationToken) {
		t.Fatalf("VerifyEmail(expired) error = %v", err)
	}
}

// --- ResendVerificationEmail ---

func TestServiceResendVerificationEmailSuccess(t *testing.T) {
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))
	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "email_verification_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	resp, err := service.ResendVerificationEmail(ctx, "ALICE@example.com")
	if err != nil || resp.Message == "" {
		t.Fatalf("ResendVerificationEmail() = %+v, %v", resp, err)
	}
}

func TestServiceResendVerificationEmailErrors(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)
	if _, err := service.ResendVerificationEmail(ctx, "missing@example.com"); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("ResendVerificationEmail(missing account) error = %v", err)
	}

	accountID := uuid.New()
	now := time.Now().UTC()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", &now, nil))
	if _, err := service.ResendVerificationEmail(ctx, "alice@example.com"); !errors.Is(err, ErrEmailAlreadyVerified) {
		t.Fatalf("ResendVerificationEmail(already verified) error = %v", err)
	}

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "bob@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(gorm.ErrRecordNotFound)
	if _, err := service.ResendVerificationEmail(ctx, "bob@example.com"); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("ResendVerificationEmail(missing profile) error = %v", err)
	}
}

func TestServiceResendVerificationEmailMailerFailure(t *testing.T) {
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), failingMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))
	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "email_verification_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	if _, err := service.ResendVerificationEmail(ctx, "alice@example.com"); !errors.Is(err, ErrVerificationEmailFailed) {
		t.Fatalf("ResendVerificationEmail(mailer failure) error = %v", err)
	}
}

// --- ChangePassword ---

func TestServiceChangePasswordSuccess(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	passwordHash := hashedPassword(t, "OldPass123!")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "ACTIVE", nil, nil))
	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	if err := service.ChangePassword(ctx, accountID, "OldPass123!", "NewPass456!"); err != nil {
		t.Fatalf("ChangePassword() unexpected error: %v", err)
	}
}

func TestServiceChangePasswordErrors(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnError(gorm.ErrRecordNotFound)
	if err := service.ChangePassword(ctx, accountID, "x", "y"); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("ChangePassword(missing account) error = %v", err)
	}

	passwordHash := hashedPassword(t, "RealPass123!")
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", passwordHash, "USER", "ACTIVE", nil, nil))
	if err := service.ChangePassword(ctx, accountID, "WrongPass!", "NewPass456!"); !errors.Is(err, ErrInvalidCredentials) {
		t.Fatalf("ChangePassword(wrong current password) error = %v", err)
	}
}

// --- ForgotPassword ---

func TestServiceForgotPasswordUnknownEmailSilent(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnError(gorm.ErrRecordNotFound)

	if err := service.ForgotPassword(ctx, "missing@example.com"); err != nil {
		t.Fatalf("ForgotPassword(unknown email) unexpected error: %v", err)
	}
}

func TestServiceForgotPasswordSuccessWithMailer(t *testing.T) {
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))
	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "password_reset_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "password_reset_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	if err := service.ForgotPassword(ctx, "ALICE@example.com"); err != nil {
		t.Fatalf("ForgotPassword() unexpected error: %v", err)
	}
}

func TestServiceForgotPasswordMailerDisabledLogsLink(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), nil)
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "password_reset_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "password_reset_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	if err := service.ForgotPassword(ctx, "alice@example.com"); err != nil {
		t.Fatalf("ForgotPassword(no mailer) unexpected error: %v", err)
	}
}

func TestServiceForgotPasswordMailerFailureIsSwallowed(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), failingMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))
	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "password_reset_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectQuery(`INSERT INTO "password_reset_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	if err := service.ForgotPassword(ctx, "alice@example.com"); err != nil {
		t.Fatalf("ForgotPassword(mailer failure) should not propagate error, got: %v", err)
	}
}

func TestServiceForgotPasswordTransactionError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	dbErr := errors.New("db down")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE lower\(email\)`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))
	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "password_reset_tokens"`).
		WillReturnError(dbErr)
	mock.ExpectRollback()

	if err := service.ForgotPassword(ctx, "alice@example.com"); !errors.Is(err, dbErr) {
		t.Fatalf("ForgotPassword(transaction error) error = %v, want %v", err, dbErr)
	}
}

// --- ResetPassword ---

func TestServiceResetPasswordSuccess(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	tokenID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "password_reset_tokens" WHERE token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "token_hash", "expires_at", "created_at"}).
			AddRow(tokenID, accountID, hashToken("reset-token"), now.Add(time.Hour), now))
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "old-hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectExec(`DELETE FROM "password_reset_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	if err := service.ResetPassword(ctx, " reset-token ", "NewPass456!"); err != nil {
		t.Fatalf("ResetPassword() unexpected error: %v", err)
	}
}

func TestServiceResetPasswordErrors(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()

	if err := service.ResetPassword(ctx, "  ", "NewPass456!"); !errors.Is(err, ErrInvalidResetToken) {
		t.Fatalf("ResetPassword(blank token) error = %v", err)
	}

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "password_reset_tokens" WHERE token_hash`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectRollback()
	if err := service.ResetPassword(ctx, "missing-token", "NewPass456!"); !errors.Is(err, ErrInvalidResetToken) {
		t.Fatalf("ResetPassword(missing token) error = %v", err)
	}

	accountID := uuid.New()
	tokenID := uuid.New()
	past := time.Now().UTC().Add(-time.Hour)
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "password_reset_tokens" WHERE token_hash`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "account_id", "token_hash", "expires_at", "created_at"}).
			AddRow(tokenID, accountID, hashToken("expired-token"), past, past))
	mock.ExpectRollback()
	if err := service.ResetPassword(ctx, "expired-token", "NewPass456!"); !errors.Is(err, ErrExpiredResetToken) {
		t.Fatalf("ResetPassword(expired token) error = %v", err)
	}
}

// --- UpdateAccountStatus (service layer) ---

func TestServiceUpdateAccountStatusSuccess(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectExec(`UPDATE "accounts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))

	resp, err := service.UpdateAccountStatus(ctx, accountID, "SUSPENDED")
	if err != nil || resp.Status != "SUSPENDED" {
		t.Fatalf("UpdateAccountStatus() = %+v, %v", resp, err)
	}
}

func TestServiceUpdateAccountStatusRepositoryError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectRollback()

	if _, err := service.UpdateAccountStatus(ctx, accountID, "BANNED"); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("UpdateAccountStatus(missing account) error = %v", err)
	}
}

// --- accountToResponse / Me ---

func TestServiceMeSuccessWithAndWithoutProfile(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	displayName := "Alice Example"

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", &displayName))

	resp, err := service.Me(ctx, accountID)
	if err != nil || resp.Username != "alice" || resp.DisplayName != "Alice Example" || resp.ProfileID == nil {
		t.Fatalf("Me() = %+v, %v", resp, err)
	}

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(gorm.ErrRecordNotFound)
	resp2, err := service.Me(ctx, accountID)
	if err != nil || resp2.ProfileID != nil || resp2.Username != "" {
		t.Fatalf("Me(no profile) = %+v, %v", resp2, err)
	}
}

func TestServiceMeAccountLookupError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnError(gorm.ErrRecordNotFound)
	if _, err := service.Me(ctx, accountID); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("Me(missing) error = %v", err)
	}
}

func TestServiceMeProfileLookupError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	service := NewService(NewRepository(db), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()
	dbErr := errors.New("db down")

	mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE id`).
		WillReturnRows(accountRows(accountID, "alice@example.com", "hash", "USER", "ACTIVE", nil, nil))
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(dbErr)
	if _, err := service.Me(ctx, accountID); !errors.Is(err, dbErr) {
		t.Fatalf("Me(profile error) error = %v, want %v", err, dbErr)
	}
}

// --- reactivateIfExpired direct unit coverage ---

func TestReactivateIfExpiredNoOpCases(t *testing.T) {
	db, _ := newMockAuthDB(t)
	repo := NewRepository(db)
	ctx := context.Background()

	active := &models.Account{Status: "ACTIVE"}
	if err := reactivateIfExpired(ctx, repo, active); err != nil {
		t.Fatalf("reactivateIfExpired(active) unexpected error: %v", err)
	}

	future := time.Now().UTC().Add(time.Hour)
	notYetExpired := &models.Account{Status: "SUSPENDED", SuspendedUntil: &future}
	if err := reactivateIfExpired(ctx, repo, notYetExpired); err != nil {
		t.Fatalf("reactivateIfExpired(not yet expired) unexpected error: %v", err)
	}

	banned := &models.Account{Status: "BANNED", SuspendedUntil: nil}
	if err := reactivateIfExpired(ctx, repo, banned); err != nil {
		t.Fatalf("reactivateIfExpired(banned) unexpected error: %v", err)
	}
}

func TestReactivateIfExpiredUpdateError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	ctx := context.Background()
	dbErr := errors.New("update failed")

	past := time.Now().UTC().Add(-time.Hour)
	account := &models.Account{ID: uuid.New(), Status: "SUSPENDED", SuspendedUntil: &past}

	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "accounts"`).WillReturnError(dbErr)
	mock.ExpectRollback()

	if err := reactivateIfExpired(ctx, repo, account); !errors.Is(err, dbErr) {
		t.Fatalf("reactivateIfExpired(update error) error = %v, want %v", err, dbErr)
	}
}

// --- createAuthResponse / createEmailVerificationToken direct unit coverage ---

func TestCreateAuthResponseSuccess(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	ctx := context.Background()
	accountID := uuid.New()
	account := models.Account{ID: accountID, Email: "alice@example.com", Role: "USER"}

	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "sessions"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(profileRows(uuid.New(), accountID, "alice", nil))

	resp, err := createAuthResponse(ctx, repo, account)
	if err != nil || resp.AccessToken == "" || resp.RefreshToken == "" || resp.TokenType != "Bearer" {
		t.Fatalf("createAuthResponse() = %+v, %v", resp, err)
	}
}

func TestCreateAuthResponseSessionCreationError(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	ctx := context.Background()
	dbErr := errors.New("session insert failed")
	account := models.Account{ID: uuid.New(), Email: "alice@example.com", Role: "USER"}

	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "sessions"`).WillReturnError(dbErr)
	mock.ExpectRollback()

	if _, err := createAuthResponse(ctx, repo, account); !errors.Is(err, dbErr) {
		t.Fatalf("createAuthResponse(session error) error = %v, want %v", err, dbErr)
	}
}

func TestCreateEmailVerificationTokenSuccess(t *testing.T) {
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	ctx := context.Background()
	accountID := uuid.New()

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectCommit()
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "email_verification_tokens"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	token, err := createEmailVerificationToken(ctx, repo, accountID)
	if err != nil || token == "" {
		t.Fatalf("createEmailVerificationToken() = %q, %v", token, err)
	}
}

func TestCreateEmailVerificationTokenDeleteError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	ctx := context.Background()
	dbErr := errors.New("delete failed")

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).WillReturnError(dbErr)
	mock.ExpectRollback()

	if _, err := createEmailVerificationToken(ctx, repo, uuid.New()); !errors.Is(err, dbErr) {
		t.Fatalf("createEmailVerificationToken(delete error) error = %v, want %v", err, dbErr)
	}
}

func TestCreateEmailVerificationTokenCreateError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	ctx := context.Background()
	dbErr := errors.New("insert failed")

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "email_verification_tokens"`).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectCommit()
	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "email_verification_tokens"`).WillReturnError(dbErr)
	mock.ExpectRollback()

	if _, err := createEmailVerificationToken(ctx, repo, uuid.New()); !errors.Is(err, dbErr) {
		t.Fatalf("createEmailVerificationToken(insert error) error = %v, want %v", err, dbErr)
	}
}

// --- accountToResponse direct coverage for profile error branch ---

func TestAccountToResponseProfileError(t *testing.T) {
	db, mock := newMockAuthDB(t)
	repo := NewRepository(db)
	ctx := context.Background()
	dbErr := errors.New("profile lookup failed")
	account := models.Account{ID: uuid.New(), Email: "alice@example.com"}

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(dbErr)

	if _, err := accountToResponse(ctx, repo, account); !errors.Is(err, dbErr) {
		t.Fatalf("accountToResponse(profile error) error = %v, want %v", err, dbErr)
	}
}

var _ = regexp.MustCompile // garde l'import si les regex inline changent
