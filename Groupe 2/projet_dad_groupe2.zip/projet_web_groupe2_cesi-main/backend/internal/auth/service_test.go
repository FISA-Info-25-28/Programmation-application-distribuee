package auth

import (
	"context"
	"testing"

	"github.com/google/uuid"
)

func TestAuthServiceConstructorAndErrors(t *testing.T) {
	mailer := &noopVerificationMailer{}
	service := NewService(nil, mailer)
	if service == nil || service.repo != nil || service.mailer != mailer {
		t.Fatalf("NewService(nil) = %+v, want service with nil repo", service)
	}

	if (&AccountSuspendedError{}).Error() != "account suspended" {
		t.Fatal("AccountSuspendedError should expose stable message")
	}
	if ErrInvalidCredentials.Error() != "invalid credentials" {
		t.Fatal("auth errors should expose stable messages")
	}
}

func TestAuthServiceWorkflowsDryRun(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://localhost")
	service := NewService(NewRepository(authDryRunDB(t)), noopVerificationMailer{})
	ctx := context.Background()
	accountID := uuid.New()

	_, _ = service.UsernameAvailable(ctx, "alice")
	_, _ = service.UsernameAvailable(ctx, "no")
	_, _ = service.EmailAvailable(ctx, "alice@example.com")
	_, _ = service.Register(ctx, "alice@example.com", "StrongPass123!", "alice_user", "Alice")
	_, _ = service.Login(ctx, "alice@example.com", "StrongPass123!")
	_ = service.Logout(ctx, "refresh-token")
	_, _ = service.Refresh(ctx, "refresh-token")
	_, _ = service.Me(ctx, accountID)
	_, _ = service.VerifyEmail(ctx, "email-token")
	_, _ = service.ResendVerificationEmail(ctx, "alice@example.com")
	_ = service.ChangePassword(ctx, accountID, "StrongPass123!", "NewStrongPass123!")
	_, _ = service.UpdateAccountStatus(ctx, accountID, "SUSPENDED")
	_ = service.sendVerificationEmail("alice@example.com", "Alice", "token")
	_ = service.ForgotPassword(ctx, "alice@example.com")
	_ = service.ResetPassword(ctx, "reset-token", "NewStrongPass123!")
}

type noopVerificationMailer struct{}

func (noopVerificationMailer) SendVerificationEmail(_, _, _ string) error  { return nil }
func (noopVerificationMailer) SendPasswordResetEmail(_, _, _ string) error { return nil }
