package auth

import (
	"strings"
	"testing"
)

func TestRandomToken(t *testing.T) {
	token, err := randomToken(16)
	if err != nil {
		t.Fatalf("randomToken() unexpected error: %v", err)
	}
	if token == "" || strings.Contains(token, "=") {
		t.Fatalf("randomToken() = %q, want raw URL-safe token", token)
	}
}

func TestHashToken(t *testing.T) {
	if got := hashToken("token"); got != "3c469e9d6c5875d37a43f353d4f88e61fcf812c66eee3457465a40b0da4153e0" {
		t.Fatalf("hashToken() = %q", got)
	}
	if hashToken("token") == hashToken("other") {
		t.Fatal("hashToken() should produce different hashes for different inputs")
	}
}

func TestBearerToken(t *testing.T) {
	if got := bearerToken("Bearer abc"); got != "abc" {
		t.Fatalf("bearerToken() = %q, want abc", got)
	}
	if got := bearerToken("Bearer"); got != "" {
		t.Fatalf("bearerToken(invalid) = %q, want empty", got)
	}
}
