package config

import (
	"os"
	"strings"
)

// Env lit une variable d'environnement.
// Entree : key, fallback.
// Sortie : valeur retour de type string.
func Env(key, fallback string) string {
	value := strings.TrimSpace(os.Getenv(key))
	if value == "" {
		return fallback
	}

	return value
}

// Port lit le port du service.
// Entree : fallback.
// Sortie : valeur retour de type string.
func Port(fallback string) string {
	return Env("PORT", fallback)
}
