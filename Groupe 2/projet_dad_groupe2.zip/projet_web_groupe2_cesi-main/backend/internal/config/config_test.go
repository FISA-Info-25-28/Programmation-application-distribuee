package config

import "testing"

func TestEnv(t *testing.T) {
	t.Setenv("BREEZY_TEST_ENV", " value ")
	if got := Env("BREEZY_TEST_ENV", "fallback"); got != "value" {
		t.Fatalf("Env() = %q, want value", got)
	}

	t.Setenv("BREEZY_TEST_EMPTY", "   ")
	if got := Env("BREEZY_TEST_EMPTY", "fallback"); got != "fallback" {
		t.Fatalf("Env(empty) = %q, want fallback", got)
	}
}

func TestPort(t *testing.T) {
	t.Setenv("PORT", " 9090 ")
	if got := Port("8080"); got != "9090" {
		t.Fatalf("Port() = %q, want 9090", got)
	}
}
