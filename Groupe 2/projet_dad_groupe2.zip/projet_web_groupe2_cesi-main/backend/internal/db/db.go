package db

import (
	"time"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var connectAttempts = 30
var connectRetryDelay = 2 * time.Second

// Connect ouvre une connexion GORM vers PostgreSQL.
// Entree : dsn.
// Sortie : valeurs retour de la fonction.
func Connect(dsn string) (*gorm.DB, error) {
	var lastErr error
	for attempt := 1; attempt <= connectAttempts; attempt++ {
		database, err := gorm.Open(postgres.Open(dsn), &gorm.Config{
			Logger: logger.Default.LogMode(logger.Warn),
		})
		if err != nil {
			lastErr = err
			time.Sleep(connectRetryDelay)
			continue
		}

		sqlDB, err := database.DB()
		if err != nil {
			lastErr = err
			time.Sleep(connectRetryDelay)
			continue
		}
		if err = sqlDB.Ping(); err != nil {
			lastErr = err
			time.Sleep(connectRetryDelay)
			continue
		}

		return database, nil
	}

	return nil, lastErr
}
