package db

import (
	"testing"
	"time"
)

func TestConnectReturnsErrorForInvalidDSN(t *testing.T) {
	previousAttempts := connectAttempts
	previousDelay := connectRetryDelay
	connectAttempts = 1
	connectRetryDelay = 0
	t.Cleanup(func() {
		connectAttempts = previousAttempts
		connectRetryDelay = previousDelay
	})

	start := time.Now()
	database, err := Connect("postgres://bad host")
	if err == nil {
		t.Fatal("Connect() expected error for invalid DSN")
	}
	if database != nil {
		t.Fatalf("Connect() database = %v, want nil", database)
	}
	if time.Since(start) > time.Second {
		t.Fatal("Connect() test path should not wait for production retry delay")
	}
}

func TestConnectRetriesBeforeReturningError(t *testing.T) {
	previousAttempts := connectAttempts
	previousDelay := connectRetryDelay
	connectAttempts = 3
	connectRetryDelay = 0
	t.Cleanup(func() {
		connectAttempts = previousAttempts
		connectRetryDelay = previousDelay
	})

	// Adresse refusant la connexion : gorm.Open echoue immediatement a
	// chaque tentative (dial refuse), ce qui exerce la boucle de retry
	// (connectAttempts > 1) avant de renvoyer la derniere erreur rencontree.
	database, err := Connect("postgres://u:p@127.0.0.1:1/db?sslmode=disable")
	if err == nil {
		t.Fatal("Connect() expected error for unreachable host")
	}
	if database != nil {
		t.Fatalf("Connect() database = %v, want nil", database)
	}
}
