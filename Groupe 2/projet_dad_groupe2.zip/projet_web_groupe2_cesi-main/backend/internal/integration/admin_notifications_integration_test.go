package integration

import (
	"net/http"
	"testing"

	"breezy/backend/internal/moderation"
	"breezy/backend/internal/notifications"
	"breezy/backend/internal/users"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

func runModerationHTTPWorkflow(t *testing.T, fixtures integrationFixtures, db *gorm.DB, userToken, moderatorToken string) {
	t.Helper()
	router := gin.New()
	moderation.RegisterRoutes(router, moderation.NewHandler(db))
	var report struct {
		ID uuid.UUID `json:"id"`
	}
	doJSON(t, router, http.MethodPost, "/posts/"+fixtures.alicePostID.String()+"/report", map[string]any{"reason": "http report"}, userToken, http.StatusCreated, &report)
	doJSON(t, router, http.MethodPost, "/posts/"+fixtures.alicePostID.String()+"/report", map[string]any{"reason": "duplicate report"}, userToken, http.StatusConflict, nil)
	doJSON(t, router, http.MethodPost, "/posts/not-a-uuid/report", map[string]any{"reason": "bad id"}, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodGet, "/reports", nil, moderatorToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/reports", nil, userToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPatch, "/reports/"+report.ID.String(), map[string]any{"status": "RESOLVED"}, moderatorToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/reports/"+report.ID.String(), map[string]any{"status": "PENDING"}, moderatorToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPatch, "/reports/"+uuid.NewString(), map[string]any{"status": "REVIEWED"}, moderatorToken, http.StatusNotFound, nil)
	doJSON(t, router, http.MethodPost, "/users/"+fixtures.privateProfileID.String()+"/suspend", map[string]any{"durationHours": 24, "reason": "http suspend"}, moderatorToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/users/"+fixtures.privateProfileID.String()+"/suspend", map[string]any{"durationHours": 2}, moderatorToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/users/"+fixtures.moderatorProfileID.String()+"/ban", nil, moderatorToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPost, "/users/"+fixtures.moderatorProfileID.String()+"/lift", nil, moderatorToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPost, "/users/not-a-uuid/ban", nil, moderatorToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodGet, "/sanctions", nil, moderatorToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/users/"+fixtures.privateProfileID.String()+"/lift", nil, moderatorToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/users/"+fixtures.privateProfileID.String()+"/ban", map[string]any{"reason": "http ban"}, moderatorToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/users/"+fixtures.privateProfileID.String()+"/lift", nil, moderatorToken, http.StatusOK, nil)
}

func runUsersHTTPWorkflow(t *testing.T, fixtures integrationFixtures, db *gorm.DB, userToken, adminToken string) {
	t.Helper()
	router := gin.New()
	users.RegisterRoutes(router, users.NewHandler(db))
	doJSON(t, router, http.MethodGet, "/suggestions", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/search?q=bob", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/admin/users", nil, adminToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/admin/users", nil, userToken, http.StatusForbidden, nil)
	var created struct {
		AccountID uuid.UUID `json:"accountId"`
	}
	doJSON(t, router, http.MethodPost, "/admin/users", map[string]any{"email": "admin-created@example.com", "password": "StrongPass123!", "username": "admin_created", "displayName": "Admin Created", "role": "USER"}, adminToken, http.StatusCreated, &created)
	doJSON(t, router, http.MethodPatch, "/admin/users/"+created.AccountID.String()+"/role", map[string]any{"role": "MODERATOR"}, adminToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/admin/users/"+fixtures.adminAccountID.String()+"/role", map[string]any{"role": "USER"}, adminToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/admin/users", map[string]any{"email": fixtures.aliceEmail, "password": "StrongPass123!", "username": "duplicate_email", "displayName": "Duplicate", "role": "USER"}, adminToken, http.StatusConflict, nil)
	doJSON(t, router, http.MethodPost, "/admin/users", map[string]any{"email": "duplicate.username@example.com", "password": "StrongPass123!", "username": fixtures.aliceUsername, "displayName": "Duplicate", "role": "USER"}, adminToken, http.StatusConflict, nil)
	doJSON(t, router, http.MethodPost, "/admin/users", map[string]any{"email": "invalid"}, adminToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPatch, "/admin/users/"+uuid.NewString()+"/role", map[string]any{"role": "USER"}, adminToken, http.StatusNotFound, nil)
}

func runNotificationsHTTPWorkflow(t *testing.T, fixtures integrationFixtures, db *gorm.DB, userToken string) {
	t.Helper()
	router := gin.New()
	notifications.RegisterRoutes(router, notifications.NewHandler(db))
	doJSON(t, router, http.MethodGet, "/notifications", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/notifications/unread-count", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/notifications/"+fixtures.notificationID.String()+"/read", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/notifications/"+uuid.NewString()+"/read", nil, userToken, http.StatusNotFound, nil)
	doJSON(t, router, http.MethodPatch, "/notifications/not-a-uuid/read", nil, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/notifications/read-all", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodDelete, "/notifications/selected", map[string]any{"ids": []uuid.UUID{}}, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodDelete, "/notifications/selected", map[string]any{"ids": []uuid.UUID{fixtures.notificationID}}, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodDelete, "/notifications", nil, userToken, http.StatusOK, nil)
}
