package integration

import (
	"net/http"
	"testing"
	"time"

	authpkg "breezy/backend/internal/auth"
	"breezy/backend/internal/middleware"
	"breezy/backend/internal/profile"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

func runAuthHTTPWorkflow(t *testing.T, fixtures integrationFixtures, db *gorm.DB, userToken, adminToken string) {
	t.Helper()
	router := gin.New()
	authpkg.RegisterRoutes(router, authpkg.NewHandler(db))
	doJSON(t, router, http.MethodGet, "/check-username?username=available_http", nil, "", http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/check-email?email=http-check@example.com", nil, "", http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/login", map[string]any{"email": fixtures.aliceEmail, "password": fixtures.password}, "", http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/me", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/me/password", map[string]any{"currentPassword": fixtures.password, "newPassword": "StrongPass456!"}, userToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodPatch, "/me/password", map[string]any{"currentPassword": "StrongPass456!", "newPassword": fixtures.password}, userToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodPatch, "/accounts/"+fixtures.bobAccountID.String()+"/status", map[string]any{"status": "ACTIVE"}, adminToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/check-username?username=x", nil, "", http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/login", map[string]any{"email": fixtures.aliceEmail, "password": "wrong-password"}, "", http.StatusUnauthorized, nil)
	doJSON(t, router, http.MethodGet, "/verify-email?token=invalid", nil, "", http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/resend-verification", map[string]any{"email": fixtures.aliceEmail}, "", http.StatusConflict, nil)
	doJSON(t, router, http.MethodPost, "/forgot-password", map[string]any{"email": "missing@example.com"}, "", http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/reset-password", map[string]any{"token": "invalid-token", "newPassword": "StrongPass789!"}, "", http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPatch, "/accounts/"+fixtures.bobAccountID.String()+"/status", map[string]any{"status": "LOCKED"}, adminToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/register", map[string]any{
		"email": "handler.register@example.com", "password": "StrongPass123!", "username": "handler_register", "displayName": "Handler Register",
	}, "", http.StatusCreated, nil)
	doJSON(t, router, http.MethodPost, "/register", map[string]any{
		"email": "handler.register@example.com", "password": "StrongPass123!", "username": "handler_register_2", "displayName": "Duplicate Email",
	}, "", http.StatusConflict, nil)
	doJSON(t, router, http.MethodPost, "/register", map[string]any{
		"email": "different@example.com", "password": "StrongPass123!", "username": fixtures.aliceUsername, "displayName": "Duplicate Username",
	}, "", http.StatusConflict, nil)
	doJSON(t, router, http.MethodPost, "/refresh", map[string]any{"refreshToken": "invalid-refresh-token"}, "", http.StatusUnauthorized, nil)
	doJSON(t, router, http.MethodPatch, "/me/password", map[string]any{"currentPassword": "wrong-password", "newPassword": "StrongPass789!"}, userToken, http.StatusUnauthorized, nil)
	doJSON(t, router, http.MethodPost, "/resend-verification", map[string]any{"email": "absent@example.com"}, "", http.StatusNotFound, nil)
	doJSON(t, router, http.MethodPatch, "/accounts/"+uuid.NewString()+"/status", map[string]any{"status": "ACTIVE"}, adminToken, http.StatusNotFound, nil)
	missingToken := accessToken(t, uuid.New(), middleware.RoleUser)
	doJSON(t, router, http.MethodGet, "/me", nil, missingToken, http.StatusUnauthorized, nil)

	future := time.Now().UTC().Add(time.Hour)
	if err := db.Table("auth.accounts").Where("id = ?", fixtures.bobAccountID).Updates(map[string]any{"status": "SUSPENDED", "suspended_until": future}).Error; err != nil {
		t.Fatalf("suspend account fixture: %v", err)
	}
	doJSON(t, router, http.MethodPost, "/login", map[string]any{"email": "bob.integration@example.com", "password": fixtures.password}, "", http.StatusForbidden, nil)
	if err := db.Table("auth.accounts").Where("id = ?", fixtures.bobAccountID).Updates(map[string]any{"status": "BANNED", "suspended_until": nil}).Error; err != nil {
		t.Fatalf("ban account fixture: %v", err)
	}
	doJSON(t, router, http.MethodPost, "/login", map[string]any{"email": "bob.integration@example.com", "password": fixtures.password}, "", http.StatusForbidden, nil)
	if err := db.Table("auth.accounts").Where("id = ?", fixtures.bobAccountID).Update("status", "ACTIVE").Error; err != nil {
		t.Fatalf("restore account fixture: %v", err)
	}
	runOAuthCallbacks(t, router)
}

func runProfileHTTPWorkflow(t *testing.T, fixtures integrationFixtures, db *gorm.DB, userToken string) {
	t.Helper()
	router := gin.New()
	profile.RegisterRoutes(router, profile.NewHandler(db))
	doJSON(t, router, http.MethodGet, "/me", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/me", map[string]any{"displayName": "Alice HTTP", "bio": "covered by integration", "isPrivate": false}, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/preferences", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/preferences", map[string]any{"theme": "dark", "language": "fr", "emailNotifications": false, "pushNotifications": true}, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/me/pin/"+fixtures.alicePostID.String(), nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodDelete, "/me/pin", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/"+fixtures.bobUsername, nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/missing_profile", nil, userToken, http.StatusNotFound, nil)
	doJSON(t, router, http.MethodPatch, "/me", map[string]any{"displayName": "   "}, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPatch, "/me", map[string]any{"avatarUrl": "not-a-url"}, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPatch, "/preferences", map[string]any{"theme": "purple"}, userToken, http.StatusBadRequest, nil)

	var bobPostIDRaw string
	if err := db.Table("posts.posts").Select("id::text").Where("author_id = ?", fixtures.bobProfileID).Limit(1).Scan(&bobPostIDRaw).Error; err != nil {
		t.Fatalf("find bob post fixture: %v", err)
	}
	bobPostID, err := uuid.Parse(bobPostIDRaw)
	if err != nil {
		t.Fatalf("parse bob post fixture: %v", err)
	}
	doJSON(t, router, http.MethodPost, "/me/pin/"+bobPostID.String(), nil, userToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPost, "/me/pin/not-a-uuid", nil, userToken, http.StatusBadRequest, nil)
}
