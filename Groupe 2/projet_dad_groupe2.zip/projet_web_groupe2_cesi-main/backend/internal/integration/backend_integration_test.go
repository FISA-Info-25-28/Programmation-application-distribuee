package integration

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"
	"time"

	authpkg "breezy/backend/internal/auth"
	"breezy/backend/internal/messages"
	"breezy/backend/internal/middleware"
	"breezy/backend/internal/models"
	"breezy/backend/internal/moderation"
	"breezy/backend/internal/notifications"
	postpkg "breezy/backend/internal/post"
	"breezy/backend/internal/profile"
	"breezy/backend/internal/sanction"
	"breezy/backend/internal/security"
	"breezy/backend/internal/social"
	"breezy/backend/internal/users"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/testcontainers/testcontainers-go"
	"github.com/testcontainers/testcontainers-go/modules/postgres"
	"github.com/testcontainers/testcontainers-go/wait"
	"golang.org/x/crypto/bcrypt"
	postgresdriver "gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func TestBackendServicesWithPostgres(t *testing.T) {
	if testing.Short() {
		t.Skip("integration test skipped in short mode")
	}
	ctx := context.Background()
	conn := startPostgres(t, ctx)

	admin := openDB(t, withSearchPath(conn, "public"))
	authDB := openDB(t, withSearchPath(conn, "auth"))
	profileDB := openDB(t, withSearchPath(conn, "profiles"))
	postDB := openDB(t, withSearchPath(conn, "posts"))
	socialDB := openDB(t, withSearchPath(conn, "social"))
	messagesDB := openDB(t, withSearchPath(conn, "messages"))
	moderationDB := openDB(t, withSearchPath(conn, "moderation"))

	applyMigrations(t, admin)
	applyCompatibilitySchema(t, admin)
	if err := sanction.EnsureColumns(admin); err != nil {
		t.Fatalf("EnsureColumns() unexpected error: %v", err)
	}

	fixtures := seedFixtures(t, authDB, profileDB, postDB, socialDB, messagesDB)

	t.Setenv("JWT_SECRET", "integration-secret")
	t.Setenv("SMTP_ENABLED", "false")
	mailer := &integrationMailer{}
	authSvc := authpkg.NewService(authpkg.NewRepository(authDB), mailer)
	profileSvc := profile.NewService(profile.NewRepository(profileDB))
	postSvc := postpkg.NewService(postpkg.NewRepository(postDB))
	socialSvc := social.NewService(social.NewRepository(socialDB))
	messageSvc := messages.NewService(messages.NewRepository(messagesDB))
	userSvc := users.NewService(users.NewRepository(socialDB))
	moderationRepo := moderation.NewRepository(moderationDB)
	notificationRepo := notifications.NewRepository(socialDB)

	if _, err := authSvc.UsernameAvailable(ctx, "new_user"); err != nil {
		t.Fatalf("UsernameAvailable() unexpected error: %v", err)
	}
	if _, err := authSvc.EmailAvailable(ctx, "new@example.com"); err != nil {
		t.Fatalf("EmailAvailable() unexpected error: %v", err)
	}
	login, err := authSvc.Login(ctx, fixtures.aliceEmail, fixtures.password)
	if err != nil {
		t.Fatalf("Login() unexpected error: %v", err)
	}
	if _, err := authSvc.Me(ctx, fixtures.aliceAccountID); err != nil {
		t.Fatalf("Me() unexpected error: %v", err)
	}
	if _, err := authSvc.Refresh(ctx, login.RefreshToken); err != nil {
		t.Fatalf("Refresh() unexpected error: %v", err)
	}
	if err := authSvc.Logout(ctx, login.RefreshToken); err != nil {
		t.Fatalf("Logout() unexpected error: %v", err)
	}
	registered, err := authSvc.Register(ctx, "registered.integration@example.com", "StrongPass123!", "registered_http", "Registered HTTP")
	if err != nil {
		t.Fatalf("Register() unexpected error: %v", err)
	}
	if !registered.RequiresEmailVerification || mailer.verificationToken == "" {
		t.Fatalf("Register() did not generate a verification token: %+v", registered)
	}
	verified, err := authSvc.VerifyEmail(ctx, mailer.verificationToken)
	if err != nil || verified.Message == "" {
		t.Fatalf("VerifyEmail() = %+v, %v", verified, err)
	}
	if err := authSvc.ForgotPassword(ctx, "registered.integration@example.com"); err != nil {
		t.Fatalf("ForgotPassword() unexpected error: %v", err)
	}
	if mailer.resetToken == "" {
		t.Fatal("ForgotPassword() did not generate a reset token")
	}
	if err := authSvc.ResetPassword(ctx, mailer.resetToken, "AnotherStrong123!"); err != nil {
		t.Fatalf("ResetPassword() unexpected error: %v", err)
	}
	if _, err := authSvc.Login(ctx, "registered.integration@example.com", "AnotherStrong123!"); err != nil {
		t.Fatalf("Login(after reset) unexpected error: %v", err)
	}
	if _, err := authSvc.FindOrCreateGoogleAccount(ctx, "google.integration@example.com", "Google Integration"); err != nil {
		t.Fatalf("FindOrCreateGoogleAccount(new) unexpected error: %v", err)
	}
	if _, err := authSvc.FindOrCreateGoogleAccount(ctx, "google.integration@example.com", "Google Integration"); err != nil {
		t.Fatalf("FindOrCreateGoogleAccount(existing) unexpected error: %v", err)
	}
	if _, err := authSvc.FindOrCreateGitHubAccount(ctx, "github.integration@example.com", "GitHub Integration", "github-integration"); err != nil {
		t.Fatalf("FindOrCreateGitHubAccount(new) unexpected error: %v", err)
	}
	if _, err := authSvc.FindOrCreateGitHubAccount(ctx, "github.integration@example.com", "GitHub Integration", "github-integration"); err != nil {
		t.Fatalf("FindOrCreateGitHubAccount(existing) unexpected error: %v", err)
	}

	if _, err := profileSvc.Me(ctx, fixtures.aliceAccountID); err != nil {
		t.Fatalf("profile.Me() unexpected error: %v", err)
	}
	if _, err := profileSvc.Show(ctx, fixtures.bobUsername, fixtures.aliceAccountID); err != nil {
		t.Fatalf("profile.Show() unexpected error: %v", err)
	}
	if _, err := profileSvc.Preferences(ctx, fixtures.aliceAccountID); err != nil {
		t.Fatalf("profile.Preferences() unexpected error: %v", err)
	}
	if err := profileSvc.PinPost(ctx, fixtures.aliceAccountID, fixtures.alicePostID); err != nil {
		t.Fatalf("PinPost() unexpected error: %v", err)
	}
	if err := profileSvc.UnpinPost(ctx, fixtures.aliceAccountID); err != nil {
		t.Fatalf("UnpinPost() unexpected error: %v", err)
	}

	if _, err := socialSvc.Follow(ctx, fixtures.aliceAccountID, fixtures.privateProfileID); err != nil {
		t.Fatalf("Follow(private) unexpected error: %v", err)
	}
	if _, err := socialSvc.Follow(ctx, fixtures.aliceAccountID, fixtures.bobProfileID); err != nil {
		t.Fatalf("Follow(public) unexpected error: %v", err)
	}
	if _, err := socialSvc.Followers(ctx, fixtures.bobProfileID, 1, 20); err != nil {
		t.Fatalf("Followers() unexpected error: %v", err)
	}
	if _, err := socialSvc.Following(ctx, fixtures.aliceProfileID, 1, 20); err != nil {
		t.Fatalf("Following() unexpected error: %v", err)
	}
	if _, err := socialSvc.Block(ctx, fixtures.aliceAccountID, fixtures.privateProfileID); err != nil {
		t.Fatalf("Block() unexpected error: %v", err)
	}
	if _, err := socialSvc.Unblock(ctx, fixtures.aliceAccountID, fixtures.privateProfileID); err != nil {
		t.Fatalf("Unblock() unexpected error: %v", err)
	}
	if _, err := socialSvc.Unfollow(ctx, fixtures.aliceAccountID, fixtures.bobProfileID); err != nil {
		t.Fatalf("Unfollow() unexpected error: %v", err)
	}

	if _, err := postSvc.GetPosts(ctx); err != nil {
		t.Fatalf("GetPosts() unexpected error: %v", err)
	}
	if _, err := postSvc.GetPostByID(ctx, fixtures.alicePostID); err != nil {
		t.Fatalf("GetPostByID() unexpected error: %v", err)
	}
	if _, err := postSvc.GetRepliesByParentID(ctx, fixtures.alicePostID); err != nil {
		t.Fatalf("GetRepliesByParentID() unexpected error: %v", err)
	}
	if _, err := postSvc.GetPostsByTag(ctx, "go"); err != nil {
		t.Fatalf("GetPostsByTag() unexpected error: %v", err)
	}
	if _, err := postSvc.SearchPostsByKeyword(ctx, "integration"); err != nil {
		t.Fatalf("SearchPostsByKeyword() unexpected error: %v", err)
	}
	if _, err := postSvc.GetPostsByAuthor(ctx, fixtures.aliceUsername); err != nil {
		t.Fatalf("GetPostsByAuthor() unexpected error: %v", err)
	}
	if err := postSvc.LikePost(ctx, fixtures.bobAccountID, fixtures.alicePostID); err != nil {
		t.Fatalf("LikePost() unexpected error: %v", err)
	}
	if err := postSvc.UnlikePost(ctx, fixtures.bobAccountID, fixtures.alicePostID); err != nil {
		t.Fatalf("UnlikePost() unexpected error: %v", err)
	}
	if err := postSvc.Repost(ctx, fixtures.bobAccountID, fixtures.alicePostID); err != nil {
		t.Fatalf("Repost() unexpected error: %v", err)
	}
	if err := postSvc.Unrepost(ctx, fixtures.bobAccountID, fixtures.alicePostID); err != nil {
		t.Fatalf("Unrepost() unexpected error: %v", err)
	}
	if err := postSvc.BookmarkPost(ctx, fixtures.bobAccountID, fixtures.alicePostID); err != nil {
		t.Fatalf("BookmarkPost() unexpected error: %v", err)
	}
	if _, err := postSvc.GetBookmarkedPosts(ctx, fixtures.bobAccountID); err != nil {
		t.Fatalf("GetBookmarkedPosts() unexpected error: %v", err)
	}
	if err := postSvc.UnbookmarkPost(ctx, fixtures.bobAccountID, fixtures.alicePostID); err != nil {
		t.Fatalf("UnbookmarkPost() unexpected error: %v", err)
	}

	conversation, err := messageSvc.CreateConversation(ctx, fixtures.aliceAccountID, fixtures.bobUsername)
	if err != nil {
		t.Fatalf("CreateConversation() unexpected error: %v", err)
	}
	sent, err := messageSvc.SendMessage(ctx, fixtures.aliceAccountID, conversation.ID, "hello bob", "", "", nil, nil, nil)
	if err != nil {
		t.Fatalf("SendMessage() unexpected error: %v", err)
	}
	if _, err := messageSvc.Messages(ctx, fixtures.bobAccountID, conversation.ID); err != nil {
		t.Fatalf("Messages() unexpected error: %v", err)
	}
	if _, err := messageSvc.UpdateMessage(ctx, fixtures.aliceAccountID, sent.ID, "edited hello", ""); err != nil {
		t.Fatalf("UpdateMessage() unexpected error: %v", err)
	}
	if _, err := messageSvc.ReactToMessage(ctx, fixtures.bobAccountID, sent.ID, "HEART"); err != nil {
		t.Fatalf("ReactToMessage() unexpected error: %v", err)
	}
	if _, err := messageSvc.UnlikeMessage(ctx, fixtures.bobAccountID, sent.ID); err != nil {
		t.Fatalf("UnlikeMessage() unexpected error: %v", err)
	}
	if _, err := messageSvc.SetRetention(ctx, fixtures.aliceAccountID, "1h"); err != nil {
		t.Fatalf("SetRetention() unexpected error: %v", err)
	}
	if _, err := messageSvc.GetRetention(ctx, fixtures.aliceAccountID); err != nil {
		t.Fatalf("GetRetention() unexpected error: %v", err)
	}
	if _, err := messageSvc.TotalUnreadCount(ctx, fixtures.bobAccountID); err != nil {
		t.Fatalf("TotalUnreadCount() unexpected error: %v", err)
	}

	report := models.Report{ReporterID: fixtures.bobProfileID, ReportedPostID: &fixtures.alicePostID, Reason: "integration"}
	if err := moderationRepo.CreatePostReport(ctx, &report); err != nil {
		t.Fatalf("CreatePostReport() unexpected error: %v", err)
	}
	if _, err := moderationRepo.ListReports(ctx); err != nil {
		t.Fatalf("ListReports() unexpected error: %v", err)
	}
	if _, err := moderationRepo.UpdateReportStatus(ctx, report.ID, fixtures.moderatorProfileID, "REVIEWED"); err != nil {
		t.Fatalf("UpdateReportStatus() unexpected error: %v", err)
	}
	if _, err := moderationRepo.SuspendUser(ctx, fixtures.privateProfileID, fixtures.moderatorAccountID, "MODERATOR", time.Now().Add(time.Hour)); err != nil {
		t.Fatalf("SuspendUser() unexpected error: %v", err)
	}
	if _, err := moderationRepo.LiftModeration(ctx, fixtures.privateProfileID, fixtures.moderatorAccountID, "MODERATOR"); err != nil {
		t.Fatalf("LiftModeration() unexpected error: %v", err)
	}

	if _, err := userSvc.SearchForAccount(ctx, fixtures.aliceAccountID, "bob"); err != nil {
		t.Fatalf("SearchForAccount() unexpected error: %v", err)
	}
	if _, err := userSvc.Suggestions(ctx, fixtures.aliceAccountID, 10); err != nil {
		t.Fatalf("Suggestions() unexpected error: %v", err)
	}
	if _, err := notificationRepo.List(ctx, fixtures.aliceProfileID); err != nil {
		t.Fatalf("notifications.List() unexpected error: %v", err)
	}
	if _, err := notificationRepo.CountUnread(ctx, fixtures.aliceProfileID); err != nil {
		t.Fatalf("notifications.CountUnread() unexpected error: %v", err)
	}

	runHTTPWorkflows(t, fixtures, authDB, profileDB, postDB, socialDB, messagesDB, moderationDB)
}

type integrationFixtures struct {
	password           string
	aliceEmail         string
	aliceUsername      string
	aliceAccountID     uuid.UUID
	aliceProfileID     uuid.UUID
	alicePostID        uuid.UUID
	bobAccountID       uuid.UUID
	bobProfileID       uuid.UUID
	bobUsername        string
	privateProfileID   uuid.UUID
	privateAccountID   uuid.UUID
	moderatorAccountID uuid.UUID
	moderatorProfileID uuid.UUID
	adminAccountID     uuid.UUID
	adminProfileID     uuid.UUID
	notificationID     uuid.UUID
}

type integrationMailer struct {
	verificationToken string
	resetToken        string
}

func (m *integrationMailer) SendVerificationEmail(_, _ string, verificationURL string) error {
	m.verificationToken = tokenFromURL(verificationURL, "verifyEmailToken")
	return nil
}

func (m *integrationMailer) SendPasswordResetEmail(_, _ string, resetURL string) error {
	m.resetToken = tokenFromURL(resetURL, "resetToken")
	return nil
}

func tokenFromURL(rawURL, key string) string {
	parsed, err := url.Parse(rawURL)
	if err != nil {
		return ""
	}
	return parsed.Query().Get(key)
}

func startPostgres(t *testing.T, ctx context.Context) string {
	t.Helper()
	container, err := postgres.Run(ctx,
		"postgres:16-alpine",
		postgres.WithDatabase("breezy_test"),
		postgres.WithUsername("postgres"),
		postgres.WithPassword("postgres"),
		testcontainers.WithWaitStrategy(wait.ForListeningPort("5432/tcp").WithStartupTimeout(60*time.Second)),
	)
	if err != nil {
		t.Fatalf("start postgres container: %v", err)
	}
	t.Cleanup(func() {
		_ = container.Terminate(context.Background())
	})
	conn, err := container.ConnectionString(ctx, "sslmode=disable")
	if err != nil {
		t.Fatalf("postgres connection string: %v", err)
	}
	return conn
}

func openDB(t *testing.T, dsn string) *gorm.DB {
	t.Helper()
	db, err := gorm.Open(postgresdriver.Open(dsn), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Silent),
	})
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	sqlDB, err := db.DB()
	if err != nil {
		t.Fatalf("db handle: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	return db
}

func applyMigrations(t *testing.T, db *gorm.DB) {
	t.Helper()
	root := repoRoot(t)
	files, err := filepath.Glob(filepath.Join(root, "migrations", "*.sql"))
	if err != nil {
		t.Fatalf("glob migrations: %v", err)
	}
	sort.Strings(files)
	for _, file := range files {
		body, err := os.ReadFile(file)
		if err != nil {
			t.Fatalf("read migration %s: %v", file, err)
		}
		if err := db.Exec(string(body)).Error; err != nil {
			t.Fatalf("apply migration %s: %v", filepath.Base(file), err)
		}
	}
}

func applyCompatibilitySchema(t *testing.T, db *gorm.DB) {
	t.Helper()
	sql := `
ALTER TABLE profiles.profiles ADD COLUMN IF NOT EXISTS pinned_post_id uuid;
ALTER TABLE posts.posts ADD COLUMN IF NOT EXISTS lang varchar(10) NOT NULL DEFAULT '';

CREATE TABLE IF NOT EXISTS auth.password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS social.blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id uuid NOT NULL,
  blocked_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT blocks_unique UNIQUE (blocker_id, blocked_id)
);

CREATE TABLE IF NOT EXISTS posts.polls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL UNIQUE,
  ends_at timestamptz,
  closed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS posts.poll_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id uuid NOT NULL,
  text varchar(80) NOT NULL,
  position integer NOT NULL DEFAULT 0,
  vote_count integer NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS posts.poll_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id uuid NOT NULL,
  option_id uuid NOT NULL,
  user_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT idx_poll_vote_unique UNIQUE (poll_id, user_id)
);
CREATE TABLE IF NOT EXISTS posts.bookmarks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL,
  user_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT idx_bookmark_unique UNIQUE (user_id, post_id)
);
`
	if err := db.Exec(sql).Error; err != nil {
		t.Fatalf("apply compatibility schema: %v", err)
	}
}

func repoRoot(t *testing.T) string {
	t.Helper()
	dir, err := os.Getwd()
	if err != nil {
		t.Fatalf("getwd: %v", err)
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "migrations")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatal("backend root with migrations directory not found")
		}
		dir = parent
	}
}

func withSearchPath(dsn, schema string) string {
	parsed, err := url.Parse(dsn)
	if err != nil {
		if strings.Contains(dsn, "?") {
			return dsn + "&search_path=" + schema
		}
		return dsn + "?search_path=" + schema
	}
	values := parsed.Query()
	values.Set("search_path", schema)
	parsed.RawQuery = values.Encode()
	return parsed.String()
}

func seedFixtures(t *testing.T, authDB, profileDB, postDB, socialDB, messagesDB *gorm.DB) integrationFixtures {
	t.Helper()
	password := "StrongPass123!"
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		t.Fatalf("hash password: %v", err)
	}
	now := time.Now().UTC()
	aliceAccountID := uuid.New()
	bobAccountID := uuid.New()
	privateAccountID := uuid.New()
	moderatorAccountID := uuid.New()
	adminAccountID := uuid.New()
	aliceProfileID := uuid.New()
	bobProfileID := uuid.New()
	privateProfileID := uuid.New()
	moderatorProfileID := uuid.New()
	adminProfileID := uuid.New()
	alicePostID := uuid.New()
	replyID := uuid.New()
	notificationID := uuid.New()

	accounts := []models.Account{
		{ID: aliceAccountID, Email: "alice.integration@example.com", PasswordHash: string(hash), Role: "USER", Status: "ACTIVE", EmailVerifiedAt: &now},
		{ID: bobAccountID, Email: "bob.integration@example.com", PasswordHash: string(hash), Role: "USER", Status: "ACTIVE", EmailVerifiedAt: &now},
		{ID: privateAccountID, Email: "private.integration@example.com", PasswordHash: string(hash), Role: "USER", Status: "ACTIVE", EmailVerifiedAt: &now},
		{ID: moderatorAccountID, Email: "mod.integration@example.com", PasswordHash: string(hash), Role: "MODERATOR", Status: "ACTIVE", EmailVerifiedAt: &now},
		{ID: adminAccountID, Email: "admin.integration@example.com", PasswordHash: string(hash), Role: "ADMIN", Status: "ACTIVE", EmailVerifiedAt: &now},
	}
	if err := authDB.Table("auth.accounts").Create(&accounts).Error; err != nil {
		t.Fatalf("seed accounts: %v", err)
	}

	aliceName := "Alice Integration"
	bobName := "Bob Integration"
	privateName := "Private Integration"
	modName := "Moderator Integration"
	adminName := "Admin Integration"
	profiles := []map[string]any{
		{"id": aliceProfileID, "account_id": aliceAccountID, "username": "alice_integration", "display_name": aliceName, "is_private": false},
		{"id": bobProfileID, "account_id": bobAccountID, "username": "bob_integration", "display_name": bobName, "is_private": false},
		{"id": privateProfileID, "account_id": privateAccountID, "username": "private_integration", "display_name": privateName, "is_private": true},
		{"id": moderatorProfileID, "account_id": moderatorAccountID, "username": "mod_integration", "display_name": modName, "is_private": false},
		{"id": adminProfileID, "account_id": adminAccountID, "username": "admin_integration", "display_name": adminName, "is_private": false},
	}
	if err := profileDB.Table("profiles.profiles").Create(&profiles).Error; err != nil {
		t.Fatalf("seed profiles: %v", err)
	}
	preferences := []models.UserPreference{
		{ProfileID: aliceProfileID, Locale: "fr", Theme: "light"},
		{ProfileID: bobProfileID, Locale: "en", Theme: "dark"},
	}
	if err := profileDB.Table("profiles.preferences").Create(&preferences).Error; err != nil {
		t.Fatalf("seed preferences: %v", err)
	}

	posts := []map[string]any{
		{"id": alicePostID, "author_id": aliceProfileID, "content": "integration #go @bob_integration", "visibility": "PUBLIC"},
		{"id": replyID, "author_id": bobProfileID, "content": "reply integration", "parent_id": alicePostID, "visibility": "PUBLIC"},
	}
	if err := postDB.Table("posts.posts").Create(&posts).Error; err != nil {
		t.Fatalf("seed posts: %v", err)
	}
	tagID := uuid.New()
	if err := postDB.Table("posts.tags").Create(&models.Tag{ID: tagID, Name: "go"}).Error; err != nil {
		t.Fatalf("seed tag: %v", err)
	}
	if err := postDB.Table("posts.post_tags").Create(&models.PostTag{PostID: alicePostID, TagID: tagID}).Error; err != nil {
		t.Fatalf("seed post tag: %v", err)
	}
	if err := postDB.Table("posts.media").Create(&models.Media{ID: uuid.New(), PostID: alicePostID, MediaType: "IMAGE", URL: "/api/media/files/integration.png"}).Error; err != nil {
		t.Fatalf("seed media: %v", err)
	}

	if err := socialDB.Table("social.follows").Create(&models.Follow{ID: uuid.New(), FollowerID: bobProfileID, FollowedID: aliceProfileID}).Error; err != nil {
		t.Fatalf("seed follow: %v", err)
	}
	if err := socialDB.Table("social.notifications").Create(&models.Notification{ID: notificationID, RecipientID: aliceProfileID, ActorID: bobProfileID, Type: "LIKE", PostID: &alicePostID}).Error; err != nil {
		t.Fatalf("seed notification: %v", err)
	}
	if err := messagesDB.Table("messages.message_preferences").Create(&models.MessagePreference{ProfileID: aliceProfileID, Retention: "forever"}).Error; err != nil {
		t.Fatalf("seed message preference: %v", err)
	}

	return integrationFixtures{
		password:           password,
		aliceEmail:         "alice.integration@example.com",
		aliceUsername:      "alice_integration",
		aliceAccountID:     aliceAccountID,
		aliceProfileID:     aliceProfileID,
		alicePostID:        alicePostID,
		bobAccountID:       bobAccountID,
		bobProfileID:       bobProfileID,
		bobUsername:        "bob_integration",
		privateProfileID:   privateProfileID,
		privateAccountID:   privateAccountID,
		moderatorAccountID: moderatorAccountID,
		moderatorProfileID: moderatorProfileID,
		adminAccountID:     adminAccountID,
		adminProfileID:     adminProfileID,
		notificationID:     notificationID,
	}
}

func runHTTPWorkflows(t *testing.T, fixtures integrationFixtures, authDB, profileDB, postDB, socialDB, messagesDB, moderationDB *gorm.DB) {
	t.Helper()
	gin.SetMode(gin.TestMode)

	userToken := accessToken(t, fixtures.aliceAccountID, middleware.RoleUser)
	bobToken := accessToken(t, fixtures.bobAccountID, middleware.RoleUser)
	privateToken := accessToken(t, fixtures.privateAccountID, middleware.RoleUser)
	moderatorToken := accessToken(t, fixtures.moderatorAccountID, middleware.RoleModerator)
	adminToken := accessToken(t, fixtures.adminAccountID, middleware.RoleAdmin)

	runAuthHTTPWorkflow(t, fixtures, authDB, userToken, adminToken)
	runProfileHTTPWorkflow(t, fixtures, profileDB, userToken)

	runPostHTTPWorkflow(t, fixtures, postDB, userToken, bobToken, privateToken)
	runSocialHTTPWorkflow(t, fixtures, socialDB, userToken, privateToken)

	runMessagesHTTPWorkflow(t, fixtures, messagesDB, userToken, bobToken)
	runModerationHTTPWorkflow(t, fixtures, moderationDB, userToken, moderatorToken)
	runUsersHTTPWorkflow(t, fixtures, socialDB, userToken, adminToken)
	runNotificationsHTTPWorkflow(t, fixtures, socialDB, userToken)
}

func accessToken(t *testing.T, accountID uuid.UUID, role string) string {
	t.Helper()
	token, err := security.SignAccessToken(accountID, role, time.Hour)
	if err != nil {
		t.Fatalf("sign access token: %v", err)
	}
	return token
}

func runOAuthCallbacks(t *testing.T, router http.Handler) {
	t.Helper()
	t.Setenv("GOOGLE_CLIENT_ID", "google-client")
	t.Setenv("GOOGLE_CLIENT_SECRET", "google-secret")
	t.Setenv("GITHUB_CLIENT_ID", "github-client")
	t.Setenv("GITHUB_CLIENT_SECRET", "github-secret")
	t.Setenv("FRONTEND_PUBLIC_URL", "http://frontend.test")

	previousTransport := http.DefaultClient.Transport
	http.DefaultClient.Transport = oauthTransport{}
	t.Cleanup(func() { http.DefaultClient.Transport = previousTransport })

	doOAuthCallback(t, router, "/google/callback?state=google-state&code=google-code", "breezy_oauth_state", "google-state", "google=1")
	doOAuthCallback(t, router, "/github/callback?state=github-state&code=github-code", "breezy_gh_state", "github-state", "github=1")
	doOAuthCallback(t, router, "/google/callback?state=wrong&code=code", "breezy_oauth_state", "expected", "googleError=state")
	doOAuthCallback(t, router, "/github/callback?state=github-state", "breezy_gh_state", "github-state", "githubError=cancelled")
}

func doOAuthCallback(t *testing.T, router http.Handler, path, cookieName, cookieValue, locationContains string) {
	t.Helper()
	req := httptest.NewRequest(http.MethodGet, path, nil)
	req.AddCookie(&http.Cookie{Name: cookieName, Value: cookieValue})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusFound || !strings.Contains(rec.Header().Get("Location"), locationContains) {
		t.Fatalf("GET %s status/location = %d/%q", path, rec.Code, rec.Header().Get("Location"))
	}
}

type oauthTransport struct{}

func (oauthTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	body := `{}`
	switch req.URL.Host + req.URL.Path {
	case "oauth2.googleapis.com/token":
		body = `{"access_token":"google-access"}`
	case "www.googleapis.com/oauth2/v3/userinfo":
		body = `{"sub":"google-id","email":"google.callback@example.com","email_verified":true,"name":"Google Callback"}`
	case "github.com/login/oauth/access_token":
		body = `{"access_token":"github-access","token_type":"bearer"}`
	case "api.github.com/user":
		body = `{"id":42,"login":"github-callback","name":"GitHub Callback","email":"github.callback@example.com"}`
	case "api.github.com/user/emails":
		body = `[{"email":"github.callback@example.com","primary":true,"verified":true}]`
	}
	return &http.Response{
		StatusCode: http.StatusOK,
		Header:     make(http.Header),
		Body:       io.NopCloser(strings.NewReader(body)),
		Request:    req,
	}, nil
}

func doJSON(t *testing.T, router http.Handler, method, path string, body any, token string, wantStatus int, target any) {
	t.Helper()
	var payload bytes.Buffer
	if body != nil {
		if err := json.NewEncoder(&payload).Encode(body); err != nil {
			t.Fatalf("encode %s %s payload: %v", method, path, err)
		}
	}
	req := httptest.NewRequest(method, path, &payload)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != wantStatus {
		t.Fatalf("%s %s status = %d, want %d; body=%s", method, path, rec.Code, wantStatus, rec.Body.String())
	}
	if target != nil && rec.Body.Len() > 0 {
		if err := json.Unmarshal(rec.Body.Bytes(), target); err != nil {
			t.Fatalf("decode %s %s response: %v; body=%s", method, path, err, rec.Body.String())
		}
	}
}
