package integration

import (
	"net/http"
	"testing"

	"breezy/backend/internal/messages"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

func runMessagesHTTPWorkflow(t *testing.T, fixtures integrationFixtures, db *gorm.DB, userToken, bobToken string) {
	t.Helper()
	router := gin.New()
	messages.RegisterRoutes(router, messages.NewHandler(db))
	var conversation struct {
		ID uuid.UUID `json:"id"`
	}
	doJSON(t, router, http.MethodPost, "/conversations", map[string]any{"username": fixtures.bobUsername}, userToken, http.StatusCreated, &conversation)
	doJSON(t, router, http.MethodPost, "/conversations", map[string]any{"username": fixtures.aliceUsername}, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodGet, "/conversations", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/conversations/unread-count", nil, bobToken, http.StatusOK, nil)
	var sent struct {
		ID uuid.UUID `json:"id"`
	}
	doJSON(t, router, http.MethodPost, "/conversations/"+conversation.ID.String()+"/messages", map[string]any{"content": "hello via http"}, userToken, http.StatusCreated, &sent)
	doJSON(t, router, http.MethodGet, "/conversations/"+conversation.ID.String()+"/messages", nil, bobToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/messages/"+sent.ID.String()+"/like", nil, bobToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/messages/"+sent.ID.String()+"/reaction", map[string]any{"reaction": "THUMBS_UP"}, bobToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodDelete, "/messages/"+sent.ID.String()+"/reaction", nil, bobToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/messages/"+sent.ID.String(), map[string]any{"content": "edited via http"}, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/messages/"+sent.ID.String(), map[string]any{"content": "forbidden edit"}, bobToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPost, "/conversations/"+conversation.ID.String()+"/messages", map[string]any{"content": ""}, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/messages/"+sent.ID.String()+"/reaction", map[string]any{"reaction": "LAUGH"}, bobToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodGet, "/conversations/"+uuid.NewString()+"/messages", nil, userToken, http.StatusNotFound, nil)
	doJSON(t, router, http.MethodPost, "/messages/"+uuid.NewString()+"/like", nil, userToken, http.StatusNotFound, nil)
	doJSON(t, router, http.MethodDelete, "/messages/"+sent.ID.String(), nil, bobToken, http.StatusForbidden, nil)

	var mediaReply struct {
		ID uuid.UUID `json:"id"`
	}
	doJSON(t, router, http.MethodPost, "/conversations/"+conversation.ID.String()+"/messages", map[string]any{
		"content": "reply with media", "mediaUrl": "/api/media/files/message.png", "mediaType": "IMAGE", "replyToId": sent.ID,
	}, bobToken, http.StatusCreated, &mediaReply)
	doJSON(t, router, http.MethodGet, "/conversations/"+conversation.ID.String()+"/messages", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/messages/settings", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/messages/settings", map[string]any{"retention": "7d"}, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/messages/settings", map[string]any{"retention": "invalid"}, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodDelete, "/messages/"+sent.ID.String(), nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPatch, "/messages/"+sent.ID.String(), map[string]any{"content": "after deletion"}, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/messages/"+sent.ID.String()+"/reaction", map[string]any{"reaction": "HEART"}, bobToken, http.StatusBadRequest, nil)
}
