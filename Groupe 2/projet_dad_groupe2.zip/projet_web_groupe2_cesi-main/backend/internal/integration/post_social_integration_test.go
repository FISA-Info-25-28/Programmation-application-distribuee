package integration

import (
	"net/http"
	"testing"
	"time"

	postpkg "breezy/backend/internal/post"
	"breezy/backend/internal/social"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

func runPostHTTPWorkflow(t *testing.T, fixtures integrationFixtures, db *gorm.DB, userToken, bobToken, privateToken string) {
	t.Helper()
	router := gin.New()
	postpkg.RegisterRoutes(router, postpkg.NewHandler(db))
	var createdPost struct {
		ID   uuid.UUID `json:"id"`
		Poll *struct {
			Options []struct {
				ID uuid.UUID `json:"id"`
			} `json:"options"`
		} `json:"poll"`
	}
	doJSON(t, router, http.MethodPost, "/", map[string]any{
		"content": "HTTP integration #coverage with poll", "visibility": "PUBLIC",
		"media": []map[string]string{{"type": "IMAGE", "url": "/api/media/files/http.png"}},
		"poll":  map[string]any{"options": []string{"yes", "no"}, "durationHours": 2.0},
	}, userToken, http.StatusCreated, &createdPost)
	if createdPost.ID == uuid.Nil || createdPost.Poll == nil || len(createdPost.Poll.Options) == 0 {
		t.Fatalf("created post response did not include poll options: %+v", createdPost)
	}
	if err := db.Table("social.follows").Create(map[string]any{
		"id": uuid.New(), "follower_id": fixtures.aliceProfileID, "followed_id": fixtures.bobProfileID,
	}).Error; err != nil {
		t.Fatalf("seed following feed relation: %v", err)
	}
	doJSON(t, router, http.MethodPost, "/", map[string]any{
		"content": "bob top-level following feed", "visibility": "PUBLIC",
	}, bobToken, http.StatusCreated, nil)
	if err := db.Table("profiles.profiles").Where("id = ?", fixtures.adminProfileID).Update("display_name", "Test C\u00e9dric").Error; err != nil {
		t.Fatalf("seed TEST notification target: %v", err)
	}
	doJSON(t, router, http.MethodPost, "/", map[string]any{
		"content": "trigger TEST notification", "visibility": "PUBLIC",
	}, userToken, http.StatusCreated, nil)
	doJSON(t, router, http.MethodGet, "/feed", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/following", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/tags/trending?limit=5", nil, "", http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/search?q=HTTP", nil, "", http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/tag/coverage", nil, "", http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/author/"+fixtures.aliceUsername, nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/author/"+fixtures.aliceUsername+"/replies", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/author/"+fixtures.bobUsername+"/reposts", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/"+createdPost.ID.String(), nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/"+createdPost.ID.String()+"/like", nil, bobToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodPost, "/"+createdPost.ID.String()+"/like", nil, bobToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodDelete, "/"+createdPost.ID.String()+"/like", nil, bobToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodPost, "/"+createdPost.ID.String()+"/repost", nil, bobToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodPost, "/"+createdPost.ID.String()+"/repost", nil, bobToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodDelete, "/"+createdPost.ID.String()+"/repost", nil, bobToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodPost, "/"+createdPost.ID.String()+"/bookmark", nil, bobToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodGet, "/bookmarks", nil, bobToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodDelete, "/"+createdPost.ID.String()+"/bookmark", nil, bobToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodPost, "/"+createdPost.ID.String()+"/poll/vote", map[string]any{"optionId": createdPost.Poll.Options[0].ID}, bobToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/"+createdPost.ID.String()+"/poll/vote", map[string]any{"optionId": createdPost.Poll.Options[0].ID}, bobToken, http.StatusConflict, nil)
	doJSON(t, router, http.MethodPost, "/"+createdPost.ID.String()+"/poll/close", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/"+createdPost.ID.String()+"/poll/close", nil, userToken, http.StatusConflict, nil)
	doJSON(t, router, http.MethodPost, "/"+createdPost.ID.String()+"/poll/close", nil, bobToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPatch, "/"+createdPost.ID.String()+"/visibility", map[string]any{"visibility": "PRIVATE"}, bobToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodDelete, "/"+createdPost.ID.String(), nil, bobToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPatch, "/"+createdPost.ID.String()+"/visibility", map[string]any{"visibility": "FOLLOWERS"}, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodDelete, "/"+createdPost.ID.String(), nil, userToken, http.StatusNoContent, nil)
	doJSON(t, router, http.MethodGet, "/"+uuid.NewString(), nil, userToken, http.StatusNotFound, nil)
	doJSON(t, router, http.MethodPost, "/"+uuid.NewString()+"/like", nil, bobToken, http.StatusNotFound, nil)
	doJSON(t, router, http.MethodPost, "/", map[string]any{"content": "", "visibility": "PUBLIC"}, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/", map[string]any{"content": "private profile cannot publish public", "visibility": "PUBLIC"}, privateToken, http.StatusForbidden, nil)

	var reply struct {
		ID uuid.UUID `json:"id"`
	}
	doJSON(t, router, http.MethodPost, "/", map[string]any{
		"content": "reply with @alice_integration mention", "parentId": fixtures.alicePostID, "visibility": "PUBLIC",
	}, bobToken, http.StatusCreated, &reply)
	doJSON(t, router, http.MethodGet, "/"+fixtures.alicePostID.String()+"/replies", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/author/"+fixtures.bobUsername+"/replies", nil, userToken, http.StatusOK, nil)

	var privatePost struct {
		ID uuid.UUID `json:"id"`
	}
	doJSON(t, router, http.MethodPost, "/", map[string]any{
		"content": "followers only post", "visibility": "FOLLOWERS",
	}, privateToken, http.StatusCreated, &privatePost)
	doJSON(t, router, http.MethodGet, "/"+privatePost.ID.String(), nil, userToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodGet, "/author/private_integration", nil, userToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPatch, "/"+privatePost.ID.String()+"/visibility", map[string]any{"visibility": "PUBLIC"}, privateToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodGet, "/author/does_not_exist", nil, userToken, http.StatusNotFound, nil)
	doJSON(t, router, http.MethodDelete, "/"+uuid.NewString()+"/repost", nil, bobToken, http.StatusNotFound, nil)
	doJSON(t, router, http.MethodDelete, "/"+uuid.NewString()+"/bookmark", nil, bobToken, http.StatusNotFound, nil)

	if err := db.Table("auth.accounts").Where("id = ?", fixtures.bobAccountID).Updates(map[string]any{
		"status": "SUSPENDED", "suspended_until": time.Now().UTC().Add(time.Hour),
	}).Error; err != nil {
		t.Fatalf("suspend bob for post guards: %v", err)
	}
	doJSON(t, router, http.MethodPost, "/", map[string]any{"content": "blocked while suspended"}, bobToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPost, "/"+fixtures.alicePostID.String()+"/like", nil, bobToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPost, "/"+fixtures.alicePostID.String()+"/repost", nil, bobToken, http.StatusForbidden, nil)
	doJSON(t, router, http.MethodPost, "/"+fixtures.alicePostID.String()+"/bookmark", nil, bobToken, http.StatusForbidden, nil)
	if err := db.Table("auth.accounts").Where("id = ?", fixtures.bobAccountID).Updates(map[string]any{
		"status": "ACTIVE", "suspended_until": nil,
	}).Error; err != nil {
		t.Fatalf("restore bob after post guards: %v", err)
	}
}

func runSocialHTTPWorkflow(t *testing.T, fixtures integrationFixtures, db *gorm.DB, userToken, privateToken string) {
	t.Helper()
	router := gin.New()
	social.RegisterRoutes(router, social.NewHandler(db))
	doJSON(t, router, http.MethodPost, "/follow/"+fixtures.aliceProfileID.String(), nil, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/block/"+fixtures.aliceProfileID.String(), nil, userToken, http.StatusBadRequest, nil)
	doJSON(t, router, http.MethodPost, "/follow/"+fixtures.privateProfileID.String(), nil, userToken, http.StatusCreated, nil)
	doJSON(t, router, http.MethodPost, "/follow-requests/"+fixtures.aliceProfileID.String()+"/accept", nil, privateToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodDelete, "/follow-requests/"+fixtures.aliceProfileID.String(), nil, privateToken, http.StatusNotFound, nil)
	doJSON(t, router, http.MethodGet, "/"+fixtures.privateProfileID.String()+"/followers", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodGet, "/"+fixtures.aliceProfileID.String()+"/following", nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodPost, "/block/"+fixtures.privateProfileID.String(), nil, userToken, http.StatusCreated, nil)
	doJSON(t, router, http.MethodDelete, "/block/"+fixtures.privateProfileID.String(), nil, userToken, http.StatusOK, nil)
	doJSON(t, router, http.MethodDelete, "/follow/"+fixtures.privateProfileID.String(), nil, userToken, http.StatusOK, nil)
}
