package media

import (
	"errors"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"breezy/backend/internal/config"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

const (
	maxUploadSize     = 100 << 20 // 100 Mo
	multipartOverhead = 1 << 20
)

type mediaFormat struct {
	extension string
	mediaType string
}

var allowedMIME = map[string]mediaFormat{
	"image/jpeg":      {extension: ".jpg", mediaType: "IMAGE"},
	"image/png":       {extension: ".png", mediaType: "IMAGE"},
	"image/webp":      {extension: ".webp", mediaType: "IMAGE"},
	"image/gif":       {extension: ".gif", mediaType: "IMAGE"},
	"video/mp4":       {extension: ".mp4", mediaType: "VIDEO"},
	"video/webm":      {extension: ".webm", mediaType: "VIDEO"},
	"video/quicktime": {extension: ".mov", mediaType: "VIDEO"},
}

type Handler struct {
	uploadDir string
	baseURL   string
}

func NewHandler(uploadDir, baseURL string) *Handler {
	return &Handler{uploadDir: uploadDir, baseURL: baseURL}
}

func (h *Handler) Health(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"service": config.Env("SERVICE_NAME", "media-service"),
		"status":  "ok",
	})
}

func (h *Handler) Upload(c *gin.Context) {
	c.Request.Body = http.MaxBytesReader(c.Writer, c.Request.Body, maxUploadSize+multipartOverhead)

	file, header, err := c.Request.FormFile("file")
	if err != nil {
		status := http.StatusBadRequest
		message := "fichier manquant ou formulaire invalide"
		var maxBytesError *http.MaxBytesError
		if errors.As(err, &maxBytesError) {
			status = http.StatusRequestEntityTooLarge
			message = "fichier trop volumineux (max 100 Mo)"
		}
		c.JSON(status, gin.H{"error": message})
		return
	}
	defer file.Close()

	if header.Size > maxUploadSize {
		c.JSON(http.StatusRequestEntityTooLarge, gin.H{"error": "fichier trop volumineux (max 100 Mo)"})
		return
	}

	// Détecter le type MIME sur le contenu, pas l'extension
	buf := make([]byte, 512)
	n, _ := file.Read(buf)
	mimeType := http.DetectContentType(buf[:n])

	format, ok := resolveFormat(mimeType, header)
	if !ok {
		c.JSON(http.StatusUnprocessableEntity, gin.H{
			"error": "format non autorise - jpeg, png, webp, gif, mp4, webm et mov acceptes",
		})
		return
	}

	if _, err := file.Seek(0, io.SeekStart); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "erreur interne"})
		return
	}

	filename := uuid.NewString() + format.extension
	dest := filepath.Join(h.uploadDir, filename)

	out, err := os.Create(dest)
	if err != nil {
		log.Printf("media: impossible de créer %s : %v", dest, err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "impossible de sauvegarder le fichier"})
		return
	}
	defer out.Close()

	if _, err := io.Copy(out, file); err != nil {
		os.Remove(dest)
		log.Printf("media: copie interrompue pour %s : %v", dest, err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "impossible de sauvegarder le fichier"})
		return
	}

	log.Printf("media: sauvegardé %s (original : %s)", filename, header.Filename)
	c.JSON(http.StatusCreated, gin.H{
		"url":       h.baseURL + "/files/" + filename,
		"filename":  filename,
		"mediaType": format.mediaType,
		"mimeType":  mimeType,
	})
}

func resolveFormat(mimeType string, header *multipart.FileHeader) (mediaFormat, bool) {
	if format, ok := allowedMIME[mimeType]; ok {
		return format, true
	}

	if mimeType == "application/octet-stream" {
		switch strings.ToLower(filepath.Ext(header.Filename)) {
		case ".mov":
			return allowedMIME["video/quicktime"], true
		case ".mp4":
			return allowedMIME["video/mp4"], true
		case ".webm":
			return allowedMIME["video/webm"], true
		}
	}

	return mediaFormat{}, false
}
