package media

import (
	"bytes"
	"encoding/json"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
)

// newUploadRequest construit une requete multipart contenant un champ "file"
// avec le contenu et le nom de fichier fournis.
func newUploadRequest(t *testing.T, filename string, content []byte) (*http.Request, error) {
	t.Helper()
	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, err := writer.CreateFormFile("file", filename)
	if err != nil {
		return nil, err
	}
	if _, err := part.Write(content); err != nil {
		return nil, err
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}

	req := httptest.NewRequest(http.MethodPost, "/upload", body)
	req.Header.Set("Content-Type", writer.FormDataContentType())
	return req, nil
}

func TestUploadPNG(t *testing.T) {
	gin.SetMode(gin.TestMode)

	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, err := writer.CreateFormFile("file", "photo.png")
	if err != nil {
		t.Fatal(err)
	}
	png := []byte{0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a}
	png = append(png, bytes.Repeat([]byte{0}, 512)...)
	if _, err := part.Write(png); err != nil {
		t.Fatal(err)
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}

	uploadDir := t.TempDir()
	handler := NewHandler(uploadDir, "http://localhost:8080/api/media")
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = httptest.NewRequest(http.MethodPost, "/upload", body)
	context.Request.Header.Set("Content-Type", writer.FormDataContentType())

	handler.Upload(context)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected 201, got %d: %s", recorder.Code, recorder.Body.String())
	}

	var response struct {
		URL       string `json:"url"`
		Filename  string `json:"filename"`
		MediaType string `json:"mediaType"`
	}
	if err := json.Unmarshal(recorder.Body.Bytes(), &response); err != nil {
		t.Fatal(err)
	}
	if response.MediaType != "IMAGE" || !strings.HasSuffix(response.URL, response.Filename) {
		t.Fatalf("unexpected response: %+v", response)
	}
	if _, err := os.Stat(uploadDir + string(os.PathSeparator) + response.Filename); err != nil {
		t.Fatalf("uploaded file missing: %v", err)
	}
}

func TestUploadRejectsUnsupportedFormat(t *testing.T) {
	gin.SetMode(gin.TestMode)

	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, err := writer.CreateFormFile("file", "note.txt")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := part.Write([]byte("plain text")); err != nil {
		t.Fatal(err)
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}

	handler := NewHandler(t.TempDir(), "http://localhost:8080/api/media")
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = httptest.NewRequest(http.MethodPost, "/upload", body)
	context.Request.Header.Set("Content-Type", writer.FormDataContentType())

	handler.Upload(context)

	if recorder.Code != http.StatusUnprocessableEntity {
		t.Fatalf("expected 422, got %d: %s", recorder.Code, recorder.Body.String())
	}
}

func TestResolveFormatOctetStreamVideos(t *testing.T) {
	tests := map[string]string{
		"clip.mov":  "VIDEO",
		"clip.mp4":  "VIDEO",
		"clip.webm": "VIDEO",
	}
	for filename, want := range tests {
		format, ok := resolveFormat("application/octet-stream", &multipart.FileHeader{Filename: filename})
		if !ok || format.mediaType != want {
			t.Fatalf("resolveFormat(%s) = %+v/%v, want %s/true", filename, format, ok, want)
		}
	}
}

func TestUploadMissingFile(t *testing.T) {
	gin.SetMode(gin.TestMode)

	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}

	handler := NewHandler(t.TempDir(), "http://localhost:8080/api/media")
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = httptest.NewRequest(http.MethodPost, "/upload", body)
	context.Request.Header.Set("Content-Type", writer.FormDataContentType())

	handler.Upload(context)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d: %s", recorder.Code, recorder.Body.String())
	}
}

func TestUploadFileTooLarge(t *testing.T) {
	gin.SetMode(gin.TestMode)

	// header.Size depasse maxUploadSize sans declencher MaxBytesError,
	// car la taille totale du corps multipart reste sous la limite globale.
	content := bytes.Repeat([]byte{0x89, 0x50, 0x4e, 0x47}, (maxUploadSize/4)+1)
	req, err := newUploadRequest(t, "big.png", content)
	if err != nil {
		t.Fatal(err)
	}

	handler := NewHandler(t.TempDir(), "http://localhost:8080/api/media")
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = req

	handler.Upload(context)

	if recorder.Code != http.StatusRequestEntityTooLarge {
		t.Fatalf("expected 413, got %d: %s", recorder.Code, recorder.Body.String())
	}
}

func TestUploadExceedsMaxBytesReader(t *testing.T) {
	gin.SetMode(gin.TestMode)

	// Depasse maxUploadSize + multipartOverhead pour declencher http.MaxBytesError
	// via le MaxBytesReader applique sur le corps de la requete.
	content := bytes.Repeat([]byte("a"), maxUploadSize+multipartOverhead+1024)
	req, err := newUploadRequest(t, "huge.bin", content)
	if err != nil {
		t.Fatal(err)
	}

	handler := NewHandler(t.TempDir(), "http://localhost:8080/api/media")
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = req

	handler.Upload(context)

	if recorder.Code != http.StatusRequestEntityTooLarge {
		t.Fatalf("expected 413, got %d: %s", recorder.Code, recorder.Body.String())
	}
}

func TestUploadDiskWriteFailure(t *testing.T) {
	gin.SetMode(gin.TestMode)

	png := []byte{0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a}
	png = append(png, bytes.Repeat([]byte{0}, 512)...)
	req, err := newUploadRequest(t, "photo.png", png)
	if err != nil {
		t.Fatal(err)
	}

	// Repertoire de destination inexistant : os.Create echouera.
	invalidDir := filepathJoinNonexistent(t)
	handler := NewHandler(invalidDir, "http://localhost:8080/api/media")
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = req

	handler.Upload(context)

	if recorder.Code != http.StatusInternalServerError {
		t.Fatalf("expected 500, got %d: %s", recorder.Code, recorder.Body.String())
	}
}

func filepathJoinNonexistent(t *testing.T) string {
	t.Helper()
	return t.TempDir() + string(os.PathSeparator) + "does" + string(os.PathSeparator) + "not" + string(os.PathSeparator) + "exist"
}

func TestUploadEachAllowedFormat(t *testing.T) {
	gin.SetMode(gin.TestMode)

	cases := []struct {
		name      string
		filename  string
		magic     []byte
		mediaType string
	}{
		{"jpeg", "photo.jpg", []byte{0xFF, 0xD8, 0xFF, 0xE0}, "IMAGE"},
		{"webp", "photo.webp", []byte("RIFF\x00\x00\x00\x00WEBPVP"), "IMAGE"},
		{"gif", "photo.gif", []byte("GIF89a"), "IMAGE"},
		{"mp4", "clip.mp4", []byte{0, 0, 0, 0x18, 0x66, 0x74, 0x79, 0x70, 0x6d, 0x70, 0x34, 0x32}, "VIDEO"},
		{"webm", "clip.webm", []byte{0x1A, 0x45, 0xDF, 0xA3}, "VIDEO"},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			content := append(append([]byte{}, tc.magic...), bytes.Repeat([]byte{0}, 512)...)
			req, err := newUploadRequest(t, tc.filename, content)
			if err != nil {
				t.Fatal(err)
			}

			uploadDir := t.TempDir()
			handler := NewHandler(uploadDir, "http://localhost:8080/api/media")
			recorder := httptest.NewRecorder()
			context, _ := gin.CreateTestContext(recorder)
			context.Request = req

			handler.Upload(context)

			if recorder.Code != http.StatusCreated {
				t.Fatalf("expected 201, got %d: %s", recorder.Code, recorder.Body.String())
			}

			var response struct {
				MediaType string `json:"mediaType"`
				Filename  string `json:"filename"`
			}
			if err := json.Unmarshal(recorder.Body.Bytes(), &response); err != nil {
				t.Fatal(err)
			}
			if response.MediaType != tc.mediaType {
				t.Fatalf("mediaType = %q, want %q", response.MediaType, tc.mediaType)
			}
			if _, err := os.Stat(uploadDir + string(os.PathSeparator) + response.Filename); err != nil {
				t.Fatalf("uploaded file missing: %v", err)
			}
		})
	}
}

func TestUploadMOVViaOctetStream(t *testing.T) {
	gin.SetMode(gin.TestMode)

	// Contenu sans signature MIME reconnue -> DetectContentType renverra
	// application/octet-stream, et resolveFormat se basera sur l'extension.
	content := bytes.Repeat([]byte{0x01, 0x02, 0x03}, 200)
	req, err := newUploadRequest(t, "clip.mov", content)
	if err != nil {
		t.Fatal(err)
	}

	uploadDir := t.TempDir()
	handler := NewHandler(uploadDir, "http://localhost:8080/api/media")
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = req

	handler.Upload(context)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected 201, got %d: %s", recorder.Code, recorder.Body.String())
	}
}

func TestUploadFileReadAndCopy(t *testing.T) {
	gin.SetMode(gin.TestMode)

	png := []byte{0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a}
	png = append(png, bytes.Repeat([]byte{0xAB}, 4096)...)
	req, err := newUploadRequest(t, "photo.png", png)
	if err != nil {
		t.Fatal(err)
	}

	uploadDir := t.TempDir()
	handler := NewHandler(uploadDir, "http://localhost:8080/api/media")
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = req

	handler.Upload(context)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected 201, got %d: %s", recorder.Code, recorder.Body.String())
	}

	var response struct {
		Filename string `json:"filename"`
	}
	if err := json.Unmarshal(recorder.Body.Bytes(), &response); err != nil {
		t.Fatal(err)
	}

	saved, err := os.ReadFile(uploadDir + string(os.PathSeparator) + response.Filename)
	if err != nil {
		t.Fatalf("ReadFile() unexpected error: %v", err)
	}
	if !bytes.Equal(saved, png) {
		t.Fatal("saved file content does not match uploaded content")
	}
}

func TestRegisterRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	RegisterRoutes(router, NewHandler(t.TempDir(), "http://media.test"))

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200", rec.Code)
	}

	rec = httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/upload", nil))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("POST /upload status = %d, want 401", rec.Code)
	}
}
