package media

import (
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
)

func RegisterRoutes(router *gin.Engine, handler *Handler) {
	router.GET("/health", handler.Health)
	router.Static("/files", handler.uploadDir)

	protected := router.Group("/", middleware.AuthRequired())
	protected.POST("/upload", handler.Upload)
}
