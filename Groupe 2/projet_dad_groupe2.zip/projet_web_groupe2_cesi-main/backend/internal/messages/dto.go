package messages

import (
	"errors"
	"strings"
	"time"

	"breezy/backend/internal/validation"
	"github.com/google/uuid"
)

type participantResponse struct {
	ID          uuid.UUID `json:"id"`
	Username    string    `json:"username"`
	DisplayName string    `json:"displayName"`
	AvatarURL   *string   `json:"avatarUrl"`
	// PublicKey est la cle publique X25519 (base64) du participant, utilisee
	// par le client pour chiffrer/dechiffrer les messages de cette conversation.
	PublicKey *string `json:"publicKey"`
}

type conversationResponse struct {
	ID                  uuid.UUID           `json:"id"`
	CurrentProfileID    uuid.UUID           `json:"currentProfileId"`
	Participant         participantResponse `json:"participant"`
	LastMessage         string              `json:"lastMessage"`
	LastMessageNonce    string              `json:"lastMessageNonce"`
	LastMessageSenderID *uuid.UUID          `json:"lastMessageSenderId"`
	LastMessageAt       time.Time           `json:"lastMessageAt"`
	UnreadCount         int64               `json:"unreadCount"`
}

type messageResponse struct {
	ID             uuid.UUID                 `json:"id"`
	ConversationID uuid.UUID                 `json:"conversationId"`
	SenderID       uuid.UUID                 `json:"senderId"`
	Content        string                    `json:"content"`
	Nonce          string                    `json:"nonce"`
	MediaURL       *string                   `json:"mediaUrl,omitempty"`
	MediaType      *string                   `json:"mediaType,omitempty"`
	ReplyToID      *uuid.UUID                `json:"replyToId,omitempty"`
	ReplyTo        *messageReplyResponse     `json:"replyTo,omitempty"`
	LikeCount      int64                     `json:"likeCount"`
	LikedByMe      bool                      `json:"likedByMe"`
	Reactions      []messageReactionResponse `json:"reactions"`
	IsFirstUnread  bool                      `json:"isFirstUnread"`
	Status         string                    `json:"status"`
	CreatedAt      time.Time                 `json:"createdAt"`
	EditedAt       *time.Time                `json:"editedAt,omitempty"`
	DeletedAt      *time.Time                `json:"deletedAt,omitempty"`
}

type messageReactionResponse struct {
	Type        string `json:"type"`
	Count       int64  `json:"count"`
	ReactedByMe bool   `json:"reactedByMe"`
}

type messageReplyResponse struct {
	ID        uuid.UUID  `json:"id"`
	SenderID  uuid.UUID  `json:"senderId"`
	Content   string     `json:"content"`
	Nonce     string     `json:"nonce"`
	MediaType *string    `json:"mediaType,omitempty"`
	DeletedAt *time.Time `json:"deletedAt,omitempty"`
}

type createConversationRequest struct {
	Username string `json:"username" binding:"required"`
}

func (r createConversationRequest) Validate() error {
	return validation.Username(r.Username)
}

// sendMessageRequest.Content transporte le ciphertext (base64, chiffre cote
// client avec NaCl box) accompagne de son Nonce lorsque le destinataire a
// deja une cle publique enregistree. Si Nonce est vide, Content est traite
// comme du texte en clair "legacy" (destinataire pas encore equipe d'une
// cle, ou message anterieur au chiffrement) : pas de blocage de l'envoi.
// La limite appliquee ici (4000) protege seulement contre un blob
// anormalement gros, la limite de 500 caracteres visibles est imposee par
// le client.
type sendMessageRequest struct {
	Content   string     `json:"content" binding:"max=4000"`
	Nonce     string     `json:"nonce" binding:"max=64"`
	Kind      string     `json:"kind"`
	MediaURL  *string    `json:"mediaUrl"`
	MediaType *string    `json:"mediaType"`
	ReplyToID *uuid.UUID `json:"replyToId"`
}

func (r sendMessageRequest) Validate() error {
	content := strings.TrimSpace(r.Content)
	if len(content) > 4000 {
		return errors.New("message is too long")
	}
	kind := strings.TrimSpace(r.Kind)
	if kind != "" {
		if err := validation.OneOf(kind, "TEXT", "SHARED_POST"); err != nil {
			return errors.New("invalid message kind")
		}
	}
	if r.MediaURL == nil && r.MediaType == nil {
		if content == "" {
			return errors.New("message text or media required")
		}
		return nil
	}
	if r.MediaURL == nil || r.MediaType == nil {
		return errors.New("media url and type are required together")
	}
	if err := validation.MediaURL(*r.MediaURL); err != nil {
		return err
	}
	if err := validation.OneOf(*r.MediaType, "IMAGE", "VIDEO"); err != nil {
		return errors.New("invalid media type")
	}
	return nil
}

// updateMessageRequest.Nonce est vide lorsque le destinataire n'a pas (encore)
// de cle publique enregistree : Content est alors stocke en clair, comme a
// l'envoi initial (cf. sendMessageRequest).
type updateMessageRequest struct {
	Content string `json:"content" binding:"required,max=4000"`
	Nonce   string `json:"nonce" binding:"max=64"`
}

func (r updateMessageRequest) Validate() error {
	if _, err := validation.TrimmedRequired(r.Content, 4000, "content"); err != nil {
		return err
	}
	return nil
}

type messageReactionRequest struct {
	Reaction string `json:"reaction" binding:"required"`
}

func (r messageReactionRequest) Validate() error {
	return validation.OneOf(strings.TrimSpace(r.Reaction), "HEART", "THUMBS_UP", "THUMBS_DOWN")
}

type retentionRequest struct {
	Retention string `json:"retention" binding:"required"`
}

func (r retentionRequest) Validate() error {
	trimmed := strings.TrimSpace(r.Retention)
	switch trimmed {
	case "forever", "1h", "7d", "30d":
		return nil
	default:
		return errors.New("invalid retention")
	}
}

type retentionResponse struct {
	Retention string `json:"retention"`
}
