package messages

import (
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
)

func ptrString(value string) *string { return &value }

func TestSendMessageRequestValidate(t *testing.T) {
	if err := (sendMessageRequest{Content: "hello"}).Validate(); err != nil {
		t.Fatalf("sendMessageRequest.Validate(text) unexpected error: %v", err)
	}
	if err := (sendMessageRequest{MediaURL: ptrString("/api/media/files/a.png"), MediaType: ptrString("image")}).Validate(); err != nil {
		t.Fatalf("sendMessageRequest.Validate(media) unexpected error: %v", err)
	}

	tests := []sendMessageRequest{
		{},
		{Content: string(make([]rune, 4001))},
		{MediaURL: ptrString("/api/media/files/a.png")},
		{MediaURL: ptrString("/bad/a.png"), MediaType: ptrString("IMAGE")},
		{MediaURL: ptrString("/api/media/files/a.png"), MediaType: ptrString("AUDIO")},
	}
	for _, req := range tests {
		if err := req.Validate(); err == nil {
			t.Fatalf("sendMessageRequest.Validate(%+v) expected error", req)
		}
	}
}

func TestMessageRequestValidators(t *testing.T) {
	if err := (createConversationRequest{Username: "valid_user"}).Validate(); err != nil {
		t.Fatalf("createConversationRequest.Validate() unexpected error: %v", err)
	}
	if err := (updateMessageRequest{Content: "updated"}).Validate(); err != nil {
		t.Fatalf("updateMessageRequest.Validate() unexpected error: %v", err)
	}
	if err := (messageReactionRequest{Reaction: "heart"}).Validate(); err != nil {
		t.Fatalf("messageReactionRequest.Validate() unexpected error: %v", err)
	}
	if err := (retentionRequest{Retention: "7d"}).Validate(); err != nil {
		t.Fatalf("retentionRequest.Validate() unexpected error: %v", err)
	}

	invalid := []error{
		(createConversationRequest{Username: "no-dash"}).Validate(),
		(updateMessageRequest{Content: ""}).Validate(),
		(messageReactionRequest{Reaction: "SMILE"}).Validate(),
		(retentionRequest{Retention: "2d"}).Validate(),
	}
	for i, err := range invalid {
		if err == nil {
			t.Fatalf("invalid validator %d expected error", i)
		}
	}
}

func TestMessageServicePureHelpers(t *testing.T) {
	if !validMessageReaction("HEART") || validMessageReaction("SMILE") {
		t.Fatal("validMessageReaction() returned unexpected result")
	}

	url, kind, err := normalizeMessageMedia(ptrString(" /api/media/files/a.png "), ptrString(" video "))
	if err != nil {
		t.Fatalf("normalizeMessageMedia() unexpected error: %v", err)
	}
	if *url != "/api/media/files/a.png" || *kind != "VIDEO" {
		t.Fatalf("normalizeMessageMedia() = %q/%q, want normalized url/VIDEO", *url, *kind)
	}
	if _, _, err := normalizeMessageMedia(ptrString("/api/media/files/a.png"), nil); err == nil {
		t.Fatal("normalizeMessageMedia() expected paired media error")
	}
	if url, kind, err := normalizeMessageMedia(nil, nil); err != nil || url != nil || kind != nil {
		t.Fatalf("normalizeMessageMedia(nil) = %v/%v/%v, want nil/nil/nil", url, kind, err)
	}

	for _, retention := range []string{"forever", "1h", "30d"} {
		if !validRetention(retention) {
			t.Fatalf("validRetention(%q) = false, want true", retention)
		}
	}
	if validRetention("2d") {
		t.Fatal("validRetention(2d) = true, want false")
	}
	foreverDuration, foreverOK := retentionDuration("forever")
	hourDuration, hourOK := retentionDuration("1h")
	if foreverDuration != 0 || foreverOK || hourDuration != time.Hour || !hourOK {
		t.Fatal("retentionDuration() returned unexpected values")
	}
}

func TestMessageToResponse(t *testing.T) {
	currentID := uuid.New()
	otherID := uuid.New()
	conversationID := uuid.New()
	messageID := uuid.New()
	replyID := uuid.New()
	createdAt := time.Now().UTC().Add(-time.Minute)
	readAt := time.Now().UTC()

	message := models.PrivateMessage{
		ID:             messageID,
		ConversationID: conversationID,
		SenderID:       currentID,
		Content:        "hello",
		ReplyToID:      &replyID,
		CreatedAt:      createdAt,
	}
	replies := map[uuid.UUID]models.PrivateMessage{
		replyID: {ID: replyID, SenderID: otherID, Content: "reply"},
	}

	response := messageToResponse(message, currentID, &readAt, 2, true, nil, false, replies)
	if response.Status != "READ" {
		t.Fatalf("messageToResponse().Status = %q, want READ", response.Status)
	}
	if response.ReplyTo == nil || response.ReplyTo.Content != "reply" {
		t.Fatal("messageToResponse() expected reply preview")
	}
	if response.LikeCount != 2 || !response.LikedByMe {
		t.Fatal("messageToResponse() did not preserve like state")
	}
}
