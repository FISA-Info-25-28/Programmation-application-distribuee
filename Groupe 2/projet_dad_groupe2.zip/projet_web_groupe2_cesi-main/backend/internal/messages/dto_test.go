package messages

import (
	"strings"
	"testing"

	"github.com/google/uuid"
)

func TestMessagesDTOValidation(t *testing.T) {
	if err := (createConversationRequest{Username: "alice"}).Validate(); err != nil {
		t.Fatalf("createConversationRequest.Validate() unexpected error: %v", err)
	}
	if err := (sendMessageRequest{Content: "hello"}).Validate(); err != nil {
		t.Fatalf("sendMessageRequest.Validate(text) unexpected error: %v", err)
	}

	mediaURL := "/api/media/files/a.png"
	mediaType := "IMAGE"
	replyID := uuid.New()
	if err := (sendMessageRequest{MediaURL: &mediaURL, MediaType: &mediaType, ReplyToID: &replyID}).Validate(); err != nil {
		t.Fatalf("sendMessageRequest.Validate(media) unexpected error: %v", err)
	}

	for _, req := range []sendMessageRequest{
		{},
		{Content: strings.Repeat("a", 4001)},
		{MediaURL: &mediaURL},
	} {
		if err := req.Validate(); err == nil {
			t.Fatalf("sendMessageRequest.Validate(%+v) expected error", req)
		}
	}

	if err := (messageReactionRequest{Reaction: "HEART"}).Validate(); err != nil {
		t.Fatalf("messageReactionRequest.Validate() unexpected error: %v", err)
	}
	if err := (retentionRequest{Retention: "7d"}).Validate(); err != nil {
		t.Fatalf("retentionRequest.Validate() unexpected error: %v", err)
	}
	if err := (retentionRequest{Retention: "bad"}).Validate(); err == nil {
		t.Fatal("retentionRequest.Validate() expected error")
	}
}
