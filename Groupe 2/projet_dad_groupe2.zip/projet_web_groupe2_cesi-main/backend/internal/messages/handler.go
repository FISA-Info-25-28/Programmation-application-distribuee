package messages

import (
	"context"
	"errors"
	"net/http"

	"breezy/backend/internal/config"
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Handler struct {
	db      *gorm.DB
	service *Service
}

func NewHandler(db *gorm.DB) *Handler {
	return &Handler{db: db, service: NewService(NewRepository(db))}
}

func (h *Handler) accountStatus(ctx context.Context, accountID uuid.UUID) (string, error) {
	var status string
	result := h.db.WithContext(ctx).Raw("SELECT status FROM auth.accounts WHERE id = ?", accountID).Scan(&status)
	if result.Error != nil {
		return "", result.Error
	}
	return status, nil
}

func (h *Handler) Health(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"service": config.Env("SERVICE_NAME", "messages-service"),
		"status":  "ok",
	})
}

func (h *Handler) ListConversations(c *gin.Context) {
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	conversations, err := h.service.ListConversations(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "conversations lookup failed"})
		return
	}
	c.JSON(http.StatusOK, conversations)
}

func (h *Handler) CreateConversation(c *gin.Context) {
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	status, err := h.accountStatus(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to verify account status"})
		return
	}
	if status == "SUSPENDED" || status == "BANNED" {
		c.JSON(http.StatusForbidden, gin.H{"error": "account suspended"})
		return
	}
	var req createConversationRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid conversation payload"})
		return
	}
	conversation, err := h.service.CreateConversation(c.Request.Context(), accountID, req.Username)
	if err != nil {
		switch {
		case errors.Is(err, gorm.ErrRecordNotFound):
			c.JSON(http.StatusNotFound, gin.H{"error": "profile not found"})
		case errors.Is(err, ErrConversationWithSelf):
			c.JSON(http.StatusBadRequest, gin.H{"error": "cannot message yourself"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "conversation creation failed"})
		}
		return
	}
	c.JSON(http.StatusCreated, conversation)
}

func (h *Handler) Messages(c *gin.Context) {
	accountID, conversationID, ok := h.ids(c)
	if !ok {
		return
	}
	messages, err := h.service.Messages(c.Request.Context(), accountID, conversationID)
	if err != nil {
		h.handleConversationError(c, err, "messages lookup failed")
		return
	}
	c.JSON(http.StatusOK, messages)
}

func (h *Handler) SendMessage(c *gin.Context) {
	accountID, conversationID, ok := h.ids(c)
	if !ok {
		return
	}
	status, err := h.accountStatus(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to verify account status"})
		return
	}
	if status == "SUSPENDED" || status == "BANNED" {
		c.JSON(http.StatusForbidden, gin.H{"error": "account suspended"})
		return
	}
	var req sendMessageRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid message payload"})
		return
	}
	message, err := h.service.SendMessage(c.Request.Context(), accountID, conversationID, req.Content, req.Nonce, req.Kind, req.MediaURL, req.MediaType, req.ReplyToID)
	if err != nil {
		if errors.Is(err, ErrInvalidMessage) {
			c.JSON(http.StatusBadRequest, gin.H{"error": "message text or media required"})
			return
		}
		h.handleConversationError(c, err, "message send failed")
		return
	}
	c.JSON(http.StatusCreated, message)
}

func (h *Handler) LikeMessage(c *gin.Context) {
	accountID, messageID, ok := h.messageIDs(c)
	if !ok {
		return
	}
	message, err := h.service.LikeMessage(c.Request.Context(), accountID, messageID)
	if err != nil {
		h.handleMessageError(c, err, "message like failed")
		return
	}
	c.JSON(http.StatusOK, message)
}

func (h *Handler) ReactToMessage(c *gin.Context) {
	accountID, messageID, ok := h.messageIDs(c)
	if !ok {
		return
	}
	var req messageReactionRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid reaction"})
		return
	}
	message, err := h.service.ReactToMessage(c.Request.Context(), accountID, messageID, req.Reaction)
	if err != nil {
		h.handleMessageError(c, err, "message reaction failed")
		return
	}
	c.JSON(http.StatusOK, message)
}

func (h *Handler) UnlikeMessage(c *gin.Context) {
	accountID, messageID, ok := h.messageIDs(c)
	if !ok {
		return
	}
	message, err := h.service.UnlikeMessage(c.Request.Context(), accountID, messageID)
	if err != nil {
		h.handleMessageError(c, err, "message unlike failed")
		return
	}
	c.JSON(http.StatusOK, message)
}

func (h *Handler) UpdateMessage(c *gin.Context) {
	accountID, messageID, ok := h.messageIDs(c)
	if !ok {
		return
	}

	var req updateMessageRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid message payload"})
		return
	}

	message, err := h.service.UpdateMessage(c.Request.Context(), accountID, messageID, req.Content, req.Nonce)
	if err != nil {
		h.handleMessageError(c, err, "message update failed")
		return
	}

	c.JSON(http.StatusOK, message)
}

func (h *Handler) DeleteMessage(c *gin.Context) {
	accountID, messageID, ok := h.messageIDs(c)
	if !ok {
		return
	}

	message, err := h.service.DeleteMessage(c.Request.Context(), accountID, messageID)
	if err != nil {
		h.handleMessageError(c, err, "message delete failed")
		return
	}

	c.JSON(http.StatusOK, message)
}

func (h *Handler) GetUnreadCount(c *gin.Context) {
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	count, err := h.service.TotalUnreadCount(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "unread count failed"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"count": count})
}

func (h *Handler) GetRetention(c *gin.Context) {
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	retention, err := h.service.GetRetention(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "message settings lookup failed"})
		return
	}
	c.JSON(http.StatusOK, retentionResponse{Retention: retention})
}

func (h *Handler) SetRetention(c *gin.Context) {
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	var req retentionRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid message settings payload"})
		return
	}
	retention, err := h.service.SetRetention(c.Request.Context(), accountID, req.Retention)
	if err != nil {
		if errors.Is(err, ErrInvalidRetention) {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid message retention"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "message settings update failed"})
		return
	}
	c.JSON(http.StatusOK, retentionResponse{Retention: retention})
}

func (h *Handler) ids(c *gin.Context) (uuid.UUID, uuid.UUID, bool) {
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return uuid.Nil, uuid.Nil, false
	}
	conversationID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid conversation id"})
		return uuid.Nil, uuid.Nil, false
	}
	return accountID, conversationID, true
}

func (h *Handler) messageIDs(c *gin.Context) (uuid.UUID, uuid.UUID, bool) {
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return uuid.Nil, uuid.Nil, false
	}
	messageID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid message id"})
		return uuid.Nil, uuid.Nil, false
	}
	return accountID, messageID, true
}

func (h *Handler) handleConversationError(c *gin.Context, err error, fallback string) {
	if errors.Is(err, gorm.ErrRecordNotFound) {
		c.JSON(http.StatusNotFound, gin.H{"error": "conversation not found"})
		return
	}
	c.JSON(http.StatusInternalServerError, gin.H{"error": fallback})
}

func (h *Handler) handleMessageError(c *gin.Context, err error, fallback string) {
	switch {
	case errors.Is(err, gorm.ErrRecordNotFound):
		c.JSON(http.StatusNotFound, gin.H{"error": "message not found"})
	case errors.Is(err, ErrForbiddenMessage):
		c.JSON(http.StatusForbidden, gin.H{"error": "cannot edit another user's message"})
	case errors.Is(err, ErrInvalidMessage):
		c.JSON(http.StatusBadRequest, gin.H{"error": "message cannot be empty"})
	case errors.Is(err, ErrDeletedMessage):
		c.JSON(http.StatusBadRequest, gin.H{"error": "message was deleted"})
	case errors.Is(err, ErrSharedPostMessage):
		c.JSON(http.StatusConflict, gin.H{"error": "shared posts cannot be edited"})
	default:
		c.JSON(http.StatusInternalServerError, gin.H{"error": fallback})
	}
}
