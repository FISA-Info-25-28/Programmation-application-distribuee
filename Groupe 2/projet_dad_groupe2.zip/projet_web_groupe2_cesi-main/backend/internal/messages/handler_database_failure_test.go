package messages

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"breezy/backend/internal/middleware"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func TestMessagesHandlerDatabaseFailures(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(closedMessagesDB(t))
	accountID := uuid.New()
	conversationID := uuid.NewString()
	messageID := uuid.NewString()

	tests := []struct {
		name, method, path, body string
		setup                    func(*gin.Engine)
	}{
		{name: "list", method: http.MethodGet, path: "/conversations", setup: func(r *gin.Engine) { r.GET("/conversations", handler.ListConversations) }},
		{name: "create", method: http.MethodPost, path: "/conversations", body: `{"username":"alice"}`, setup: func(r *gin.Engine) { r.POST("/conversations", handler.CreateConversation) }},
		{name: "messages", method: http.MethodGet, path: "/conversations/" + conversationID + "/messages", setup: func(r *gin.Engine) { r.GET("/conversations/:id/messages", handler.Messages) }},
		{name: "send", method: http.MethodPost, path: "/conversations/" + conversationID + "/messages", body: `{"content":"hello"}`, setup: func(r *gin.Engine) { r.POST("/conversations/:id/messages", handler.SendMessage) }},
		{name: "like", method: http.MethodPost, path: "/messages/" + messageID + "/like", setup: func(r *gin.Engine) { r.POST("/messages/:id/like", handler.LikeMessage) }},
		{name: "reaction", method: http.MethodPost, path: "/messages/" + messageID + "/reaction", body: `{"reaction":"HEART"}`, setup: func(r *gin.Engine) { r.POST("/messages/:id/reaction", handler.ReactToMessage) }},
		{name: "unlike", method: http.MethodDelete, path: "/messages/" + messageID + "/like", setup: func(r *gin.Engine) { r.DELETE("/messages/:id/like", handler.UnlikeMessage) }},
		{name: "update", method: http.MethodPatch, path: "/messages/" + messageID, body: `{"content":"edited"}`, setup: func(r *gin.Engine) { r.PATCH("/messages/:id", handler.UpdateMessage) }},
		{name: "delete", method: http.MethodDelete, path: "/messages/" + messageID, setup: func(r *gin.Engine) { r.DELETE("/messages/:id", handler.DeleteMessage) }},
		{name: "unread", method: http.MethodGet, path: "/conversations/unread-count", setup: func(r *gin.Engine) { r.GET("/conversations/unread-count", handler.GetUnreadCount) }},
		{name: "retention get", method: http.MethodGet, path: "/messages/settings", setup: func(r *gin.Engine) { r.GET("/messages/settings", handler.GetRetention) }},
		{name: "retention set", method: http.MethodPatch, path: "/messages/settings", body: `{"retention":"7d"}`, setup: func(r *gin.Engine) { r.PATCH("/messages/settings", handler.SetRetention) }},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
			tt.setup(router)
			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			rec := httptest.NewRecorder()
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusInternalServerError {
				t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
			}
		})
	}
}

func closedMessagesDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	mock.ExpectClose()
	if err := sqlDB.Close(); err != nil {
		t.Fatalf("Close() unexpected error: %v", err)
	}
	return db
}
