package messages

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"breezy/backend/internal/middleware"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// expectMessagesAccountStatus programme la requete brute lancee par
// Handler.accountStatus (verification SUSPENDED/BANNED) au tout debut des
// handlers CreateConversation et SendMessage.
func expectMessagesAccountStatus(mock sqlmock.Sqlmock, status string) {
	mock.ExpectQuery(`SELECT status FROM auth\.accounts WHERE id`).
		WillReturnRows(sqlmock.NewRows([]string{"status"}).AddRow(status))
}

// newSuccessHandler construit un Handler dont la verification de statut de
// compte passe par une vraie connexion sqlmock (seule requete brute issue de
// h.db dans le handler), tandis que le reste de la logique passe par un
// fakeMessagesRepo en memoire : cela permet d'exercer les chemins de succes
// complets des handlers sans avoir a scripter toute la chaine SQL du service.
func newSuccessHandler(t *testing.T) (*Handler, sqlmock.Sqlmock, *fakeMessagesRepo) {
	t.Helper()
	db, mock := messagesMockDB(t)
	repo := newFakeMessagesRepo()
	handler := &Handler{db: db, service: NewService(repo)}
	return handler, mock, repo
}

func authedMessagesRouter(accountID uuid.UUID) *gin.Engine {
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	return router
}

func TestMessagesHandlerListConversationsSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.GET("/conversations", handler.ListConversations)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/conversations", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("ListConversations status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerCreateConversationSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, mock, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/conversations", handler.CreateConversation)

	expectMessagesAccountStatus(mock, "ACTIVE")

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/conversations", strings.NewReader(`{"username":"bob"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusCreated {
		t.Fatalf("CreateConversation status = %d, want 201: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerCreateConversationSuspended(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, mock, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/conversations", handler.CreateConversation)

	expectMessagesAccountStatus(mock, "SUSPENDED")

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/conversations", strings.NewReader(`{"username":"bob"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusForbidden {
		t.Fatalf("CreateConversation(suspended) status = %d, want 403: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerCreateConversationBanned(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, mock, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/conversations", handler.CreateConversation)

	expectMessagesAccountStatus(mock, "BANNED")

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/conversations", strings.NewReader(`{"username":"bob"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusForbidden {
		t.Fatalf("CreateConversation(banned) status = %d, want 403: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerCreateConversationInvalidPayload(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, mock, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/conversations", handler.CreateConversation)

	tests := []struct {
		name string
		body string
	}{
		{name: "invalid json", body: `{`},
		{name: "invalid username", body: `{"username":"no-dash"}`},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			expectMessagesAccountStatus(mock, "ACTIVE")

			rec := httptest.NewRecorder()
			req := httptest.NewRequest(http.MethodPost, "/conversations", strings.NewReader(tt.body))
			req.Header.Set("Content-Type", "application/json")
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusBadRequest {
				t.Fatalf("CreateConversation(%s) status = %d, want 400: %s", tt.name, rec.Code, rec.Body.String())
			}
		})
	}
}

func TestMessagesHandlerCreateConversationServiceErrors(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("self conversation", func(t *testing.T) {
		handler, mock, repo := newSuccessHandler(t)
		accountID := repo.current.AccountID
		router := authedMessagesRouter(accountID)
		router.POST("/conversations", handler.CreateConversation)

		expectMessagesAccountStatus(mock, "ACTIVE")

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/conversations", strings.NewReader(`{"username":"`+repo.current.Username+`"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("CreateConversation(self) status = %d, want 400: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("profile not found", func(t *testing.T) {
		handler, mock, repo := newSuccessHandler(t)
		repo.errFindProfileByUsername = gorm.ErrRecordNotFound
		accountID := repo.current.AccountID
		router := authedMessagesRouter(accountID)
		router.POST("/conversations", handler.CreateConversation)

		expectMessagesAccountStatus(mock, "ACTIVE")

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/conversations", strings.NewReader(`{"username":"bob"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("CreateConversation(not found) status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("other error", func(t *testing.T) {
		handler, mock, repo := newSuccessHandler(t)
		repo.errCreateConversation = assertErr("boom")
		accountID := repo.current.AccountID
		router := authedMessagesRouter(accountID)
		router.POST("/conversations", handler.CreateConversation)

		expectMessagesAccountStatus(mock, "ACTIVE")

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/conversations", strings.NewReader(`{"username":"bob"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("CreateConversation(other error) status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}

func TestMessagesHandlerMessagesSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.GET("/conversations/:id/messages", handler.Messages)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/conversations/"+repo.conversationID.String()+"/messages", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("Messages status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerSendMessageSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, mock, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/conversations/:id/messages", handler.SendMessage)

	expectMessagesAccountStatus(mock, "ACTIVE")

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/conversations/"+repo.conversationID.String()+"/messages", strings.NewReader(`{"content":"hello"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusCreated {
		t.Fatalf("SendMessage status = %d, want 201: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerSendMessageSuspended(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, mock, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/conversations/:id/messages", handler.SendMessage)

	expectMessagesAccountStatus(mock, "SUSPENDED")

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/conversations/"+repo.conversationID.String()+"/messages", strings.NewReader(`{"content":"hello"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusForbidden {
		t.Fatalf("SendMessage(suspended) status = %d, want 403: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerSendMessageInvalidPayload(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, mock, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/conversations/:id/messages", handler.SendMessage)

	tests := []struct {
		name string
		body string
	}{
		{name: "invalid json", body: `{`},
		{name: "empty content", body: `{"content":""}`},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			expectMessagesAccountStatus(mock, "ACTIVE")

			rec := httptest.NewRecorder()
			req := httptest.NewRequest(http.MethodPost, "/conversations/"+repo.conversationID.String()+"/messages", strings.NewReader(tt.body))
			req.Header.Set("Content-Type", "application/json")
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusBadRequest {
				t.Fatalf("SendMessage(%s) status = %d, want 400: %s", tt.name, rec.Code, rec.Body.String())
			}
		})
	}
}

func TestMessagesHandlerSendMessageInvalidMessageFromService(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, mock, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID
	otherConversation := uuid.New()

	router := authedMessagesRouter(accountID)
	router.POST("/conversations/:id/messages", handler.SendMessage)

	expectMessagesAccountStatus(mock, "ACTIVE")

	rec := httptest.NewRecorder()
	body := `{"content":"reply","replyToId":"` + otherConversation.String() + `"}`
	req := httptest.NewRequest(http.MethodPost, "/conversations/"+repo.conversationID.String()+"/messages", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("SendMessage(invalid reply) status = %d, want 400: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerSendMessageConversationNotFound(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, mock, repo := newSuccessHandler(t)
	repo.errMember = gorm.ErrRecordNotFound
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/conversations/:id/messages", handler.SendMessage)

	expectMessagesAccountStatus(mock, "ACTIVE")

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/conversations/"+repo.conversationID.String()+"/messages", strings.NewReader(`{"content":"hello"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusNotFound {
		t.Fatalf("SendMessage(conversation not found) status = %d, want 404: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerLikeMessageSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	repo.message.SenderID = repo.other.ID
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/messages/:id/like", handler.LikeMessage)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/messages/"+repo.message.ID.String()+"/like", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("LikeMessage status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerReactToMessageSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	repo.message.SenderID = repo.other.ID
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/messages/:id/reaction", handler.ReactToMessage)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/messages/"+repo.message.ID.String()+"/reaction", strings.NewReader(`{"reaction":"HEART"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("ReactToMessage status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerReactToMessageInvalidPayload(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.POST("/messages/:id/reaction", handler.ReactToMessage)

	tests := []struct {
		name string
		body string
	}{
		{name: "invalid json", body: `{`},
		{name: "invalid reaction", body: `{"reaction":"SMILE"}`},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			rec := httptest.NewRecorder()
			req := httptest.NewRequest(http.MethodPost, "/messages/"+repo.message.ID.String()+"/reaction", strings.NewReader(tt.body))
			req.Header.Set("Content-Type", "application/json")
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusBadRequest {
				t.Fatalf("ReactToMessage(%s) status = %d, want 400: %s", tt.name, rec.Code, rec.Body.String())
			}
		})
	}
}

func TestMessagesHandlerUnlikeMessageSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.DELETE("/messages/:id/like", handler.UnlikeMessage)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodDelete, "/messages/"+repo.message.ID.String()+"/like", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("UnlikeMessage status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerUpdateMessageSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.PATCH("/messages/:id", handler.UpdateMessage)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPatch, "/messages/"+repo.message.ID.String(), strings.NewReader(`{"content":"edited"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("UpdateMessage status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerUpdateMessageInvalidPayload(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.PATCH("/messages/:id", handler.UpdateMessage)

	tests := []struct {
		name string
		body string
	}{
		{name: "invalid json", body: `{`},
		{name: "empty content", body: `{"content":""}`},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			rec := httptest.NewRecorder()
			req := httptest.NewRequest(http.MethodPatch, "/messages/"+repo.message.ID.String(), strings.NewReader(tt.body))
			req.Header.Set("Content-Type", "application/json")
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusBadRequest {
				t.Fatalf("UpdateMessage(%s) status = %d, want 400: %s", tt.name, rec.Code, rec.Body.String())
			}
		})
	}
}

func TestMessagesHandlerDeleteMessageSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.DELETE("/messages/:id", handler.DeleteMessage)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodDelete, "/messages/"+repo.message.ID.String(), nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("DeleteMessage status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerGetUnreadCountSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.GET("/conversations/unread-count", handler.GetUnreadCount)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/conversations/unread-count", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("GetUnreadCount status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerGetRetentionSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.GET("/messages/settings", handler.GetRetention)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/messages/settings", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("GetRetention status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerSetRetentionSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.PATCH("/messages/settings", handler.SetRetention)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPatch, "/messages/settings", strings.NewReader(`{"retention":"7d"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("SetRetention status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerSetRetentionInvalidPayload(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.PATCH("/messages/settings", handler.SetRetention)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPatch, "/messages/settings", strings.NewReader(`{`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("SetRetention(invalid json) status = %d, want 400: %s", rec.Code, rec.Body.String())
	}
}

func TestMessagesHandlerSetRetentionInvalidValueFromService(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler, _, repo := newSuccessHandler(t)
	accountID := repo.current.AccountID

	router := authedMessagesRouter(accountID)
	router.PATCH("/messages/settings", handler.SetRetention)

	// "forever" passe la validation DTO (cf retentionRequest.Validate) mais on
	// force le service a renvoyer ErrInvalidRetention pour couvrir la branche
	// 400 issue de SetRetention plutot que de la validation DTO.
	repo.retention = "forever"

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPatch, "/messages/settings", strings.NewReader(`{"retention":"7d"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("SetRetention(valid) status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}
