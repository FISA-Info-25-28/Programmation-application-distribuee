package messages

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

func TestMessagesHandlerMissingAccount(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(nil)

	tests := []struct {
		method string
		path   string
		setup  func(*gin.Engine)
	}{
		{method: http.MethodGet, path: "/conversations", setup: func(r *gin.Engine) { r.GET("/conversations", handler.ListConversations) }},
		{method: http.MethodPost, path: "/conversations", setup: func(r *gin.Engine) { r.POST("/conversations", handler.CreateConversation) }},
		{method: http.MethodGet, path: "/conversations/bad/messages", setup: func(r *gin.Engine) { r.GET("/conversations/:id/messages", handler.Messages) }},
		{method: http.MethodPost, path: "/conversations/bad/messages", setup: func(r *gin.Engine) { r.POST("/conversations/:id/messages", handler.SendMessage) }},
		{method: http.MethodGet, path: "/conversations/unread-count", setup: func(r *gin.Engine) { r.GET("/conversations/unread-count", handler.GetUnreadCount) }},
		{method: http.MethodGet, path: "/messages/settings", setup: func(r *gin.Engine) { r.GET("/messages/settings", handler.GetRetention) }},
		{method: http.MethodPatch, path: "/messages/settings", setup: func(r *gin.Engine) { r.PATCH("/messages/settings", handler.SetRetention) }},
		{method: http.MethodPost, path: "/messages/bad/like", setup: func(r *gin.Engine) { r.POST("/messages/:id/like", handler.LikeMessage) }},
		{method: http.MethodDelete, path: "/messages/bad/like", setup: func(r *gin.Engine) { r.DELETE("/messages/:id/like", handler.UnlikeMessage) }},
		{method: http.MethodPatch, path: "/messages/bad", setup: func(r *gin.Engine) { r.PATCH("/messages/:id", handler.UpdateMessage) }},
		{method: http.MethodDelete, path: "/messages/bad", setup: func(r *gin.Engine) { r.DELETE("/messages/:id", handler.DeleteMessage) }},
	}

	for _, tt := range tests {
		router := gin.New()
		tt.setup(router)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("%s %s status = %d, want 500", tt.method, tt.path, rec.Code)
		}
	}
}

func TestMessagesHandlerInvalidIDsAndErrors(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(nil)
	accountID := uuid.New()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	router.GET("/conversations/:id/messages", handler.Messages)
	router.POST("/messages/:id/reaction", handler.ReactToMessage)
	router.DELETE("/messages/:id/like", handler.UnlikeMessage)
	router.PATCH("/messages/:id", handler.UpdateMessage)
	router.DELETE("/messages/:id", handler.DeleteMessage)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/conversations/bad/messages", nil))
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("invalid conversation id status = %d, want 400", rec.Code)
	}

	rec = httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/messages/bad/reaction", nil))
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("invalid message id status = %d, want 400", rec.Code)
	}

	for _, tt := range []struct {
		method string
		path   string
	}{
		{method: http.MethodDelete, path: "/messages/bad/like"},
		{method: http.MethodPatch, path: "/messages/bad"},
		{method: http.MethodDelete, path: "/messages/bad"},
	} {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("%s %s status = %d, want 400", tt.method, tt.path, rec.Code)
		}
	}

	for _, tt := range []struct {
		fn   func(*gin.Context)
		err  error
		want int
	}{
		{fn: func(c *gin.Context) { handler.handleConversationError(c, gorm.ErrRecordNotFound, "fallback") }, want: http.StatusNotFound},
		{fn: func(c *gin.Context) { handler.handleConversationError(c, assertErr("boom"), "fallback") }, want: http.StatusInternalServerError},
		{fn: func(c *gin.Context) { handler.handleMessageError(c, gorm.ErrRecordNotFound, "fallback") }, want: http.StatusNotFound},
		{fn: func(c *gin.Context) { handler.handleMessageError(c, ErrForbiddenMessage, "fallback") }, want: http.StatusForbidden},
		{fn: func(c *gin.Context) { handler.handleMessageError(c, ErrInvalidMessage, "fallback") }, want: http.StatusBadRequest},
		{fn: func(c *gin.Context) { handler.handleMessageError(c, ErrDeletedMessage, "fallback") }, want: http.StatusBadRequest},
		{fn: func(c *gin.Context) { handler.handleMessageError(c, ErrSharedPostMessage, "fallback") }, want: http.StatusConflict},
		{fn: func(c *gin.Context) { handler.handleMessageError(c, assertErr("boom"), "fallback") }, want: http.StatusInternalServerError},
	} {
		rec := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(rec)
		tt.fn(c)
		if rec.Code != tt.want {
			t.Fatalf("handler error status = %d, want %d", rec.Code, tt.want)
		}
	}
}

type assertErr string

func (e assertErr) Error() string { return string(e) }

func TestRegisterRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	RegisterRoutes(router, NewHandler(nil))

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200", rec.Code)
	}

	rec = httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/conversations", nil))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("GET /conversations status = %d, want 401", rec.Code)
	}
}
