package messages

import (
	"context"
	"time"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository struct {
	db *gorm.DB
}

func NewRepository(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

func (r *Repository) FindProfileByAccountID(ctx context.Context, accountID uuid.UUID) (models.Profile, error) {
	var profile models.Profile
	err := r.db.WithContext(ctx).Table("profiles.profiles").Where("account_id = ?", accountID).First(&profile).Error
	return profile, err
}

func (r *Repository) FindProfileByUsername(ctx context.Context, username string) (models.Profile, error) {
	var profile models.Profile
	err := r.db.WithContext(ctx).Table("profiles.profiles").Where("lower(username) = lower(?)", username).First(&profile).Error
	return profile, err
}

func (r *Repository) FindProfileByID(ctx context.Context, id uuid.UUID) (models.Profile, error) {
	var profile models.Profile
	err := r.db.WithContext(ctx).Table("profiles.profiles").Where("id = ?", id).First(&profile).Error
	return profile, err
}

func (r *Repository) ConversationIDsForProfile(ctx context.Context, profileID uuid.UUID) ([]uuid.UUID, error) {
	var ids []uuid.UUID
	err := r.db.WithContext(ctx).
		Table("members").
		Where("profile_id = ?", profileID).
		Pluck("conversation_id", &ids).
		Error
	return ids, err
}

func (r *Repository) OtherMember(ctx context.Context, conversationID, profileID uuid.UUID) (models.ConversationMember, error) {
	var member models.ConversationMember
	err := r.db.WithContext(ctx).
		Table("members").
		Where("conversation_id = ? AND profile_id <> ?", conversationID, profileID).
		First(&member).
		Error
	return member, err
}

func (r *Repository) Member(ctx context.Context, conversationID, profileID uuid.UUID) (models.ConversationMember, error) {
	var member models.ConversationMember
	err := r.db.WithContext(ctx).
		Table("members").
		Where("conversation_id = ? AND profile_id = ?", conversationID, profileID).
		First(&member).
		Error
	return member, err
}

func (r *Repository) FindConversationBetween(ctx context.Context, a, b uuid.UUID) (uuid.UUID, error) {
	var ids []uuid.UUID
	err := r.db.WithContext(ctx).
		Raw(`
			SELECT m1.conversation_id
			FROM members m1
			JOIN members m2 ON m2.conversation_id = m1.conversation_id
			WHERE m1.profile_id = ? AND m2.profile_id = ?
			LIMIT 1
		`, a, b).
		Scan(&ids).
		Error
	if err != nil {
		return uuid.Nil, err
	}
	if len(ids) == 0 {
		return uuid.Nil, gorm.ErrRecordNotFound
	}
	return ids[0], nil
}

func (r *Repository) CreateConversation(ctx context.Context, a, b uuid.UUID) (uuid.UUID, error) {
	tx := r.db.WithContext(ctx).Begin()
	if tx.Error != nil {
		return uuid.Nil, tx.Error
	}

	conversation := models.Conversation{}
	if err := tx.Table("conversations").Create(&conversation).Error; err != nil {
		tx.Rollback()
		return uuid.Nil, err
	}

	members := []models.ConversationMember{
		{ConversationID: conversation.ID, ProfileID: a},
		{ConversationID: conversation.ID, ProfileID: b},
	}
	if err := tx.Table("members").Create(&members).Error; err != nil {
		tx.Rollback()
		return uuid.Nil, err
	}

	return conversation.ID, tx.Commit().Error
}

func (r *Repository) LastMessage(ctx context.Context, conversationID uuid.UUID, since *time.Time) (models.PrivateMessage, error) {
	var message models.PrivateMessage
	query := r.db.WithContext(ctx).Table("private_messages").Where("conversation_id = ?", conversationID)
	if since != nil {
		query = query.Where("created_at >= ?", *since)
	}
	err := query.Order("created_at DESC").First(&message).Error
	return message, err
}

func (r *Repository) CountUnread(ctx context.Context, conversationID, profileID uuid.UUID, lastReadAt *time.Time, since *time.Time) (int64, error) {
	var count int64
	query := r.db.WithContext(ctx).
		Table("private_messages").
		Where("conversation_id = ? AND sender_id <> ?", conversationID, profileID)
	if lastReadAt != nil {
		query = query.Where("created_at > ?", *lastReadAt)
	}
	if since != nil {
		query = query.Where("created_at >= ?", *since)
	}
	err := query.Count(&count).Error
	return count, err
}

func (r *Repository) Messages(ctx context.Context, conversationID uuid.UUID, since *time.Time) ([]models.PrivateMessage, error) {
	var messages []models.PrivateMessage
	query := r.db.WithContext(ctx).Table("private_messages").Where("conversation_id = ?", conversationID)
	if since != nil {
		query = query.Where("created_at >= ?", *since)
	}
	err := query.Order("created_at ASC").Find(&messages).Error
	return messages, err
}

func (r *Repository) FindMessagesByIDs(ctx context.Context, ids []uuid.UUID) (map[uuid.UUID]models.PrivateMessage, error) {
	if len(ids) == 0 {
		return map[uuid.UUID]models.PrivateMessage{}, nil
	}

	var messages []models.PrivateMessage
	err := r.db.WithContext(ctx).
		Table("private_messages").
		Where("id IN ?", ids).
		Find(&messages).
		Error
	if err != nil {
		return nil, err
	}

	byID := make(map[uuid.UUID]models.PrivateMessage, len(messages))
	for _, message := range messages {
		byID[message.ID] = message
	}
	return byID, nil
}

func (r *Repository) CreateMessage(ctx context.Context, message *models.PrivateMessage) error {
	return r.db.WithContext(ctx).Table("private_messages").Create(message).Error
}

func (r *Repository) FindMessageByID(ctx context.Context, messageID uuid.UUID) (models.PrivateMessage, error) {
	var message models.PrivateMessage
	err := r.db.WithContext(ctx).
		Table("private_messages").
		Where("id = ?", messageID).
		First(&message).
		Error
	return message, err
}

func (r *Repository) UpdateMessageContent(ctx context.Context, messageID uuid.UUID, content, nonce string, editedAt time.Time) (models.PrivateMessage, error) {
	var message models.PrivateMessage
	err := r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Table("private_messages").Where("id = ?", messageID).First(&message).Error; err != nil {
			return err
		}
		message.Content = content
		message.Nonce = nonce
		message.EditedAt = &editedAt
		return tx.Table("private_messages").
			Where("id = ?", messageID).
			Updates(map[string]any{
				"content":   content,
				"nonce":     nonce,
				"edited_at": editedAt,
			}).
			Error
	})
	return message, err
}

func (r *Repository) MarkMessageDeleted(ctx context.Context, messageID uuid.UUID, deletedAt time.Time) (models.PrivateMessage, error) {
	var message models.PrivateMessage
	err := r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Table("private_messages").Where("id = ?", messageID).First(&message).Error; err != nil {
			return err
		}
		message.Content = ""
		message.Nonce = ""
		message.MediaURL = nil
		message.MediaType = nil
		message.DeletedAt = &deletedAt
		return tx.Table("private_messages").
			Where("id = ?", messageID).
			Updates(map[string]any{
				"content":    "",
				"nonce":      "",
				"media_url":  nil,
				"media_type": nil,
				"deleted_at": deletedAt,
			}).
			Error
	})
	return message, err
}

func (r *Repository) MarkRead(ctx context.Context, conversationID, profileID uuid.UUID, now time.Time) error {
	return r.db.WithContext(ctx).
		Table("members").
		Where("conversation_id = ? AND profile_id = ?", conversationID, profileID).
		Update("last_read_at", now).
		Error
}

func (r *Repository) Retention(ctx context.Context, profileID uuid.UUID) (string, error) {
	var preference models.MessagePreference
	err := r.db.WithContext(ctx).Table("message_preferences").Where("profile_id = ?", profileID).First(&preference).Error
	if err != nil {
		return "", err
	}
	return preference.Retention, nil
}

func (r *Repository) SaveRetention(ctx context.Context, profileID uuid.UUID, retention string) error {
	preference := models.MessagePreference{ProfileID: profileID, Retention: retention}
	return r.db.WithContext(ctx).
		Table("message_preferences").
		Save(&preference).
		Error
}

func (r *Repository) CountTotalUnread(ctx context.Context, profileID uuid.UUID) (int64, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Raw(`
			SELECT COUNT(pm.id)
			FROM private_messages pm
			JOIN members m ON m.conversation_id = pm.conversation_id
			WHERE m.profile_id = ?
			  AND pm.sender_id <> ?
			  AND (m.last_read_at IS NULL OR pm.created_at > m.last_read_at)
		`, profileID, profileID).
		Scan(&count).
		Error
	return count, err
}

func (r *Repository) CountLikesByMessageIDs(ctx context.Context, messageIDs []uuid.UUID) (map[uuid.UUID]int64, error) {
	if len(messageIDs) == 0 {
		return map[uuid.UUID]int64{}, nil
	}

	var rows []struct {
		MessageID uuid.UUID `gorm:"column:message_id"`
		Count     int64     `gorm:"column:count"`
	}
	err := r.db.WithContext(ctx).
		Table("message_likes").
		Select("message_id, COUNT(*) AS count").
		Where("message_id IN ? AND reaction = ?", messageIDs, "HEART").
		Group("message_id").
		Scan(&rows).
		Error
	if err != nil {
		return nil, err
	}

	counts := make(map[uuid.UUID]int64, len(rows))
	for _, row := range rows {
		counts[row.MessageID] = row.Count
	}
	return counts, nil
}

func (r *Repository) FindLikedMessageIDs(ctx context.Context, profileID uuid.UUID, messageIDs []uuid.UUID) (map[uuid.UUID]bool, error) {
	if profileID == uuid.Nil || len(messageIDs) == 0 {
		return map[uuid.UUID]bool{}, nil
	}

	var rows []struct {
		MessageID uuid.UUID `gorm:"column:message_id"`
	}
	err := r.db.WithContext(ctx).
		Table("message_likes").
		Select("message_id").
		Where("user_id = ? AND message_id IN ? AND reaction = ?", profileID, messageIDs, "HEART").
		Scan(&rows).
		Error
	if err != nil {
		return nil, err
	}

	liked := make(map[uuid.UUID]bool, len(rows))
	for _, row := range rows {
		liked[row.MessageID] = true
	}
	return liked, nil
}

func (r *Repository) ReactionsByMessageIDs(ctx context.Context, profileID uuid.UUID, messageIDs []uuid.UUID) (map[uuid.UUID][]messageReactionResponse, error) {
	if len(messageIDs) == 0 {
		return map[uuid.UUID][]messageReactionResponse{}, nil
	}

	var rows []struct {
		MessageID   uuid.UUID `gorm:"column:message_id"`
		Reaction    string    `gorm:"column:reaction"`
		Count       int64     `gorm:"column:count"`
		ReactedByMe bool      `gorm:"column:reacted_by_me"`
	}
	err := r.db.WithContext(ctx).
		Table("message_likes").
		Select("message_id, reaction, COUNT(*) AS count, BOOL_OR(user_id = ?) AS reacted_by_me", profileID).
		Where("message_id IN ?", messageIDs).
		Group("message_id, reaction").
		Scan(&rows).
		Error
	if err != nil {
		return nil, err
	}

	reactions := make(map[uuid.UUID][]messageReactionResponse, len(rows))
	for _, row := range rows {
		reactions[row.MessageID] = append(reactions[row.MessageID], messageReactionResponse{
			Type:        row.Reaction,
			Count:       row.Count,
			ReactedByMe: row.ReactedByMe,
		})
	}
	return reactions, nil
}

func (r *Repository) CreateLike(ctx context.Context, like models.MessageLike) error {
	return r.db.WithContext(ctx).
		Table("message_likes").
		FirstOrCreate(&like, models.MessageLike{MessageID: like.MessageID, UserID: like.UserID}).
		Error
}

func (r *Repository) SetReaction(ctx context.Context, reaction models.MessageLike) error {
	return r.db.WithContext(ctx).
		Table("message_likes").
		Where("message_id = ? AND user_id = ?", reaction.MessageID, reaction.UserID).
		Assign(models.MessageLike{Reaction: reaction.Reaction}).
		FirstOrCreate(&reaction, models.MessageLike{MessageID: reaction.MessageID, UserID: reaction.UserID}).
		Error
}

func (r *Repository) DeleteLike(ctx context.Context, messageID, profileID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Table("message_likes").
		Where("message_id = ? AND user_id = ?", messageID, profileID).
		Delete(&models.MessageLike{}).
		Error
}
