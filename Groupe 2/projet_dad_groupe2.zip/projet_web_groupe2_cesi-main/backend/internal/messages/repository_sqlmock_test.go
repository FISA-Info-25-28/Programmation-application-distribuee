package messages

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// messagesMockDB ouvre une connexion GORM pilotee par sqlmock (mode reel, pas
// DryRun) afin de pouvoir scripter precisement les lignes et erreurs SQL
// renvoyees a chaque requete, pour couvrir les branches d'erreur et de succes
// du repository messages.
func messagesMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

func TestRepositoryFindConversationBetween(t *testing.T) {
	ctx := context.Background()
	a, b := uuid.New(), uuid.New()

	t.Run("found", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		conversationID := uuid.New()

		mock.ExpectQuery("SELECT m1.conversation_id").
			WillReturnRows(sqlmock.NewRows([]string{"conversation_id"}).AddRow(conversationID))

		got, err := repo.FindConversationBetween(ctx, a, b)
		if err != nil || got != conversationID {
			t.Fatalf("FindConversationBetween() = %v, %v, want %v, nil", got, err, conversationID)
		}
	})

	t.Run("not found", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)

		mock.ExpectQuery("SELECT m1.conversation_id").
			WillReturnRows(sqlmock.NewRows([]string{"conversation_id"}))

		_, err := repo.FindConversationBetween(ctx, a, b)
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("FindConversationBetween() error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("query error", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("boom")

		mock.ExpectQuery("SELECT m1.conversation_id").WillReturnError(wantErr)

		_, err := repo.FindConversationBetween(ctx, a, b)
		if err == nil {
			t.Fatal("FindConversationBetween() expected error, got nil")
		}
	})
}

func TestRepositoryCreateConversation(t *testing.T) {
	ctx := context.Background()
	a, b := uuid.New(), uuid.New()

	t.Run("success", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		conversationID := uuid.New()

		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "conversations"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(conversationID))
		mock.ExpectExec(`INSERT INTO "members"`).WillReturnResult(sqlmock.NewResult(0, 2))
		mock.ExpectCommit()

		got, err := repo.CreateConversation(ctx, a, b)
		if err != nil {
			t.Fatalf("CreateConversation() unexpected error: %v", err)
		}
		if got == uuid.Nil {
			t.Fatal("CreateConversation() returned nil id")
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet expectations: %v", err)
		}
	})

	t.Run("begin fails", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("begin failed")

		mock.ExpectBegin().WillReturnError(wantErr)

		_, err := repo.CreateConversation(ctx, a, b)
		if err == nil {
			t.Fatal("CreateConversation() expected error when Begin fails")
		}
	})

	t.Run("conversation insert fails", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("insert failed")

		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "conversations"`).WillReturnError(wantErr)
		mock.ExpectRollback()

		_, err := repo.CreateConversation(ctx, a, b)
		if err == nil {
			t.Fatal("CreateConversation() expected error when conversation insert fails")
		}
	})

	t.Run("members insert fails", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		conversationID := uuid.New()
		wantErr := errors.New("members insert failed")

		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "conversations"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(conversationID))
		mock.ExpectExec(`INSERT INTO "members"`).WillReturnError(wantErr)
		mock.ExpectRollback()

		_, err := repo.CreateConversation(ctx, a, b)
		if err == nil {
			t.Fatal("CreateConversation() expected error when members insert fails")
		}
	})
}

func TestRepositoryUpdateMessageContent(t *testing.T) {
	ctx := context.Background()
	messageID := uuid.New()
	conversationID := uuid.New()
	senderID := uuid.New()
	now := time.Now().UTC()

	t.Run("success", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)

		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT \* FROM "private_messages"`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "conversation_id", "sender_id", "content", "created_at"}).
				AddRow(messageID, conversationID, senderID, "original", now))
		mock.ExpectExec(`UPDATE "private_messages"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		got, err := repo.UpdateMessageContent(ctx, messageID, "edited", "", now)
		if err != nil {
			t.Fatalf("UpdateMessageContent() unexpected error: %v", err)
		}
		if got.Content != "edited" || got.EditedAt == nil {
			t.Fatalf("UpdateMessageContent() = %+v, want content edited with EditedAt set", got)
		}
	})

	t.Run("message not found", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)

		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT \* FROM "private_messages"`).
			WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectRollback()

		_, err := repo.UpdateMessageContent(ctx, messageID, "edited", "", now)
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("UpdateMessageContent() error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("update exec fails", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("update failed")

		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT \* FROM "private_messages"`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "conversation_id", "sender_id", "content", "created_at"}).
				AddRow(messageID, conversationID, senderID, "original", now))
		mock.ExpectExec(`UPDATE "private_messages"`).WillReturnError(wantErr)
		mock.ExpectRollback()

		_, err := repo.UpdateMessageContent(ctx, messageID, "edited", "", now)
		if err == nil {
			t.Fatal("UpdateMessageContent() expected error when update fails")
		}
	})
}

func TestRepositoryMarkMessageDeleted(t *testing.T) {
	ctx := context.Background()
	messageID := uuid.New()
	conversationID := uuid.New()
	senderID := uuid.New()
	now := time.Now().UTC()

	t.Run("success", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)

		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT \* FROM "private_messages"`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "conversation_id", "sender_id", "content", "created_at"}).
				AddRow(messageID, conversationID, senderID, "hello", now))
		mock.ExpectExec(`UPDATE "private_messages"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		got, err := repo.MarkMessageDeleted(ctx, messageID, now)
		if err != nil {
			t.Fatalf("MarkMessageDeleted() unexpected error: %v", err)
		}
		if got.DeletedAt == nil || got.Content != "" {
			t.Fatalf("MarkMessageDeleted() = %+v, want DeletedAt set and empty content", got)
		}
	})

	t.Run("message not found", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)

		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT \* FROM "private_messages"`).
			WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectRollback()

		_, err := repo.MarkMessageDeleted(ctx, messageID, now)
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("MarkMessageDeleted() error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("update exec fails", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("update failed")

		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT \* FROM "private_messages"`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "conversation_id", "sender_id", "content", "created_at"}).
				AddRow(messageID, conversationID, senderID, "hello", now))
		mock.ExpectExec(`UPDATE "private_messages"`).WillReturnError(wantErr)
		mock.ExpectRollback()

		_, err := repo.MarkMessageDeleted(ctx, messageID, now)
		if err == nil {
			t.Fatal("MarkMessageDeleted() expected error when update fails")
		}
	})
}

func TestRepositoryCountLikesByMessageIDs(t *testing.T) {
	ctx := context.Background()
	messageID := uuid.New()

	t.Run("success", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)

		mock.ExpectQuery(`SELECT message_id, COUNT`).
			WillReturnRows(sqlmock.NewRows([]string{"message_id", "count"}).AddRow(messageID, int64(2)))

		got, err := repo.CountLikesByMessageIDs(ctx, []uuid.UUID{messageID})
		if err != nil || got[messageID] != 2 {
			t.Fatalf("CountLikesByMessageIDs() = %v, %v, want {%v: 2}", got, err, messageID)
		}
	})

	t.Run("query error", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("boom")

		mock.ExpectQuery(`SELECT message_id, COUNT`).WillReturnError(wantErr)

		_, err := repo.CountLikesByMessageIDs(ctx, []uuid.UUID{messageID})
		if err == nil {
			t.Fatal("CountLikesByMessageIDs() expected error, got nil")
		}
	})
}

func TestRepositoryFindLikedMessageIDs(t *testing.T) {
	ctx := context.Background()
	profileID := uuid.New()
	messageID := uuid.New()

	t.Run("success", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)

		mock.ExpectQuery(`SELECT message_id FROM "message_likes"`).
			WillReturnRows(sqlmock.NewRows([]string{"message_id"}).AddRow(messageID))

		got, err := repo.FindLikedMessageIDs(ctx, profileID, []uuid.UUID{messageID})
		if err != nil || !got[messageID] {
			t.Fatalf("FindLikedMessageIDs() = %v, %v, want {%v: true}", got, err, messageID)
		}
	})

	t.Run("query error", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("boom")

		mock.ExpectQuery(`SELECT message_id FROM "message_likes"`).WillReturnError(wantErr)

		_, err := repo.FindLikedMessageIDs(ctx, profileID, []uuid.UUID{messageID})
		if err == nil {
			t.Fatal("FindLikedMessageIDs() expected error, got nil")
		}
	})
}

func TestRepositoryReactionsByMessageIDs(t *testing.T) {
	ctx := context.Background()
	profileID := uuid.New()
	messageID := uuid.New()

	t.Run("success", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)

		mock.ExpectQuery(`SELECT message_id, reaction, COUNT`).
			WillReturnRows(sqlmock.NewRows([]string{"message_id", "reaction", "count", "reacted_by_me"}).
				AddRow(messageID, "HEART", int64(1), true))

		got, err := repo.ReactionsByMessageIDs(ctx, profileID, []uuid.UUID{messageID})
		if err != nil || len(got[messageID]) != 1 || got[messageID][0].Type != "HEART" {
			t.Fatalf("ReactionsByMessageIDs() = %v, %v, want HEART reaction", got, err)
		}
	})

	t.Run("query error", func(t *testing.T) {
		db, mock := messagesMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("boom")

		mock.ExpectQuery(`SELECT message_id, reaction, COUNT`).WillReturnError(wantErr)

		_, err := repo.ReactionsByMessageIDs(ctx, profileID, []uuid.UUID{messageID})
		if err == nil {
			t.Fatal("ReactionsByMessageIDs() expected error, got nil")
		}
	})
}

func TestRepositoryFindMessagesByIDsQueryError(t *testing.T) {
	db, mock := messagesMockDB(t)
	repo := NewRepository(db)
	wantErr := errors.New("boom")

	mock.ExpectQuery(`SELECT \* FROM "private_messages"`).WillReturnError(wantErr)

	_, err := repo.FindMessagesByIDs(context.Background(), []uuid.UUID{uuid.New()})
	if err == nil {
		t.Fatal("FindMessagesByIDs() expected error, got nil")
	}
}

func TestRepositoryRetentionQueryError(t *testing.T) {
	db, mock := messagesMockDB(t)
	repo := NewRepository(db)
	wantErr := errors.New("boom")

	mock.ExpectQuery(`SELECT \* FROM "message_preferences"`).WillReturnError(wantErr)

	_, err := repo.Retention(context.Background(), uuid.New())
	if err == nil {
		t.Fatal("Retention() expected error, got nil")
	}
}
