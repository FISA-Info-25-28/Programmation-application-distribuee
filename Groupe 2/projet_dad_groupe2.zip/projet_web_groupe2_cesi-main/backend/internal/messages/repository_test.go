package messages

import (
	"context"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestMessagesRepositoryConstructor(t *testing.T) {
	repo := NewRepository(nil)
	if repo == nil || repo.db != nil {
		t.Fatalf("NewRepository(nil) = %+v, want repository with nil db", repo)
	}
}

func TestMessagesRepositoryQueriesDryRun(t *testing.T) {
	repo := NewRepository(messagesDryRunDB(t))
	ctx := context.Background()
	profileID := uuid.New()
	otherID := uuid.New()
	conversationID := uuid.New()
	messageID := uuid.New()
	now := time.Now()

	_, _ = repo.FindProfileByAccountID(ctx, uuid.New())
	_, _ = repo.FindProfileByUsername(ctx, "alice")
	_, _ = repo.FindProfileByID(ctx, profileID)
	_, _ = repo.ConversationIDsForProfile(ctx, profileID)
	_, _ = repo.OtherMember(ctx, conversationID, profileID)
	_, _ = repo.Member(ctx, conversationID, profileID)
	_, _ = repo.FindConversationBetween(ctx, profileID, otherID)
	_, _ = repo.CreateConversation(ctx, profileID, otherID)
	_, _ = repo.LastMessage(ctx, conversationID, nil)
	_, _ = repo.LastMessage(ctx, conversationID, &now)
	_, _ = repo.CountUnread(ctx, conversationID, profileID, nil, nil)
	_, _ = repo.CountUnread(ctx, conversationID, profileID, &now, &now)
	_, _ = repo.Messages(ctx, conversationID, nil)
	_, _ = repo.Messages(ctx, conversationID, &now)
	_, _ = repo.FindMessagesByIDs(ctx, nil)
	_, _ = repo.FindMessagesByIDs(ctx, []uuid.UUID{messageID})
	_ = repo.CreateMessage(ctx, &models.PrivateMessage{ID: messageID, ConversationID: conversationID, SenderID: profileID, Content: "hello"})
	_, _ = repo.FindMessageByID(ctx, messageID)
	_, _ = repo.UpdateMessageContent(ctx, messageID, "edited", "", now)
	_, _ = repo.MarkMessageDeleted(ctx, messageID, now)
	_ = repo.MarkRead(ctx, conversationID, profileID, now)
	_, _ = repo.Retention(ctx, profileID)
	_ = repo.SaveRetention(ctx, profileID, "1h")
	_, _ = repo.CountTotalUnread(ctx, profileID)
	_, _ = repo.CountLikesByMessageIDs(ctx, nil)
	_, _ = repo.CountLikesByMessageIDs(ctx, []uuid.UUID{messageID})
	_, _ = repo.FindLikedMessageIDs(ctx, uuid.Nil, []uuid.UUID{messageID})
	_, _ = repo.FindLikedMessageIDs(ctx, profileID, []uuid.UUID{messageID})
	_, _ = repo.ReactionsByMessageIDs(ctx, profileID, nil)
	_, _ = repo.ReactionsByMessageIDs(ctx, profileID, []uuid.UUID{messageID})
	_ = repo.CreateLike(ctx, models.MessageLike{MessageID: messageID, UserID: profileID, Reaction: "HEART"})
	_ = repo.SetReaction(ctx, models.MessageLike{MessageID: messageID, UserID: profileID, Reaction: "THUMBS_UP"})
	_ = repo.DeleteLike(ctx, messageID, profileID)
}

func messagesDryRunDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{DryRun: true})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db
}
