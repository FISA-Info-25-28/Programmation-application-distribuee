package messages

import (
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
)

func RegisterRoutes(router *gin.Engine, handler *Handler) {
	router.Use(middleware.JSONBody())

	router.GET("/health", handler.Health)

	authenticated := router.Group("/")
	authenticated.Use(middleware.AuthRequired())
	authenticated.GET("/conversations", handler.ListConversations)
	authenticated.GET("/conversations/unread-count", handler.GetUnreadCount)
	authenticated.POST("/conversations", handler.CreateConversation)
	authenticated.GET("/conversations/:id/messages", handler.Messages)
	authenticated.POST("/conversations/:id/messages", handler.SendMessage)
	authenticated.GET("/messages/settings", handler.GetRetention)
	authenticated.PATCH("/messages/settings", handler.SetRetention)
	authenticated.POST("/messages/:id/like", handler.LikeMessage)
	authenticated.DELETE("/messages/:id/like", handler.UnlikeMessage)
	authenticated.POST("/messages/:id/reaction", handler.ReactToMessage)
	authenticated.DELETE("/messages/:id/reaction", handler.UnlikeMessage)
	authenticated.PATCH("/messages/:id", handler.UpdateMessage)
	authenticated.DELETE("/messages/:id", handler.DeleteMessage)
}
