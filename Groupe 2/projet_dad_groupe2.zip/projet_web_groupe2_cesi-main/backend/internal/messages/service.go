package messages

import (
	"context"
	"errors"
	"sort"
	"strings"
	"time"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

var (
	ErrConversationWithSelf = errors.New("conversation with self")
	ErrInvalidRetention     = errors.New("invalid message retention")
	ErrForbiddenMessage     = errors.New("forbidden message")
	ErrInvalidMessage       = errors.New("invalid message")
	ErrDeletedMessage       = errors.New("deleted message")
	ErrSharedPostMessage    = errors.New("shared post message")
)

type Service struct {
	repo messagesRepository
}

type messagesRepository interface {
	FindProfileByAccountID(context.Context, uuid.UUID) (models.Profile, error)
	FindProfileByUsername(context.Context, string) (models.Profile, error)
	FindProfileByID(context.Context, uuid.UUID) (models.Profile, error)
	ConversationIDsForProfile(context.Context, uuid.UUID) ([]uuid.UUID, error)
	OtherMember(context.Context, uuid.UUID, uuid.UUID) (models.ConversationMember, error)
	Member(context.Context, uuid.UUID, uuid.UUID) (models.ConversationMember, error)
	FindConversationBetween(context.Context, uuid.UUID, uuid.UUID) (uuid.UUID, error)
	CreateConversation(context.Context, uuid.UUID, uuid.UUID) (uuid.UUID, error)
	LastMessage(context.Context, uuid.UUID, *time.Time) (models.PrivateMessage, error)
	CountUnread(context.Context, uuid.UUID, uuid.UUID, *time.Time, *time.Time) (int64, error)
	Messages(context.Context, uuid.UUID, *time.Time) ([]models.PrivateMessage, error)
	FindMessagesByIDs(context.Context, []uuid.UUID) (map[uuid.UUID]models.PrivateMessage, error)
	CreateMessage(context.Context, *models.PrivateMessage) error
	FindMessageByID(context.Context, uuid.UUID) (models.PrivateMessage, error)
	UpdateMessageContent(context.Context, uuid.UUID, string, string, time.Time) (models.PrivateMessage, error)
	MarkMessageDeleted(context.Context, uuid.UUID, time.Time) (models.PrivateMessage, error)
	MarkRead(context.Context, uuid.UUID, uuid.UUID, time.Time) error
	Retention(context.Context, uuid.UUID) (string, error)
	SaveRetention(context.Context, uuid.UUID, string) error
	CountTotalUnread(context.Context, uuid.UUID) (int64, error)
	CountLikesByMessageIDs(context.Context, []uuid.UUID) (map[uuid.UUID]int64, error)
	FindLikedMessageIDs(context.Context, uuid.UUID, []uuid.UUID) (map[uuid.UUID]bool, error)
	ReactionsByMessageIDs(context.Context, uuid.UUID, []uuid.UUID) (map[uuid.UUID][]messageReactionResponse, error)
	SetReaction(context.Context, models.MessageLike) error
	DeleteLike(context.Context, uuid.UUID, uuid.UUID) error
}

// NewService construit le service de messagerie autour de son repository.
// Entree : repo.
// Sortie : valeur retour de type *Service.
func NewService(repo messagesRepository) *Service {
	return &Service{repo: repo}
}

// ListConversations recupere les conversations du compte courant avec leur dernier message.
// Entree : ctx, accountID.
// Sortie : valeurs retour de la fonction.
func (s *Service) ListConversations(ctx context.Context, accountID uuid.UUID) ([]conversationResponse, error) {
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return nil, err
	}

	since, err := s.retentionSince(ctx, current.ID)
	if err != nil {
		return nil, err
	}

	ids, err := s.repo.ConversationIDsForProfile(ctx, current.ID)
	if err != nil {
		return nil, err
	}

	responses := make([]conversationResponse, 0, len(ids))
	for _, id := range ids {
		member, err := s.repo.Member(ctx, id, current.ID)
		if err != nil {
			return nil, err
		}
		otherMember, err := s.repo.OtherMember(ctx, id, current.ID)
		if err != nil {
			return nil, err
		}
		otherProfile, err := s.repo.FindProfileByID(ctx, otherMember.ProfileID)
		if err != nil {
			return nil, err
		}

		lastMessage, err := s.repo.LastMessage(ctx, id, since)
		var lastMessageSenderID *uuid.UUID
		if errors.Is(err, gorm.ErrRecordNotFound) {
			lastMessage = models.PrivateMessage{ConversationID: id, Content: "", CreatedAt: time.Time{}}
		} else if err != nil {
			return nil, err
		} else {
			if lastMessage.DeletedAt != nil {
				lastMessage.Content = "Message supprimé"
				lastMessage.Nonce = ""
			} else if strings.TrimSpace(lastMessage.Content) == "" && lastMessage.MediaType != nil {
				if *lastMessage.MediaType == "VIDEO" {
					lastMessage.Content = "Video"
				} else {
					lastMessage.Content = "Image ou GIF"
				}
				lastMessage.Nonce = ""
			}
			lastMessageSenderID = &lastMessage.SenderID
		}

		unread, err := s.repo.CountUnread(ctx, id, current.ID, member.LastReadAt, since)
		if err != nil {
			return nil, err
		}

		responses = append(responses, conversationResponse{
			ID:                  id,
			CurrentProfileID:    current.ID,
			Participant:         profileToParticipant(otherProfile),
			LastMessage:         lastMessage.Content,
			LastMessageNonce:    lastMessage.Nonce,
			LastMessageSenderID: lastMessageSenderID,
			LastMessageAt:       lastMessage.CreatedAt,
			UnreadCount:         unread,
		})
	}

	sort.SliceStable(responses, func(i, j int) bool {
		return responses[i].LastMessageAt.After(responses[j].LastMessageAt)
	})

	return responses, nil
}

// CreateConversation ouvre ou retrouve une conversation avec un autre utilisateur.
// Entree : ctx, accountID, username.
// Sortie : valeurs retour de la fonction.
func (s *Service) CreateConversation(ctx context.Context, accountID uuid.UUID, username string) (conversationResponse, error) {
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return conversationResponse{}, err
	}

	target, err := s.repo.FindProfileByUsername(ctx, strings.TrimSpace(username))
	if err != nil {
		return conversationResponse{}, err
	}
	if target.ID == current.ID {
		return conversationResponse{}, ErrConversationWithSelf
	}

	conversationID, err := s.repo.FindConversationBetween(ctx, current.ID, target.ID)
	if errors.Is(err, gorm.ErrRecordNotFound) {
		conversationID, err = s.repo.CreateConversation(ctx, current.ID, target.ID)
	}
	if err != nil {
		return conversationResponse{}, err
	}

	return conversationResponse{
		ID:               conversationID,
		CurrentProfileID: current.ID,
		Participant:      profileToParticipant(target),
		LastMessage:      "",
		LastMessageAt:    time.Now().UTC(),
		UnreadCount:      0,
	}, nil
}

// Messages recupere les messages visibles d'une conversation et la marque comme lue.
// Entree : ctx, accountID, conversationID.
// Sortie : valeurs retour de la fonction.
func (s *Service) Messages(ctx context.Context, accountID, conversationID uuid.UUID) ([]messageResponse, error) {
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return nil, err
	}
	currentMember, err := s.repo.Member(ctx, conversationID, current.ID)
	if err != nil {
		return nil, err
	}
	otherMember, err := s.repo.OtherMember(ctx, conversationID, current.ID)
	if err != nil {
		return nil, err
	}

	since, err := s.retentionSince(ctx, current.ID)
	if err != nil {
		return nil, err
	}

	messages, err := s.repo.Messages(ctx, conversationID, since)
	if err != nil {
		return nil, err
	}
	responses, err := s.messagesToResponses(ctx, messages, current.ID, otherMember.LastReadAt, currentMember.LastReadAt)
	if err != nil {
		return nil, err
	}
	if err := s.repo.MarkRead(ctx, conversationID, current.ID, time.Now().UTC()); err != nil {
		return nil, err
	}
	return responses, nil
}

// SendMessage valide puis enregistre un message texte, media ou une reponse dans une conversation.
// content est le ciphertext chiffre cote client (NaCl box) accompagne de son nonce ;
// le serveur ne dechiffre jamais le texte.
// Entree : ctx, accountID, conversationID, content, nonce, kind, mediaURL, mediaType, replyToID.
// Sortie : valeurs retour de la fonction.
func (s *Service) SendMessage(ctx context.Context, accountID, conversationID uuid.UUID, content, nonce, kind string, mediaURL, mediaType *string, replyToID *uuid.UUID) (messageResponse, error) {
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return messageResponse{}, err
	}
	if replyToID != nil {
		replyTo, err := s.repo.FindMessageByID(ctx, *replyToID)
		if err != nil {
			return messageResponse{}, err
		}
		if replyTo.ConversationID != conversationID {
			return messageResponse{}, ErrInvalidMessage
		}
	}
	if _, err := s.repo.Member(ctx, conversationID, current.ID); err != nil {
		return messageResponse{}, err
	}
	otherMember, err := s.repo.OtherMember(ctx, conversationID, current.ID)
	if err != nil {
		return messageResponse{}, err
	}

	trimmedContent := strings.TrimSpace(content)
	normalizedURL, normalizedType, err := normalizeMessageMedia(mediaURL, mediaType)
	if err != nil || (trimmedContent == "" && normalizedURL == nil) {
		return messageResponse{}, ErrInvalidMessage
	}

	kind = strings.TrimSpace(kind)
	if kind == "" {
		kind = "TEXT"
	}

	message := models.PrivateMessage{
		ConversationID: conversationID,
		SenderID:       current.ID,
		Content:        trimmedContent,
		Nonce:          strings.TrimSpace(nonce),
		Kind:           kind,
		MediaURL:       normalizedURL,
		MediaType:      normalizedType,
		ReplyToID:      replyToID,
	}
	if err := s.repo.CreateMessage(ctx, &message); err != nil {
		return messageResponse{}, err
	}
	responses, err := s.messagesToResponses(ctx, []models.PrivateMessage{message}, current.ID, otherMember.LastReadAt, nil)
	if err != nil {
		return messageResponse{}, err
	}
	return responses[0], nil
}

// UpdateMessage modifie le contenu chiffre d'un message envoye par l'utilisateur courant.
// content/nonce sont le nouveau ciphertext et son nonce, chiffres cote client.
// Entree : ctx, accountID, messageID, content, nonce.
// Sortie : valeurs retour de la fonction.
func (s *Service) UpdateMessage(ctx context.Context, accountID, messageID uuid.UUID, content, nonce string) (messageResponse, error) {
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return messageResponse{}, err
	}

	message, err := s.repo.FindMessageByID(ctx, messageID)
	if err != nil {
		return messageResponse{}, err
	}
	if message.SenderID != current.ID {
		return messageResponse{}, ErrForbiddenMessage
	}
	if message.DeletedAt != nil {
		return messageResponse{}, ErrDeletedMessage
	}
	if message.Kind == "SHARED_POST" {
		return messageResponse{}, ErrSharedPostMessage
	}
	otherMember, err := s.repo.OtherMember(ctx, message.ConversationID, current.ID)
	if err != nil {
		return messageResponse{}, err
	}

	nextContent := strings.TrimSpace(content)
	nextNonce := strings.TrimSpace(nonce)
	if nextContent == "" {
		return messageResponse{}, ErrInvalidMessage
	}

	updated, err := s.repo.UpdateMessageContent(ctx, messageID, nextContent, nextNonce, time.Now().UTC())
	if err != nil {
		return messageResponse{}, err
	}
	updated.Content = nextContent
	updated.Nonce = nextNonce
	responses, err := s.messagesToResponses(ctx, []models.PrivateMessage{updated}, current.ID, otherMember.LastReadAt, nil)
	if err != nil {
		return messageResponse{}, err
	}
	return responses[0], nil
}

// DeleteMessage marque comme supprime un message appartenant a l'utilisateur courant.
// Entree : ctx, accountID, messageID.
// Sortie : valeurs retour de la fonction.
func (s *Service) DeleteMessage(ctx context.Context, accountID, messageID uuid.UUID) (messageResponse, error) {
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return messageResponse{}, err
	}

	message, err := s.repo.FindMessageByID(ctx, messageID)
	if err != nil {
		return messageResponse{}, err
	}
	if message.SenderID != current.ID {
		return messageResponse{}, ErrForbiddenMessage
	}
	if message.DeletedAt != nil {
		return messageResponse{}, ErrDeletedMessage
	}
	otherMember, err := s.repo.OtherMember(ctx, message.ConversationID, current.ID)
	if err != nil {
		return messageResponse{}, err
	}

	deleted, err := s.repo.MarkMessageDeleted(ctx, messageID, time.Now().UTC())
	if err != nil {
		return messageResponse{}, err
	}

	responses, err := s.messagesToResponses(ctx, []models.PrivateMessage{deleted}, current.ID, otherMember.LastReadAt, nil)
	if err != nil {
		return messageResponse{}, err
	}
	return responses[0], nil
}

// LikeMessage ajoute une reaction coeur sur un message.
// Entree : ctx, accountID, messageID.
// Sortie : valeurs retour de la fonction.
func (s *Service) LikeMessage(ctx context.Context, accountID, messageID uuid.UUID) (messageResponse, error) {
	return s.ReactToMessage(ctx, accountID, messageID, "HEART")
}

// ReactToMessage enregistre ou remplace la reaction de l'utilisateur sur un message.
// Entree : ctx, accountID, messageID, reaction.
// Sortie : valeurs retour de la fonction.
func (s *Service) ReactToMessage(ctx context.Context, accountID, messageID uuid.UUID, reaction string) (messageResponse, error) {
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return messageResponse{}, err
	}
	message, err := s.repo.FindMessageByID(ctx, messageID)
	if err != nil {
		return messageResponse{}, err
	}
	if _, err := s.repo.Member(ctx, message.ConversationID, current.ID); err != nil {
		return messageResponse{}, err
	}
	if message.DeletedAt != nil {
		return messageResponse{}, ErrDeletedMessage
	}
	if message.SenderID == current.ID {
		return messageResponse{}, ErrInvalidMessage
	}
	reaction = strings.TrimSpace(reaction)
	if !validMessageReaction(reaction) {
		return messageResponse{}, ErrInvalidMessage
	}
	if err := s.repo.SetReaction(ctx, models.MessageLike{MessageID: messageID, UserID: current.ID, Reaction: reaction}); err != nil {
		return messageResponse{}, err
	}
	otherMember, err := s.repo.OtherMember(ctx, message.ConversationID, current.ID)
	if err != nil {
		return messageResponse{}, err
	}
	responses, err := s.messagesToResponses(ctx, []models.PrivateMessage{message}, current.ID, otherMember.LastReadAt, nil)
	if err != nil {
		return messageResponse{}, err
	}
	return responses[0], nil
}

// UnlikeMessage retire la reaction de l'utilisateur courant sur un message.
// Entree : ctx, accountID, messageID.
// Sortie : valeurs retour de la fonction.
func (s *Service) UnlikeMessage(ctx context.Context, accountID, messageID uuid.UUID) (messageResponse, error) {
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return messageResponse{}, err
	}
	message, err := s.repo.FindMessageByID(ctx, messageID)
	if err != nil {
		return messageResponse{}, err
	}
	if _, err := s.repo.Member(ctx, message.ConversationID, current.ID); err != nil {
		return messageResponse{}, err
	}
	if err := s.repo.DeleteLike(ctx, messageID, current.ID); err != nil {
		return messageResponse{}, err
	}
	otherMember, err := s.repo.OtherMember(ctx, message.ConversationID, current.ID)
	if err != nil {
		return messageResponse{}, err
	}
	responses, err := s.messagesToResponses(ctx, []models.PrivateMessage{message}, current.ID, otherMember.LastReadAt, nil)
	if err != nil {
		return messageResponse{}, err
	}
	return responses[0], nil
}

// TotalUnreadCount compte tous les messages non lus du profil courant.
// Entree : ctx, accountID.
// Sortie : valeurs retour de la fonction.
func (s *Service) TotalUnreadCount(ctx context.Context, accountID uuid.UUID) (int64, error) {
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return 0, err
	}
	return s.repo.CountTotalUnread(ctx, current.ID)
}

// GetRetention recupere la duree de conservation des messages du profil courant.
// Entree : ctx, accountID.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetRetention(ctx context.Context, accountID uuid.UUID) (string, error) {
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return "", err
	}
	retention, err := s.repo.Retention(ctx, current.ID)
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return "forever", nil
	}
	return retention, err
}

// SetRetention valide et enregistre la duree de conservation des messages.
// Entree : ctx, accountID, retention.
// Sortie : valeurs retour de la fonction.
func (s *Service) SetRetention(ctx context.Context, accountID uuid.UUID, retention string) (string, error) {
	if !validRetention(retention) {
		return "", ErrInvalidRetention
	}
	current, err := s.repo.FindProfileByAccountID(ctx, accountID)
	if err != nil {
		return "", err
	}
	if err := s.repo.SaveRetention(ctx, current.ID, retention); err != nil {
		return "", err
	}
	return retention, nil
}

// retentionSince calcule la date minimale des messages a afficher selon la retention.
// Entree : ctx, profileID.
// Sortie : valeurs retour de la fonction.
func (s *Service) retentionSince(ctx context.Context, profileID uuid.UUID) (*time.Time, error) {
	retention, err := s.repo.Retention(ctx, profileID)
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if retention == "forever" {
		return nil, nil
	}

	duration, ok := retentionDuration(retention)
	if !ok {
		return nil, nil
	}
	since := time.Now().UTC().Add(-duration)
	return &since, nil
}

// profileToParticipant transforme un profil en participant de conversation.
// Entree : profile.
// Sortie : valeur retour de type participantResponse.
func profileToParticipant(profile models.Profile) participantResponse {
	displayName := profile.Username
	if profile.DisplayName != nil && strings.TrimSpace(*profile.DisplayName) != "" {
		displayName = *profile.DisplayName
	}
	return participantResponse{
		ID:          profile.ID,
		Username:    profile.Username,
		DisplayName: displayName,
		AvatarURL:   profile.AvatarURL,
		PublicKey:   profile.PublicKey,
	}
}

// messagesToResponses enrichit les messages avec reactions, likes, reponses et etat de lecture.
// Entree : ctx, messages, currentProfileID, recipientLastReadAt, currentLastReadAt.
// Sortie : valeurs retour de la fonction.
func (s *Service) messagesToResponses(ctx context.Context, messages []models.PrivateMessage, currentProfileID uuid.UUID, recipientLastReadAt, currentLastReadAt *time.Time) ([]messageResponse, error) {
	messageIDs := make([]uuid.UUID, 0, len(messages))
	replyIDs := make([]uuid.UUID, 0, len(messages))
	for _, message := range messages {
		messageIDs = append(messageIDs, message.ID)
		if message.ReplyToID != nil {
			replyIDs = append(replyIDs, *message.ReplyToID)
		}
	}

	likeCounts, err := s.repo.CountLikesByMessageIDs(ctx, messageIDs)
	if err != nil {
		return nil, err
	}
	likedByMe, err := s.repo.FindLikedMessageIDs(ctx, currentProfileID, messageIDs)
	if err != nil {
		return nil, err
	}
	reactions, err := s.repo.ReactionsByMessageIDs(ctx, currentProfileID, messageIDs)
	if err != nil {
		return nil, err
	}
	replies, err := s.repo.FindMessagesByIDs(ctx, replyIDs)
	if err != nil {
		return nil, err
	}

	responses := make([]messageResponse, 0, len(messages))
	firstUnreadSet := false
	for _, message := range messages {
		isFirstUnread := false
		if !firstUnreadSet && message.SenderID != currentProfileID && (currentLastReadAt == nil || message.CreatedAt.After(*currentLastReadAt)) {
			isFirstUnread = true
			firstUnreadSet = true
		}
		responses = append(responses, messageToResponse(message, currentProfileID, recipientLastReadAt, likeCounts[message.ID], likedByMe[message.ID], reactions[message.ID], isFirstUnread, replies))
	}
	return responses, nil
}

// messageToResponse transforme un message prive enrichi en DTO avec son statut de lecture.
// Entree : message, currentProfileID, recipientLastReadAt, likeCount, likedByMe, reactions, isFirstUnread, replies.
// Sortie : valeur retour de type messageResponse.
func messageToResponse(message models.PrivateMessage, currentProfileID uuid.UUID, recipientLastReadAt *time.Time, likeCount int64, likedByMe bool, reactions []messageReactionResponse, isFirstUnread bool, replies map[uuid.UUID]models.PrivateMessage) messageResponse {
	status := "DELIVERED"
	if message.SenderID == currentProfileID && recipientLastReadAt != nil && !recipientLastReadAt.Before(message.CreatedAt) {
		status = "READ"
	}
	if reactions == nil {
		reactions = []messageReactionResponse{}
	}
	var replyTo *messageReplyResponse
	if message.ReplyToID != nil {
		if reply, ok := replies[*message.ReplyToID]; ok {
			content := reply.Content
			nonce := reply.Nonce
			if reply.DeletedAt != nil {
				content = "Message supprime"
				nonce = ""
			}
			replyTo = &messageReplyResponse{
				ID:        reply.ID,
				SenderID:  reply.SenderID,
				Content:   content,
				Nonce:     nonce,
				MediaType: reply.MediaType,
				DeletedAt: reply.DeletedAt,
			}
		}
	}

	return messageResponse{
		ID:             message.ID,
		ConversationID: message.ConversationID,
		SenderID:       message.SenderID,
		Content:        message.Content,
		Nonce:          message.Nonce,
		MediaURL:       message.MediaURL,
		MediaType:      message.MediaType,
		ReplyToID:      message.ReplyToID,
		ReplyTo:        replyTo,
		LikeCount:      likeCount,
		LikedByMe:      likedByMe,
		Reactions:      reactions,
		IsFirstUnread:  isFirstUnread,
		Status:         status,
		CreatedAt:      message.CreatedAt,
		EditedAt:       message.EditedAt,
		DeletedAt:      message.DeletedAt,
	}
}

// validMessageReaction verifie que la reaction demandee est supportee.
// Entree : reaction.
// Sortie : valeur retour de type bool.
func validMessageReaction(reaction string) bool {
	switch reaction {
	case "HEART", "THUMBS_UP", "THUMBS_DOWN":
		return true
	default:
		return false
	}
}

// normalizeMessageMedia valide et normalise les informations media d'un message.
// Entree : mediaURL, mediaType.
// Sortie : valeurs retour de la fonction.
func normalizeMessageMedia(mediaURL, mediaType *string) (*string, *string, error) {
	if mediaURL == nil && mediaType == nil {
		return nil, nil, nil
	}
	if mediaURL == nil || mediaType == nil {
		return nil, nil, ErrInvalidMessage
	}

	url := strings.TrimSpace(*mediaURL)
	kind := strings.ToUpper(strings.TrimSpace(*mediaType))
	if !strings.Contains(url, "/api/media/files/") || (kind != "IMAGE" && kind != "VIDEO") {
		return nil, nil, ErrInvalidMessage
	}
	return &url, &kind, nil
}

// validRetention verifie que la valeur de retention est acceptee.
// Entree : retention.
// Sortie : valeur retour de type bool.
func validRetention(retention string) bool {
	_, ok := retentionDuration(retention)
	return ok || retention == "forever"
}

// retentionDuration convertit une retention bornee en duree.
// Entree : retention.
// Sortie : valeurs retour de la fonction.
func retentionDuration(retention string) (time.Duration, bool) {
	switch retention {
	case "1h":
		return time.Hour, true
	case "7d":
		return 7 * 24 * time.Hour, true
	case "30d":
		return 30 * 24 * time.Hour, true
	default:
		return 0, false
	}
}
