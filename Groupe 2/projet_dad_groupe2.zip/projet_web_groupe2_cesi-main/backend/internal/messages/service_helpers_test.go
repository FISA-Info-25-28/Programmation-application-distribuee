package messages

import (
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
)

func TestProfileToParticipant(t *testing.T) {
	displayName := " Alice "
	avatar := "https://example.com/a.png"
	profile := models.Profile{ID: uuid.New(), Username: "alice", DisplayName: &displayName, AvatarURL: &avatar}

	got := profileToParticipant(profile)
	if got.ID != profile.ID || got.Username != "alice" || got.DisplayName != displayName || got.AvatarURL != &avatar {
		t.Fatalf("profileToParticipant() = %+v, want mapped profile", got)
	}

	blank := " "
	profile.DisplayName = &blank
	got = profileToParticipant(profile)
	if got.DisplayName != "alice" {
		t.Fatalf("profileToParticipant(blank) displayName = %q, want username", got.DisplayName)
	}
}

// TestRetentionDuration couvre tous les cas du switch retentionDuration,
// dont plusieurs (2h, 3h, 7d, 30d) n'etaient pas atteints par les tests existants.
func TestRetentionDuration(t *testing.T) {
	cases := []struct {
		retention string
		wantDur   time.Duration
		wantOk    bool
	}{
		{"1h", time.Hour, true},
		{"7d", 7 * 24 * time.Hour, true},
		{"30d", 30 * 24 * time.Hour, true},
		{"forever", 0, false},
		{"unknown", 0, false},
		{"", 0, false},
	}

	for _, tc := range cases {
		t.Run(tc.retention, func(t *testing.T) {
			dur, ok := retentionDuration(tc.retention)
			if ok != tc.wantOk {
				t.Fatalf("retentionDuration(%q) ok = %v, want %v", tc.retention, ok, tc.wantOk)
			}
			if ok && dur != tc.wantDur {
				t.Fatalf("retentionDuration(%q) = %v, want %v", tc.retention, dur, tc.wantDur)
			}
		})
	}
}

// TestValidRetention couvre validRetention pour les valeurs bornees, "forever" et invalide.
func TestValidRetention(t *testing.T) {
	if !validRetention("1h") {
		t.Fatal("validRetention(1h) should be true")
	}
	if !validRetention("forever") {
		t.Fatal("validRetention(forever) should be true")
	}
	if validRetention("never") {
		t.Fatal("validRetention(never) should be false")
	}
}
