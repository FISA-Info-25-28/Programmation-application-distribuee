package messages

import (
	"context"
	"errors"
	"strings"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type fakeMessagesRepo struct {
	current        models.Profile
	target         models.Profile
	other          models.Profile
	conversationID uuid.UUID
	message        models.PrivateMessage
	reply          models.PrivateMessage
	retention      string
	noLastMessage  bool

	// Champs d'injection d'erreur : quand non-nil, la methode correspondante
	// renvoie cette erreur au lieu de son comportement normal. Permettent de
	// driver les branches de propagation d'erreur du service sans base reelle.
	errFindProfileByAccountID  error
	errFindProfileByUsername   error
	errFindProfileByID         error
	errConversationIDs         error
	errOtherMember             error
	errMember                  error
	errFindConversationBetween error
	errCreateConversation      error
	errLastMessage             error
	errCountUnread             error
	errMessages                error
	errFindMessagesByIDs       error
	errCreateMessage           error
	errFindMessageByID         error
	errUpdateMessageContent    error
	errMarkMessageDeleted      error
	errMarkRead                error
	errRetention               error
	errSaveRetention           error
	errCountTotalUnread        error
	errCountLikesByMessageIDs  error
	errFindLikedMessageIDs     error
	errReactionsByMessageIDs   error
	errSetReaction             error
	errDeleteLike              error
}

func newFakeMessagesRepo() *fakeMessagesRepo {
	now := time.Now().UTC().Add(-time.Minute)
	current := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "alice"}
	targetName := "Bob"
	target := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "bob", DisplayName: &targetName}
	conversationID := uuid.New()
	reply := models.PrivateMessage{
		ID:             uuid.New(),
		ConversationID: conversationID,
		SenderID:       target.ID,
		Content:        "original",
		CreatedAt:      now,
	}
	message := models.PrivateMessage{
		ID:             uuid.New(),
		ConversationID: conversationID,
		SenderID:       current.ID,
		Content:        "hello",
		ReplyToID:      &reply.ID,
		CreatedAt:      now.Add(time.Second),
	}
	return &fakeMessagesRepo{
		current:        current,
		target:         target,
		other:          target,
		conversationID: conversationID,
		message:        message,
		reply:          reply,
		retention:      "forever",
	}
}

func (r *fakeMessagesRepo) FindProfileByAccountID(context.Context, uuid.UUID) (models.Profile, error) {
	if r.errFindProfileByAccountID != nil {
		return models.Profile{}, r.errFindProfileByAccountID
	}
	return r.current, nil
}

func (r *fakeMessagesRepo) FindProfileByUsername(_ context.Context, username string) (models.Profile, error) {
	if r.errFindProfileByUsername != nil {
		return models.Profile{}, r.errFindProfileByUsername
	}
	if username == r.current.Username {
		return r.current, nil
	}
	return r.target, nil
}

func (r *fakeMessagesRepo) FindProfileByID(_ context.Context, id uuid.UUID) (models.Profile, error) {
	if r.errFindProfileByID != nil {
		return models.Profile{}, r.errFindProfileByID
	}
	if id == r.current.ID {
		return r.current, nil
	}
	return r.other, nil
}

func (r *fakeMessagesRepo) ConversationIDsForProfile(context.Context, uuid.UUID) ([]uuid.UUID, error) {
	if r.errConversationIDs != nil {
		return nil, r.errConversationIDs
	}
	return []uuid.UUID{r.conversationID}, nil
}

func (r *fakeMessagesRepo) OtherMember(context.Context, uuid.UUID, uuid.UUID) (models.ConversationMember, error) {
	if r.errOtherMember != nil {
		return models.ConversationMember{}, r.errOtherMember
	}
	lastRead := time.Now().UTC()
	return models.ConversationMember{ConversationID: r.conversationID, ProfileID: r.other.ID, LastReadAt: &lastRead}, nil
}

func (r *fakeMessagesRepo) Member(context.Context, uuid.UUID, uuid.UUID) (models.ConversationMember, error) {
	if r.errMember != nil {
		return models.ConversationMember{}, r.errMember
	}
	return models.ConversationMember{ConversationID: r.conversationID, ProfileID: r.current.ID}, nil
}

func (r *fakeMessagesRepo) FindConversationBetween(context.Context, uuid.UUID, uuid.UUID) (uuid.UUID, error) {
	if r.errFindConversationBetween != nil {
		return uuid.Nil, r.errFindConversationBetween
	}
	return uuid.Nil, gorm.ErrRecordNotFound
}

func (r *fakeMessagesRepo) CreateConversation(context.Context, uuid.UUID, uuid.UUID) (uuid.UUID, error) {
	if r.errCreateConversation != nil {
		return uuid.Nil, r.errCreateConversation
	}
	return r.conversationID, nil
}

func (r *fakeMessagesRepo) LastMessage(context.Context, uuid.UUID, *time.Time) (models.PrivateMessage, error) {
	if r.errLastMessage != nil {
		return models.PrivateMessage{}, r.errLastMessage
	}
	if r.noLastMessage {
		return models.PrivateMessage{}, gorm.ErrRecordNotFound
	}
	return r.message, nil
}

func (r *fakeMessagesRepo) CountUnread(context.Context, uuid.UUID, uuid.UUID, *time.Time, *time.Time) (int64, error) {
	if r.errCountUnread != nil {
		return 0, r.errCountUnread
	}
	return 2, nil
}

func (r *fakeMessagesRepo) Messages(context.Context, uuid.UUID, *time.Time) ([]models.PrivateMessage, error) {
	if r.errMessages != nil {
		return nil, r.errMessages
	}
	return []models.PrivateMessage{r.reply, r.message}, nil
}

func (r *fakeMessagesRepo) FindMessagesByIDs(_ context.Context, ids []uuid.UUID) (map[uuid.UUID]models.PrivateMessage, error) {
	if r.errFindMessagesByIDs != nil {
		return nil, r.errFindMessagesByIDs
	}
	messages := map[uuid.UUID]models.PrivateMessage{}
	for _, id := range ids {
		if id == r.reply.ID {
			messages[id] = r.reply
		}
	}
	return messages, nil
}

func (r *fakeMessagesRepo) CreateMessage(_ context.Context, message *models.PrivateMessage) error {
	if r.errCreateMessage != nil {
		return r.errCreateMessage
	}
	message.ID = uuid.New()
	message.CreatedAt = time.Now().UTC()
	r.message = *message
	return nil
}

func (r *fakeMessagesRepo) FindMessageByID(_ context.Context, id uuid.UUID) (models.PrivateMessage, error) {
	if r.errFindMessageByID != nil {
		return models.PrivateMessage{}, r.errFindMessageByID
	}
	if id == r.reply.ID {
		return r.reply, nil
	}
	if id != r.message.ID {
		return models.PrivateMessage{ID: id, ConversationID: uuid.New(), SenderID: r.other.ID, Content: "elsewhere"}, nil
	}
	return r.message, nil
}

func (r *fakeMessagesRepo) UpdateMessageContent(_ context.Context, _ uuid.UUID, content string, _ string, editedAt time.Time) (models.PrivateMessage, error) {
	if r.errUpdateMessageContent != nil {
		return models.PrivateMessage{}, r.errUpdateMessageContent
	}
	r.message.Content = content
	r.message.EditedAt = &editedAt
	return r.message, nil
}

func (r *fakeMessagesRepo) MarkMessageDeleted(_ context.Context, _ uuid.UUID, deletedAt time.Time) (models.PrivateMessage, error) {
	if r.errMarkMessageDeleted != nil {
		return models.PrivateMessage{}, r.errMarkMessageDeleted
	}
	r.message.Content = ""
	r.message.DeletedAt = &deletedAt
	return r.message, nil
}

func (r *fakeMessagesRepo) MarkRead(context.Context, uuid.UUID, uuid.UUID, time.Time) error {
	if r.errMarkRead != nil {
		return r.errMarkRead
	}
	return nil
}

func (r *fakeMessagesRepo) Retention(context.Context, uuid.UUID) (string, error) {
	if r.errRetention != nil {
		return "", r.errRetention
	}
	if r.retention == "" {
		return "", gorm.ErrRecordNotFound
	}
	return r.retention, nil
}

func (r *fakeMessagesRepo) SaveRetention(_ context.Context, _ uuid.UUID, retention string) error {
	if r.errSaveRetention != nil {
		return r.errSaveRetention
	}
	r.retention = retention
	return nil
}

func (r *fakeMessagesRepo) CountTotalUnread(context.Context, uuid.UUID) (int64, error) {
	if r.errCountTotalUnread != nil {
		return 0, r.errCountTotalUnread
	}
	return 5, nil
}

func (r *fakeMessagesRepo) CountLikesByMessageIDs(context.Context, []uuid.UUID) (map[uuid.UUID]int64, error) {
	if r.errCountLikesByMessageIDs != nil {
		return nil, r.errCountLikesByMessageIDs
	}
	return map[uuid.UUID]int64{r.message.ID: 3}, nil
}

func (r *fakeMessagesRepo) FindLikedMessageIDs(context.Context, uuid.UUID, []uuid.UUID) (map[uuid.UUID]bool, error) {
	if r.errFindLikedMessageIDs != nil {
		return nil, r.errFindLikedMessageIDs
	}
	return map[uuid.UUID]bool{r.message.ID: true}, nil
}

func (r *fakeMessagesRepo) ReactionsByMessageIDs(context.Context, uuid.UUID, []uuid.UUID) (map[uuid.UUID][]messageReactionResponse, error) {
	if r.errReactionsByMessageIDs != nil {
		return nil, r.errReactionsByMessageIDs
	}
	return map[uuid.UUID][]messageReactionResponse{
		r.message.ID: {{Type: "HEART", Count: 3, ReactedByMe: true}},
	}, nil
}

func (r *fakeMessagesRepo) SetReaction(context.Context, models.MessageLike) error {
	if r.errSetReaction != nil {
		return r.errSetReaction
	}
	return nil
}

func (r *fakeMessagesRepo) DeleteLike(context.Context, uuid.UUID, uuid.UUID) error {
	if r.errDeleteLike != nil {
		return r.errDeleteLike
	}
	return nil
}

func TestMessagesServiceWithMockedRepository(t *testing.T) {
	ctx := context.Background()
	repo := newFakeMessagesRepo()
	service := NewService(repo)
	accountID := repo.current.AccountID

	conversations, err := service.ListConversations(ctx, accountID)
	if err != nil || len(conversations) != 1 || conversations[0].UnreadCount != 2 {
		t.Fatalf("ListConversations() = %+v, %v", conversations, err)
	}

	created, err := service.CreateConversation(ctx, accountID, " bob ")
	if err != nil || created.ID != repo.conversationID {
		t.Fatalf("CreateConversation() = %+v, %v", created, err)
	}

	messages, err := service.Messages(ctx, accountID, repo.conversationID)
	if err != nil || len(messages) != 2 || messages[1].ReplyTo == nil {
		t.Fatalf("Messages() = %+v, %v", messages, err)
	}

	sent, err := service.SendMessage(ctx, accountID, repo.conversationID, " hi ", "", "", nil, nil, &repo.reply.ID)
	if err != nil || sent.Content != "hi" {
		t.Fatalf("SendMessage() = %+v, %v", sent, err)
	}

	updated, err := service.UpdateMessage(ctx, accountID, repo.message.ID, " edited ", "")
	if err != nil || updated.Content != "edited" || updated.EditedAt == nil {
		t.Fatalf("UpdateMessage() = %+v, %v", updated, err)
	}

	deleted, err := service.DeleteMessage(ctx, accountID, repo.message.ID)
	if err != nil || deleted.DeletedAt == nil {
		t.Fatalf("DeleteMessage() = %+v, %v", deleted, err)
	}

	repo.message.DeletedAt = nil
	repo.message.SenderID = repo.other.ID
	reacted, err := service.ReactToMessage(ctx, accountID, repo.message.ID, "THUMBS_UP")
	if err != nil || reacted.ID != repo.message.ID {
		t.Fatalf("ReactToMessage() = %+v, %v", reacted, err)
	}
	if _, err := service.UnlikeMessage(ctx, accountID, repo.message.ID); err != nil {
		t.Fatalf("UnlikeMessage() error = %v", err)
	}

	count, err := service.TotalUnreadCount(ctx, accountID)
	if err != nil || count != 5 {
		t.Fatalf("TotalUnreadCount() = %d, %v", count, err)
	}
	if got, err := service.GetRetention(ctx, accountID); err != nil || got != "forever" {
		t.Fatalf("GetRetention() = %q, %v", got, err)
	}
	if got, err := service.SetRetention(ctx, accountID, "7d"); err != nil || got != "7d" {
		t.Fatalf("SetRetention() = %q, %v", got, err)
	}
}

func TestMessagesServiceMockedBusinessErrors(t *testing.T) {
	ctx := context.Background()
	repo := newFakeMessagesRepo()
	service := NewService(repo)
	accountID := repo.current.AccountID

	if _, err := service.CreateConversation(ctx, accountID, repo.current.Username); !errors.Is(err, ErrConversationWithSelf) {
		t.Fatalf("CreateConversation(self) error = %v", err)
	}

	otherConversation := uuid.New()
	if _, err := service.SendMessage(ctx, accountID, repo.conversationID, "reply", "", "", nil, nil, &otherConversation); !errors.Is(err, ErrInvalidMessage) {
		t.Fatalf("SendMessage(wrong reply) error = %v", err)
	}

	repo.message.SenderID = repo.other.ID
	if _, err := service.UpdateMessage(ctx, accountID, repo.message.ID, "edited", ""); !errors.Is(err, ErrForbiddenMessage) {
		t.Fatalf("UpdateMessage(foreign) error = %v", err)
	}

	repo.message.SenderID = repo.current.ID
	now := time.Now().UTC()
	repo.message.DeletedAt = &now
	if _, err := service.UpdateMessage(ctx, accountID, repo.message.ID, "edited", ""); !errors.Is(err, ErrDeletedMessage) {
		t.Fatalf("UpdateMessage(deleted) error = %v", err)
	}

	repo.message.DeletedAt = nil
	repo.message.Kind = "SHARED_POST"
	if _, err := service.UpdateMessage(ctx, accountID, repo.message.ID, "edited", ""); !errors.Is(err, ErrSharedPostMessage) {
		t.Fatalf("UpdateMessage(shared post) error = %v", err)
	}

	repo.message.Content = "hello"
	repo.message.SenderID = repo.other.ID
	if _, err := service.ReactToMessage(ctx, accountID, repo.message.ID, "WOW"); !errors.Is(err, ErrInvalidMessage) {
		t.Fatalf("ReactToMessage(invalid) error = %v", err)
	}

	if _, err := service.SetRetention(ctx, accountID, "never"); !errors.Is(err, ErrInvalidRetention) {
		t.Fatalf("SetRetention(invalid) error = %v", err)
	}
}

func TestMessagesServiceListConversationLastMessageVariants(t *testing.T) {
	ctx := context.Background()

	t.Run("record not found returns empty preview", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.noLastMessage = true
		got, err := NewService(repo).ListConversations(ctx, repo.current.AccountID)
		if err != nil || len(got) != 1 || got[0].LastMessage != "" {
			t.Fatalf("ListConversations() = %+v, %v", got, err)
		}
	})

	t.Run("deleted message preview", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		deletedAt := time.Now().UTC()
		repo.message.DeletedAt = &deletedAt
		got, err := NewService(repo).ListConversations(ctx, repo.current.AccountID)
		if err != nil || !strings.Contains(got[0].LastMessage, "supprim") {
			t.Fatalf("ListConversations() = %+v, %v", got, err)
		}
	})

	t.Run("media previews", func(t *testing.T) {
		for mediaType, want := range map[string]string{"VIDEO": "Video", "IMAGE": "Image ou GIF"} {
			repo := newFakeMessagesRepo()
			repo.message.Content = " "
			repo.message.MediaType = &mediaType
			got, err := NewService(repo).ListConversations(ctx, repo.current.AccountID)
			if err != nil || got[0].LastMessage != want {
				t.Fatalf("ListConversations(%s) = %+v, %v", mediaType, got, err)
			}
		}
	})
}

func TestMessagesServiceRetentionAndMediaVariants(t *testing.T) {
	ctx := context.Background()
	repo := newFakeMessagesRepo()
	service := NewService(repo)

	repo.retention = ""
	if got, err := service.GetRetention(ctx, repo.current.AccountID); err != nil || got != "forever" {
		t.Fatalf("GetRetention(missing) = %q, %v", got, err)
	}
	if since, err := service.retentionSince(ctx, repo.current.ID); err != nil || since != nil {
		t.Fatalf("retentionSince(missing) = %v, %v", since, err)
	}

	repo.retention = "1h"
	if since, err := service.retentionSince(ctx, repo.current.ID); err != nil || since == nil {
		t.Fatalf("retentionSince(1h) = %v, %v", since, err)
	}

	imageURL := " /api/media/files/image.png "
	imageType := " image "
	normalizedURL, normalizedType, err := normalizeMessageMedia(&imageURL, &imageType)
	if err != nil || *normalizedURL != "/api/media/files/image.png" || *normalizedType != "IMAGE" {
		t.Fatalf("normalizeMessageMedia() = %v/%v/%v", normalizedURL, normalizedType, err)
	}

	invalidURL := "/tmp/image.png"
	if _, _, err := normalizeMessageMedia(&invalidURL, &imageType); !errors.Is(err, ErrInvalidMessage) {
		t.Fatalf("normalizeMessageMedia(invalid url) error = %v", err)
	}
	if _, _, err := normalizeMessageMedia(&imageURL, nil); !errors.Is(err, ErrInvalidMessage) {
		t.Fatalf("normalizeMessageMedia(missing type) error = %v", err)
	}
}

// TestMessagesServiceRepositoryErrorPropagation pousse chaque appel de
// repository en erreur tour a tour pour couvrir les branches "return nil, err"
// de chaque methode du service, sans avoir besoin d'une vraie base.
func TestMessagesServiceRepositoryErrorPropagation(t *testing.T) {
	ctx := context.Background()
	boom := errors.New("boom")

	t.Run("ListConversations", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errRetention = boom
		if _, err := NewService(repo).ListConversations(ctx, repo.current.AccountID); err == nil {
			t.Fatal("ListConversations() expected error when retention lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errConversationIDs = boom
		if _, err := NewService(repo).ListConversations(ctx, repo.current.AccountID); err == nil {
			t.Fatal("ListConversations() expected error when conversation ids lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errMember = boom
		if _, err := NewService(repo).ListConversations(ctx, repo.current.AccountID); err == nil {
			t.Fatal("ListConversations() expected error when member lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errOtherMember = boom
		if _, err := NewService(repo).ListConversations(ctx, repo.current.AccountID); err == nil {
			t.Fatal("ListConversations() expected error when other member lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errFindProfileByID = boom
		if _, err := NewService(repo).ListConversations(ctx, repo.current.AccountID); err == nil {
			t.Fatal("ListConversations() expected error when other profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errLastMessage = boom
		if _, err := NewService(repo).ListConversations(ctx, repo.current.AccountID); err == nil {
			t.Fatal("ListConversations() expected error when last message lookup fails (non not-found)")
		}

		repo = newFakeMessagesRepo()
		repo.errCountUnread = boom
		if _, err := NewService(repo).ListConversations(ctx, repo.current.AccountID); err == nil {
			t.Fatal("ListConversations() expected error when unread count fails")
		}

		repo = newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).ListConversations(ctx, repo.current.AccountID); err == nil {
			t.Fatal("ListConversations() expected error when current profile lookup fails")
		}
	})

	t.Run("CreateConversation", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).CreateConversation(ctx, repo.current.AccountID, "bob"); err == nil {
			t.Fatal("CreateConversation() expected error when current profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errFindProfileByUsername = boom
		if _, err := NewService(repo).CreateConversation(ctx, repo.current.AccountID, "bob"); err == nil {
			t.Fatal("CreateConversation() expected error when target profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errFindConversationBetween = boom
		if _, err := NewService(repo).CreateConversation(ctx, repo.current.AccountID, "bob"); err == nil {
			t.Fatal("CreateConversation() expected error when conversation lookup fails (non not-found)")
		}

		repo = newFakeMessagesRepo()
		repo.errCreateConversation = boom
		if _, err := NewService(repo).CreateConversation(ctx, repo.current.AccountID, "bob"); err == nil {
			t.Fatal("CreateConversation() expected error when conversation creation fails")
		}
	})

	t.Run("Messages", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).Messages(ctx, repo.current.AccountID, repo.conversationID); err == nil {
			t.Fatal("Messages() expected error when current profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errMember = boom
		if _, err := NewService(repo).Messages(ctx, repo.current.AccountID, repo.conversationID); err == nil {
			t.Fatal("Messages() expected error when member lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errOtherMember = boom
		if _, err := NewService(repo).Messages(ctx, repo.current.AccountID, repo.conversationID); err == nil {
			t.Fatal("Messages() expected error when other member lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errRetention = boom
		if _, err := NewService(repo).Messages(ctx, repo.current.AccountID, repo.conversationID); err == nil {
			t.Fatal("Messages() expected error when retention lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errMessages = boom
		if _, err := NewService(repo).Messages(ctx, repo.current.AccountID, repo.conversationID); err == nil {
			t.Fatal("Messages() expected error when messages lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errMarkRead = boom
		if _, err := NewService(repo).Messages(ctx, repo.current.AccountID, repo.conversationID); err == nil {
			t.Fatal("Messages() expected error when mark read fails")
		}
	})

	t.Run("SendMessage", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).SendMessage(ctx, repo.current.AccountID, repo.conversationID, "hi", "", "", nil, nil, nil); err == nil {
			t.Fatal("SendMessage() expected error when current profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errFindMessageByID = boom
		if _, err := NewService(repo).SendMessage(ctx, repo.current.AccountID, repo.conversationID, "hi", "", "", nil, nil, &repo.reply.ID); err == nil {
			t.Fatal("SendMessage() expected error when reply lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errMember = boom
		if _, err := NewService(repo).SendMessage(ctx, repo.current.AccountID, repo.conversationID, "hi", "", "", nil, nil, nil); err == nil {
			t.Fatal("SendMessage() expected error when member lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errOtherMember = boom
		if _, err := NewService(repo).SendMessage(ctx, repo.current.AccountID, repo.conversationID, "hi", "", "", nil, nil, nil); err == nil {
			t.Fatal("SendMessage() expected error when other member lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errCreateMessage = boom
		if _, err := NewService(repo).SendMessage(ctx, repo.current.AccountID, repo.conversationID, "hi", "", "", nil, nil, nil); err == nil {
			t.Fatal("SendMessage() expected error when create message fails")
		}

		repo = newFakeMessagesRepo()
		repo.errCountLikesByMessageIDs = boom
		if _, err := NewService(repo).SendMessage(ctx, repo.current.AccountID, repo.conversationID, "hi", "", "", nil, nil, nil); err == nil {
			t.Fatal("SendMessage() expected error when messagesToResponses fails")
		}
	})

	t.Run("UpdateMessage", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).UpdateMessage(ctx, repo.current.AccountID, repo.message.ID, "edited", ""); err == nil {
			t.Fatal("UpdateMessage() expected error when current profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errFindMessageByID = boom
		if _, err := NewService(repo).UpdateMessage(ctx, repo.current.AccountID, repo.message.ID, "edited", ""); err == nil {
			t.Fatal("UpdateMessage() expected error when message lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errOtherMember = boom
		if _, err := NewService(repo).UpdateMessage(ctx, repo.current.AccountID, repo.message.ID, "edited", ""); err == nil {
			t.Fatal("UpdateMessage() expected error when other member lookup fails")
		}

		repo = newFakeMessagesRepo()
		if _, err := NewService(repo).UpdateMessage(ctx, repo.current.AccountID, repo.message.ID, "   ", ""); !errors.Is(err, ErrInvalidMessage) {
			t.Fatalf("UpdateMessage(blank) error = %v, want ErrInvalidMessage", err)
		}

		repo = newFakeMessagesRepo()
		repo.errUpdateMessageContent = boom
		if _, err := NewService(repo).UpdateMessage(ctx, repo.current.AccountID, repo.message.ID, "edited", ""); err == nil {
			t.Fatal("UpdateMessage() expected error when content update fails")
		}

		repo = newFakeMessagesRepo()
		repo.errCountLikesByMessageIDs = boom
		if _, err := NewService(repo).UpdateMessage(ctx, repo.current.AccountID, repo.message.ID, "edited", ""); err == nil {
			t.Fatal("UpdateMessage() expected error when messagesToResponses fails")
		}
	})

	t.Run("DeleteMessage", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).DeleteMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("DeleteMessage() expected error when current profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errFindMessageByID = boom
		if _, err := NewService(repo).DeleteMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("DeleteMessage() expected error when message lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.message.SenderID = repo.other.ID
		if _, err := NewService(repo).DeleteMessage(ctx, repo.current.AccountID, repo.message.ID); !errors.Is(err, ErrForbiddenMessage) {
			t.Fatalf("DeleteMessage(foreign) error = %v, want ErrForbiddenMessage", err)
		}

		repo = newFakeMessagesRepo()
		deletedAt := time.Now().UTC()
		repo.message.DeletedAt = &deletedAt
		if _, err := NewService(repo).DeleteMessage(ctx, repo.current.AccountID, repo.message.ID); !errors.Is(err, ErrDeletedMessage) {
			t.Fatalf("DeleteMessage(already deleted) error = %v, want ErrDeletedMessage", err)
		}

		repo = newFakeMessagesRepo()
		repo.errOtherMember = boom
		if _, err := NewService(repo).DeleteMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("DeleteMessage() expected error when other member lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errMarkMessageDeleted = boom
		if _, err := NewService(repo).DeleteMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("DeleteMessage() expected error when MarkMessageDeleted fails")
		}

		repo = newFakeMessagesRepo()
		repo.errCountLikesByMessageIDs = boom
		if _, err := NewService(repo).DeleteMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("DeleteMessage() expected error when messagesToResponses fails")
		}
	})

	t.Run("ReactToMessage", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).ReactToMessage(ctx, repo.current.AccountID, repo.message.ID, "HEART"); err == nil {
			t.Fatal("ReactToMessage() expected error when current profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errFindMessageByID = boom
		if _, err := NewService(repo).ReactToMessage(ctx, repo.current.AccountID, repo.message.ID, "HEART"); err == nil {
			t.Fatal("ReactToMessage() expected error when message lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errMember = boom
		if _, err := NewService(repo).ReactToMessage(ctx, repo.current.AccountID, repo.message.ID, "HEART"); err == nil {
			t.Fatal("ReactToMessage() expected error when member lookup fails")
		}

		repo = newFakeMessagesRepo()
		deletedAt := time.Now().UTC()
		repo.message.DeletedAt = &deletedAt
		if _, err := NewService(repo).ReactToMessage(ctx, repo.current.AccountID, repo.message.ID, "HEART"); !errors.Is(err, ErrDeletedMessage) {
			t.Fatalf("ReactToMessage(deleted) error = %v, want ErrDeletedMessage", err)
		}

		repo = newFakeMessagesRepo()
		repo.errSetReaction = boom
		repo.message.SenderID = repo.other.ID
		if _, err := NewService(repo).ReactToMessage(ctx, repo.current.AccountID, repo.message.ID, "HEART"); err == nil {
			t.Fatal("ReactToMessage() expected error when SetReaction fails")
		}

		repo = newFakeMessagesRepo()
		repo.errOtherMember = boom
		repo.message.SenderID = repo.other.ID
		if _, err := NewService(repo).ReactToMessage(ctx, repo.current.AccountID, repo.message.ID, "HEART"); err == nil {
			t.Fatal("ReactToMessage() expected error when other member lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errCountLikesByMessageIDs = boom
		repo.message.SenderID = repo.other.ID
		if _, err := NewService(repo).ReactToMessage(ctx, repo.current.AccountID, repo.message.ID, "HEART"); err == nil {
			t.Fatal("ReactToMessage() expected error when messagesToResponses fails")
		}
	})

	t.Run("UnlikeMessage", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).UnlikeMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("UnlikeMessage() expected error when current profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errFindMessageByID = boom
		if _, err := NewService(repo).UnlikeMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("UnlikeMessage() expected error when message lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errMember = boom
		if _, err := NewService(repo).UnlikeMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("UnlikeMessage() expected error when member lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errDeleteLike = boom
		if _, err := NewService(repo).UnlikeMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("UnlikeMessage() expected error when DeleteLike fails")
		}

		repo = newFakeMessagesRepo()
		repo.errOtherMember = boom
		if _, err := NewService(repo).UnlikeMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("UnlikeMessage() expected error when other member lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errCountLikesByMessageIDs = boom
		if _, err := NewService(repo).UnlikeMessage(ctx, repo.current.AccountID, repo.message.ID); err == nil {
			t.Fatal("UnlikeMessage() expected error when messagesToResponses fails")
		}
	})

	t.Run("messagesToResponses each repo call", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindLikedMessageIDs = boom
		if _, err := NewService(repo).Messages(ctx, repo.current.AccountID, repo.conversationID); err == nil {
			t.Fatal("Messages() expected error when FindLikedMessageIDs fails")
		}

		repo = newFakeMessagesRepo()
		repo.errReactionsByMessageIDs = boom
		if _, err := NewService(repo).Messages(ctx, repo.current.AccountID, repo.conversationID); err == nil {
			t.Fatal("Messages() expected error when ReactionsByMessageIDs fails")
		}

		repo = newFakeMessagesRepo()
		repo.errFindMessagesByIDs = boom
		if _, err := NewService(repo).Messages(ctx, repo.current.AccountID, repo.conversationID); err == nil {
			t.Fatal("Messages() expected error when FindMessagesByIDs fails")
		}
	})

	t.Run("retentionSince propagates non not-found errors", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errRetention = boom
		if _, err := NewService(repo).retentionSince(ctx, repo.current.ID); err == nil {
			t.Fatal("retentionSince() expected error when retention lookup fails")
		}
	})

	t.Run("retentionDuration unknown value", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.retention = "unknown"
		since, err := NewService(repo).retentionSince(ctx, repo.current.ID)
		if err != nil || since != nil {
			t.Fatalf("retentionSince(unknown retention) = %v, %v, want nil, nil", since, err)
		}
	})

	t.Run("SetRetention propagates profile lookup error", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).SetRetention(ctx, repo.current.AccountID, "1h"); err == nil {
			t.Fatal("SetRetention() expected error when current profile lookup fails")
		}
	})

	t.Run("SetRetention propagates save error", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errSaveRetention = boom
		if _, err := NewService(repo).SetRetention(ctx, repo.current.AccountID, "1h"); err == nil {
			t.Fatal("SetRetention() expected error when SaveRetention fails")
		}
	})

	t.Run("TotalUnreadCount propagates errors", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).TotalUnreadCount(ctx, repo.current.AccountID); err == nil {
			t.Fatal("TotalUnreadCount() expected error when current profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errCountTotalUnread = boom
		if _, err := NewService(repo).TotalUnreadCount(ctx, repo.current.AccountID); err == nil {
			t.Fatal("TotalUnreadCount() expected error when CountTotalUnread fails")
		}
	})

	t.Run("GetRetention propagates non not-found errors", func(t *testing.T) {
		repo := newFakeMessagesRepo()
		repo.errFindProfileByAccountID = boom
		if _, err := NewService(repo).GetRetention(ctx, repo.current.AccountID); err == nil {
			t.Fatal("GetRetention() expected error when current profile lookup fails")
		}

		repo = newFakeMessagesRepo()
		repo.errRetention = boom
		if _, err := NewService(repo).GetRetention(ctx, repo.current.AccountID); err == nil {
			t.Fatal("GetRetention() expected error when retention lookup fails")
		}
	})
}

func TestMessagesServiceMessageToResponseReplyDeletedContent(t *testing.T) {
	ctx := context.Background()
	repo := newFakeMessagesRepo()
	reply := repo.reply
	deletedAt := time.Now().UTC()
	reply.ID = uuid.New()
	repo.reply = reply

	service := NewService(repo)
	repo.message.ReplyToID = &reply.ID

	// Marquer la reponse comme supprimee dans le repo simule pour que
	// messageToResponse bascule le contenu vers "Message supprime".
	deletedReply := reply
	deletedReply.DeletedAt = &deletedAt
	originalFindMessagesByIDs := repo.reply
	repo.reply = deletedReply
	if _, err := service.Messages(ctx, repo.current.AccountID, repo.conversationID); err != nil {
		t.Fatalf("Messages() unexpected error: %v", err)
	}
	repo.reply = originalFindMessagesByIDs
}
