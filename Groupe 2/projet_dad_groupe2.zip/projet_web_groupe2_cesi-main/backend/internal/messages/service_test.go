package messages

import (
	"context"
	"testing"

	"github.com/google/uuid"
)

func TestMessagesServiceConstructorAndHelpers(t *testing.T) {
	service := NewService(nil)
	if service == nil || service.repo != nil {
		t.Fatalf("NewService(nil) = %+v, want service with nil repo", service)
	}

	if !validMessageReaction("HEART") || validMessageReaction("WOW") {
		t.Fatal("validMessageReaction() returned unexpected result")
	}
	if !validRetention("forever") || validRetention("bad") {
		t.Fatal("validRetention() returned unexpected result")
	}
	if duration, ok := retentionDuration("1h"); !ok || duration == 0 {
		t.Fatalf("retentionDuration(1h) = %v/%v, want positive/true", duration, ok)
	}
}

func TestMessagesServiceWorkflowsDryRun(t *testing.T) {
	service := NewService(NewRepository(messagesDryRunDB(t)))
	ctx := context.Background()
	accountID := uuid.New()
	conversationID := uuid.New()
	messageID := uuid.New()
	mediaURL := "/api/media/files/a.png"
	mediaType := "IMAGE"

	_, _ = service.ListConversations(ctx, accountID)
	_, _ = service.CreateConversation(ctx, accountID, "alice")
	_, _ = service.Messages(ctx, accountID, conversationID)
	_, _ = service.SendMessage(ctx, accountID, conversationID, "hello", "", "", nil, nil, nil)
	_, _ = service.SendMessage(ctx, accountID, conversationID, "", "", "", &mediaURL, &mediaType, nil)
	_, _ = service.UpdateMessage(ctx, accountID, messageID, "edited", "")
	_, _ = service.DeleteMessage(ctx, accountID, messageID)
	_, _ = service.LikeMessage(ctx, accountID, messageID)
	_, _ = service.ReactToMessage(ctx, accountID, messageID, "HEART")
	_, _ = service.UnlikeMessage(ctx, accountID, messageID)
	_, _ = service.TotalUnreadCount(ctx, accountID)
	_, _ = service.GetRetention(ctx, accountID)
	_, _ = service.SetRetention(ctx, accountID, "1h")
}
