package middleware

import (
	"context"
	"net/http"
	"strings"

	"breezy/backend/internal/security"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

const (
	// ContextAccountID est la cle utilisee pour stocker l'ID du compte dans Gin.
	ContextAccountID = "accountID"
	ContextRole      = "role"

	RoleUser      = "USER"
	RoleModerator = "MODERATOR"
	RoleAdmin     = "ADMIN"
)

type contextKey string

const requestAccountIDKey contextKey = "accountID"

// AuthRequired protege une route Gin.
// Entree : aucune entree directe.
// requete HTTP.
// Sortie : valeur retour de type gin.HandlerFunc.
// renvoie 401 si le Bearer token est absent/invalide.
func AuthRequired() gin.HandlerFunc {
	return func(c *gin.Context) {
		token := bearerToken(c.GetHeader("Authorization"))
		if token == "" {
			token = cookieToken(c)
		}
		if token == "" {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "missing bearer token"})
			return
		}

		claims, err := security.VerifyAccessToken(token)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid bearer token"})
			return
		}

		accountID, err := uuid.Parse(claims.Subject)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid bearer token"})
			return
		}

		c.Set(ContextAccountID, accountID)
		c.Set(ContextRole, claims.Role)
		c.Request = c.Request.WithContext(context.WithValue(c.Request.Context(), requestAccountIDKey, accountID))
		c.Next()
	}
}

// AuthOptional enrichit le contexte si un token valide est present, sans
// bloquer les routes publiques si le token est absent ou invalide.
// Entree : aucune entree directe.
// Sortie : valeur retour de type gin.HandlerFunc.
func AuthOptional() gin.HandlerFunc {
	return func(c *gin.Context) {
		token := bearerToken(c.GetHeader("Authorization"))
		if token == "" {
			token = cookieToken(c)
		}
		if token == "" {
			c.Next()
			return
		}

		claims, err := security.VerifyAccessToken(token)
		if err != nil {
			c.Next()
			return
		}

		accountID, err := uuid.Parse(claims.Subject)
		if err == nil {
			c.Set(ContextAccountID, accountID)
			c.Set(ContextRole, claims.Role)
			c.Request = c.Request.WithContext(context.WithValue(c.Request.Context(), requestAccountIDKey, accountID))
		}

		c.Next()
	}
}

func RequestAccountID(ctx context.Context) (uuid.UUID, bool) {
	accountID, ok := ctx.Value(requestAccountIDKey).(uuid.UUID)
	return accountID, ok
}

// AccountID recupere l'identifiant du compte courant.
// Entree : c.
// Sortie : valeurs retour de la fonction.
func AccountID(c *gin.Context) (uuid.UUID, bool) {
	value, exists := c.Get(ContextAccountID)
	if !exists {
		return uuid.Nil, false
	}

	accountID, ok := value.(uuid.UUID)
	return accountID, ok
}

// Role recupere le role du compte courant.
// Entree : c.
// Sortie : valeurs retour de la fonction.
func Role(c *gin.Context) (string, bool) {
	value, exists := c.Get(ContextRole)
	if !exists {
		return "", false
	}

	role, ok := value.(string)
	return role, ok
}

func RequireRole(requiredRole string) gin.HandlerFunc {
	return func(c *gin.Context) {
		role, ok := Role(c)
		if !ok || roleRank(role) < roleRank(requiredRole) {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "insufficient role"})
			return
		}

		c.Next()
	}
}

// bearerToken extrait un token Bearer.
// Entree : header.
// Sortie : valeur retour de type string.
func bearerToken(header string) string {
	fields := strings.Fields(header)
	if len(fields) != 2 || !strings.EqualFold(fields[0], "Bearer") {
		return ""
	}
	return fields[1]
}

func cookieToken(c *gin.Context) string {
	token, err := c.Cookie("breezy_access_token")
	if err != nil {
		return ""
	}
	return strings.TrimSpace(token)
}

func roleRank(role string) int {
	switch strings.ToUpper(role) {
	case RoleAdmin:
		return 3
	case RoleModerator:
		return 2
	case RoleUser:
		return 1
	default:
		return 0
	}
}
