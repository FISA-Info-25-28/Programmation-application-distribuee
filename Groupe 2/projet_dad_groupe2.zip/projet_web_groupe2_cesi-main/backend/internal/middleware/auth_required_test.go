package middleware

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"breezy/backend/internal/security"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

// forgeAccessToken construit un JWT HS256 valide (signature correcte avec le
// secret fourni) mais dont le Subject n'est pas un UUID, afin d'exercer la
// branche uuid.Parse(err != nil) de AuthOptional/AuthRequired.
func forgeAccessToken(t *testing.T, secret, subject, role string, expiresAt int64) string {
	t.Helper()

	header := map[string]string{"alg": "HS256", "typ": "JWT"}
	claims := map[string]any{"sub": subject, "role": role, "exp": expiresAt}

	headerJSON, err := json.Marshal(header)
	if err != nil {
		t.Fatal(err)
	}
	claimsJSON, err := json.Marshal(claims)
	if err != nil {
		t.Fatal(err)
	}

	signingInput := base64.RawURLEncoding.EncodeToString(headerJSON) + "." + base64.RawURLEncoding.EncodeToString(claimsJSON)
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(signingInput))
	signature := base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
	return signingInput + "." + signature
}

func TestAuthRequiredAcceptsBearerToken(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	accountID := uuid.New()
	token, err := security.SignAccessToken(accountID, RoleModerator, time.Hour)
	if err != nil {
		t.Fatalf("SignAccessToken() unexpected error: %v", err)
	}

	router := gin.New()
	router.Use(AuthRequired())
	router.GET("/me", func(c *gin.Context) {
		gotID, ok := AccountID(c)
		if !ok || gotID != accountID {
			t.Fatalf("AccountID() = %v/%v, want %v/true", gotID, ok, accountID)
		}
		gotCtxID, ok := RequestAccountID(c.Request.Context())
		if !ok || gotCtxID != accountID {
			t.Fatalf("RequestAccountID() = %v/%v, want %v/true", gotCtxID, ok, accountID)
		}
		gotRole, ok := Role(c)
		if !ok || gotRole != RoleModerator {
			t.Fatalf("Role() = %q/%v, want MODERATOR/true", gotRole, ok)
		}
		c.Status(http.StatusNoContent)
	})

	req := httptest.NewRequest(http.MethodGet, "/me", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusNoContent {
		t.Fatalf("status = %d, want 204", rec.Code)
	}
}

func TestAuthRequiredRejectsMissingToken(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(AuthRequired())
	router.GET("/me", func(c *gin.Context) { c.Status(http.StatusNoContent) })

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/me", nil))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status = %d, want 401", rec.Code)
	}
}

func TestAuthOptionalDoesNotBlockInvalidToken(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(AuthOptional())
	router.GET("/public", func(c *gin.Context) {
		if _, ok := AccountID(c); ok {
			t.Fatal("AccountID() should be absent for invalid optional token")
		}
		c.Status(http.StatusNoContent)
	})

	req := httptest.NewRequest(http.MethodGet, "/public", nil)
	req.Header.Set("Authorization", "Bearer invalid")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusNoContent {
		t.Fatalf("status = %d, want 204", rec.Code)
	}
}

func TestAuthOptionalSetsContextForValidToken(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	accountID := uuid.New()
	token, err := security.SignAccessToken(accountID, RoleUser, time.Hour)
	if err != nil {
		t.Fatalf("SignAccessToken() unexpected error: %v", err)
	}

	router := gin.New()
	router.Use(AuthOptional())
	router.GET("/public", func(c *gin.Context) {
		gotID, ok := AccountID(c)
		if !ok || gotID != accountID {
			t.Fatalf("AccountID() = %v/%v, want %v/true", gotID, ok, accountID)
		}
		gotRole, ok := Role(c)
		if !ok || gotRole != RoleUser {
			t.Fatalf("Role() = %q/%v, want USER/true", gotRole, ok)
		}
		if _, ok := RequestAccountID(c.Request.Context()); !ok {
			t.Fatal("RequestAccountID() should be set for valid optional token")
		}
		c.Status(http.StatusNoContent)
	})

	req := httptest.NewRequest(http.MethodGet, "/public", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusNoContent {
		t.Fatalf("status = %d, want 204", rec.Code)
	}
}

func TestAuthOptionalDoesNotBlockMissingToken(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(AuthOptional())
	router.GET("/public", func(c *gin.Context) {
		if _, ok := AccountID(c); ok {
			t.Fatal("AccountID() should be absent when no token is provided")
		}
		c.Status(http.StatusNoContent)
	})

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/public", nil))
	if rec.Code != http.StatusNoContent {
		t.Fatalf("status = %d, want 204", rec.Code)
	}
}

func TestAuthOptionalUsesCookieToken(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	accountID := uuid.New()
	token, err := security.SignAccessToken(accountID, RoleUser, time.Hour)
	if err != nil {
		t.Fatalf("SignAccessToken() unexpected error: %v", err)
	}

	router := gin.New()
	router.Use(AuthOptional())
	router.GET("/public", func(c *gin.Context) {
		gotID, ok := AccountID(c)
		if !ok || gotID != accountID {
			t.Fatalf("AccountID() = %v/%v, want %v/true", gotID, ok, accountID)
		}
		c.Status(http.StatusNoContent)
	})

	req := httptest.NewRequest(http.MethodGet, "/public", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_access_token", Value: token})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusNoContent {
		t.Fatalf("status = %d, want 204", rec.Code)
	}
}

func TestAuthOptionalIgnoresTokenWithNonUUIDSubject(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	token := forgeAccessToken(t, "test-secret", "not-a-uuid", RoleUser, time.Now().Add(time.Hour).Unix())

	router := gin.New()
	router.Use(AuthOptional())
	router.GET("/public", func(c *gin.Context) {
		if _, ok := AccountID(c); ok {
			t.Fatal("AccountID() should be absent when token subject is not a UUID")
		}
		c.Status(http.StatusNoContent)
	})

	req := httptest.NewRequest(http.MethodGet, "/public", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusNoContent {
		t.Fatalf("status = %d, want 204", rec.Code)
	}
}

func TestAuthRequiredRejectsTokenWithNonUUIDSubject(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	token := forgeAccessToken(t, "test-secret", "not-a-uuid", RoleUser, time.Now().Add(time.Hour).Unix())

	router := gin.New()
	router.Use(AuthRequired())
	router.GET("/me", func(c *gin.Context) { c.Status(http.StatusNoContent) })

	req := httptest.NewRequest(http.MethodGet, "/me", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status = %d, want 401", rec.Code)
	}
}

func TestAuthRequiredRejectsInvalidToken(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")

	router := gin.New()
	router.Use(AuthRequired())
	router.GET("/me", func(c *gin.Context) { c.Status(http.StatusNoContent) })

	req := httptest.NewRequest(http.MethodGet, "/me", nil)
	req.Header.Set("Authorization", "Bearer not.a.validtoken")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status = %d, want 401", rec.Code)
	}
}

func TestAuthRequiredUsesCookieToken(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	accountID := uuid.New()
	token, err := security.SignAccessToken(accountID, RoleUser, time.Hour)
	if err != nil {
		t.Fatalf("SignAccessToken() unexpected error: %v", err)
	}

	router := gin.New()
	router.Use(AuthRequired())
	router.GET("/me", func(c *gin.Context) {
		gotID, ok := AccountID(c)
		if !ok || gotID != accountID {
			t.Fatalf("AccountID() = %v/%v, want %v/true", gotID, ok, accountID)
		}
		c.Status(http.StatusNoContent)
	})

	req := httptest.NewRequest(http.MethodGet, "/me", nil)
	req.AddCookie(&http.Cookie{Name: "breezy_access_token", Value: token})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusNoContent {
		t.Fatalf("status = %d, want 204", rec.Code)
	}
}

func TestRequireRole(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(ContextRole, RoleUser)
		c.Next()
	})
	router.GET("/admin", RequireRole(RoleAdmin), func(c *gin.Context) { c.Status(http.StatusNoContent) })

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/admin", nil))
	if rec.Code != http.StatusForbidden {
		t.Fatalf("status = %d, want 403", rec.Code)
	}
}

func TestRoleHandlesMissingAndWrongType(t *testing.T) {
	gin.SetMode(gin.TestMode)

	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	if got, ok := Role(c); ok || got != "" {
		t.Fatalf("Role(missing) = %q/%v, want empty/false", got, ok)
	}

	c.Set(ContextRole, 42)
	if got, ok := Role(c); ok || got != "" {
		t.Fatalf("Role(wrong type) = %q/%v, want empty/false", got, ok)
	}

	if roleRank("UNKNOWN") != 0 {
		t.Fatal("roleRank(unknown) should return lowest rank")
	}
}

func TestBearerAndCookieToken(t *testing.T) {
	if got := bearerToken("bearer abc"); got != "abc" {
		t.Fatalf("bearerToken() = %q, want abc", got)
	}
	if got := bearerToken("Basic abc"); got != "" {
		t.Fatalf("bearerToken(Basic) = %q, want empty", got)
	}

	gin.SetMode(gin.TestMode)
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Request = httptest.NewRequest(http.MethodGet, "/", nil)
	c.Request.AddCookie(&http.Cookie{Name: "breezy_access_token", Value: " cookie-token "})
	if got := cookieToken(c); got != "cookie-token" {
		t.Fatalf("cookieToken() = %q, want cookie-token", got)
	}
}
