package middleware

import (
	"net/http"

	"breezy/backend/internal/config"
)

// CORS applique les headers Access-Control sur les reponses du gateway.
// Entree : next.
// Sortie : valeur retour de type http.Handler.
func CORS(next http.Handler) http.Handler {
	origin := config.Env("CORS_ORIGIN", "http://localhost:4200")
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", origin)
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
		w.Header().Set("Access-Control-Allow-Credentials", "true")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}
