package middleware

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestCORS(t *testing.T) {
	t.Setenv("CORS_ORIGIN", "http://frontend.test")
	nextCalled := false
	handler := CORS(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		nextCalled = true
		w.WriteHeader(http.StatusCreated)
	}))

	rec := httptest.NewRecorder()
	handler.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/", nil))
	if rec.Code != http.StatusCreated || !nextCalled {
		t.Fatalf("CORS GET status/called = %d/%v, want 201/true", rec.Code, nextCalled)
	}
	if got := rec.Header().Get("Access-Control-Allow-Origin"); got != "http://frontend.test" {
		t.Fatalf("Access-Control-Allow-Origin = %q, want configured origin", got)
	}

	nextCalled = false
	rec = httptest.NewRecorder()
	handler.ServeHTTP(rec, httptest.NewRequest(http.MethodOptions, "/", nil))
	if rec.Code != http.StatusNoContent || nextCalled {
		t.Fatalf("CORS OPTIONS status/called = %d/%v, want 204/false", rec.Code, nextCalled)
	}
}
