package middleware

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
)

func TestJSONBodyRejectsNonJSONPostBody(t *testing.T) {
	router := testJSONBodyRouter()
	request := httptest.NewRequest(http.MethodPost, "/known", strings.NewReader("hello"))
	request.Header.Set("Content-Type", "text/plain")

	response := httptest.NewRecorder()
	router.ServeHTTP(response, request)

	if response.Code != http.StatusUnsupportedMediaType {
		t.Fatalf("expected %d, got %d", http.StatusUnsupportedMediaType, response.Code)
	}
}

func TestJSONBodyRejectsTooLargeBody(t *testing.T) {
	router := testJSONBodyRouter()
	request := httptest.NewRequest(http.MethodPatch, "/known", strings.NewReader(strings.Repeat("a", int(maxJSONBodySize)+1)))
	request.Header.Set("Content-Type", "application/json")

	response := httptest.NewRecorder()
	router.ServeHTTP(response, request)

	if response.Code != http.StatusRequestEntityTooLarge {
		t.Fatalf("expected %d, got %d", http.StatusRequestEntityTooLarge, response.Code)
	}
}

func TestJSONBodyAllowsEmptyPostBody(t *testing.T) {
	router := testJSONBodyRouter()
	request := httptest.NewRequest(http.MethodPost, "/known", nil)

	response := httptest.NewRecorder()
	router.ServeHTTP(response, request)

	if response.Code != http.StatusNoContent {
		t.Fatalf("expected %d, got %d", http.StatusNoContent, response.Code)
	}
}

func TestJSONBodyAllowsValidJSONContentType(t *testing.T) {
	router := testJSONBodyRouter()
	request := httptest.NewRequest(http.MethodPost, "/known", strings.NewReader(`{"a":1}`))
	request.Header.Set("Content-Type", "application/json")

	response := httptest.NewRecorder()
	router.ServeHTTP(response, request)

	if response.Code != http.StatusNoContent {
		t.Fatalf("expected %d, got %d", http.StatusNoContent, response.Code)
	}
}

func TestJSONBodyAllowsJSONSuffixContentType(t *testing.T) {
	router := testJSONBodyRouter()
	request := httptest.NewRequest(http.MethodPatch, "/known", strings.NewReader(`{"a":1}`))
	request.Header.Set("Content-Type", "application/vnd.api+json")

	response := httptest.NewRecorder()
	router.ServeHTTP(response, request)

	if response.Code != http.StatusNoContent {
		t.Fatalf("expected %d, got %d", http.StatusNoContent, response.Code)
	}
}

func TestJSONBodyRejectsMalformedContentTypeHeader(t *testing.T) {
	router := testJSONBodyRouter()
	request := httptest.NewRequest(http.MethodPost, "/known", strings.NewReader(`{"a":1}`))
	request.Header.Set("Content-Type", ";;;not-a-media-type")

	response := httptest.NewRecorder()
	router.ServeHTTP(response, request)

	if response.Code != http.StatusUnsupportedMediaType {
		t.Fatalf("expected %d, got %d", http.StatusUnsupportedMediaType, response.Code)
	}
}

func TestJSONBodyIgnoresOtherMethods(t *testing.T) {
	router := testJSONBodyRouter()
	router.GET("/known", func(c *gin.Context) { c.Status(http.StatusNoContent) })

	request := httptest.NewRequest(http.MethodGet, "/known", nil)
	response := httptest.NewRecorder()
	router.ServeHTTP(response, request)

	if response.Code != http.StatusNoContent {
		t.Fatalf("expected %d, got %d", http.StatusNoContent, response.Code)
	}
}

func TestJSONBodyAllowsEmptyPatchBody(t *testing.T) {
	router := testJSONBodyRouter()
	request := httptest.NewRequest(http.MethodPatch, "/known", nil)

	response := httptest.NewRecorder()
	router.ServeHTTP(response, request)

	if response.Code != http.StatusNoContent {
		t.Fatalf("expected %d, got %d", http.StatusNoContent, response.Code)
	}
}

func testJSONBodyRouter() *gin.Engine {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(JSONBody())
	router.POST("/known", func(c *gin.Context) { c.Status(http.StatusNoContent) })
	router.PATCH("/known", func(c *gin.Context) { c.Status(http.StatusNoContent) })
	return router
}
