package middleware

import (
	"net"
	"net/http"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
)

// visitor suit la consommation de jetons d'une IP pour le rate limiting.
type visitor struct {
	tokens   float64
	lastSeen time.Time
}

// RateLimiter applique un algorithme de seau a jetons par IP, en memoire.
// Suffisant pour un POC mono-instance (pas de Redis/etat partage requis).
type RateLimiter struct {
	mu       sync.Mutex
	visitors map[string]*visitor
	rate     float64 // jetons regeneres par seconde
	burst    float64 // capacite maximale du seau
}

// NewRateLimiter construit un limiteur autorisant `burst` requetes immediates
// puis `maxRequests` requetes par `window` en regime permanent.
// Entree : maxRequests, window.
// Sortie : valeur retour de type *RateLimiter.
func NewRateLimiter(maxRequests int, window time.Duration) *RateLimiter {
	rl := &RateLimiter{
		visitors: make(map[string]*visitor),
		rate:     float64(maxRequests) / window.Seconds(),
		burst:    float64(maxRequests),
	}
	go rl.cleanupLoop()
	return rl
}

// allow consomme un jeton pour la cle donnee si possible.
// Entree : key.
// Sortie : valeur retour de type bool.
func (rl *RateLimiter) allow(key string) bool {
	rl.mu.Lock()
	defer rl.mu.Unlock()

	now := time.Now()
	v, ok := rl.visitors[key]
	if !ok {
		v = &visitor{tokens: rl.burst - 1, lastSeen: now}
		rl.visitors[key] = v
		return true
	}

	elapsed := now.Sub(v.lastSeen).Seconds()
	v.tokens += elapsed * rl.rate
	if v.tokens > rl.burst {
		v.tokens = rl.burst
	}
	v.lastSeen = now

	if v.tokens < 1 {
		return false
	}

	v.tokens--
	return true
}

// cleanupLoop purge periodiquement les IP inactives pour eviter une fuite memoire.
// Entree : aucune entree directe.
// Sortie : aucune valeur.
func (rl *RateLimiter) cleanupLoop() {
	for {
		time.Sleep(10 * time.Minute)
		rl.mu.Lock()
		cutoff := time.Now().Add(-10 * time.Minute)
		for key, v := range rl.visitors {
			if v.lastSeen.Before(cutoff) {
				delete(rl.visitors, key)
			}
		}
		rl.mu.Unlock()
	}
}

// Middleware retourne un gin.HandlerFunc qui bloque les requetes depassant la
// limite configuree, identifiees par IP source. Renvoie 429 en cas de depassement.
// Entree : aucune entree directe.
// Sortie : valeur retour de type gin.HandlerFunc.
func (rl *RateLimiter) Middleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		key := clientIP(c.Request)
		if !rl.allow(key) {
			c.AbortWithStatusJSON(http.StatusTooManyRequests, gin.H{"error": "too many requests, please retry later"})
			return
		}
		c.Next()
	}
}

// clientIP determine l'adresse IP source de la requete.
// La gateway est le point d'entree public unique (pas de reverse proxy en
// amont dans cette architecture POC), donc RemoteAddr n'est pas falsifiable
// par le client : on ne fait volontairement pas confiance a X-Forwarded-For.
// Entree : r.
// Sortie : valeur retour de type string.
func clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}
