package models

import (
	"time"

	"github.com/google/uuid"
)

// Account represente un compte applicatif utilise pour l'authentification.
// Entree principale en creation : email, passwordHash, role et status.
// Sortie/usage : modele GORM persiste dans le schema auth, avec ID et dates
// generes par PostgreSQL/GORM.
type Account struct {
	ID           uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	Email        string    `gorm:"uniqueIndex;not null"`
	PasswordHash string    `gorm:"not null"`
	Role         string    `gorm:"type:text;not null;default:'USER'"`
	Status       string    `gorm:"type:text;not null;default:'ACTIVE'"`
	// SuspendedUntil porte la date de fin d'une suspension temporaire. Nil pour un
	// compte actif ou banni definitivement. Une suspension expiree est levee
	// automatiquement a la prochaine connexion (voir auth.Service.reactivateIfExpired).
	SuspendedUntil  *time.Time
	EmailVerifiedAt *time.Time
	// LastLoginAt porte la date de la derniere connexion reussie (POST /auth/login).
	LastLoginAt *time.Time
	CreatedAt   time.Time
	UpdatedAt   time.Time
}

// Session represente une session longue duree basee sur un refresh token hash.
// Entree principale en creation : accountID, refreshTokenHash et expiresAt.
// Sortie/usage : permet de verifier, renouveler ou revoquer une session.
type Session struct {
	ID               uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	AccountID        uuid.UUID `gorm:"type:uuid;not null;index"`
	RefreshTokenHash string    `gorm:"not null"`
	ExpiresAt        time.Time `gorm:"not null"`
	RevokedAt        *time.Time
	CreatedAt        time.Time
}

// EmailVerificationToken stocke un jeton de verification d'e-mail sous forme
// hashee.
// Entree principale en creation : accountID, tokenHash et expiresAt.
// Sortie/usage : permet de verifier une adresse e-mail sans stocker le token
// brut.
type EmailVerificationToken struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	AccountID uuid.UUID `gorm:"type:uuid;not null;index"`
	TokenHash string    `gorm:"not null"`
	ExpiresAt time.Time `gorm:"not null"`
	CreatedAt time.Time
}

// PasswordResetToken stocke un jeton de reinitialisation de mot de passe.
// Expire apres 1h et est supprime apres utilisation.
type PasswordResetToken struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	AccountID uuid.UUID `gorm:"type:uuid;not null;index"`
	TokenHash string    `gorm:"not null;uniqueIndex"`
	ExpiresAt time.Time `gorm:"not null"`
	CreatedAt time.Time
}
