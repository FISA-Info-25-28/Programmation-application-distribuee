package models

import (
	"testing"
	"time"

	"github.com/google/uuid"
)

func TestAuthModelsFields(t *testing.T) {
	accountID := uuid.New()
	now := time.Now()
	account := Account{ID: accountID, Email: "a@example.com", Role: "ADMIN", Status: "ACTIVE", EmailVerifiedAt: &now}
	if account.ID != accountID || account.Email != "a@example.com" || account.EmailVerifiedAt == nil {
		t.Fatalf("Account fields = %+v, want assigned values", account)
	}

	session := Session{AccountID: accountID, RefreshTokenHash: "hash", ExpiresAt: now}
	if session.AccountID != accountID || session.RefreshTokenHash == "" || session.ExpiresAt.IsZero() {
		t.Fatalf("Session fields = %+v, want assigned values", session)
	}

	verification := EmailVerificationToken{AccountID: accountID, TokenHash: "hash", ExpiresAt: now}
	reset := PasswordResetToken{AccountID: accountID, TokenHash: "hash", ExpiresAt: now}
	if verification.AccountID != accountID || reset.AccountID != accountID {
		t.Fatal("token models should keep account id")
	}
}
