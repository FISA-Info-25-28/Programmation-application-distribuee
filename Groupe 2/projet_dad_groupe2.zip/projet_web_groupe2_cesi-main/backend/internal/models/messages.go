package models

import (
	"time"

	"github.com/google/uuid"
)

type Conversation struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	CreatedAt time.Time
	UpdatedAt time.Time
}

func (Conversation) TableName() string {
	return "conversations"
}

type ConversationMember struct {
	ConversationID uuid.UUID `gorm:"type:uuid;primaryKey"`
	ProfileID      uuid.UUID `gorm:"type:uuid;primaryKey"`
	LastReadAt     *time.Time
}

func (ConversationMember) TableName() string {
	return "members"
}

type PrivateMessage struct {
	ID             uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	ConversationID uuid.UUID `gorm:"type:uuid;not null;index"`
	SenderID       uuid.UUID `gorm:"type:uuid;not null;index"`
	// Content contient le texte chiffre de bout en bout (ciphertext base64,
	// chiffre avec NaCl box) lorsque Nonce est rempli. Pour les messages
	// envoyes avant la mise en place du chiffrement (Nonce vide), il contient
	// encore le texte en clair d'origine, affiche tel quel sans tentative de
	// dechiffrement (compatibilite retroactive, pas de perte de donnees).
	Content   string     `gorm:"not null"`
	Nonce     string     `gorm:"type:text;not null;default:''"`
	Kind      string     `gorm:"type:text;not null;default:'TEXT'"`
	MediaURL  *string    `gorm:"type:text"`
	MediaType *string    `gorm:"type:text"`
	ReplyToID *uuid.UUID `gorm:"type:uuid;index"`
	CreatedAt time.Time
	EditedAt  *time.Time
	DeletedAt *time.Time `gorm:"index"`
}

func (PrivateMessage) TableName() string {
	return "private_messages"
}

type MessagePreference struct {
	ProfileID uuid.UUID `gorm:"type:uuid;primaryKey"`
	Retention string    `gorm:"type:text;not null;default:'forever'"`
	UpdatedAt time.Time
}

func (MessagePreference) TableName() string {
	return "message_preferences"
}

type MessageLike struct {
	MessageID uuid.UUID `gorm:"type:uuid;primaryKey"`
	UserID    uuid.UUID `gorm:"type:uuid;primaryKey"`
	Reaction  string    `gorm:"type:text;not null;default:'HEART'"`
	CreatedAt time.Time
}

func (MessageLike) TableName() string {
	return "message_likes"
}
