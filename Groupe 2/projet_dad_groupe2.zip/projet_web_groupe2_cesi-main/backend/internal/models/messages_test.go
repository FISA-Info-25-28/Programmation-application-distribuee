package models

import (
	"testing"

	"github.com/google/uuid"
)

func TestMessageModelTableNamesAndFields(t *testing.T) {
	conversationID := uuid.New()
	profileID := uuid.New()
	if (Conversation{}).TableName() != "conversations" || (ConversationMember{}).TableName() != "members" {
		t.Fatal("conversation table names should be stable")
	}
	if (PrivateMessage{}).TableName() != "private_messages" || (MessagePreference{}).TableName() != "message_preferences" || (MessageLike{}).TableName() != "message_likes" {
		t.Fatal("message table names should be stable")
	}

	member := ConversationMember{ConversationID: conversationID, ProfileID: profileID}
	message := PrivateMessage{ConversationID: conversationID, SenderID: profileID, Content: "hello"}
	if member.ConversationID != conversationID || message.SenderID != profileID {
		t.Fatal("message models should keep assigned ids")
	}
}
