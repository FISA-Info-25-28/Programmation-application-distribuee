package models

import "testing"

func TestProfileDisplayNameOrUsername(t *testing.T) {
	displayName := "  Alice Breezy  "
	profile := Profile{Username: " alice ", DisplayName: &displayName}
	if got := profile.DisplayNameOrUsername(); got != "Alice Breezy" {
		t.Fatalf("DisplayNameOrUsername() = %q, want Alice Breezy", got)
	}

	blank := "   "
	profile.DisplayName = &blank
	if got := profile.DisplayNameOrUsername(); got != "alice" {
		t.Fatalf("DisplayNameOrUsername(blank) = %q, want alice", got)
	}
}

func TestTableNames(t *testing.T) {
	tests := map[string]string{
		Conversation{}.TableName():       "conversations",
		ConversationMember{}.TableName(): "members",
		PrivateMessage{}.TableName():     "private_messages",
		MessagePreference{}.TableName():  "message_preferences",
		MessageLike{}.TableName():        "message_likes",
		Media{}.TableName():              "media",
		UserPreference{}.TableName():     "profiles.preferences",
	}

	for got, want := range tests {
		if got != want {
			t.Fatalf("TableName() = %q, want %q", got, want)
		}
	}
}
