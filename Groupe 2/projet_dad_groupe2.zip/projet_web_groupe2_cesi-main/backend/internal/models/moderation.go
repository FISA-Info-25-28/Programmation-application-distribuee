package models

import (
	"time"

	"github.com/google/uuid"
)

type Report struct {
	ID             uuid.UUID  `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	ReporterID     uuid.UUID  `gorm:"type:uuid;not null;index"`
	ReportedPostID *uuid.UUID `gorm:"type:uuid;index"`
	ReportedUserID *uuid.UUID `gorm:"type:uuid;index"`
	Reason         string     `gorm:"not null"`
	Status         string     `gorm:"type:text;not null;default:'PENDING';index"`
	ReviewedBy     *uuid.UUID `gorm:"type:uuid"`
	ReviewedAt     *time.Time
	CreatedAt      time.Time
}
