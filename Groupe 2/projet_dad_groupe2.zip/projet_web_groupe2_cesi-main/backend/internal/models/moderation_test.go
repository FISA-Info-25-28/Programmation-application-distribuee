package models

import (
	"testing"

	"github.com/google/uuid"
)

func TestReportModelFields(t *testing.T) {
	reporterID := uuid.New()
	postID := uuid.New()
	report := Report{ReporterID: reporterID, ReportedPostID: &postID, Reason: "spam", Status: "PENDING"}
	if report.ReporterID != reporterID || report.ReportedPostID == nil || report.Reason != "spam" || report.Status != "PENDING" {
		t.Fatalf("Report fields = %+v, want assigned values", report)
	}
}
