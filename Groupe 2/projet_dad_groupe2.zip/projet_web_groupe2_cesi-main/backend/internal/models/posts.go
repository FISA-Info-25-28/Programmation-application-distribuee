package models

import (
	"time"

	"github.com/google/uuid"
)

// Post represente une publication ou une reponse publiee par un utilisateur.
// Entree principale en creation : authorID, content, parentID optionnel et
// visibility.
// Sortie/usage : modele GORM lu par le service posts pour construire les fils.
type Post struct {
	ID         uuid.UUID  `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	AuthorID   uuid.UUID  `gorm:"type:uuid;not null;index"`
	Content    string     `gorm:"type:varchar(280);not null"`
	Lang       string     `gorm:"type:varchar(10);not null;default:''"`
	ParentID   *uuid.UUID `gorm:"type:uuid;index"`
	Visibility string     `gorm:"type:text;not null;default:'PUBLIC'"`
	// OriginalVisibility memorise la visibilite reelle d'un post pendant que son
	// auteur est sanctionne (le post est alors force en PRIVATE). Nil = post non
	// masque. Restauree a la levee de la sanction (cf. package sanction).
	OriginalVisibility *string `gorm:"type:text"`
	CreatedAt          time.Time
	UpdatedAt          time.Time
	DeletedAt          *time.Time `gorm:"index"`
}

// Media represente un fichier associe a une publication.
// Entree principale en creation : postID, mediaType et URL.
// Sortie/usage : rattache des images/videos/fichiers a un post.
type Media struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	PostID    uuid.UUID `gorm:"type:uuid;not null;index"`
	MediaType string    `gorm:"type:text;not null"`
	URL       string    `gorm:"not null"`
	CreatedAt time.Time
}

// TableName force GORM a utiliser la table "media" au lieu du pluriel par
// defaut.
// Entree : aucune entree directe.
// Sortie : valeur retour de type string.
func (Media) TableName() string { return "media" }

// Like represente le like d'un utilisateur sur une publication.
// Entree principale en creation : postID et userID.
// Sortie/usage : sert au comptage et a l'etat "deja like".
type Like struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	PostID    uuid.UUID `gorm:"type:uuid;not null;index"`
	UserID    uuid.UUID `gorm:"type:uuid;not null;index"`
	CreatedAt time.Time
}

// Repost represente le repost d'une publication par un utilisateur.
// Entree principale en creation : postID et userID.
// Sortie/usage : sert au comptage et a l'etat "deja reposte".
type Repost struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	PostID    uuid.UUID `gorm:"type:uuid;not null;index"`
	UserID    uuid.UUID `gorm:"type:uuid;not null;index"`
	CreatedAt time.Time
}

// Tag represente un mot-cle associe aux publications.
// Entree principale en creation : name unique.
// Sortie/usage : permet de regrouper et rechercher les posts par mot-cle.
type Tag struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	Name      string    `gorm:"unique;not null"`
	CreatedAt time.Time
}

// PostTag represente la table de liaison entre publications et tags.
// Entree principale : postID et tagID.
// Sortie/usage : association many-to-many entre Post et Tag.
type PostTag struct {
	PostID uuid.UUID `gorm:"type:uuid;primaryKey"`
	TagID  uuid.UUID `gorm:"type:uuid;primaryKey"`
}

// Poll represente un sondage attache a une publication.
// EndsAt=nil signifie pas d'expiration automatique (cloture manuelle uniquement).
// ClosedAt non-nil signifie que le createur a clos le sondage manuellement.
type Poll struct {
	ID        uuid.UUID  `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	PostID    uuid.UUID  `gorm:"type:uuid;not null;uniqueIndex"`
	EndsAt    *time.Time `gorm:"index"`
	ClosedAt  *time.Time
	CreatedAt time.Time
	Options   []PollOption `gorm:"foreignKey:PollID"`
}

// PollOption est une option de vote dans un sondage.
// VoteCount est incrémenté en base au moment du vote pour la perf.
type PollOption struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	PollID    uuid.UUID `gorm:"type:uuid;not null;index"`
	Text      string    `gorm:"type:varchar(80);not null"`
	Position  int       `gorm:"not null;default:0"`
	VoteCount int       `gorm:"not null;default:0"`
}

// PollVote enregistre le vote d'un utilisateur pour une option.
// L'index composite unique (poll_id, user_id) garantit 1 vote par utilisateur.
type PollVote struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	PollID    uuid.UUID `gorm:"type:uuid;not null;uniqueIndex:idx_poll_vote_unique"`
	OptionID  uuid.UUID `gorm:"type:uuid;not null"`
	UserID    uuid.UUID `gorm:"type:uuid;not null;uniqueIndex:idx_poll_vote_unique"`
	CreatedAt time.Time
}

// Bookmark represente un post sauvegarde par un utilisateur.
// L'index composite unique (user_id, post_id) garantit un seul signet par post par utilisateur.
type Bookmark struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	PostID    uuid.UUID `gorm:"type:uuid;not null;uniqueIndex:idx_bookmark_unique"`
	UserID    uuid.UUID `gorm:"type:uuid;not null;uniqueIndex:idx_bookmark_unique"`
	CreatedAt time.Time
}
