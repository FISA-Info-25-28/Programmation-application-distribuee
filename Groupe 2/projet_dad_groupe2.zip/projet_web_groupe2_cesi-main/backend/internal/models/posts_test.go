package models

import (
	"testing"

	"github.com/google/uuid"
)

func TestPostModelsFields(t *testing.T) {
	postID := uuid.New()
	authorID := uuid.New()
	visibility := "PUBLIC"
	post := Post{ID: postID, AuthorID: authorID, Content: "hello", Visibility: visibility, OriginalVisibility: &visibility}
	if post.ID != postID || post.AuthorID != authorID || post.OriginalVisibility == nil {
		t.Fatalf("Post fields = %+v, want assigned values", post)
	}

	media := Media{PostID: postID, MediaType: "IMAGE", URL: "/api/media/files/a.png"}
	if media.TableName() != "media" || media.PostID != postID {
		t.Fatalf("Media model = %+v, want media table and post id", media)
	}

	pollID := uuid.New()
	optionID := uuid.New()
	poll := Poll{ID: pollID, PostID: postID, Options: []PollOption{{ID: optionID, PollID: pollID, Text: "A"}}}
	vote := PollVote{PollID: pollID, OptionID: optionID, UserID: authorID}
	bookmark := Bookmark{PostID: postID, UserID: authorID}
	if len(poll.Options) != 1 || vote.OptionID != optionID || bookmark.UserID != authorID {
		t.Fatal("poll/vote/bookmark models should keep assigned ids")
	}
}
