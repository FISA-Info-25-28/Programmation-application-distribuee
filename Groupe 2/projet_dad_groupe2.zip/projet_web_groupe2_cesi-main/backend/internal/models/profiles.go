package models

import (
	"strings"
	"time"

	"github.com/google/uuid"
)

// Profile represente les informations publiques d'un utilisateur.
// Entree principale en creation : accountID, username, displayName, bio et
// avatarURL.
// Sortie/usage : fiche publique affichee dans le frontend.
type Profile struct {
	ID           uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	AccountID    uuid.UUID `gorm:"type:uuid;not null;uniqueIndex"`
	Username     string    `gorm:"uniqueIndex;not null"`
	DisplayName  *string
	Bio          *string
	AvatarURL    *string
	BannerURL    *string
	IsPrivate    bool       `gorm:"not null;default:false"`
	PinnedPostID *uuid.UUID `gorm:"type:uuid"`
	// PublicKey est la cle publique X25519 (base64) utilisee pour le chiffrement
	// de bout en bout des messages prives. La cle privee correspondante ne
	// quitte jamais le navigateur de l'utilisateur.
	PublicKey *string `gorm:"type:text"`
	// OriginalUsername / OriginalDisplayName memorisent l'identite reelle pendant
	// qu'un compte est sanctionne (anonymise en "user_<id>"). Nil = profil non
	// anonymise. Restaurees a la levee de la sanction (cf. package sanction).
	OriginalUsername    *string
	OriginalDisplayName *string
	CreatedAt           time.Time
	UpdatedAt           time.Time
}

func (p Profile) DisplayNameOrUsername() string {
	if p.DisplayName != nil && strings.TrimSpace(*p.DisplayName) != "" {
		return strings.TrimSpace(*p.DisplayName)
	}
	return strings.TrimSpace(p.Username)
}
