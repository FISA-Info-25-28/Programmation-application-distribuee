package models

import (
	"testing"

	"github.com/google/uuid"
)

func TestProfileModelFieldsAndDisplayName(t *testing.T) {
	accountID := uuid.New()
	displayName := " Alice "
	profile := Profile{AccountID: accountID, Username: "alice", DisplayName: &displayName, IsPrivate: true}
	if profile.AccountID != accountID || profile.DisplayNameOrUsername() != "Alice" || !profile.IsPrivate {
		t.Fatalf("Profile = %+v, want assigned fields and trimmed display name", profile)
	}
}
