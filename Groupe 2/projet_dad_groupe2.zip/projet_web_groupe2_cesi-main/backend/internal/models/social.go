package models

import (
	"time"

	"github.com/google/uuid"
)

// Follow represente une relation d'abonnement entre deux utilisateurs.
// Entree principale en creation : followerID et followedID.
// Sortie/usage : determine abonnements, abonnes et fil des suivis.
type Follow struct {
	ID         uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	FollowerID uuid.UUID `gorm:"type:uuid;not null;index"`
	FollowedID uuid.UUID `gorm:"type:uuid;not null;index"`
	CreatedAt  time.Time
}

// FollowRequest represente une demande d'abonnement a un profil prive.
// Elle est supprimee des qu'elle est acceptee, refusee ou annulee.
type FollowRequest struct {
	ID          uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	RequesterID uuid.UUID `gorm:"type:uuid;not null;uniqueIndex:follow_requests_unique"`
	TargetID    uuid.UUID `gorm:"type:uuid;not null;uniqueIndex:follow_requests_unique;index"`
	CreatedAt   time.Time
}

// Block represents a one-way block initiated by BlockerID against BlockedID.
type Block struct {
	ID        uuid.UUID `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	BlockerID uuid.UUID `gorm:"type:uuid;not null;uniqueIndex:blocks_unique"`
	BlockedID uuid.UUID `gorm:"type:uuid;not null;uniqueIndex:blocks_unique"`
	CreatedAt time.Time
}

// Notification represente une alerte destinee a un utilisateur.
// Entree principale en creation : recipientID, actorID, type et postID
// optionnel.
// Sortie/usage : affiche les evenements non lus/lus pour un utilisateur.
type Notification struct {
	ID          uuid.UUID  `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	RecipientID uuid.UUID  `gorm:"type:uuid;not null;index"`
	ActorID     uuid.UUID  `gorm:"type:uuid;not null"`
	Type        string     `gorm:"type:text;not null"`
	PostID      *uuid.UUID `gorm:"type:uuid"`
	IsRead      bool       `gorm:"not null;default:false"`
	CreatedAt   time.Time
}
