package models

import (
	"testing"

	"github.com/google/uuid"
)

func TestSocialModelsFields(t *testing.T) {
	followerID := uuid.New()
	followedID := uuid.New()
	follow := Follow{FollowerID: followerID, FollowedID: followedID}
	request := FollowRequest{RequesterID: followerID, TargetID: followedID}
	block := Block{BlockerID: followerID, BlockedID: followedID}
	notification := Notification{RecipientID: followedID, ActorID: followerID, Type: "FOLLOW"}

	if follow.FollowedID != followedID || request.TargetID != followedID || block.BlockedID != followedID || notification.ActorID != followerID {
		t.Fatal("social models should keep assigned ids")
	}
}
