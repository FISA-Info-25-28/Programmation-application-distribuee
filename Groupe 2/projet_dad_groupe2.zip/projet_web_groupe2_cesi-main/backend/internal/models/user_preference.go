package models

import (
	"time"

	"github.com/google/uuid"
)

type UserPreference struct {
	ProfileID uuid.UUID `gorm:"type:uuid;primaryKey"`
	Locale    string    `gorm:"type:text;not null;default:'fr'"`
	Theme     string    `gorm:"type:text;not null;default:'light'"`
	UpdatedAt time.Time
}

func (UserPreference) TableName() string {
	return "profiles.preferences"
}
