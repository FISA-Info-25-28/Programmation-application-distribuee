package models

import (
	"testing"

	"github.com/google/uuid"
)

func TestUserPreferenceModel(t *testing.T) {
	profileID := uuid.New()
	preference := UserPreference{ProfileID: profileID, Locale: "pt", Theme: "dark"}
	if preference.TableName() != "profiles.preferences" || preference.ProfileID != profileID || preference.Locale != "pt" || preference.Theme != "dark" {
		t.Fatalf("UserPreference = %+v, want table name and assigned values", preference)
	}
}
