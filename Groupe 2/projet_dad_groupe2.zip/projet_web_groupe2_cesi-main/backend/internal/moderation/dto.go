package moderation

import (
	"time"

	"breezy/backend/internal/validation"
	"github.com/google/uuid"
)

type reportResponse struct {
	ID                  uuid.UUID  `json:"id"`
	ReporterID          uuid.UUID  `json:"reporterId"`
	ReporterUsername    string     `json:"reporterUsername,omitempty"`
	ReporterDisplayName string     `json:"reporterDisplayName,omitempty"`
	ReportedPostID      *uuid.UUID `json:"reportedPostId,omitempty"`
	ReportedPostContent string     `json:"reportedPostContent,omitempty"`
	ReportedUserID      *uuid.UUID `json:"reportedUserId,omitempty"`
	Reason              string     `json:"reason"`
	Status              string     `json:"status"`
	ReviewedBy          *uuid.UUID `json:"reviewedBy,omitempty"`
	ReviewedAt          *time.Time `json:"reviewedAt,omitempty"`
	CreatedAt           time.Time  `json:"createdAt"`
}

type createPostReportRequest struct {
	Reason string `json:"reason" binding:"required"`
}

func (r createPostReportRequest) Validate() error {
	_, err := validation.TrimmedRequired(r.Reason, 500, "reason")
	return err
}

type reviewReportRequest struct {
	Status string `json:"status" binding:"required"`
}

func (r reviewReportRequest) Validate() error {
	return validation.OneOf(r.Status, "REVIEWED", "RESOLVED", "REJECTED")
}

// banUserRequest porte la raison facultative d'un bannissement.
type banUserRequest struct {
	Reason string `json:"reason"`
}

// suspendUserRequest porte la duree d'une suspension temporaire, exprimee en
// heures. Valeurs acceptees (liste blanche cote handler) : 1, 24, 72, 168, 336, 720.
type suspendUserRequest struct {
	DurationHours int    `json:"durationHours" binding:"required"`
	Reason        string `json:"reason"`
}

// moderationActionResponse decrit l'etat du compte cible apres une action de
// moderation (bannissement, suspension ou levee de sanction).
type moderationActionResponse struct {
	ProfileID      uuid.UUID  `json:"profileId"`
	AccountID      uuid.UUID  `json:"accountId"`
	Status         string     `json:"status"`
	SuspendedUntil *time.Time `json:"suspendedUntil,omitempty"`
}

// moderatedUserResponse decrit un compte actuellement sous sanction, expose a la
// page de moderation pour permettre la levee ou le changement de duree.
type moderatedUserResponse struct {
	ProfileID      uuid.UUID  `json:"profileId"`
	AccountID      uuid.UUID  `json:"accountId"`
	Username       string     `json:"username"`
	DisplayName    string     `json:"displayName"`
	Role           string     `json:"role"`
	Status         string     `json:"status"`
	SuspendedUntil *time.Time `json:"suspendedUntil,omitempty"`
	UpdatedAt      time.Time  `json:"updatedAt"`
}
