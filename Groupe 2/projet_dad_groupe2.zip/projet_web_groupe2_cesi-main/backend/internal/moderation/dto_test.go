package moderation

import (
	"strings"
	"testing"
)

func TestCreatePostReportRequestValidate(t *testing.T) {
	if err := (createPostReportRequest{Reason: "spam"}).Validate(); err != nil {
		t.Fatalf("createPostReportRequest.Validate() unexpected error: %v", err)
	}
	if err := (createPostReportRequest{Reason: " "}).Validate(); err == nil {
		t.Fatal("createPostReportRequest.Validate() expected required reason error")
	}
	if err := (createPostReportRequest{Reason: strings.Repeat("x", 501)}).Validate(); err == nil {
		t.Fatal("createPostReportRequest.Validate() expected length error")
	}
}

func TestReviewReportRequestValidate(t *testing.T) {
	for _, status := range []string{"REVIEWED", "resolved", " REJECTED "} {
		if err := (reviewReportRequest{Status: status}).Validate(); err != nil {
			t.Fatalf("reviewReportRequest.Validate(%q) unexpected error: %v", status, err)
		}
	}
	if err := (reviewReportRequest{Status: "PENDING"}).Validate(); err == nil {
		t.Fatal("reviewReportRequest.Validate() expected invalid status error")
	}
}
