package moderation

import (
	"errors"
	"io"
	"log"
	"net/http"
	"strings"
	"time"

	"breezy/backend/internal/config"
	"breezy/backend/internal/middleware"
	"breezy/backend/internal/models"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Handler struct {
	db     *gorm.DB
	repo   *Repository
	mailer sanctionMailer
}

func NewHandler(db *gorm.DB) *Handler {
	return &Handler{
		db:     db,
		repo:   NewRepository(db),
		mailer: newSanctionMailerFromEnv(),
	}
}

func (h *Handler) Health(c *gin.Context) {
	dbStatus := "ok"
	if h.db == nil {
		dbStatus = "unavailable"
	} else if sqlDB, err := h.db.DB(); err != nil || sqlDB.PingContext(c.Request.Context()) != nil {
		dbStatus = "error"
	}

	c.JSON(http.StatusOK, gin.H{
		"service": config.Env("SERVICE_NAME", "moderation-service"),
		"status":  "ok",
		"db":      dbStatus,
	})
}

func (h *Handler) ListReports(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	reports, err := h.repo.ListReports(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "reports lookup failed"})
		return
	}

	c.JSON(http.StatusOK, toReportResponses(reports))
}

func (h *Handler) CreatePostReport(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid post id"})
		return
	}

	var req createPostReportRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid report payload"})
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	reporterID, err := h.repo.FindProfileIDByAccountID(c.Request.Context(), accountID)
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, gorm.ErrRecordNotFound) {
			status = http.StatusNotFound
		}
		c.JSON(status, gin.H{"error": "reporter profile lookup failed"})
		return
	}

	report := models.Report{
		ReporterID:     reporterID,
		ReportedPostID: &postID,
		Reason:         strings.TrimSpace(req.Reason),
		Status:         reportStatusPending,
	}
	if report.Reason == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "reason is required"})
		return
	}

	if err := h.repo.CreatePostReport(c.Request.Context(), &report); err != nil {
		if errors.Is(err, ErrAlreadyReported) {
			c.JSON(http.StatusConflict, gin.H{"error": "post already reported"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "report creation failed"})
		return
	}

	c.JSON(http.StatusCreated, toBasicReportResponse(report))
}

func (h *Handler) ReviewReport(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	reportID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid report id"})
		return
	}

	var req reviewReportRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid review payload"})
		return
	}

	status := strings.ToUpper(strings.TrimSpace(req.Status))
	if !validReviewedStatus(status) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid report status"})
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	reviewerID, err := h.repo.FindProfileIDByAccountID(c.Request.Context(), accountID)
	if err != nil {
		statusCode := http.StatusInternalServerError
		if errors.Is(err, gorm.ErrRecordNotFound) {
			statusCode = http.StatusNotFound
		}
		c.JSON(statusCode, gin.H{"error": "reviewer profile lookup failed"})
		return
	}

	if _, err := h.repo.UpdateReportStatus(c.Request.Context(), reportID, reviewerID, status); err != nil {
		statusCode := http.StatusInternalServerError
		if errors.Is(err, gorm.ErrRecordNotFound) {
			statusCode = http.StatusNotFound
		}
		c.JSON(statusCode, gin.H{"error": "report update failed"})
		return
	}

	report, err := h.repo.FindEnrichedReport(c.Request.Context(), reportID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "report lookup failed"})
		return
	}

	c.JSON(http.StatusOK, toReportResponse(report))
}

// allowedSuspensionHours liste blanche les durees de suspension acceptees
// (1h, 1j, 3j, 7j, 14j, 30j), alignee sur le slider du frontend.
var allowedSuspensionHours = map[int]bool{1: true, 24: true, 72: true, 168: true, 336: true, 720: true}

// BanUser bannit definitivement l'auteur (profileId) cible.
// Entree HTTP : profileId en parametre de chemin.
// Sortie HTTP : 200 avec moderationActionResponse, 400 (profileId invalide),
// 403 (cible interdite), 404 (profil introuvable), 500/503 sinon.
func (h *Handler) BanUser(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	profileID, actorID, actorRole, ok := h.moderationContext(c)
	if !ok {
		return
	}

	var req banUserRequest
	if err := c.ShouldBindJSON(&req); err != nil && !errors.Is(err, io.EOF) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid ban payload"})
		return
	}

	target, err := h.repo.BanUser(c.Request.Context(), profileID, actorID, actorRole)
	if err != nil {
		h.respondModerationError(c, err)
		return
	}

	if h.mailer != nil && target.Email != "" {
		reason := strings.TrimSpace(req.Reason)
		go func() {
			if err := h.mailer.SendBanEmail(target.Email, target.DisplayName, reason); err != nil {
				log.Printf("[moderation] ban email failed for %s: %v", target.Email, err)
			}
		}()
	}

	c.JSON(http.StatusOK, moderationActionResponse{
		ProfileID: profileID,
		AccountID: target.AccountID,
		Status:    "BANNED",
	})
}

// SuspendUser suspend temporairement l'auteur (profileId) cible.
// Entree HTTP : profileId en parametre de chemin et JSON suspendUserRequest.
// Sortie HTTP : 200 avec moderationActionResponse, 400 (profileId/duree
// invalide), 403 (cible interdite), 404 (profil introuvable), 500/503 sinon.
func (h *Handler) SuspendUser(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	profileID, actorID, actorRole, ok := h.moderationContext(c)
	if !ok {
		return
	}

	var req suspendUserRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid suspend payload"})
		return
	}
	if !allowedSuspensionHours[req.DurationHours] {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid suspension duration"})
		return
	}

	until := time.Now().UTC().Add(time.Duration(req.DurationHours) * time.Hour)
	target, err := h.repo.SuspendUser(c.Request.Context(), profileID, actorID, actorRole, until)
	if err != nil {
		h.respondModerationError(c, err)
		return
	}

	if h.mailer != nil && target.Email != "" {
		reason := strings.TrimSpace(req.Reason)
		suspendUntil := until
		go func() {
			if err := h.mailer.SendSuspensionEmail(target.Email, target.DisplayName, reason, suspendUntil); err != nil {
				log.Printf("[moderation] suspension email failed for %s: %v", target.Email, err)
			}
		}()
	}

	c.JSON(http.StatusOK, moderationActionResponse{
		ProfileID:      profileID,
		AccountID:      target.AccountID,
		Status:         "SUSPENDED",
		SuspendedUntil: &until,
	})
}

// ListModeratedUsers renvoie la liste des comptes actuellement sous sanction
// (bannis ou suspendus non expires) pour l'espace de gestion de la moderation.
// Sortie HTTP : 200 avec []moderatedUserResponse, 500/503 sinon.
// Entree : c.
func (h *Handler) ListModeratedUsers(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accounts, err := h.repo.ListModeratedAccounts(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "moderated users lookup failed"})
		return
	}

	c.JSON(http.StatusOK, toModeratedUserResponses(accounts))
}

// LiftModeration leve la sanction (suspension ou bannissement) du compte cible et
// le remet en statut ACTIVE.
// Entree HTTP : profileId en parametre de chemin.
// Sortie HTTP : 200 avec moderationActionResponse, 400 (profileId invalide),
// 403 (cible interdite), 404 (profil introuvable), 500/503 sinon.
func (h *Handler) LiftModeration(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	profileID, actorID, actorRole, ok := h.moderationContext(c)
	if !ok {
		return
	}

	target, err := h.repo.LiftModeration(c.Request.Context(), profileID, actorID, actorRole)
	if err != nil {
		h.respondModerationError(c, err)
		return
	}

	c.JSON(http.StatusOK, moderationActionResponse{
		ProfileID: profileID,
		AccountID: target.AccountID,
		Status:    "ACTIVE",
	})
}

// moderationContext extrait et valide le profileId cible et l'identite de
// l'auteur de l'action. Repond directement (et renvoie ok=false) en cas
// d'erreur. Sortie : profileID cible, accountID et role de l'auteur, ok.
// Entree : c.
// Sortie : valeurs retour de la fonction.
func (h *Handler) moderationContext(c *gin.Context) (uuid.UUID, uuid.UUID, string, bool) {
	profileID, err := uuid.Parse(c.Param("profileId"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid profile id"})
		return uuid.Nil, uuid.Nil, "", false
	}

	actorID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return uuid.Nil, uuid.Nil, "", false
	}

	actorRole, _ := middleware.Role(c)
	return profileID, actorID, actorRole, true
}

// respondModerationError mappe les erreurs metier de moderation vers un code HTTP.
// Entree : c, err.
// Sortie : aucune valeur.
func (h *Handler) respondModerationError(c *gin.Context, err error) {
	switch {
	case errors.Is(err, gorm.ErrRecordNotFound):
		c.JSON(http.StatusNotFound, gin.H{"error": "target account not found"})
	case errors.Is(err, ErrCannotTargetSelf):
		c.JSON(http.StatusForbidden, gin.H{"error": "cannot moderate your own account"})
	case errors.Is(err, ErrInsufficientRoleOverTarget):
		c.JSON(http.StatusForbidden, gin.H{"error": "insufficient role over target account"})
	default:
		c.JSON(http.StatusInternalServerError, gin.H{"error": "moderation action failed"})
	}
}

func (h *Handler) databaseAvailable(c *gin.Context) bool {
	if h.db != nil {
		return true
	}

	c.JSON(http.StatusServiceUnavailable, gin.H{"error": "database unavailable"})
	return false
}

func toReportResponses(reports []EnrichedReport) []reportResponse {
	response := make([]reportResponse, len(reports))
	for i, report := range reports {
		response[i] = toReportResponse(report)
	}

	return response
}

func toReportResponse(report EnrichedReport) reportResponse {
	return reportResponse{
		ID:                  report.ID,
		ReporterID:          report.ReporterID,
		ReporterUsername:    report.ReporterUsername,
		ReporterDisplayName: report.ReporterDisplayName,
		ReportedPostID:      report.ReportedPostID,
		ReportedPostContent: report.ReportedPostContent,
		ReportedUserID:      report.ReportedUserID,
		Reason:              report.Reason,
		Status:              report.Status,
		ReviewedBy:          report.ReviewedBy,
		ReviewedAt:          report.ReviewedAt,
		CreatedAt:           report.CreatedAt,
	}
}

func toBasicReportResponse(report models.Report) reportResponse {
	return reportResponse{
		ID:             report.ID,
		ReporterID:     report.ReporterID,
		ReportedPostID: report.ReportedPostID,
		ReportedUserID: report.ReportedUserID,
		Reason:         report.Reason,
		Status:         report.Status,
		ReviewedBy:     report.ReviewedBy,
		ReviewedAt:     report.ReviewedAt,
		CreatedAt:      report.CreatedAt,
	}
}

func toModeratedUserResponses(accounts []ModeratedAccount) []moderatedUserResponse {
	response := make([]moderatedUserResponse, len(accounts))
	for i, account := range accounts {
		response[i] = moderatedUserResponse{
			ProfileID:      account.ProfileID,
			AccountID:      account.AccountID,
			Username:       account.Username,
			DisplayName:    account.DisplayName,
			Role:           account.Role,
			Status:         account.Status,
			SuspendedUntil: account.SuspendedUntil,
			UpdatedAt:      account.UpdatedAt,
		}
	}

	return response
}

func validReviewedStatus(status string) bool {
	switch status {
	case "REVIEWED", "RESOLVED", "REJECTED":
		return true
	default:
		return false
	}
}
