package moderation

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"breezy/backend/internal/middleware"
	"breezy/backend/internal/models"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

func TestModerationHandlerDatabaseUnavailable(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(nil)
	id := uuid.NewString()

	tests := []struct {
		method string
		path   string
		setup  func(*gin.Engine)
		want   int
	}{
		{method: http.MethodGet, path: "/health", setup: func(r *gin.Engine) { r.GET("/health", handler.Health) }, want: http.StatusOK},
		{method: http.MethodGet, path: "/reports", setup: func(r *gin.Engine) { r.GET("/reports", handler.ListReports) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/posts/" + id + "/report", setup: func(r *gin.Engine) { r.POST("/posts/:id/report", handler.CreatePostReport) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPatch, path: "/reports/" + id, setup: func(r *gin.Engine) { r.PATCH("/reports/:id", handler.ReviewReport) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/users/" + id + "/ban", setup: func(r *gin.Engine) { r.POST("/users/:profileId/ban", handler.BanUser) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/users/" + id + "/suspend", setup: func(r *gin.Engine) { r.POST("/users/:profileId/suspend", handler.SuspendUser) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/users/" + id + "/lift", setup: func(r *gin.Engine) { r.POST("/users/:profileId/lift", handler.LiftModeration) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/sanctions", setup: func(r *gin.Engine) { r.GET("/sanctions", handler.ListModeratedUsers) }, want: http.StatusServiceUnavailable},
	}

	for _, tt := range tests {
		router := gin.New()
		tt.setup(router)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != tt.want {
			t.Fatalf("%s %s status = %d, want %d", tt.method, tt.path, rec.Code, tt.want)
		}
	}
}

func TestModerationResponsesAndErrors(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := &Handler{}

	for _, tt := range []struct {
		err  error
		want int
	}{
		{err: gorm.ErrRecordNotFound, want: http.StatusNotFound},
		{err: ErrCannotTargetSelf, want: http.StatusForbidden},
		{err: ErrInsufficientRoleOverTarget, want: http.StatusForbidden},
		{err: assertErr("boom"), want: http.StatusInternalServerError},
	} {
		rec := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(rec)
		handler.respondModerationError(c, tt.err)
		if rec.Code != tt.want {
			t.Fatalf("respondModerationError(%v) status = %d, want %d", tt.err, rec.Code, tt.want)
		}
	}

	reportID := uuid.New()
	postID := uuid.New()
	reviewerID := uuid.New()
	reviewedAt := time.Now().UTC()
	report := EnrichedReport{
		Report: models.Report{
			ID:             reportID,
			ReporterID:     uuid.New(),
			ReportedPostID: &postID,
			Reason:         "spam",
			Status:         "RESOLVED",
			ReviewedBy:     &reviewerID,
			ReviewedAt:     &reviewedAt,
			CreatedAt:      reviewedAt,
		},
		ReporterUsername:    "alice",
		ReporterDisplayName: "Alice",
		ReportedPostContent: "bad post",
	}
	if got := toReportResponses([]EnrichedReport{report}); len(got) != 1 || got[0].ID != reportID || got[0].ReportedPostID != &postID {
		t.Fatalf("toReportResponses() = %+v, want mapped report", got)
	}

	basic := toBasicReportResponse(report.Report)
	if basic.ID != reportID || basic.ReportedPostID != &postID || basic.Status != "RESOLVED" {
		t.Fatalf("toBasicReportResponse() = %+v, want mapped basic report", basic)
	}

	until := time.Now().UTC().Add(time.Hour)
	accounts := []ModeratedAccount{{ProfileID: uuid.New(), AccountID: uuid.New(), Username: "bob", DisplayName: "Bob", Role: "USER", Status: "SUSPENDED", SuspendedUntil: &until, UpdatedAt: until}}
	if got := toModeratedUserResponses(accounts); len(got) != 1 || got[0].Status != "SUSPENDED" || got[0].SuspendedUntil != &until {
		t.Fatalf("toModeratedUserResponses() = %+v, want mapped account", got)
	}

	if !validReviewedStatus("RESOLVED") || validReviewedStatus("PENDING") {
		t.Fatal("validReviewedStatus() returned unexpected result")
	}
}

type assertErr string

func (e assertErr) Error() string { return string(e) }

func TestRegisterRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	RegisterRoutes(router, NewHandler(nil))

	tests := []struct {
		method string
		path   string
		want   int
	}{
		{method: http.MethodGet, path: "/health", want: http.StatusOK},
		{method: http.MethodGet, path: "/reports", want: http.StatusUnauthorized},
		{method: http.MethodPost, path: "/posts/" + uuid.NewString() + "/report", want: http.StatusUnauthorized},
	}

	for _, tt := range tests {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != tt.want {
			t.Fatalf("%s %s status = %d, want %d", tt.method, tt.path, rec.Code, tt.want)
		}
	}
}

func TestModerationHandlerInvalidInputsWithDatabase(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(&gorm.DB{})
	accountID := uuid.New()

	tests := []struct {
		name        string
		method      string
		path        string
		body        string
		withAccount bool
		setup       func(*gin.Engine)
		want        int
	}{
		{name: "create report invalid post id", method: http.MethodPost, path: "/posts/bad/report", body: `{"reason":"spam"}`, setup: func(r *gin.Engine) { r.POST("/posts/:id/report", handler.CreatePostReport) }, want: http.StatusBadRequest},
		{name: "review invalid report id", method: http.MethodPatch, path: "/reports/bad", body: `{"status":"RESOLVED"}`, setup: func(r *gin.Engine) { r.PATCH("/reports/:id", handler.ReviewReport) }, want: http.StatusBadRequest},
		{name: "review invalid payload", method: http.MethodPatch, path: "/reports/" + uuid.NewString(), body: `{"status":"PENDING"}`, setup: func(r *gin.Engine) { r.PATCH("/reports/:id", handler.ReviewReport) }, want: http.StatusBadRequest},
		{name: "ban invalid profile id", method: http.MethodPost, path: "/users/bad/ban", withAccount: true, setup: func(r *gin.Engine) { r.POST("/users/:profileId/ban", handler.BanUser) }, want: http.StatusBadRequest},
		{name: "suspend invalid profile id", method: http.MethodPost, path: "/users/bad/suspend", withAccount: true, setup: func(r *gin.Engine) { r.POST("/users/:profileId/suspend", handler.SuspendUser) }, want: http.StatusBadRequest},
		{name: "suspend invalid json", method: http.MethodPost, path: "/users/" + uuid.NewString() + "/suspend", body: "{", withAccount: true, setup: func(r *gin.Engine) { r.POST("/users/:profileId/suspend", handler.SuspendUser) }, want: http.StatusBadRequest},
		{name: "suspend invalid duration", method: http.MethodPost, path: "/users/" + uuid.NewString() + "/suspend", body: `{"durationHours":2}`, withAccount: true, setup: func(r *gin.Engine) { r.POST("/users/:profileId/suspend", handler.SuspendUser) }, want: http.StatusBadRequest},
		{name: "lift invalid profile id", method: http.MethodPost, path: "/users/bad/lift", withAccount: true, setup: func(r *gin.Engine) { r.POST("/users/:profileId/lift", handler.LiftModeration) }, want: http.StatusBadRequest},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			if tt.withAccount {
				router.Use(func(c *gin.Context) {
					c.Set(middleware.ContextAccountID, accountID)
					c.Set(middleware.ContextRole, middleware.RoleModerator)
					c.Next()
				})
			}
			tt.setup(router)
			rec := httptest.NewRecorder()
			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			router.ServeHTTP(rec, req)
			if rec.Code != tt.want {
				t.Fatalf("status = %d, want %d: %s", rec.Code, tt.want, rec.Body.String())
			}
		})
	}
}
