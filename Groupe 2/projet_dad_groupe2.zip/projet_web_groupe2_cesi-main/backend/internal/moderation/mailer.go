package moderation

import (
	"fmt"
	"net/smtp"
	"strconv"
	"strings"
	"time"

	"breezy/backend/internal/config"
)

type sanctionMailer interface {
	SendBanEmail(to, displayName, reason string) error
	SendSuspensionEmail(to, displayName, reason string, until time.Time) error
}

type smtpSanctionMailer struct {
	host         string
	port         int
	username     string
	password     string
	from         string
	supportEmail string
}

func newSanctionMailerFromEnv() sanctionMailer {
	if strings.EqualFold(config.Env("SMTP_ENABLED", "true"), "false") {
		return nil
	}

	port, err := strconv.Atoi(config.Env("SMTP_PORT", "1025"))
	if err != nil {
		port = 1025
	}

	supportEmail := config.Env("SUPPORT_EMAIL", config.Env("SMTP_FROM", "no-reply@breezy.local"))

	return &smtpSanctionMailer{
		host:         config.Env("SMTP_HOST", "mailpit"),
		port:         port,
		username:     config.Env("SMTP_USERNAME", ""),
		password:     config.Env("SMTP_PASSWORD", ""),
		from:         config.Env("SMTP_FROM", "no-reply@breezy.local"),
		supportEmail: supportEmail,
	}
}

func (m *smtpSanctionMailer) send(to, subject, plain, html string) error {
	boundary := "breezy-boundary-sanction"

	msg := strings.Join([]string{
		fmt.Sprintf("From: Breezy <%s>", m.from),
		fmt.Sprintf("To: %s", to),
		fmt.Sprintf("Subject: %s", subject),
		"MIME-Version: 1.0",
		fmt.Sprintf("Content-Type: multipart/alternative; boundary=%q", boundary),
		"",
		"--" + boundary,
		`Content-Type: text/plain; charset="UTF-8"`,
		"",
		plain,
		"",
		"--" + boundary,
		`Content-Type: text/html; charset="UTF-8"`,
		"",
		html,
		"",
		"--" + boundary + "--",
	}, "\r\n")

	addr := fmt.Sprintf("%s:%d", m.host, m.port)
	var auth smtp.Auth
	if m.username != "" {
		auth = smtp.PlainAuth("", m.username, m.password, m.host)
	}

	return smtp.SendMail(addr, auth, m.from, []string{to}, []byte(msg))
}

func (m *smtpSanctionMailer) SendBanEmail(to, displayName, reason string) error {
	name := strings.TrimSpace(displayName)
	if name == "" {
		name = "cher utilisateur"
	}

	reasonLine := ""
	if reason != "" {
		reasonLine = "\r\nMotif : " + reason + "\r\n"
	}

	plain := strings.Join([]string{
		fmt.Sprintf("Bonjour %s,", name),
		"",
		"Nous t'informons que ton compte Breezy a ete banni definitivement.",
		reasonLine,
		"Si tu penses qu'il s'agit d'une erreur, contacte notre equipe : " + strings.ReplaceAll(m.supportEmail, ",", " ou "),
		"",
		"L'equipe Breezy",
	}, "\r\n")

	html := buildBanEmailHTML(name, reason, m.supportEmail)

	return m.send(to, "Ton compte Breezy a ete banni", plain, html)
}

func (m *smtpSanctionMailer) SendSuspensionEmail(to, displayName, reason string, until time.Time) error {
	name := strings.TrimSpace(displayName)
	if name == "" {
		name = "cher utilisateur"
	}

	untilStr := until.UTC().Format("02/01/2006 a 15h04 UTC")

	reasonLine := ""
	if reason != "" {
		reasonLine = "\r\nMotif : " + reason + "\r\n"
	}

	plain := strings.Join([]string{
		fmt.Sprintf("Bonjour %s,", name),
		"",
		fmt.Sprintf("Nous t'informons que ton compte Breezy a ete suspendu jusqu'au %s.", untilStr),
		reasonLine,
		"Pendant cette periode, tu ne pourras pas te connecter ni publier de contenu.",
		"Ta suspension sera levee automatiquement a l'echeance.",
		"",
		"Si tu penses qu'il s'agit d'une erreur, contacte notre equipe : " + strings.ReplaceAll(m.supportEmail, ",", " ou "),
		"",
		"L'equipe Breezy",
	}, "\r\n")

	html := buildSuspensionEmailHTML(name, reason, untilStr, m.supportEmail)

	return m.send(to, "Ton compte Breezy a ete suspendu", plain, html)
}

func supportLinks(supportEmail string) string {
	addrs := strings.Split(supportEmail, ",")
	links := make([]string, 0, len(addrs))
	for _, addr := range addrs {
		addr = strings.TrimSpace(addr)
		if addr != "" {
			links = append(links, `<a href="mailto:`+addr+`" style="color:#00a9c0;">`+addr+`</a>`)
		}
	}
	return strings.Join(links, " &middot; ")
}

func buildBanEmailHTML(name, reason, supportEmail string) string {
	reasonBlock := ""
	if reason != "" {
		reasonBlock = `
          <table cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;background:#fff1f2;border-radius:12px;padding:16px 20px;width:100%;">
            <tr>
              <td>
                <p style="margin:0;font-size:13px;color:#c0392b;font-weight:700;">Motif :</p>
                <p style="margin:4px 0 0;font-size:14px;color:#0e2a2f;">` + reason + `</p>
              </td>
            </tr>
          </table>`
	}

	return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Compte banni</title>
</head>
<body style="margin:0;padding:0;background:#edf6f7;font-family:Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background:#edf6f7;padding:48px 16px;">
  <tr><td align="center">
    <table width="560" cellpadding="0" cellspacing="0" role="presentation" style="max-width:560px;width:100%;">
      <tr>
        <td align="center" style="padding-bottom:28px;">
          <span style="font-size:32px;font-weight:900;color:#00a9c0;letter-spacing:-1px;font-family:Arial,sans-serif;">Breezy</span>
        </td>
      </tr>
      <tr>
        <td style="background:#ffffff;border-radius:24px;padding:48px;box-shadow:0 4px 24px rgba(0,169,192,0.12);">
          <h1 style="margin:0 0 8px;font-size:24px;font-weight:700;color:#c0392b;line-height:1.3;">
            Compte banni
          </h1>
          <p style="margin:0 0 20px;font-size:15px;color:#5a8a96;line-height:1.7;">
            Bonjour <strong style="color:#0e2a2f;">` + name + `</strong>,
          </p>
          <p style="margin:0 0 20px;font-size:15px;color:#5a8a96;line-height:1.7;">
            Nous t'informons que ton compte Breezy a ete <strong style="color:#c0392b;">banni definitivement</strong>.
          </p>` +
		reasonBlock + `
          <p style="margin:0 0 28px;font-size:15px;color:#5a8a96;line-height:1.7;">
            Si tu penses qu'il s'agit d'une erreur, contacte notre equipe :<br>
            ` + supportLinks(supportEmail) + `
          </p>
          <hr style="border:none;border-top:1px solid #e4eef0;margin:0 0 24px;">
          <p style="margin:0;font-size:12px;color:#a8bfc4;line-height:1.7;">
            Cet e-mail a ete envoye automatiquement par l'equipe de moderation Breezy.
          </p>
        </td>
      </tr>
      <tr>
        <td align="center" style="padding:24px 0 0;">
          <p style="margin:0;font-size:12px;color:#a8bfc4;">&copy; 2026 Breezy &middot; Reseau social leger</p>
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`
}

func buildSuspensionEmailHTML(name, reason, untilStr, supportEmail string) string {
	reasonBlock := ""
	if reason != "" {
		reasonBlock = `
          <table cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;background:#fff8f0;border-radius:12px;padding:16px 20px;width:100%;">
            <tr>
              <td>
                <p style="margin:0;font-size:13px;color:#e67e22;font-weight:700;">Motif :</p>
                <p style="margin:4px 0 0;font-size:14px;color:#0e2a2f;">` + reason + `</p>
              </td>
            </tr>
          </table>`
	}

	return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Compte suspendu</title>
</head>
<body style="margin:0;padding:0;background:#edf6f7;font-family:Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background:#edf6f7;padding:48px 16px;">
  <tr><td align="center">
    <table width="560" cellpadding="0" cellspacing="0" role="presentation" style="max-width:560px;width:100%;">
      <tr>
        <td align="center" style="padding-bottom:28px;">
          <span style="font-size:32px;font-weight:900;color:#00a9c0;letter-spacing:-1px;font-family:Arial,sans-serif;">Breezy</span>
        </td>
      </tr>
      <tr>
        <td style="background:#ffffff;border-radius:24px;padding:48px;box-shadow:0 4px 24px rgba(0,169,192,0.12);">
          <h1 style="margin:0 0 8px;font-size:24px;font-weight:700;color:#e67e22;line-height:1.3;">
            Compte suspendu temporairement
          </h1>
          <p style="margin:0 0 20px;font-size:15px;color:#5a8a96;line-height:1.7;">
            Bonjour <strong style="color:#0e2a2f;">` + name + `</strong>,
          </p>
          <p style="margin:0 0 20px;font-size:15px;color:#5a8a96;line-height:1.7;">
            Ton compte Breezy a ete <strong style="color:#e67e22;">suspendu temporairement</strong>.
          </p>
          <table cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;background:#fff8f0;border-radius:12px;padding:16px 20px;width:100%;">
            <tr>
              <td>
                <p style="margin:0;font-size:14px;color:#0e2a2f;font-weight:700;">Suspendu jusqu'au :</p>
                <p style="margin:4px 0 0;font-size:16px;color:#e67e22;font-weight:700;">` + untilStr + `</p>
              </td>
            </tr>
          </table>` +
		reasonBlock + `
          <p style="margin:0 0 20px;font-size:15px;color:#5a8a96;line-height:1.7;">
            Pendant cette periode, tu ne pourras pas te connecter ni publier de contenu.<br>
            Ta suspension sera levee <strong>automatiquement</strong> a l'echeance.
          </p>
          <p style="margin:0 0 28px;font-size:15px;color:#5a8a96;line-height:1.7;">
            Si tu penses qu'il s'agit d'une erreur, contacte notre equipe :<br>
            ` + supportLinks(supportEmail) + `
          </p>
          <hr style="border:none;border-top:1px solid #e4eef0;margin:0 0 24px;">
          <p style="margin:0;font-size:12px;color:#a8bfc4;line-height:1.7;">
            Cet e-mail a ete envoye automatiquement par l'equipe de moderation Breezy.
          </p>
        </td>
      </tr>
      <tr>
        <td align="center" style="padding:24px 0 0;">
          <p style="margin:0;font-size:12px;color:#a8bfc4;">&copy; 2026 Breezy &middot; Reseau social leger</p>
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`
}
