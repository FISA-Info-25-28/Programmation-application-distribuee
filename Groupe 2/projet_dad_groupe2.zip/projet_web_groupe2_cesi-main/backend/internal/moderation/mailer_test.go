package moderation

import (
	"strings"
	"testing"
	"time"
)

func TestSupportLinks(t *testing.T) {
	got := supportLinks(" help@example.com, ,moderation@example.com ")
	if !strings.Contains(got, `mailto:help@example.com`) || !strings.Contains(got, `mailto:moderation@example.com`) {
		t.Fatalf("supportLinks() = %q, want mailto links", got)
	}
	if strings.Contains(got, `mailto: `) {
		t.Fatalf("supportLinks() = %q, should ignore blank addresses", got)
	}
}

func TestNewSanctionMailerFromEnv(t *testing.T) {
	t.Setenv("SMTP_ENABLED", "false")
	if got := newSanctionMailerFromEnv(); got != nil {
		t.Fatalf("newSanctionMailerFromEnv(disabled) = %T, want nil", got)
	}

	t.Setenv("SMTP_ENABLED", "true")
	t.Setenv("SMTP_PORT", "bad")
	t.Setenv("SMTP_HOST", "localhost")
	t.Setenv("SMTP_FROM", "moderation@example.com")
	t.Setenv("SUPPORT_EMAIL", "support@example.com")
	got := newSanctionMailerFromEnv()
	mailer, ok := got.(*smtpSanctionMailer)
	if !ok {
		t.Fatalf("newSanctionMailerFromEnv() = %T, want *smtpSanctionMailer", got)
	}
	if mailer.port != 1025 || mailer.host != "localhost" || mailer.from != "moderation@example.com" || mailer.supportEmail != "support@example.com" {
		t.Fatalf("mailer config = %+v, want env config with fallback port", mailer)
	}
}

func TestBuildModerationEmailHTML(t *testing.T) {
	ban := buildBanEmailHTML("Alice", "spam", "support@example.com")
	if !strings.Contains(ban, "Alice") || !strings.Contains(ban, "spam") || !strings.Contains(ban, "support@example.com") || !strings.Contains(ban, "Compte banni") {
		t.Fatalf("buildBanEmailHTML() missing expected content")
	}

	banWithoutReason := buildBanEmailHTML("Alice", "", "support@example.com")
	if strings.Contains(banWithoutReason, "Motif :") {
		t.Fatalf("buildBanEmailHTML(no reason) should not include reason block")
	}

	suspension := buildSuspensionEmailHTML("Bob", "abuse", "demain", "support@example.com")
	if !strings.Contains(suspension, "Bob") || !strings.Contains(suspension, "abuse") || !strings.Contains(suspension, "demain") || !strings.Contains(suspension, "Compte suspendu") {
		t.Fatalf("buildSuspensionEmailHTML() missing expected content")
	}
}

func TestSanctionMailerSendFailures(t *testing.T) {
	mailer := &smtpSanctionMailer{
		host:         "127.0.0.1",
		port:         1,
		from:         "moderation@example.com",
		supportEmail: "support@example.com,appeal@example.com",
	}

	if err := mailer.SendBanEmail("to@example.com", "", "spam"); err == nil {
		t.Fatal("SendBanEmail() expected SMTP connection error")
	}
	if err := mailer.SendSuspensionEmail("to@example.com", "", "", time.Now().Add(time.Hour)); err == nil {
		t.Fatal("SendSuspensionEmail() expected SMTP connection error")
	}
	if err := mailer.SendSuspensionEmail("to@example.com", "Bob", "spam", time.Now().Add(time.Hour)); err == nil {
		t.Fatal("SendSuspensionEmail(with reason) expected SMTP connection error")
	}

	authMailer := &smtpSanctionMailer{
		host:         "127.0.0.1",
		port:         1,
		username:     "user",
		password:     "pass",
		from:         "moderation@example.com",
		supportEmail: "support@example.com",
	}
	if err := authMailer.SendBanEmail("to@example.com", "Alice", ""); err == nil {
		t.Fatal("SendBanEmail(auth) expected SMTP connection error")
	}
}
