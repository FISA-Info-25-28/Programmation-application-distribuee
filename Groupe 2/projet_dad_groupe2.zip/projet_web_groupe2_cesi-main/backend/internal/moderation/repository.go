package moderation

import (
	"context"
	"errors"
	"time"

	"breezy/backend/internal/models"
	"breezy/backend/internal/sanction"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

const reportStatusPending = "PENDING"

var (
	ErrAlreadyReported = errors.New("post already reported by profile")
	// ErrCannotTargetSelf signale qu'un moderateur tente de se moderer lui-meme.
	ErrCannotTargetSelf = errors.New("cannot moderate own account")
	// ErrInsufficientRoleOverTarget signale qu'un moderateur vise un compte qu'il
	// n'a pas le droit de moderer (un ADMIN ne peut etre vise que par un ADMIN).
	ErrInsufficientRoleOverTarget = errors.New("insufficient role over target account")
)

// targetAccount regroupe les infos du compte vise resolues depuis un profileId.
type targetAccount struct {
	AccountID   uuid.UUID
	Role        string
	Email       string
	DisplayName string
}

type Repository struct {
	db *gorm.DB
}

type EnrichedReport struct {
	models.Report
	ReporterUsername    string
	ReporterDisplayName string
	ReportedPostContent string
}

func NewRepository(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

func (r *Repository) ListReports(ctx context.Context) ([]EnrichedReport, error) {
	var reports []EnrichedReport
	err := r.db.WithContext(ctx).
		Table("moderation.reports r").
		Select(`
			r.*,
			reporter.username AS reporter_username,
			COALESCE(reporter.display_name, reporter.username) AS reporter_display_name,
			reported_post.content AS reported_post_content
		`).
		Joins("LEFT JOIN profiles.profiles reporter ON reporter.id = r.reporter_id").
		Joins("LEFT JOIN posts.posts reported_post ON reported_post.id = r.reported_post_id").
		Order("r.created_at DESC").
		Find(&reports).
		Error

	return reports, err
}

func (r *Repository) FindEnrichedReport(ctx context.Context, reportID uuid.UUID) (EnrichedReport, error) {
	var report EnrichedReport
	err := r.db.WithContext(ctx).
		Table("moderation.reports r").
		Select(`
			r.*,
			reporter.username AS reporter_username,
			COALESCE(reporter.display_name, reporter.username) AS reporter_display_name,
			reported_post.content AS reported_post_content
		`).
		Joins("LEFT JOIN profiles.profiles reporter ON reporter.id = r.reporter_id").
		Joins("LEFT JOIN posts.posts reported_post ON reported_post.id = r.reported_post_id").
		Where("r.id = ?", reportID).
		Limit(1).
		Scan(&report).
		Error
	if err == nil && report.ID == uuid.Nil {
		err = gorm.ErrRecordNotFound
	}

	return report, err
}

func (r *Repository) FindProfileIDByAccountID(ctx context.Context, accountID uuid.UUID) (uuid.UUID, error) {
	var profile models.Profile
	err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("account_id = ?", accountID).
		First(&profile).
		Error
	if err != nil {
		return uuid.Nil, err
	}

	return profile.ID, nil
}

// FindAccountByProfileID resout le compte auth.accounts derriere un profil.
// Entree : ctx, profileID.
// Sortie : valeurs retour de la fonction.
// profil n'existe pas ou n'est rattache a aucun compte.
func (r *Repository) FindAccountByProfileID(ctx context.Context, profileID uuid.UUID) (targetAccount, error) {
	var target targetAccount
	err := r.db.WithContext(ctx).
		Table("profiles.profiles p").
		Select("a.id AS account_id, a.role AS role, a.email AS email, COALESCE(p.display_name, p.username) AS display_name").
		Joins("JOIN auth.accounts a ON a.id = p.account_id").
		Where("p.id = ?", profileID).
		Limit(1).
		Scan(&target).
		Error
	if err == nil && target.AccountID == uuid.Nil {
		err = gorm.ErrRecordNotFound
	}

	return target, err
}

// moderateUser applique une action de moderation sur le compte derriere profileID.
// Entree : ctx, profileID, actorAccountID, actorRole, status, until.
// l'action, status a appliquer ('BANNED' ou 'SUSPENDED') et until (date de fin de
// suspension, nil pour un ban). Sortie : targetAccount resolu ou une erreur
// (gorm.ErrRecordNotFound, ErrCannotTargetSelf, ErrInsufficientRoleOverTarget).
// Sortie : valeurs retour de la fonction.
func (r *Repository) moderateUser(ctx context.Context, profileID, actorAccountID uuid.UUID, actorRole, status string, until *time.Time) (targetAccount, error) {
	target, err := r.FindAccountByProfileID(ctx, profileID)
	if err != nil {
		return targetAccount{}, err
	}
	if target.AccountID == actorAccountID {
		return targetAccount{}, ErrCannotTargetSelf
	}
	if target.Role == "ADMIN" && actorRole != "ADMIN" {
		return targetAccount{}, ErrInsufficientRoleOverTarget
	}

	// Tout est applique dans une transaction : changement de statut + effets de
	// la sanction (anonymisation du profil et bascule des posts en PRIVATE), ou
	// leur restauration si l'on revient en ACTIVE.
	err = r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.
			Table("auth.accounts").
			Where("id = ?", target.AccountID).
			Updates(map[string]any{
				"status":          status,
				"suspended_until": until,
				"updated_at":      time.Now().UTC(),
			}).
			Error; err != nil {
			return err
		}

		if status == "ACTIVE" {
			return sanction.Lift(ctx, tx, target.AccountID)
		}
		return sanction.Apply(ctx, tx, target.AccountID)
	})

	return target, err
}

// BanUser bannit definitivement le compte derriere profileID.
// Entree : ctx, profileID, actorAccountID, actorRole.
// Sortie : valeurs retour de la fonction.
func (r *Repository) BanUser(ctx context.Context, profileID, actorAccountID uuid.UUID, actorRole string) (targetAccount, error) {
	return r.moderateUser(ctx, profileID, actorAccountID, actorRole, "BANNED", nil)
}

// SuspendUser suspend temporairement le compte derriere profileID jusqu'a until.
// Entree : ctx, profileID, actorAccountID, actorRole, until.
// Sortie : valeurs retour de la fonction.
func (r *Repository) SuspendUser(ctx context.Context, profileID, actorAccountID uuid.UUID, actorRole string, until time.Time) (targetAccount, error) {
	return r.moderateUser(ctx, profileID, actorAccountID, actorRole, "SUSPENDED", &until)
}

// LiftModeration leve une sanction (suspension ou bannissement) : remet le compte
// derriere profileID en statut ACTIVE et efface la date de fin de suspension.
// Entree : ctx, profileID, actorAccountID, actorRole.
// Sortie : valeurs retour de la fonction.
func (r *Repository) LiftModeration(ctx context.Context, profileID, actorAccountID uuid.UUID, actorRole string) (targetAccount, error) {
	return r.moderateUser(ctx, profileID, actorAccountID, actorRole, "ACTIVE", nil)
}

// ModeratedAccount decrit un compte actuellement sanctionne (banni ou suspendu),
// enrichi des infos de profil necessaires a l'affichage cote moderation.
type ModeratedAccount struct {
	ProfileID      uuid.UUID
	AccountID      uuid.UUID
	Username       string
	DisplayName    string
	Role           string
	Status         string
	SuspendedUntil *time.Time
	UpdatedAt      time.Time
}

// ListModeratedAccounts liste les comptes sous sanction active : tous les bannis,
// et les suspendus dont la date de fin n'est pas encore passee (les suspensions
// expirees sont considerees comme levees et donc exclues). Tri du plus recent au
// plus ancien.
// Entree : ctx.
// Sortie : valeurs retour de la fonction.
func (r *Repository) ListModeratedAccounts(ctx context.Context) ([]ModeratedAccount, error) {
	var rows []ModeratedAccount
	err := r.db.WithContext(ctx).
		Table("auth.accounts a").
		Select(`
			p.id AS profile_id,
			a.id AS account_id,
			COALESCE(p.original_username, p.username) AS username,
			COALESCE(p.original_display_name, p.original_username, p.display_name, p.username) AS display_name,
			a.role AS role,
			a.status AS status,
			a.updated_at AS updated_at
		`).
		Joins("JOIN profiles.profiles p ON p.account_id = a.id").
		Where("a.status IN ?", []string{"BANNED", "SUSPENDED"}).
		Order("a.updated_at DESC").
		Scan(&rows).
		Error

	return rows, err
}

func (r *Repository) CreatePostReport(ctx context.Context, report *models.Report) error {
	if err := r.ensureModerationNotificationType(ctx); err != nil {
		return err
	}

	return r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var count int64
		if err := tx.Table("moderation.reports").
			Where("reporter_id = ? AND reported_post_id = ?", report.ReporterID, report.ReportedPostID).
			Count(&count).
			Error; err != nil {
			return err
		}
		if count > 0 {
			return ErrAlreadyReported
		}

		if err := tx.Table("moderation.reports").Create(report).Error; err != nil {
			return err
		}

		return r.createModerationNotifications(ctx, tx, report)
	})
}

func (r *Repository) UpdateReportStatus(ctx context.Context, id, reviewerID uuid.UUID, status string) (models.Report, error) {
	now := time.Now().UTC()
	var report models.Report

	err := r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Table("moderation.reports").First(&report, "id = ?", id).Error; err != nil {
			return err
		}

		report.Status = status
		report.ReviewedBy = &reviewerID
		report.ReviewedAt = &now
		if err := tx.Table("moderation.reports").Save(&report).Error; err != nil {
			return err
		}

		if status == "REJECTED" && report.ReportedPostID != nil {
			return tx.Table("posts.posts").
				Where("id = ? AND deleted_at IS NULL", *report.ReportedPostID).
				Updates(map[string]any{
					"deleted_at": now,
					"updated_at": now,
				}).
				Error
		}
		if status == "RESOLVED" && report.ReportedPostID != nil {
			return tx.Table("posts.posts").
				Where("id = ?", *report.ReportedPostID).
				Updates(map[string]any{
					"deleted_at": nil,
					"updated_at": now,
				}).
				Error
		}

		return nil
	})

	return report, err
}

func (r *Repository) ensureModerationNotificationType(ctx context.Context) error {
	return r.db.WithContext(ctx).
		Exec("ALTER TYPE social.notification_type ADD VALUE IF NOT EXISTS 'MODERATION_REPORT'").
		Error
}

func (r *Repository) createModerationNotifications(ctx context.Context, tx *gorm.DB, report *models.Report) error {
	var recipients []models.Profile
	if err := tx.WithContext(ctx).
		Table("profiles.profiles p").
		Select("p.id").
		Joins("JOIN auth.accounts a ON a.id = p.account_id").
		Where("a.role IN ? AND a.status = ? AND p.id <> ?", []string{"MODERATOR", "ADMIN"}, "ACTIVE", report.ReporterID).
		Find(&recipients).
		Error; err != nil {
		return err
	}

	for _, recipient := range recipients {
		notification := models.Notification{
			RecipientID: recipient.ID,
			ActorID:     report.ReporterID,
			Type:        "MODERATION_REPORT",
			PostID:      report.ReportedPostID,
		}
		if err := tx.WithContext(ctx).Table("social.notifications").Create(&notification).Error; err != nil {
			return err
		}
	}

	return nil
}
