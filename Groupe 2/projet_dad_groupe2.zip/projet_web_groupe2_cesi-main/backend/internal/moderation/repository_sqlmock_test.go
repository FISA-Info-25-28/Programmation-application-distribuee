package moderation

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"regexp"
	"strings"
	"testing"
	"time"

	"breezy/backend/internal/middleware"
	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// newModerationMockDB cree un *gorm.DB adosse a un sqlmock reel (pas en DryRun),
// pour pouvoir simuler des resultats de requetes et donc exercer les branches
// metier (compteurs, comparaisons de roles, etc.) que le DryRun ne declenche pas.
func newModerationMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })

	db, err := gorm.Open(postgres.New(postgres.Config{
		Conn:                 sqlDB,
		PreferSimpleProtocol: true,
	}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

type fakeSanctionMailer struct {
	banCalls      int
	suspendCalls  int
	banErr        error
	suspendErr    error
	lastBanEmail  string
	lastSuspEmail string
}

func (f *fakeSanctionMailer) SendBanEmail(to, displayName, reason string) error {
	f.banCalls++
	f.lastBanEmail = to
	return f.banErr
}

func (f *fakeSanctionMailer) SendSuspensionEmail(to, displayName, reason string, until time.Time) error {
	f.suspendCalls++
	f.lastSuspEmail = to
	return f.suspendErr
}

// --- Repository.FindEnrichedReport / FindProfileIDByAccountID / FindAccountByProfileID ---

func TestFindEnrichedReportNotFound(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	reportID := uuid.New()

	mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"id"}))

	_, err := repo.FindEnrichedReport(context.Background(), reportID)
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("FindEnrichedReport() error = %v, want gorm.ErrRecordNotFound", err)
	}
}

func TestFindEnrichedReportFound(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	reportID := uuid.New()
	reporterID := uuid.New()

	rows := sqlmock.NewRows([]string{"id", "reporter_id", "reason", "status", "created_at", "reporter_username", "reporter_display_name", "reported_post_content"}).
		AddRow(reportID, reporterID, "spam", "PENDING", time.Now(), "alice", "Alice", "bad content")
	mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

	report, err := repo.FindEnrichedReport(context.Background(), reportID)
	if err != nil {
		t.Fatalf("FindEnrichedReport() unexpected error: %v", err)
	}
	if report.ID != reportID || report.ReporterUsername != "alice" {
		t.Fatalf("FindEnrichedReport() = %+v, want matching report", report)
	}
}

func TestFindProfileIDByAccountIDFound(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	accountID := uuid.New()
	profileID := uuid.New()

	rows := sqlmock.NewRows([]string{"id", "account_id", "username"}).
		AddRow(profileID, accountID, "alice")
	mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

	got, err := repo.FindProfileIDByAccountID(context.Background(), accountID)
	if err != nil || got != profileID {
		t.Fatalf("FindProfileIDByAccountID() = %v, %v, want %v, nil", got, err, profileID)
	}
}

func TestFindProfileIDByAccountIDNotFound(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"id"}))

	_, err := repo.FindProfileIDByAccountID(context.Background(), accountID)
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("FindProfileIDByAccountID() error = %v, want gorm.ErrRecordNotFound", err)
	}
}

func TestFindAccountByProfileIDFound(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	accountID := uuid.New()

	rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
		AddRow(accountID, "USER", "user@example.com", "Alice")
	mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

	got, err := repo.FindAccountByProfileID(context.Background(), profileID)
	if err != nil || got.AccountID != accountID || got.Role != "USER" {
		t.Fatalf("FindAccountByProfileID() = %+v, %v", got, err)
	}
}

func TestFindAccountByProfileIDNotFound(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()

	mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"account_id"}))

	_, err := repo.FindAccountByProfileID(context.Background(), profileID)
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("FindAccountByProfileID() error = %v, want gorm.ErrRecordNotFound", err)
	}
}

// --- Repository.moderateUser (via BanUser / SuspendUser / LiftModeration) ---

func TestModerateUserTargetLookupError(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	actorID := uuid.New()

	mock.ExpectQuery(`SELECT`).WillReturnError(assertErr("lookup failed"))

	_, err := repo.BanUser(context.Background(), profileID, actorID, "ADMIN")
	if err == nil {
		t.Fatal("BanUser() expected lookup error")
	}
}

func TestModerateUserCannotTargetSelf(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	actorID := uuid.New()

	rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
		AddRow(actorID, "USER", "self@example.com", "Self")
	mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

	_, err := repo.BanUser(context.Background(), profileID, actorID, "ADMIN")
	if !errors.Is(err, ErrCannotTargetSelf) {
		t.Fatalf("BanUser() error = %v, want ErrCannotTargetSelf", err)
	}
}

func TestModerateUserInsufficientRole(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	actorID := uuid.New()
	targetAccountID := uuid.New()

	rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
		AddRow(targetAccountID, "ADMIN", "admin@example.com", "Admin")
	mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

	_, err := repo.BanUser(context.Background(), profileID, actorID, "MODERATOR")
	if !errors.Is(err, ErrInsufficientRoleOverTarget) {
		t.Fatalf("BanUser() error = %v, want ErrInsufficientRoleOverTarget", err)
	}
}

func TestModerateUserBanSuccess(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	actorID := uuid.New()
	targetAccountID := uuid.New()

	rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
		AddRow(targetAccountID, "USER", "target@example.com", "Target")
	mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "auth"\."accounts"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectExec(`UPDATE profiles\.profiles`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectExec(`UPDATE posts\.posts`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectCommit()

	target, err := repo.BanUser(context.Background(), profileID, actorID, "ADMIN")
	if err != nil {
		t.Fatalf("BanUser() unexpected error: %v", err)
	}
	if target.AccountID != targetAccountID || target.Email != "target@example.com" {
		t.Fatalf("BanUser() = %+v, want resolved target", target)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestModerateUserSuspendSuccess(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	actorID := uuid.New()
	targetAccountID := uuid.New()
	until := time.Now().UTC().Add(time.Hour)

	rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
		AddRow(targetAccountID, "USER", "target@example.com", "Target")
	mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "auth"\."accounts"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectExec(`UPDATE profiles\.profiles`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectExec(`UPDATE posts\.posts`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectCommit()

	target, err := repo.SuspendUser(context.Background(), profileID, actorID, "MODERATOR", until)
	if err != nil {
		t.Fatalf("SuspendUser() unexpected error: %v", err)
	}
	if target.AccountID != targetAccountID {
		t.Fatalf("SuspendUser() = %+v, want resolved target", target)
	}
}

func TestModerateUserLiftSuccess(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	actorID := uuid.New()
	targetAccountID := uuid.New()

	rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
		AddRow(targetAccountID, "USER", "target@example.com", "Target")
	mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "auth"\."accounts"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectExec(`UPDATE posts\.posts`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectExec(`UPDATE profiles\.profiles`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	target, err := repo.LiftModeration(context.Background(), profileID, actorID, "MODERATOR")
	if err != nil {
		t.Fatalf("LiftModeration() unexpected error: %v", err)
	}
	if target.AccountID != targetAccountID {
		t.Fatalf("LiftModeration() = %+v, want resolved target", target)
	}
}

func TestModerateUserTransactionError(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	actorID := uuid.New()
	targetAccountID := uuid.New()

	rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
		AddRow(targetAccountID, "USER", "target@example.com", "Target")
	mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

	mock.ExpectBegin()
	mock.ExpectExec(`UPDATE "auth"\."accounts"`).WillReturnError(assertErr("update failed"))
	mock.ExpectRollback()

	_, err := repo.BanUser(context.Background(), profileID, actorID, "ADMIN")
	if err == nil {
		t.Fatal("BanUser() expected transaction error")
	}
}

// --- Repository.CreatePostReport ---

func TestCreatePostReportNotificationTypeError(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()

	mock.ExpectExec(`ALTER TYPE`).WillReturnError(assertErr("alter type failed"))

	err := repo.CreatePostReport(context.Background(), &models.Report{ReporterID: uuid.New(), ReportedPostID: &postID, Reason: "spam"})
	if err == nil {
		t.Fatal("CreatePostReport() expected ensureModerationNotificationType error")
	}
}

func TestCreatePostReportAlreadyReported(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()
	reporterID := uuid.New()

	mock.ExpectExec(`ALTER TYPE`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT count`).WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(1))
	mock.ExpectRollback()

	err := repo.CreatePostReport(context.Background(), &models.Report{ReporterID: reporterID, ReportedPostID: &postID, Reason: "spam"})
	if !errors.Is(err, ErrAlreadyReported) {
		t.Fatalf("CreatePostReport() error = %v, want ErrAlreadyReported", err)
	}
}

func TestCreatePostReportCountError(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()
	reporterID := uuid.New()

	mock.ExpectExec(`ALTER TYPE`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT count`).WillReturnError(assertErr("count failed"))
	mock.ExpectRollback()

	err := repo.CreatePostReport(context.Background(), &models.Report{ReporterID: reporterID, ReportedPostID: &postID, Reason: "spam"})
	if err == nil {
		t.Fatal("CreatePostReport() expected count error")
	}
}

func TestCreatePostReportCreateError(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()
	reporterID := uuid.New()

	mock.ExpectExec(`ALTER TYPE`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT count`).WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`INSERT INTO "moderation"\."reports"`).WillReturnError(assertErr("insert failed"))
	mock.ExpectRollback()

	err := repo.CreatePostReport(context.Background(), &models.Report{ReporterID: reporterID, ReportedPostID: &postID, Reason: "spam"})
	if err == nil {
		t.Fatal("CreatePostReport() expected insert error")
	}
}

func TestCreatePostReportSuccessWithNotifications(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()
	reporterID := uuid.New()
	modProfileID := uuid.New()
	reportID := uuid.New()

	mock.ExpectExec(`ALTER TYPE`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT count`).WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`INSERT INTO "moderation"\."reports"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(reportID))
	mock.ExpectQuery(`SELECT p\.id`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(modProfileID))
	mock.ExpectQuery(`INSERT INTO "social"\."notifications"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	report := &models.Report{ReporterID: reporterID, ReportedPostID: &postID, Reason: "spam"}
	if err := repo.CreatePostReport(context.Background(), report); err != nil {
		t.Fatalf("CreatePostReport() unexpected error: %v", err)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestCreatePostReportNotificationsRecipientsError(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()
	reporterID := uuid.New()
	reportID := uuid.New()

	mock.ExpectExec(`ALTER TYPE`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT count`).WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`INSERT INTO "moderation"\."reports"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(reportID))
	mock.ExpectQuery(`SELECT p\.id`).WillReturnError(assertErr("recipients failed"))
	mock.ExpectRollback()

	report := &models.Report{ReporterID: reporterID, ReportedPostID: &postID, Reason: "spam"}
	if err := repo.CreatePostReport(context.Background(), report); err == nil {
		t.Fatal("CreatePostReport() expected recipients lookup error")
	}
}

func TestCreatePostReportNotificationInsertError(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()
	reporterID := uuid.New()
	modProfileID := uuid.New()
	reportID := uuid.New()

	mock.ExpectExec(`ALTER TYPE`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT count`).WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`INSERT INTO "moderation"\."reports"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(reportID))
	mock.ExpectQuery(`SELECT p\.id`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(modProfileID))
	mock.ExpectQuery(`INSERT INTO "social"\."notifications"`).WillReturnError(assertErr("notif insert failed"))
	mock.ExpectRollback()

	report := &models.Report{ReporterID: reporterID, ReportedPostID: &postID, Reason: "spam"}
	if err := repo.CreatePostReport(context.Background(), report); err == nil {
		t.Fatal("CreatePostReport() expected notification insert error")
	}
}

// --- Repository.UpdateReportStatus ---

func TestUpdateReportStatusNotFound(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	reportID := uuid.New()
	reviewerID := uuid.New()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "moderation"\."reports"`).WillReturnRows(sqlmock.NewRows([]string{"id"}))
	mock.ExpectRollback()

	_, err := repo.UpdateReportStatus(context.Background(), reportID, reviewerID, "REVIEWED")
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("UpdateReportStatus() error = %v, want gorm.ErrRecordNotFound", err)
	}
}

func TestUpdateReportStatusReviewedSuccess(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	reportID := uuid.New()
	reviewerID := uuid.New()
	reporterID := uuid.New()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "moderation"\."reports"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "reporter_id", "reason", "status", "created_at"}).
			AddRow(reportID, reporterID, "spam", "PENDING", time.Now()))
	mock.ExpectExec(`UPDATE "moderation"\."reports"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	report, err := repo.UpdateReportStatus(context.Background(), reportID, reviewerID, "REVIEWED")
	if err != nil {
		t.Fatalf("UpdateReportStatus() unexpected error: %v", err)
	}
	if report.Status != "REVIEWED" || report.ReviewedBy == nil || *report.ReviewedBy != reviewerID {
		t.Fatalf("UpdateReportStatus() = %+v, want REVIEWED with reviewer set", report)
	}
}

func TestUpdateReportStatusRejectedSoftDeletesPost(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	reportID := uuid.New()
	reviewerID := uuid.New()
	reporterID := uuid.New()
	postID := uuid.New()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "moderation"\."reports"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "reporter_id", "reported_post_id", "reason", "status", "created_at"}).
			AddRow(reportID, reporterID, postID, "spam", "PENDING", time.Now()))
	mock.ExpectExec(`UPDATE "moderation"\."reports"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectExec(`UPDATE "posts"\."posts"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	report, err := repo.UpdateReportStatus(context.Background(), reportID, reviewerID, "REJECTED")
	if err != nil {
		t.Fatalf("UpdateReportStatus() unexpected error: %v", err)
	}
	if report.Status != "REJECTED" {
		t.Fatalf("UpdateReportStatus() = %+v, want REJECTED", report)
	}
}

func TestUpdateReportStatusResolvedRestoresPost(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	reportID := uuid.New()
	reviewerID := uuid.New()
	reporterID := uuid.New()
	postID := uuid.New()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "moderation"\."reports"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "reporter_id", "reported_post_id", "reason", "status", "created_at"}).
			AddRow(reportID, reporterID, postID, "spam", "PENDING", time.Now()))
	mock.ExpectExec(`UPDATE "moderation"\."reports"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectExec(`UPDATE "posts"\."posts"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	report, err := repo.UpdateReportStatus(context.Background(), reportID, reviewerID, "RESOLVED")
	if err != nil {
		t.Fatalf("UpdateReportStatus() unexpected error: %v", err)
	}
	if report.Status != "RESOLVED" {
		t.Fatalf("UpdateReportStatus() = %+v, want RESOLVED", report)
	}
}

func TestUpdateReportStatusSaveError(t *testing.T) {
	db, mock := newModerationMockDB(t)
	repo := NewRepository(db)
	reportID := uuid.New()
	reviewerID := uuid.New()
	reporterID := uuid.New()

	mock.ExpectBegin()
	mock.ExpectQuery(`SELECT \* FROM "moderation"\."reports"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "reporter_id", "reason", "status", "created_at"}).
			AddRow(reportID, reporterID, "spam", "PENDING", time.Now()))
	mock.ExpectExec(`UPDATE "moderation"\."reports"`).WillReturnError(assertErr("save failed"))
	mock.ExpectRollback()

	_, err := repo.UpdateReportStatus(context.Background(), reportID, reviewerID, "REVIEWED")
	if err == nil {
		t.Fatal("UpdateReportStatus() expected save error")
	}
}

// --- Handler tests driven by a repository backed by real sqlmock rows ---

func newModerationTestHandler(db *gorm.DB, mailer sanctionMailer) *Handler {
	return &Handler{db: db, repo: NewRepository(db), mailer: mailer}
}

func withAccountAndRole(accountID uuid.UUID, role string) gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Set(middleware.ContextRole, role)
		c.Next()
	}
}

func TestHandlerListReportsSuccessAndFailure(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("success", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		rows := sqlmock.NewRows([]string{"id", "reporter_id", "reason", "status", "created_at"}).
			AddRow(uuid.New(), uuid.New(), "spam", "PENDING", time.Now())
		mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

		router := gin.New()
		router.GET("/reports", handler.ListReports)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/reports", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("ListReports() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("query error", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		mock.ExpectQuery(`SELECT`).WillReturnError(assertErr("boom"))

		router := gin.New()
		router.GET("/reports", handler.ListReports)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/reports", nil))
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("ListReports() status = %d, want 500", rec.Code)
		}
	})
}

func TestHandlerCreatePostReportFlows(t *testing.T) {
	gin.SetMode(gin.TestMode)
	postID := uuid.New()
	accountID := uuid.New()

	t.Run("invalid body", func(t *testing.T) {
		db, _ := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleUser))
		router.POST("/posts/:id/report", handler.CreatePostReport)
		req := httptest.NewRequest(http.MethodPost, "/posts/"+postID.String()+"/report", strings.NewReader(`{"reason":""}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("status = %d, want 400: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("missing account", func(t *testing.T) {
		db, _ := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		router := gin.New()
		router.POST("/posts/:id/report", handler.CreatePostReport)
		req := httptest.NewRequest(http.MethodPost, "/posts/"+postID.String()+"/report", strings.NewReader(`{"reason":"spam"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("reporter profile not found", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"id"}))

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleUser))
		router.POST("/posts/:id/report", handler.CreatePostReport)
		req := httptest.NewRequest(http.MethodPost, "/posts/"+postID.String()+"/report", strings.NewReader(`{"reason":"spam"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("reporter profile lookup error", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		mock.ExpectQuery(`SELECT`).WillReturnError(assertErr("boom"))

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleUser))
		router.POST("/posts/:id/report", handler.CreatePostReport)
		req := httptest.NewRequest(http.MethodPost, "/posts/"+postID.String()+"/report", strings.NewReader(`{"reason":"spam"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("already reported conflict", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		profileID := uuid.New()
		mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
		mock.ExpectExec(`ALTER TYPE`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT count`).WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(1))
		mock.ExpectRollback()

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleUser))
		router.POST("/posts/:id/report", handler.CreatePostReport)
		req := httptest.NewRequest(http.MethodPost, "/posts/"+postID.String()+"/report", strings.NewReader(`{"reason":"spam"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusConflict {
			t.Fatalf("status = %d, want 409: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("success", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		profileID := uuid.New()
		reportID := uuid.New()
		mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
		mock.ExpectExec(`ALTER TYPE`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT count`).WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
		mock.ExpectQuery(`INSERT INTO "moderation"\."reports"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(reportID))
		mock.ExpectQuery(`SELECT p\.id`).WillReturnRows(sqlmock.NewRows([]string{"id"}))
		mock.ExpectCommit()

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleUser))
		router.POST("/posts/:id/report", handler.CreatePostReport)
		req := httptest.NewRequest(http.MethodPost, "/posts/"+postID.String()+"/report", strings.NewReader(`{"reason":"spam"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusCreated {
			t.Fatalf("status = %d, want 201: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("creation internal error", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		profileID := uuid.New()
		mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
		mock.ExpectExec(`ALTER TYPE`).WillReturnError(assertErr("boom"))

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleUser))
		router.POST("/posts/:id/report", handler.CreatePostReport)
		req := httptest.NewRequest(http.MethodPost, "/posts/"+postID.String()+"/report", strings.NewReader(`{"reason":"spam"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}

func TestHandlerReviewReportFlows(t *testing.T) {
	gin.SetMode(gin.TestMode)
	reportID := uuid.New()
	accountID := uuid.New()

	t.Run("reviewer profile not found", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"id"}))

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.PATCH("/reports/:id", handler.ReviewReport)
		req := httptest.NewRequest(http.MethodPatch, "/reports/"+reportID.String(), strings.NewReader(`{"status":"RESOLVED"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("missing account", func(t *testing.T) {
		db, _ := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		router := gin.New()
		router.PATCH("/reports/:id", handler.ReviewReport)
		req := httptest.NewRequest(http.MethodPatch, "/reports/"+reportID.String(), strings.NewReader(`{"status":"RESOLVED"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("update not found", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		reviewerProfileID := uuid.New()
		mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(reviewerProfileID))
		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT \* FROM "moderation"\."reports"`).WillReturnRows(sqlmock.NewRows([]string{"id"}))
		mock.ExpectRollback()

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.PATCH("/reports/:id", handler.ReviewReport)
		req := httptest.NewRequest(http.MethodPatch, "/reports/"+reportID.String(), strings.NewReader(`{"status":"RESOLVED"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("success", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		reviewerProfileID := uuid.New()
		reporterID := uuid.New()
		mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(reviewerProfileID))
		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT \* FROM "moderation"\."reports"`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "reporter_id", "reason", "status", "created_at"}).
				AddRow(reportID, reporterID, "spam", "PENDING", time.Now()))
		mock.ExpectExec(`UPDATE "moderation"\."reports"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		mock.ExpectQuery(`SELECT`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "reporter_id", "reason", "status", "created_at"}).
				AddRow(reportID, reporterID, "spam", "RESOLVED", time.Now()))

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.PATCH("/reports/:id", handler.ReviewReport)
		req := httptest.NewRequest(http.MethodPatch, "/reports/"+reportID.String(), strings.NewReader(`{"status":"RESOLVED"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("enriched lookup failure after update", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		reviewerProfileID := uuid.New()
		reporterID := uuid.New()
		mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(reviewerProfileID))
		mock.ExpectBegin()
		mock.ExpectQuery(`SELECT \* FROM "moderation"\."reports"`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "reporter_id", "reason", "status", "created_at"}).
				AddRow(reportID, reporterID, "spam", "PENDING", time.Now()))
		mock.ExpectExec(`UPDATE "moderation"\."reports"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		mock.ExpectQuery(`SELECT`).WillReturnError(assertErr("boom"))

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.PATCH("/reports/:id", handler.ReviewReport)
		req := httptest.NewRequest(http.MethodPatch, "/reports/"+reportID.String(), strings.NewReader(`{"status":"RESOLVED"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}

func TestHandlerBanUserFlows(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()

	t.Run("forbidden self", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
			AddRow(accountID, "USER", "self@example.com", "Self")
		mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.POST("/users/:profileId/ban", handler.BanUser)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/ban", nil)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("forbidden insufficient role", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		targetAccountID := uuid.New()
		rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
			AddRow(targetAccountID, "ADMIN", "admin@example.com", "Admin")
		mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.POST("/users/:profileId/ban", handler.BanUser)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/ban", nil)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("target not found", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"account_id"}))

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.POST("/users/:profileId/ban", handler.BanUser)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/ban", nil)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("success sends ban email", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		mailer := &fakeSanctionMailer{}
		handler := newModerationTestHandler(db, mailer)
		targetAccountID := uuid.New()
		rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
			AddRow(targetAccountID, "USER", "target@example.com", "Target")
		mock.ExpectQuery(`SELECT`).WillReturnRows(rows)
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "auth"\."accounts"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`UPDATE profiles\.profiles`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`UPDATE posts\.posts`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectCommit()

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.POST("/users/:profileId/ban", handler.BanUser)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/ban", strings.NewReader(`{"reason":"abuse"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
		}

		deadline := time.Now().Add(time.Second)
		for mailer.banCalls == 0 && time.Now().Before(deadline) {
			time.Sleep(time.Millisecond)
		}
		if mailer.banCalls != 1 {
			t.Fatalf("mailer.banCalls = %d, want 1", mailer.banCalls)
		}
	})

	t.Run("ban email error is logged not fatal", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		mailer := &fakeSanctionMailer{banErr: assertErr("smtp down")}
		handler := newModerationTestHandler(db, mailer)
		targetAccountID := uuid.New()
		rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
			AddRow(targetAccountID, "USER", "target@example.com", "Target")
		mock.ExpectQuery(`SELECT`).WillReturnRows(rows)
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "auth"\."accounts"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`UPDATE profiles\.profiles`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`UPDATE posts\.posts`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectCommit()

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.POST("/users/:profileId/ban", handler.BanUser)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/ban", strings.NewReader(`{"reason":"abuse"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
		}

		deadline := time.Now().Add(time.Second)
		for mailer.banCalls == 0 && time.Now().Before(deadline) {
			time.Sleep(time.Millisecond)
		}
		if mailer.banCalls != 1 {
			t.Fatalf("mailer.banCalls = %d, want 1", mailer.banCalls)
		}
	})

	t.Run("missing account returns 500", func(t *testing.T) {
		db, _ := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)

		router := gin.New()
		router.POST("/users/:profileId/ban", handler.BanUser)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/ban", nil)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}

func TestHandlerSuspendUserFlows(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()

	t.Run("repository error maps to 500", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		mock.ExpectQuery(`SELECT`).WillReturnError(assertErr("boom"))

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.POST("/users/:profileId/suspend", handler.SuspendUser)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/suspend", strings.NewReader(`{"durationHours":24}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("success sends suspension email", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		mailer := &fakeSanctionMailer{}
		handler := newModerationTestHandler(db, mailer)
		targetAccountID := uuid.New()
		rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
			AddRow(targetAccountID, "USER", "target@example.com", "Target")
		mock.ExpectQuery(`SELECT`).WillReturnRows(rows)
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "auth"\."accounts"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`UPDATE profiles\.profiles`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`UPDATE posts\.posts`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectCommit()

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.POST("/users/:profileId/suspend", handler.SuspendUser)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/suspend", strings.NewReader(`{"durationHours":24,"reason":"abuse"}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
		}

		deadline := time.Now().Add(time.Second)
		for mailer.suspendCalls == 0 && time.Now().Before(deadline) {
			time.Sleep(time.Millisecond)
		}
		if mailer.suspendCalls != 1 {
			t.Fatalf("mailer.suspendCalls = %d, want 1", mailer.suspendCalls)
		}
	})

	t.Run("mailer error is logged not fatal", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		mailer := &fakeSanctionMailer{suspendErr: assertErr("smtp down")}
		handler := newModerationTestHandler(db, mailer)
		targetAccountID := uuid.New()
		rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
			AddRow(targetAccountID, "USER", "target@example.com", "Target")
		mock.ExpectQuery(`SELECT`).WillReturnRows(rows)
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "auth"\."accounts"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`UPDATE profiles\.profiles`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`UPDATE posts\.posts`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectCommit()

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.POST("/users/:profileId/suspend", handler.SuspendUser)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/suspend", strings.NewReader(`{"durationHours":1}`))
		req.Header.Set("Content-Type", "application/json")
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
		}

		deadline := time.Now().Add(time.Second)
		for mailer.suspendCalls == 0 && time.Now().Before(deadline) {
			time.Sleep(time.Millisecond)
		}
		if mailer.suspendCalls != 1 {
			t.Fatalf("mailer.suspendCalls = %d, want 1", mailer.suspendCalls)
		}
	})
}

func TestHandlerListModeratedUsersSuccessAndFailure(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("success", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		rows := sqlmock.NewRows([]string{"profile_id", "account_id", "username", "display_name", "role", "status", "updated_at"}).
			AddRow(uuid.New(), uuid.New(), "bob", "Bob", "USER", "BANNED", time.Now())
		mock.ExpectQuery(`SELECT`).WillReturnRows(rows)

		router := gin.New()
		router.GET("/sanctions", handler.ListModeratedUsers)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/sanctions", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("query error", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		mock.ExpectQuery(`SELECT`).WillReturnError(assertErr("boom"))

		router := gin.New()
		router.GET("/sanctions", handler.ListModeratedUsers)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/sanctions", nil))
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}

func TestHandlerLiftModerationFlows(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()

	t.Run("success", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		targetAccountID := uuid.New()
		rows := sqlmock.NewRows([]string{"account_id", "role", "email", "display_name"}).
			AddRow(targetAccountID, "USER", "target@example.com", "Target")
		mock.ExpectQuery(`SELECT`).WillReturnRows(rows)
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "auth"\."accounts"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`UPDATE posts\.posts`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectExec(`UPDATE profiles\.profiles`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.POST("/users/:profileId/lift", handler.LiftModeration)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/lift", nil)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("not found", func(t *testing.T) {
		db, mock := newModerationMockDB(t)
		handler := newModerationTestHandler(db, nil)
		mock.ExpectQuery(`SELECT`).WillReturnRows(sqlmock.NewRows([]string{"account_id"}))

		router := gin.New()
		router.Use(withAccountAndRole(accountID, middleware.RoleModerator))
		router.POST("/users/:profileId/lift", handler.LiftModeration)
		req := httptest.NewRequest(http.MethodPost, "/users/"+profileID.String()+"/lift", nil)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})
}

func TestHandlerHealthVariants(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("nil db", func(t *testing.T) {
		handler := &Handler{}
		router := gin.New()
		router.GET("/health", handler.Health)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
		if rec.Code != http.StatusOK || !strings.Contains(rec.Body.String(), `"unavailable"`) {
			t.Fatalf("Health(nil db) = %d, %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("closed db reports error status", func(t *testing.T) {
		sqlDB, mock, err := sqlmock.New()
		if err != nil {
			t.Fatalf("sqlmock.New() unexpected error: %v", err)
		}
		db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
		if err != nil {
			t.Fatalf("gorm.Open() unexpected error: %v", err)
		}
		mock.ExpectClose()
		_ = sqlDB.Close()

		handler := &Handler{db: db}
		router := gin.New()
		router.GET("/health", handler.Health)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
		if rec.Code != http.StatusOK || !strings.Contains(rec.Body.String(), `"error"`) {
			t.Fatalf("Health(closed db) = %d, %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("healthy db", func(t *testing.T) {
		db, _ := newModerationMockDB(t)
		handler := &Handler{db: db}
		router := gin.New()
		router.GET("/health", handler.Health)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
		if rec.Code != http.StatusOK || !strings.Contains(rec.Body.String(), `"ok"`) {
			t.Fatalf("Health(ok db) = %d, %s", rec.Code, rec.Body.String())
		}
	})
}

// regexpHelper keeps the `regexp` import used in case future expectations need
// explicit quoting; current expectations rely on sqlmock's default regex matching.
var _ = regexp.QuoteMeta
