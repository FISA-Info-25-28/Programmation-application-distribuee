package moderation

import (
	"context"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestModerationRepositoryConstructor(t *testing.T) {
	repo := NewRepository(nil)
	if repo == nil || repo.db != nil {
		t.Fatalf("NewRepository(nil) = %+v, want repository with nil db", repo)
	}
}

func TestModerationRepositoryQueriesDryRun(t *testing.T) {
	repo := NewRepository(moderationDryRunDB(t))
	ctx := context.Background()
	reportID := uuid.New()
	reporterID := uuid.New()
	profileID := uuid.New()
	actorID := uuid.New()
	postID := uuid.New()
	until := time.Now().Add(time.Hour)

	_, _ = repo.ListReports(ctx)
	_, _ = repo.FindEnrichedReport(ctx, reportID)
	_, _ = repo.FindProfileIDByAccountID(ctx, actorID)
	_, _ = repo.FindAccountByProfileID(ctx, profileID)
	_, _ = repo.BanUser(ctx, profileID, actorID, "ADMIN")
	_, _ = repo.SuspendUser(ctx, profileID, actorID, "ADMIN", until)
	_, _ = repo.LiftModeration(ctx, profileID, actorID, "ADMIN")
	_, _ = repo.ListModeratedAccounts(ctx)
	_ = repo.CreatePostReport(ctx, &models.Report{ReporterID: reporterID, ReportedPostID: &postID, Reason: "spam"})
	_, _ = repo.UpdateReportStatus(ctx, reportID, actorID, "PENDING")
	_, _ = repo.UpdateReportStatus(ctx, reportID, actorID, "REJECTED")
	_, _ = repo.UpdateReportStatus(ctx, reportID, actorID, "RESOLVED")
	_ = repo.ensureModerationNotificationType(ctx)
	_ = repo.createModerationNotifications(ctx, repo.db, &models.Report{ReporterID: reporterID, ReportedPostID: &postID})
}

func TestModerateUserLocalErrors(t *testing.T) {
	if ErrCannotTargetSelf == nil {
		t.Fatal("ErrCannotTargetSelf should be defined")
	}
	if ErrInsufficientRoleOverTarget == nil {
		t.Fatal("ErrInsufficientRoleOverTarget should be defined")
	}
}

func moderationDryRunDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{DryRun: true})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db
}
