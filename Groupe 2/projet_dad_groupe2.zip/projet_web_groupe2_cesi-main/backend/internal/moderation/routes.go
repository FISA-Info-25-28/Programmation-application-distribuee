package moderation

import (
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
)

func RegisterRoutes(router *gin.Engine, handler *Handler) {
	router.Use(middleware.JSONBody())

	router.GET("/health", handler.Health)
	router.POST(
		"/posts/:id/report",
		middleware.AuthRequired(),
		handler.CreatePostReport,
	)
	router.GET(
		"/reports",
		middleware.AuthRequired(),
		middleware.RequireRole(middleware.RoleModerator),
		handler.ListReports,
	)
	router.PATCH(
		"/reports/:id",
		middleware.AuthRequired(),
		middleware.RequireRole(middleware.RoleModerator),
		handler.ReviewReport,
	)
	router.POST(
		"/users/:profileId/ban",
		middleware.AuthRequired(),
		middleware.RequireRole(middleware.RoleModerator),
		handler.BanUser,
	)
	router.POST(
		"/users/:profileId/suspend",
		middleware.AuthRequired(),
		middleware.RequireRole(middleware.RoleModerator),
		handler.SuspendUser,
	)
	router.POST(
		"/users/:profileId/lift",
		middleware.AuthRequired(),
		middleware.RequireRole(middleware.RoleModerator),
		handler.LiftModeration,
	)
	router.GET(
		"/sanctions",
		middleware.AuthRequired(),
		middleware.RequireRole(middleware.RoleModerator),
		handler.ListModeratedUsers,
	)
}
