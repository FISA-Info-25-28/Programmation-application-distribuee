package notifications

import (
	"errors"
	"time"

	"breezy/backend/internal/validation"
	"github.com/google/uuid"
)

type notificationResponse struct {
	ID               uuid.UUID  `json:"id"`
	Type             string     `json:"type"`
	ActorProfileID   uuid.UUID  `json:"actorProfileId"`
	ActorDisplayName string     `json:"actorDisplayName"`
	ActorUsername    string     `json:"actorUsername"`
	PostID           *uuid.UUID `json:"postId"`
	PostExcerpt      *string    `json:"postExcerpt"`
	RequestPending   bool       `json:"requestPending"`
	IsRead           bool       `json:"isRead"`
	CreatedAt        time.Time  `json:"createdAt"`
}

type deleteSelectedRequest struct {
	IDs []uuid.UUID `json:"ids" binding:"required,min=1"`
}

func (r deleteSelectedRequest) Validate() error {
	if len(r.IDs) == 0 {
		return errors.New("ids are required")
	}
	if len(r.IDs) > 100 {
		return errors.New("too many notification ids")
	}
	seen := make(map[uuid.UUID]bool, len(r.IDs))
	for _, id := range r.IDs {
		if err := validation.NonNilUUID(id, "notification id"); err != nil {
			return err
		}
		if seen[id] {
			return errors.New("duplicate notification id")
		}
		seen[id] = true
	}
	return nil
}
