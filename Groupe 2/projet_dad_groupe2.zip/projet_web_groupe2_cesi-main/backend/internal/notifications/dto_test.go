package notifications

import (
	"testing"

	"github.com/google/uuid"
)

func TestDeleteSelectedRequestValidate(t *testing.T) {
	id1 := uuid.New()
	id2 := uuid.New()
	if err := (deleteSelectedRequest{IDs: []uuid.UUID{id1, id2}}).Validate(); err != nil {
		t.Fatalf("deleteSelectedRequest.Validate() unexpected error: %v", err)
	}

	if err := (deleteSelectedRequest{}).Validate(); err == nil {
		t.Fatal("deleteSelectedRequest.Validate() expected required ids error")
	}
	if err := (deleteSelectedRequest{IDs: []uuid.UUID{uuid.Nil}}).Validate(); err == nil {
		t.Fatal("deleteSelectedRequest.Validate() expected nil id error")
	}
	if err := (deleteSelectedRequest{IDs: []uuid.UUID{id1, id1}}).Validate(); err == nil {
		t.Fatal("deleteSelectedRequest.Validate() expected duplicate id error")
	}

	ids := make([]uuid.UUID, 101)
	for i := range ids {
		ids[i] = uuid.New()
	}
	if err := (deleteSelectedRequest{IDs: ids}).Validate(); err == nil {
		t.Fatal("deleteSelectedRequest.Validate() expected too many ids error")
	}
}
