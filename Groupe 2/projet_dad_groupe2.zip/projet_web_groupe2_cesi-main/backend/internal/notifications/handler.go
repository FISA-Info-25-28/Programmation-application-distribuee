package notifications

import (
	"errors"
	"net/http"

	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Handler struct {
	db   *gorm.DB
	repo *Repository
}

func NewHandler(db *gorm.DB) *Handler {
	return &Handler{db: db, repo: NewRepository(db)}
}

func (h *Handler) List(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	profile, err := h.repo.FindProfileByAccountID(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "profile lookup failed"})
		return
	}

	notifications, err := h.repo.List(c.Request.Context(), profile.ID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "notifications lookup failed"})
		return
	}

	c.JSON(http.StatusOK, toResponses(notifications))
}

func (h *Handler) UnreadCount(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	profile, err := h.repo.FindProfileByAccountID(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "profile lookup failed"})
		return
	}

	count, err := h.repo.CountUnread(c.Request.Context(), profile.ID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "notifications count failed"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"count": count})
}

func (h *Handler) MarkAllRead(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	profile, err := h.repo.FindProfileByAccountID(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "profile lookup failed"})
		return
	}

	if err := h.repo.MarkAllRead(c.Request.Context(), profile.ID); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "notifications update failed"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"ok": true})
}

func (h *Handler) MarkRead(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	notificationID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid notification id"})
		return
	}

	profile, ok := h.currentProfile(c)
	if !ok {
		return
	}

	if err := h.repo.MarkRead(c.Request.Context(), notificationID, profile.ID); err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			c.JSON(http.StatusNotFound, gin.H{"error": "notification not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "notification update failed"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"ok": true})
}

func (h *Handler) DeleteAll(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	profile, ok := h.currentProfile(c)
	if !ok {
		return
	}

	if err := h.repo.DeleteAll(c.Request.Context(), profile.ID); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "notifications delete failed"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"ok": true})
}

func (h *Handler) DeleteSelected(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	var request deleteSelectedRequest
	if err := c.ShouldBindJSON(&request); err != nil || request.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid notification ids"})
		return
	}

	profile, ok := h.currentProfile(c)
	if !ok {
		return
	}

	if err := h.repo.DeleteSelected(c.Request.Context(), profile.ID, request.IDs); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "notifications delete failed"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"ok": true})
}

func (h *Handler) databaseAvailable(c *gin.Context) bool {
	if h.db != nil {
		return true
	}

	c.JSON(http.StatusServiceUnavailable, gin.H{"error": "database unavailable"})
	return false
}

func (h *Handler) currentProfile(c *gin.Context) (profileIDHolder, bool) {
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return profileIDHolder{}, false
	}

	profile, err := h.repo.FindProfileByAccountID(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "profile lookup failed"})
		return profileIDHolder{}, false
	}

	return profileIDHolder{ID: profile.ID}, true
}

type profileIDHolder struct {
	ID uuid.UUID
}

func toResponses(notifications []EnrichedNotification) []notificationResponse {
	responses := make([]notificationResponse, 0, len(notifications))
	for _, notification := range notifications {
		responses = append(responses, notificationResponse{
			ID:               notification.ID,
			Type:             notification.Type,
			ActorProfileID:   notification.ActorID,
			ActorDisplayName: notification.ActorDisplayName,
			ActorUsername:    notification.ActorUsername,
			PostID:           notification.PostID,
			PostExcerpt:      notification.PostExcerpt,
			RequestPending:   notification.FollowRequestPending,
			IsRead:           notification.IsRead,
			CreatedAt:        notification.CreatedAt,
		})
	}
	return responses
}
