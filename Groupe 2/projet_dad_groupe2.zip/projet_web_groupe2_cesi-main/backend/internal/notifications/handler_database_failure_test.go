package notifications

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"breezy/backend/internal/middleware"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func TestNotificationsHandlerDatabaseFailures(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(closedNotificationsDB(t))
	accountID := uuid.New()
	notificationID := uuid.NewString()

	tests := []struct {
		name, method, path, body string
		setup                    func(*gin.Engine)
	}{
		{name: "list", method: http.MethodGet, path: "/notifications", setup: func(r *gin.Engine) { r.GET("/notifications", handler.List) }},
		{name: "unread count", method: http.MethodGet, path: "/notifications/unread-count", setup: func(r *gin.Engine) { r.GET("/notifications/unread-count", handler.UnreadCount) }},
		{name: "mark all read", method: http.MethodPost, path: "/notifications/read-all", setup: func(r *gin.Engine) { r.POST("/notifications/read-all", handler.MarkAllRead) }},
		{name: "mark read", method: http.MethodPatch, path: "/notifications/" + notificationID + "/read", setup: func(r *gin.Engine) { r.PATCH("/notifications/:id/read", handler.MarkRead) }},
		{name: "delete all", method: http.MethodDelete, path: "/notifications", setup: func(r *gin.Engine) { r.DELETE("/notifications", handler.DeleteAll) }},
		{name: "delete selected", method: http.MethodDelete, path: "/notifications/selected", body: `{"ids":["` + notificationID + `"]}`, setup: func(r *gin.Engine) { r.DELETE("/notifications/selected", handler.DeleteSelected) }},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
			tt.setup(router)
			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			rec := httptest.NewRecorder()
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusInternalServerError {
				t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
			}
		})
	}
}

func TestNotificationsHandlerInvalidInputsWithDatabase(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(&gorm.DB{})
	accountID := uuid.New()

	tests := []struct {
		name        string
		method      string
		path        string
		body        string
		withAccount bool
		setup       func(*gin.Engine)
		want        int
	}{
		{name: "mark read invalid id", method: http.MethodPatch, path: "/notifications/bad/read", withAccount: true, setup: func(r *gin.Engine) { r.PATCH("/notifications/:id/read", handler.MarkRead) }, want: http.StatusBadRequest},
		{name: "mark read missing account", method: http.MethodPatch, path: "/notifications/" + uuid.NewString() + "/read", setup: func(r *gin.Engine) { r.PATCH("/notifications/:id/read", handler.MarkRead) }, want: http.StatusInternalServerError},
		{name: "list missing account", method: http.MethodGet, path: "/notifications", setup: func(r *gin.Engine) { r.GET("/notifications", handler.List) }, want: http.StatusInternalServerError},
		{name: "unread count missing account", method: http.MethodGet, path: "/notifications/unread-count", setup: func(r *gin.Engine) { r.GET("/notifications/unread-count", handler.UnreadCount) }, want: http.StatusInternalServerError},
		{name: "mark all read missing account", method: http.MethodPost, path: "/notifications/read-all", setup: func(r *gin.Engine) { r.POST("/notifications/read-all", handler.MarkAllRead) }, want: http.StatusInternalServerError},
		{name: "delete all missing account", method: http.MethodDelete, path: "/notifications", setup: func(r *gin.Engine) { r.DELETE("/notifications", handler.DeleteAll) }, want: http.StatusInternalServerError},
		{name: "delete selected missing account", method: http.MethodDelete, path: "/notifications/selected", body: `{"ids":["` + uuid.NewString() + `"]}`, setup: func(r *gin.Engine) { r.DELETE("/notifications/selected", handler.DeleteSelected) }, want: http.StatusInternalServerError},
		{name: "delete selected invalid json", method: http.MethodDelete, path: "/notifications/selected", body: `not-json`, withAccount: true, setup: func(r *gin.Engine) { r.DELETE("/notifications/selected", handler.DeleteSelected) }, want: http.StatusBadRequest},
		{name: "delete selected empty ids", method: http.MethodDelete, path: "/notifications/selected", body: `{"ids":[]}`, withAccount: true, setup: func(r *gin.Engine) { r.DELETE("/notifications/selected", handler.DeleteSelected) }, want: http.StatusBadRequest},
		{name: "delete selected nil id", method: http.MethodDelete, path: "/notifications/selected", body: `{"ids":["00000000-0000-0000-0000-000000000000"]}`, withAccount: true, setup: func(r *gin.Engine) { r.DELETE("/notifications/selected", handler.DeleteSelected) }, want: http.StatusBadRequest},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			if tt.withAccount {
				router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
			}
			tt.setup(router)
			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			rec := httptest.NewRecorder()
			router.ServeHTTP(rec, req)
			if rec.Code != tt.want {
				t.Fatalf("status = %d, want %d: %s", rec.Code, tt.want, rec.Body.String())
			}
		})
	}
}

func closedNotificationsDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	mock.ExpectClose()
	if err := sqlDB.Close(); err != nil {
		t.Fatalf("Close() unexpected error: %v", err)
	}
	return db
}
