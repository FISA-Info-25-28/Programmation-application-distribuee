package notifications

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"breezy/backend/internal/middleware"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// profileRows builds the sqlmock result set returned by the
// FindProfileByAccountID lookup that every authenticated notifications
// route performs before reaching its own business logic.
func profileRows(profileID, accountID uuid.UUID) *sqlmock.Rows {
	now := time.Now()
	return sqlmock.NewRows([]string{"id", "account_id", "username", "is_private", "created_at", "updated_at"}).
		AddRow(profileID, accountID, "alice", false, now, now)
}

func TestNotificationsHandlerListSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()

	db, mock := mockedNotificationsDB(t)
	mock.ExpectQuery(".*").WillReturnRows(profileRows(profileID, accountID))
	mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"id"}))

	handler := NewHandler(db)
	router := gin.New()
	router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
	router.GET("/notifications", handler.List)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/notifications", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
	if rec.Body.String() != "[]" {
		t.Fatalf("body = %s, want []", rec.Body.String())
	}
}

func TestNotificationsHandlerUnreadCountSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()

	db, mock := mockedNotificationsDB(t)
	mock.ExpectQuery(".*").WillReturnRows(profileRows(profileID, accountID))
	mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(4))

	handler := NewHandler(db)
	router := gin.New()
	router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
	router.GET("/notifications/unread-count", handler.UnreadCount)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/notifications/unread-count", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), `"count":4`) {
		t.Fatalf("body = %s, want count 4", rec.Body.String())
	}
}

func TestNotificationsHandlerMarkAllReadSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()

	db, mock := mockedNotificationsDB(t)
	mock.ExpectQuery(".*").WillReturnRows(profileRows(profileID, accountID))
	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnResult(sqlmock.NewResult(0, 2))
	mock.ExpectCommit()

	handler := NewHandler(db)
	router := gin.New()
	router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
	router.POST("/notifications/read-all", handler.MarkAllRead)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/notifications/read-all", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestNotificationsHandlerMarkReadSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()
	notificationID := uuid.New()

	db, mock := mockedNotificationsDB(t)
	mock.ExpectQuery(".*").WillReturnRows(profileRows(profileID, accountID))
	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	handler := NewHandler(db)
	router := gin.New()
	router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
	router.PATCH("/notifications/:id/read", handler.MarkRead)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodPatch, "/notifications/"+notificationID.String()+"/read", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestNotificationsHandlerMarkReadNotFound(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()
	notificationID := uuid.New()

	db, mock := mockedNotificationsDB(t)
	mock.ExpectQuery(".*").WillReturnRows(profileRows(profileID, accountID))
	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectCommit()

	handler := NewHandler(db)
	router := gin.New()
	router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
	router.PATCH("/notifications/:id/read", handler.MarkRead)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodPatch, "/notifications/"+notificationID.String()+"/read", nil))
	if rec.Code != http.StatusNotFound {
		t.Fatalf("status = %d, want 404: %s", rec.Code, rec.Body.String())
	}
}

func TestNotificationsHandlerDeleteAllSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()

	db, mock := mockedNotificationsDB(t)
	mock.ExpectQuery(".*").WillReturnRows(profileRows(profileID, accountID))
	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnResult(sqlmock.NewResult(0, 3))
	mock.ExpectCommit()

	handler := NewHandler(db)
	router := gin.New()
	router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
	router.DELETE("/notifications", handler.DeleteAll)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodDelete, "/notifications", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestNotificationsHandlerDeleteSelectedSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()
	notificationID := uuid.New()

	db, mock := mockedNotificationsDB(t)
	mock.ExpectQuery(".*").WillReturnRows(profileRows(profileID, accountID))
	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()

	handler := NewHandler(db)
	router := gin.New()
	router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
	router.DELETE("/notifications/selected", handler.DeleteSelected)

	body := `{"ids":["` + notificationID.String() + `"]}`
	req := httptest.NewRequest(http.MethodDelete, "/notifications/selected", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

func TestNotificationsHandlerProfileLookupFailed(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()

	db, mock := mockedNotificationsDB(t)
	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)

	handler := NewHandler(db)
	router := gin.New()
	router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
	router.GET("/notifications", handler.List)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/notifications", nil))
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

func TestNotificationsHandlerRepoCallFailsAfterProfileLookup(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	profileID := uuid.New()
	notificationID := uuid.New()

	tests := []struct {
		name    string
		method  string
		path    string
		body    string
		setup   func(*Handler, *gin.Engine)
		prepare func(sqlmock.Sqlmock)
	}{
		{
			name:   "list",
			method: http.MethodGet, path: "/notifications",
			setup: func(h *Handler, r *gin.Engine) { r.GET("/notifications", h.List) },
			prepare: func(mock sqlmock.Sqlmock) {
				mock.ExpectQuery(".*").WillReturnError(gorm.ErrInvalidData)
			},
		},
		{
			name:   "unread count",
			method: http.MethodGet, path: "/notifications/unread-count",
			setup: func(h *Handler, r *gin.Engine) { r.GET("/notifications/unread-count", h.UnreadCount) },
			prepare: func(mock sqlmock.Sqlmock) {
				mock.ExpectQuery(".*").WillReturnError(gorm.ErrInvalidData)
			},
		},
		{
			name:   "mark all read",
			method: http.MethodPost, path: "/notifications/read-all",
			setup: func(h *Handler, r *gin.Engine) { r.POST("/notifications/read-all", h.MarkAllRead) },
			prepare: func(mock sqlmock.Sqlmock) {
				mock.ExpectBegin()
				mock.ExpectExec(".*").WillReturnError(gorm.ErrInvalidData)
				mock.ExpectRollback()
			},
		},
		{
			name:   "mark read",
			method: http.MethodPatch, path: "/notifications/" + notificationID.String() + "/read",
			setup: func(h *Handler, r *gin.Engine) { r.PATCH("/notifications/:id/read", h.MarkRead) },
			prepare: func(mock sqlmock.Sqlmock) {
				mock.ExpectBegin()
				mock.ExpectExec(".*").WillReturnError(gorm.ErrInvalidData)
				mock.ExpectRollback()
			},
		},
		{
			name:   "delete all",
			method: http.MethodDelete, path: "/notifications",
			setup: func(h *Handler, r *gin.Engine) { r.DELETE("/notifications", h.DeleteAll) },
			prepare: func(mock sqlmock.Sqlmock) {
				mock.ExpectBegin()
				mock.ExpectExec(".*").WillReturnError(gorm.ErrInvalidData)
				mock.ExpectRollback()
			},
		},
		{
			name:   "delete selected",
			method: http.MethodDelete, path: "/notifications/selected",
			body:  `{"ids":["` + notificationID.String() + `"]}`,
			setup: func(h *Handler, r *gin.Engine) { r.DELETE("/notifications/selected", h.DeleteSelected) },
			prepare: func(mock sqlmock.Sqlmock) {
				mock.ExpectBegin()
				mock.ExpectExec(".*").WillReturnError(gorm.ErrInvalidData)
				mock.ExpectRollback()
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			db, mock := mockedNotificationsDB(t)
			mock.ExpectQuery(".*").WillReturnRows(profileRows(profileID, accountID))
			tt.prepare(mock)

			handler := NewHandler(db)
			router := gin.New()
			router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
			tt.setup(handler, router)

			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			rec := httptest.NewRecorder()
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusInternalServerError {
				t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
			}
		})
	}
}

// mockedNotificationsDB opens a live (non dry-run) gorm.DB backed by
// sqlmock so handler tests can drive real success/error responses
// returned by the repository through SQL row/result expectations.
func mockedNotificationsDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}
