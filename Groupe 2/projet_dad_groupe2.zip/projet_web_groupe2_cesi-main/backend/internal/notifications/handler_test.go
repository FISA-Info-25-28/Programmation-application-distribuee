package notifications

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

func TestNotificationsHandlerDatabaseUnavailable(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(nil)

	tests := []struct {
		method string
		path   string
		setup  func(*gin.Engine)
	}{
		{method: http.MethodGet, path: "/notifications", setup: func(r *gin.Engine) { r.GET("/notifications", handler.List) }},
		{method: http.MethodGet, path: "/notifications/unread-count", setup: func(r *gin.Engine) { r.GET("/notifications/unread-count", handler.UnreadCount) }},
		{method: http.MethodPost, path: "/notifications/read-all", setup: func(r *gin.Engine) { r.POST("/notifications/read-all", handler.MarkAllRead) }},
		{method: http.MethodPatch, path: "/notifications/bad/read", setup: func(r *gin.Engine) { r.PATCH("/notifications/:id/read", handler.MarkRead) }},
		{method: http.MethodDelete, path: "/notifications", setup: func(r *gin.Engine) { r.DELETE("/notifications", handler.DeleteAll) }},
		{method: http.MethodDelete, path: "/notifications/selected", setup: func(r *gin.Engine) { r.DELETE("/notifications/selected", handler.DeleteSelected) }},
	}

	for _, tt := range tests {
		router := gin.New()
		tt.setup(router)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != http.StatusServiceUnavailable {
			t.Fatalf("%s %s status = %d, want 503", tt.method, tt.path, rec.Code)
		}
	}
}

func TestNotificationResponses(t *testing.T) {
	postID := uuid.New()
	excerpt := "hello"
	createdAt := time.Now().UTC()
	rows := []EnrichedNotification{{
		Notification: models.Notification{
			ID:        uuid.New(),
			Type:      "FOLLOW_REQUEST",
			ActorID:   uuid.New(),
			PostID:    &postID,
			IsRead:    true,
			CreatedAt: createdAt,
		},
		ActorDisplayName:     "Alice",
		ActorUsername:        "alice",
		PostExcerpt:          &excerpt,
		FollowRequestPending: true,
	}}

	got := toResponses(rows)
	if len(got) != 1 || got[0].ActorDisplayName != "Alice" || got[0].PostID != &postID || !got[0].RequestPending || !got[0].IsRead {
		t.Fatalf("toResponses() = %+v, want mapped notification", got)
	}
}

func TestCurrentProfileMissingAccount(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(nil)
	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)

	if _, ok := handler.currentProfile(c); ok {
		t.Fatal("currentProfile() should fail without account")
	}
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("status = %d, want 500", rec.Code)
	}
}

func TestRegisterRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	RegisterRoutes(router, NewHandler(nil))

	for _, path := range []string{"/notifications", "/notifications/unread-count"} {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, path, nil))
		if rec.Code != http.StatusUnauthorized {
			t.Fatalf("GET %s status = %d, want 401", path, rec.Code)
		}
	}
}
