package notifications

import (
	"context"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository struct {
	db *gorm.DB
}

type EnrichedNotification struct {
	models.Notification
	ActorUsername        string
	ActorDisplayName     string
	PostExcerpt          *string
	FollowRequestPending bool
}

func NewRepository(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

func (r *Repository) FindProfileByAccountID(ctx context.Context, accountID uuid.UUID) (models.Profile, error) {
	var profile models.Profile
	err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("account_id = ?", accountID).
		First(&profile).
		Error
	return profile, err
}

func (r *Repository) List(ctx context.Context, profileID uuid.UUID) ([]EnrichedNotification, error) {
	var notifications []EnrichedNotification
	err := r.db.WithContext(ctx).
		Table("social.notifications n").
		Select(`
			n.*,
			actor.username AS actor_username,
			COALESCE(actor.display_name, actor.username) AS actor_display_name,
			reported_post.content AS post_excerpt,
			EXISTS (
				SELECT 1
				FROM social.follow_requests request
				WHERE request.requester_id = n.actor_id
				  AND request.target_id = n.recipient_id
			) AS follow_request_pending
		`).
		Joins("LEFT JOIN profiles.profiles actor ON actor.id = n.actor_id").
		Joins("LEFT JOIN posts.posts reported_post ON reported_post.id = n.post_id").
		Where("n.recipient_id = ?", profileID).
		Order("n.created_at DESC").
		Find(&notifications).
		Error
	return notifications, err
}

func (r *Repository) CountUnread(ctx context.Context, profileID uuid.UUID) (int64, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("social.notifications").
		Where("recipient_id = ? AND is_read = false", profileID).
		Count(&count).
		Error
	return count, err
}

func (r *Repository) MarkAllRead(ctx context.Context, profileID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Table("social.notifications").
		Where("recipient_id = ? AND is_read = false", profileID).
		Update("is_read", true).
		Error
}

func (r *Repository) MarkRead(ctx context.Context, notificationID, profileID uuid.UUID) error {
	result := r.db.WithContext(ctx).
		Table("social.notifications").
		Where("id = ? AND recipient_id = ?", notificationID, profileID).
		Update("is_read", true)
	if result.Error != nil {
		return result.Error
	}
	if result.RowsAffected == 0 {
		return gorm.ErrRecordNotFound
	}
	return nil
}

func (r *Repository) DeleteAll(ctx context.Context, profileID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Table("social.notifications").
		Where("recipient_id = ?", profileID).
		Delete(&models.Notification{}).
		Error
}

func (r *Repository) DeleteSelected(ctx context.Context, profileID uuid.UUID, notificationIDs []uuid.UUID) error {
	return r.db.WithContext(ctx).
		Table("social.notifications").
		Where("recipient_id = ? AND id IN ?", profileID, notificationIDs).
		Delete(&models.Notification{}).
		Error
}
