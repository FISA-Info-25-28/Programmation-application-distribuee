package notifications

import (
	"context"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestNotificationsRepositoryConstructor(t *testing.T) {
	repo := NewRepository(nil)
	if repo == nil || repo.db != nil {
		t.Fatalf("NewRepository(nil) = %+v, want repository with nil db", repo)
	}
}

func TestNotificationsRepositoryQueriesDryRun(t *testing.T) {
	repo := NewRepository(notificationsDryRunDB(t))
	ctx := context.Background()
	profileID := uuid.New()
	notificationID := uuid.New()

	_, _ = repo.FindProfileByAccountID(ctx, uuid.New())
	_, _ = repo.List(ctx, profileID)
	_, _ = repo.CountUnread(ctx, profileID)
	_ = repo.MarkAllRead(ctx, profileID)
	_ = repo.MarkRead(ctx, notificationID, profileID)
	_ = repo.DeleteAll(ctx, profileID)
	_ = repo.DeleteSelected(ctx, profileID, []uuid.UUID{notificationID})
}

func notificationsDryRunDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{DryRun: true})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db
}
