package notifications

import (
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
)

func RegisterRoutes(router *gin.Engine, handler *Handler) {
	router.Use(middleware.JSONBody())

	authenticated := router.Group("/")
	authenticated.Use(middleware.AuthRequired())
	authenticated.GET("/notifications", handler.List)
	authenticated.GET("/notifications/unread-count", handler.UnreadCount)
	authenticated.POST("/notifications/read-all", handler.MarkAllRead)
	authenticated.DELETE("/notifications/selected", handler.DeleteSelected)
	authenticated.PATCH("/notifications/:id/read", handler.MarkRead)
	authenticated.DELETE("/notifications", handler.DeleteAll)
}
