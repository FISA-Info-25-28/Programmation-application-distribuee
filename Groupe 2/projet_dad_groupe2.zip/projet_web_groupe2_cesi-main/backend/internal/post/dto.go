package post

import (
	"errors"
	"strings"
	"time"

	"breezy/backend/internal/validation"
	"github.com/google/uuid"
)

type postResponse struct {
	ID         uuid.UUID             `json:"id"`
	AuthorID   uuid.UUID             `json:"authorId"`
	Author     authorSummaryResponse `json:"author"`
	Content    string                `json:"content"`
	Lang       string                `json:"lang"`
	ParentID   *uuid.UUID            `json:"parentId,omitempty"`
	Visibility string                `json:"visibility"`
	CreatedAt  time.Time             `json:"createdAt"`
	UpdatedAt  time.Time             `json:"updatedAt"`

	LikesCount    int64           `json:"likesCount"`
	CommentsCount int64           `json:"commentsCount"`
	RepostCount   int64           `json:"repostCount"`
	IsLiked       bool            `json:"isLiked"`
	IsReposted    bool            `json:"isReposted"`
	IsBookmarked  bool            `json:"isBookmarked"`
	HasMedia      bool            `json:"hasMedia"`
	Media         []mediaResponse `json:"media"`

	RepostedBy *authorSummaryResponse `json:"repostedBy,omitempty"`
	Poll       *pollResponse          `json:"poll,omitempty"`
}

type pollOptionResponse struct {
	ID        uuid.UUID `json:"id"`
	Text      string    `json:"text"`
	VoteCount int       `json:"voteCount"`
	Position  int       `json:"position"`
}

type pollResponse struct {
	ID            uuid.UUID            `json:"id"`
	Options       []pollOptionResponse `json:"options"`
	TotalVotes    int                  `json:"totalVotes"`
	EndsAt        *time.Time           `json:"endsAt"`
	ClosedAt      *time.Time           `json:"closedAt"`
	IsClosed      bool                 `json:"isClosed"`
	HasVoted      bool                 `json:"hasVoted"`
	VotedOptionID *uuid.UUID           `json:"votedOptionId"`
}

type authorSummaryResponse struct {
	ID          uuid.UUID `json:"id"`
	Username    string    `json:"username"`
	DisplayName string    `json:"displayName"`
	AvatarURL   *string   `json:"avatarUrl"`
}

type postsResponse struct {
	Posts []postResponse `json:"posts"`
}

// replyResponse est une réponse enrichie accompagnée de son post parent.
// Les champs du post (réponse) sont aplatis au niveau racine, le parent est imbriqué.
type replyResponse struct {
	postResponse
	Parent *postResponse `json:"parent,omitempty"`
}

type createPostRequest struct {
	Content    string             `json:"content"`
	ParentID   *uuid.UUID         `json:"parentId"`
	Visibility string             `json:"visibility"`
	Media      []mediaRequest     `json:"media"`
	Poll       *createPollRequest `json:"poll"`
}

func (r createPostRequest) Validate() error {
	content := strings.TrimSpace(r.Content)
	if content == "" && len(r.Media) == 0 && r.Poll == nil {
		return errors.New("post content, media or poll is required")
	}
	if len([]rune(content)) > 280 {
		return errors.New("content is too long")
	}
	if r.ParentID != nil && *r.ParentID == uuid.Nil {
		return errors.New("invalid parentId")
	}
	if strings.TrimSpace(r.Visibility) != "" {
		if err := validation.OneOf(r.Visibility, "PUBLIC", "FOLLOWERS", "PRIVATE"); err != nil {
			return errors.New("invalid visibility")
		}
	}
	if len(r.Media) > 4 {
		return errors.New("too many media items")
	}
	for _, media := range r.Media {
		if err := media.Validate(); err != nil {
			return err
		}
	}
	if r.Poll != nil {
		return r.Poll.Validate()
	}
	return nil
}

type createPollRequest struct {
	Options       []string `json:"options"`
	DurationHours *float64 `json:"durationHours"` // nil = pas d'expiration auto ; 0.5 = 30 min
}

func (r createPollRequest) Validate() error {
	if len(r.Options) < 2 || len(r.Options) > 4 {
		return errors.New("poll must contain 2 to 4 options")
	}
	for _, option := range r.Options {
		if _, err := validation.TrimmedRequired(option, 80, "poll option"); err != nil {
			return err
		}
	}
	if r.DurationHours != nil && (*r.DurationHours < 1 || *r.DurationHours > 24*30) {
		return errors.New("poll duration must be between 1 and 720 hours")
	}
	return nil
}

type mediaRequest struct {
	Type string `json:"type"`
	URL  string `json:"url"`
}

func (r mediaRequest) Validate() error {
	if err := validation.OneOf(r.Type, "IMAGE", "VIDEO"); err != nil {
		return errors.New("invalid media type")
	}
	if err := validation.MediaURL(r.URL); err != nil {
		return err
	}
	return nil
}

type mediaResponse struct {
	ID   uuid.UUID `json:"id"`
	Type string    `json:"type"`
	URL  string    `json:"url"`
}

type updateVisibilityRequest struct {
	Visibility string `json:"visibility"`
}

func (r updateVisibilityRequest) Validate() error {
	return validation.OneOf(r.Visibility, "PUBLIC", "FOLLOWERS", "PRIVATE")
}

type votePollRequest struct {
	OptionID uuid.UUID `json:"optionId"`
}

func (r votePollRequest) Validate() error {
	return validation.NonNilUUID(r.OptionID, "optionId")
}

type trendingTagResponse struct {
	Name        string `json:"name"`
	PostCount   int64  `json:"postCount"`
	LikeCount   int64  `json:"likeCount"`
	RepostCount int64  `json:"repostCount"`
}
