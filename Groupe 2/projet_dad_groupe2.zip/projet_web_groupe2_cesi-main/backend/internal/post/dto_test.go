package post

import (
	"errors"
	"strings"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

func TestCreatePostRequestValidate(t *testing.T) {
	if err := (createPostRequest{Content: "hello", Visibility: "public"}).Validate(); err != nil {
		t.Fatalf("createPostRequest.Validate(text) unexpected error: %v", err)
	}
	if err := (createPostRequest{Media: []mediaRequest{{Type: "image", URL: "/api/media/files/a.png"}}}).Validate(); err != nil {
		t.Fatalf("createPostRequest.Validate(media) unexpected error: %v", err)
	}
	if err := (createPostRequest{Poll: &createPollRequest{Options: []string{"A", "B"}}}).Validate(); err != nil {
		t.Fatalf("createPostRequest.Validate(poll) unexpected error: %v", err)
	}

	nilParent := uuid.Nil
	tests := []createPostRequest{
		{},
		{Content: strings.Repeat("a", 281)},
		{Content: "hello", ParentID: &nilParent},
		{Content: "hello", Visibility: "FRIENDS"},
		{Content: "hello", Media: []mediaRequest{{Type: "IMAGE", URL: "/api/media/files/1"}, {Type: "IMAGE", URL: "/api/media/files/2"}, {Type: "IMAGE", URL: "/api/media/files/3"}, {Type: "IMAGE", URL: "/api/media/files/4"}, {Type: "IMAGE", URL: "/api/media/files/5"}}},
		{Content: "hello", Media: []mediaRequest{{Type: "AUDIO", URL: "/api/media/files/a.mp3"}}},
	}
	for _, req := range tests {
		if err := req.Validate(); err == nil {
			t.Fatalf("createPostRequest.Validate(%+v) expected error", req)
		}
	}
}

func TestPollAndPostActionValidators(t *testing.T) {
	duration := 24.0
	if err := (createPollRequest{Options: []string{"A", "B"}, DurationHours: &duration}).Validate(); err != nil {
		t.Fatalf("createPollRequest.Validate() unexpected error: %v", err)
	}

	tooShort := createPollRequest{Options: []string{"A"}}
	if err := tooShort.Validate(); err == nil {
		t.Fatal("createPollRequest.Validate() expected option count error")
	}
	tooLongDuration := 721.0
	if err := (createPollRequest{Options: []string{"A", "B"}, DurationHours: &tooLongDuration}).Validate(); err == nil {
		t.Fatal("createPollRequest.Validate() expected duration error")
	}
	if err := (createPollRequest{Options: []string{"A", "B", "C", "D", "E"}}).Validate(); err == nil {
		t.Fatal("createPollRequest.Validate() expected max option count error")
	}

	if err := (updateVisibilityRequest{Visibility: "followers"}).Validate(); err != nil {
		t.Fatalf("updateVisibilityRequest.Validate() unexpected error: %v", err)
	}
	if err := (updateVisibilityRequest{Visibility: "friends"}).Validate(); err == nil {
		t.Fatal("updateVisibilityRequest.Validate() expected invalid visibility error")
	}

	if err := (votePollRequest{OptionID: uuid.New()}).Validate(); err != nil {
		t.Fatalf("votePollRequest.Validate() unexpected error: %v", err)
	}
	if err := (votePollRequest{OptionID: uuid.Nil}).Validate(); err == nil {
		t.Fatal("votePollRequest.Validate() expected nil option error")
	}

	if err := (createPollRequest{Options: []string{" ", "B"}}).Validate(); err == nil {
		t.Fatal("createPollRequest.Validate() expected blank option TrimmedRequired error")
	}

	if err := (mediaRequest{Type: "IMAGE", URL: "/uploads/a.png"}).Validate(); err == nil {
		t.Fatal("mediaRequest.Validate() expected invalid media url error")
	}
}

func TestPostPureHelpers(t *testing.T) {
	if !isValidVisibility("PUBLIC") || isValidVisibility("FRIENDS") {
		t.Fatal("isValidVisibility() returned unexpected result")
	}
	if !validMedia([]mediaRequest{{Type: "video", URL: "/api/media/files/v.mp4"}}) {
		t.Fatal("validMedia() should accept API media video")
	}
	if validMedia([]mediaRequest{{Type: "audio", URL: "/api/media/files/a.mp3"}}) {
		t.Fatal("validMedia() should reject unsupported type")
	}
	if validMedia([]mediaRequest{{Type: "image", URL: "/uploads/a.png"}}) {
		t.Fatal("validMedia() should reject non media API url")
	}

	mediaID := uuid.New()
	response := mediaToResponse([]models.Media{{ID: mediaID, MediaType: "IMAGE", URL: "/api/media/files/a.png"}})
	if len(response) != 1 || response[0].ID != mediaID || response[0].Type != "IMAGE" || response[0].URL != "/api/media/files/a.png" {
		t.Fatalf("mediaToResponse() = %+v, want copied media fields", response)
	}

	if !IsNotFound(gorm.ErrRecordNotFound) || !IsNotFound(errors.Join(assertPostErr("wrapped"), gorm.ErrRecordNotFound)) {
		t.Fatal("IsNotFound() should recognize GORM record not found errors")
	}
	if IsNotFound(assertPostErr("boom")) {
		t.Fatal("IsNotFound() should reject unrelated errors")
	}
}

func TestPostTextHelpers(t *testing.T) {
	if got := detectLang("bonjour, je suis avec vous"); got != "fr" {
		t.Fatalf("detectLang(fr) = %q, want fr", got)
	}
	if got := detectLang("the quick post is for you"); got != "en" {
		t.Fatalf("detectLang(en) = %q, want en", got)
	}
	if got := detectLang("Привет"); got != "ru" {
		t.Fatalf("detectLang(ru) = %q, want ru", got)
	}

	for _, tt := range []struct {
		text string
		want string
	}{
		{text: "مرحبا بالعالم", want: "ar"},
		{text: "שלום עולם", want: "he"},
		{text: "你好世界", want: "zh"},
		{text: "안녕하세요 세계", want: "ko"},
		{text: "hola mundo que tal", want: "fr"},
		{text: "", want: ""},
	} {
		if got := detectLang(tt.text); got != tt.want {
			t.Fatalf("detectLang(%q) = %q, want %q", tt.text, got, tt.want)
		}
	}

	tags := extractHashtags("Hello #Go #go #Breezy")
	if len(tags) != 2 || tags[0] != "go" || tags[1] != "breezy" {
		t.Fatalf("extractHashtags() = %#v, want unique lowercase tags", tags)
	}

	mentions := extractMentions("cc @Alice and @alice plus @bob_2")
	if len(mentions) != 2 || mentions[0] != "alice" || mentions[1] != "bob_2" {
		t.Fatalf("extractMentions() = %#v, want unique lowercase mentions", mentions)
	}

	if tags := extractHashtags("no tags here"); len(tags) != 0 {
		t.Fatalf("extractHashtags(no match) = %#v, want empty", tags)
	}
	if mentions := extractMentions("no mentions here"); len(mentions) != 0 {
		t.Fatalf("extractMentions(no match) = %#v, want empty", mentions)
	}
}

func TestPollHelpers(t *testing.T) {
	if err := validatePollRequest(&createPollRequest{Options: []string{" A ", "B"}}); err != nil {
		t.Fatalf("validatePollRequest() unexpected error: %v", err)
	}
	if err := validatePollRequest(&createPollRequest{Options: []string{"A", " "}}); err == nil {
		t.Fatal("validatePollRequest() expected blank option error")
	}

	past := time.Now().Add(-time.Hour)
	future := time.Now().Add(time.Hour)
	closedAt := time.Now()
	if !isPollClosed(models.Poll{EndsAt: &past}) {
		t.Fatal("isPollClosed() should close expired poll")
	}
	if isPollClosed(models.Poll{EndsAt: &future}) {
		t.Fatal("isPollClosed() should keep future poll open")
	}
	if !isPollClosed(models.Poll{ClosedAt: &closedAt}) {
		t.Fatal("isPollClosed() should close manually closed poll")
	}

	optionID := uuid.New()
	response := buildPollResponse(models.Poll{
		ID: uuid.New(),
		Options: []models.PollOption{
			{ID: optionID, Text: "A", Position: 0, VoteCount: 2},
			{ID: uuid.New(), Text: "B", Position: 1, VoteCount: 3},
		},
	}, true, &optionID)
	if response.TotalVotes != 5 || !response.HasVoted || response.VotedOptionID != &optionID {
		t.Fatalf("buildPollResponse() = %+v, want vote metadata", response)
	}
}

type assertPostErr string

func (e assertPostErr) Error() string { return string(e) }
