package post

import (
	"context"
	"errors"
	"net/http"
	"strconv"

	"breezy/backend/internal/config"
	"breezy/backend/internal/middleware"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Handler struct {
	db      *gorm.DB
	service *Service
}

func NewHandler(db *gorm.DB) *Handler {
	repo := NewRepository(db)

	return &Handler{
		db:      db,
		service: NewService(repo),
	}
}

func (h *Handler) Health(c *gin.Context) {
	dbStatus := "ok"

	if h.db == nil {
		dbStatus = "unavailable"
	} else if sqlDB, err := h.db.DB(); err != nil || sqlDB.PingContext(c.Request.Context()) != nil {
		dbStatus = "error"
	}

	c.JSON(http.StatusOK, gin.H{
		"service": config.Env("SERVICE_NAME", "post-service"),
		"status":  "ok",
		"db":      dbStatus,
	})
}

func (h *Handler) GetPosts(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	posts, err := h.service.GetPosts(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to fetch posts",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"posts": posts,
	})
}

func (h *Handler) GetFollowingPosts(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "authenticated account missing",
		})
		return
	}

	posts, err := h.service.GetFollowingPosts(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to fetch following posts",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"posts": posts,
	})
}

func (h *Handler) GetPost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid post id",
		})
		return
	}

	post, err := h.service.GetPostByID(c.Request.Context(), postID)
	if err != nil {
		if errors.Is(err, ErrPrivateProfile) {
			c.JSON(http.StatusForbidden, gin.H{"error": "profile is private"})
			return
		}
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{
				"error": "post not found",
			})
			return
		}

		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to fetch post",
		})
		return
	}

	c.JSON(http.StatusOK, post)
}

func (h *Handler) GetReplies(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid post id",
		})
		return
	}

	posts, err := h.service.GetRepliesByParentID(c.Request.Context(), postID)
	if err != nil {
		if errors.Is(err, ErrPrivateProfile) {
			c.JSON(http.StatusForbidden, gin.H{"error": "profile is private"})
			return
		}
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{
				"error": "post not found",
			})
			return
		}

		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to fetch replies",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"posts": posts,
	})
}

func (h *Handler) GetPostsByTag(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	tag := c.Param("tag")
	if tag == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid tag"})
		return
	}

	posts, err := h.service.GetPostsByTag(c.Request.Context(), tag)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch tag posts"})
		return
	}

	c.JSON(http.StatusOK, posts)
}

func (h *Handler) GetPostsByKeyword(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	query := c.Query("q")
	if query == "" {
		c.JSON(http.StatusOK, gin.H{"posts": []postResponse{}})
		return
	}

	posts, err := h.service.SearchPostsByKeyword(c.Request.Context(), query)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to search posts"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"posts": posts})
}

func (h *Handler) GetPostsByAuthor(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	posts, err := h.service.GetPostsByAuthor(c.Request.Context(), c.Param("username"))
	if err != nil {
		if errors.Is(err, ErrPrivateProfile) {
			c.JSON(http.StatusForbidden, gin.H{"error": "profile is private"})
			return
		}
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{"error": "profile not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch profile posts"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"posts": posts})
}

func (h *Handler) GetRepostsByAuthor(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	posts, err := h.service.GetRepostsByAuthor(c.Request.Context(), c.Param("username"))
	if err != nil {
		if errors.Is(err, ErrPrivateProfile) {
			c.JSON(http.StatusForbidden, gin.H{"error": "profile is private"})
			return
		}
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{"error": "profile not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch profile reposts"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"posts": posts})
}

// GetLikedPostsByAuthor expose les posts likes par un auteur.
// Entree : c.
// Sortie HTTP : JSON contenant les posts likes visibles.
func (h *Handler) GetLikedPostsByAuthor(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	posts, err := h.service.GetLikedPostsByAuthor(c.Request.Context(), c.Param("username"))
	if err != nil {
		if errors.Is(err, ErrPrivateProfile) {
			c.JSON(http.StatusForbidden, gin.H{"error": "profile is private"})
			return
		}
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{"error": "profile not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch liked posts"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"posts": posts})
}

func (h *Handler) GetRepliesByAuthor(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	posts, err := h.service.GetRepliesByAuthor(c.Request.Context(), c.Param("username"))
	if err != nil {
		if errors.Is(err, ErrPrivateProfile) {
			c.JSON(http.StatusForbidden, gin.H{"error": "profile is private"})
			return
		}
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{"error": "profile not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch profile replies"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"posts": posts})
}

func (h *Handler) GetTrendingTags(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	limit := 3
	if rawLimit := c.Query("limit"); rawLimit != "" {
		parsedLimit, err := strconv.Atoi(rawLimit)
		if err != nil || parsedLimit < 1 || parsedLimit > 10 {
			c.JSON(http.StatusBadRequest, gin.H{"error": "limit must be between 1 and 10"})
			return
		}
		limit = parsedLimit
	}

	tags, err := h.service.GetTrendingTags(c.Request.Context(), limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch trending tags"})
		return
	}

	c.JSON(http.StatusOK, tags)
}

func (h *Handler) CreatePost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "authenticated account missing",
		})
		return
	}

	status, err := h.accountStatus(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to verify account status"})
		return
	}
	if status == "SUSPENDED" || status == "BANNED" {
		c.JSON(http.StatusForbidden, gin.H{"error": "account suspended"})
		return
	}

	var req createPostRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid post payload",
		})
		return
	}

	post, err := h.service.CreatePost(c.Request.Context(), accountID, req)
	if err != nil {
		switch {
		case errors.Is(err, ErrInvalidContent), errors.Is(err, ErrContentTooLong), errors.Is(err, ErrInvalidVisibility), errors.Is(err, ErrInvalidMedia):
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		case errors.Is(err, ErrPrivateProfilePublicVisibility):
			c.JSON(http.StatusForbidden, gin.H{"error": err.Error()})
			return
		case IsNotFound(err):
			c.JSON(http.StatusNotFound, gin.H{"error": "parent post or author profile not found"})
			return
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to create post"})
			return
		}
	}

	c.JSON(http.StatusCreated, post)
}

func (h *Handler) DeletePost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "authenticated account missing",
		})
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid post id",
		})
		return
	}

	if err := h.service.DeletePost(c.Request.Context(), accountID, postID); err != nil {
		switch {
		case errors.Is(err, ErrForbiddenPost):
			c.JSON(http.StatusForbidden, gin.H{"error": "cannot delete another user's post"})
			return
		case IsNotFound(err):
			c.JSON(http.StatusNotFound, gin.H{"error": "post not found"})
			return
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to delete post"})
			return
		}
	}

	c.Status(http.StatusNoContent)
}

func (h *Handler) UpdatePostVisibility(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "authenticated account missing",
		})
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid post id",
		})
		return
	}

	var req updateVisibilityRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid visibility payload"})
		return
	}

	post, err := h.service.UpdatePostVisibility(c.Request.Context(), accountID, postID, req.Visibility)
	if err != nil {
		switch {
		case errors.Is(err, ErrInvalidVisibility):
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		case errors.Is(err, ErrForbiddenPost):
			c.JSON(http.StatusForbidden, gin.H{"error": "cannot update another user's post"})
			return
		case errors.Is(err, ErrPrivateProfilePublicVisibility):
			c.JSON(http.StatusForbidden, gin.H{"error": err.Error()})
			return
		case IsNotFound(err):
			c.JSON(http.StatusNotFound, gin.H{"error": "post not found"})
			return
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to update post visibility"})
			return
		}
	}

	c.JSON(http.StatusOK, post)
}

func (h *Handler) LikePost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	status, err := h.accountStatus(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to verify account status"})
		return
	}
	if status == "SUSPENDED" || status == "BANNED" {
		c.JSON(http.StatusForbidden, gin.H{"error": "account suspended"})
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid post id"})
		return
	}

	if err := h.service.LikePost(c.Request.Context(), accountID, postID); err != nil {
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{"error": "post not found"})
			return
		}

		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to like post"})
		return
	}

	c.Status(http.StatusNoContent)
}

func (h *Handler) UnlikePost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "authenticated account missing",
		})
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid post id",
		})
		return
	}

	if err := h.service.UnlikePost(c.Request.Context(), accountID, postID); err != nil {
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{"error": "post or like not found"})
			return
		}

		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to unlike post"})
		return
	}

	c.Status(http.StatusNoContent)
}

func (h *Handler) Repost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "authenticated account missing",
		})
		return
	}

	status, err := h.accountStatus(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to verify account status"})
		return
	}
	if status == "SUSPENDED" || status == "BANNED" {
		c.JSON(http.StatusForbidden, gin.H{"error": "account suspended"})
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid post id",
		})
		return
	}

	if err := h.service.Repost(c.Request.Context(), accountID, postID); err != nil {
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{"error": "post not found"})
			return
		}

		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to repost"})
		return
	}

	c.Status(http.StatusNoContent)
}

func (h *Handler) Unrepost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "authenticated account missing",
		})
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid post id",
		})
		return
	}

	if err := h.service.Unrepost(c.Request.Context(), accountID, postID); err != nil {
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{"error": "post or repost not found"})
			return
		}

		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to unrepost"})
		return
	}

	c.Status(http.StatusNoContent)
}

func (h *Handler) VotePoll(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid post id"})
		return
	}

	var req votePollRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid optionId"})
		return
	}

	poll, err := h.service.VotePoll(c.Request.Context(), accountID, postID, req.OptionID)
	if err != nil {
		switch {
		case errors.Is(err, ErrAlreadyVoted):
			c.JSON(http.StatusConflict, gin.H{"error": "already voted"})
		case errors.Is(err, ErrPollClosed):
			c.JSON(http.StatusForbidden, gin.H{"error": "poll is closed"})
		case errors.Is(err, ErrInvalidPoll):
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		case IsNotFound(err):
			c.JSON(http.StatusNotFound, gin.H{"error": "poll not found"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to vote"})
		}
		return
	}

	c.JSON(http.StatusOK, poll)
}

func (h *Handler) ClosePoll(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid post id"})
		return
	}

	poll, err := h.service.ClosePoll(c.Request.Context(), accountID, postID)
	if err != nil {
		switch {
		case errors.Is(err, ErrForbiddenPoll):
			c.JSON(http.StatusForbidden, gin.H{"error": "only the author can close this poll"})
		case errors.Is(err, ErrPollClosed):
			c.JSON(http.StatusConflict, gin.H{"error": "poll already closed"})
		case IsNotFound(err):
			c.JSON(http.StatusNotFound, gin.H{"error": "poll not found"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to close poll"})
		}
		return
	}

	c.JSON(http.StatusOK, poll)
}

func (h *Handler) GetBookmarkedPosts(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	posts, err := h.service.GetBookmarkedPosts(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch bookmarks"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"posts": posts})
}

func (h *Handler) BookmarkPost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	status, err := h.accountStatus(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to verify account status"})
		return
	}
	if status == "SUSPENDED" || status == "BANNED" {
		c.JSON(http.StatusForbidden, gin.H{"error": "account suspended"})
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid post id"})
		return
	}

	if err := h.service.BookmarkPost(c.Request.Context(), accountID, postID); err != nil {
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{"error": "post not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to bookmark post"})
		return
	}

	c.Status(http.StatusNoContent)
}

func (h *Handler) UnbookmarkPost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	postID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid post id"})
		return
	}

	if err := h.service.UnbookmarkPost(c.Request.Context(), accountID, postID); err != nil {
		if IsNotFound(err) {
			c.JSON(http.StatusNotFound, gin.H{"error": "bookmark not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to remove bookmark"})
		return
	}

	c.Status(http.StatusNoContent)
}

func (h *Handler) databaseAvailable(c *gin.Context) bool {
	if h.db != nil {
		return true
	}

	c.JSON(http.StatusServiceUnavailable, gin.H{
		"error": "database unavailable",
	})

	return false
}

// accountStatus recupere le statut du compte depuis le schema auth.
// Retourne la valeur du champ status (ACTIVE, SUSPENDED, BANNED) ou une erreur.
// Entree : ctx, accountID.
// Sortie : valeurs retour de la fonction.
func (h *Handler) accountStatus(ctx context.Context, accountID uuid.UUID) (string, error) {
	var status string
	result := h.db.WithContext(ctx).Raw("SELECT status FROM auth.accounts WHERE id = ?", accountID).Scan(&status)
	if result.Error != nil {
		return "", result.Error
	}
	return status, nil
}
