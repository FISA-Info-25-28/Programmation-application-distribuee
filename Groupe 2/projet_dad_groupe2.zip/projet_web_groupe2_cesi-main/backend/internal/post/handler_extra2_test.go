package post

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"breezy/backend/internal/middleware"
	"breezy/backend/internal/models"
	"breezy/backend/internal/security"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// TestHandlerMissingAccountBranches couvre la branche "authenticated account
// missing" (middleware.AccountID renvoie ok=false) pour tous les handlers qui
// la verifient, jusqu'ici seulement exercee pour CreatePost. Aucun middleware
// ne renseigne ContextAccountID ici : c'est volontaire.
func TestHandlerMissingAccountBranches(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newPostMockDB(t)
	handler := NewHandler(db)
	id := uuid.NewString()

	tests := []struct {
		name   string
		method string
		path   string
		body   string
		setup  func(*gin.Engine)
	}{
		{name: "following posts", method: http.MethodGet, path: "/following", setup: func(r *gin.Engine) { r.GET("/following", handler.GetFollowingPosts) }},
		{name: "delete post", method: http.MethodDelete, path: "/" + id, setup: func(r *gin.Engine) { r.DELETE("/:id", handler.DeletePost) }},
		{name: "update visibility", method: http.MethodPatch, path: "/" + id + "/visibility", body: `{"visibility":"PUBLIC"}`, setup: func(r *gin.Engine) { r.PATCH("/:id/visibility", handler.UpdatePostVisibility) }},
		{name: "like post", method: http.MethodPost, path: "/" + id + "/like", setup: func(r *gin.Engine) { r.POST("/:id/like", handler.LikePost) }},
		{name: "unlike post", method: http.MethodDelete, path: "/" + id + "/like", setup: func(r *gin.Engine) { r.DELETE("/:id/like", handler.UnlikePost) }},
		{name: "repost", method: http.MethodPost, path: "/" + id + "/repost", setup: func(r *gin.Engine) { r.POST("/:id/repost", handler.Repost) }},
		{name: "unrepost", method: http.MethodDelete, path: "/" + id + "/repost", setup: func(r *gin.Engine) { r.DELETE("/:id/repost", handler.Unrepost) }},
		{name: "vote poll", method: http.MethodPost, path: "/" + id + "/poll/vote", setup: func(r *gin.Engine) { r.POST("/:id/poll/vote", handler.VotePoll) }},
		{name: "close poll", method: http.MethodPost, path: "/" + id + "/poll/close", setup: func(r *gin.Engine) { r.POST("/:id/poll/close", handler.ClosePoll) }},
		{name: "get bookmarked posts", method: http.MethodGet, path: "/bookmarks", setup: func(r *gin.Engine) { r.GET("/bookmarks", handler.GetBookmarkedPosts) }},
		{name: "bookmark post", method: http.MethodPost, path: "/" + id + "/bookmark", setup: func(r *gin.Engine) { r.POST("/:id/bookmark", handler.BookmarkPost) }},
		{name: "unbookmark post", method: http.MethodDelete, path: "/" + id + "/bookmark", setup: func(r *gin.Engine) { r.DELETE("/:id/bookmark", handler.UnbookmarkPost) }},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			tt.setup(router)
			rec := httptest.NewRecorder()
			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusInternalServerError {
				t.Fatalf("%s status = %d, want 500: %s", tt.name, rec.Code, rec.Body.String())
			}
		})
	}
}

// TestHandlerHealthDBError couvre la branche "db: error" de Handler.Health
// lorsque la connexion sous-jacente est fermee (sqlDB.PingContext echoue).
func TestHandlerHealthDBError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db := closedPostDB(t)
	handler := NewHandler(db)
	router := gin.New()
	router.GET("/health", handler.Health)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/health", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("Health status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), `"db":"error"`) {
		t.Fatalf("Health body = %s, want db error", rec.Body.String())
	}
}

// TestHandlerGetRepliesPrivateProfileAndNotFound couvre les branches 403
// "profile is private" et 404 "post not found" de Handler.GetReplies,
// jusqu'ici seulement exercees via base fermee (500 systematique) ou id
// invalide (400).
func TestHandlerGetRepliesPrivateProfileAndNotFound(t *testing.T) {
	gin.SetMode(gin.TestMode)
	postID := uuid.New()

	t.Run("private profile forbidden", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.GET("/:id/replies", handler.GetReplies)

		authorID := uuid.New()
		parent := models.Post{ID: postID, AuthorID: authorID, Visibility: "PUBLIC", Content: "hi"}
		expectFindPostByID(mock, parent)
		expectAccessibilityChecks(mock, authorID, true, false, false)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/"+postID.String()+"/replies", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("GetReplies status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("parent not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.GET("/:id/replies", handler.GetReplies)

		expectFindPostByIDNotFound(mock)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/"+postID.String()+"/replies", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("GetReplies status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})
}

// TestHandlerGetPostsByKeywordSuccess couvre le chemin de succes (requete non
// vide) de Handler.GetPostsByKeyword, jusqu'ici seulement exerce avec une
// requete vide (raccourci 200 immediat) ou une base fermee (500).
func TestHandlerGetPostsByKeywordSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newPostMockDB(t)
	handler := NewHandler(db)
	router := gin.New()
	router.GET("/search", handler.GetPostsByKeyword)

	mock.ExpectQuery(`FROM posts\.posts AS p`).WillReturnRows(
		sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}))

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/search?q=go", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("GetPostsByKeyword status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), `"posts":[]`) && !strings.Contains(rec.Body.String(), `"posts":null`) {
		t.Fatalf("GetPostsByKeyword body = %s, want posts array", rec.Body.String())
	}
}

// TestServiceViewerProfileIDWithContextAccount couvre, via une requete HTTP
// reelle passant par middleware.AuthOptional() (seul moyen d'injecter un
// accountID dans le request context utilise par viewerProfileID, la cle
// interne de middleware n'etant pas exportee), les branches "lookup reussi"
// et "lookup en erreur" de viewerProfileID -- jusqu'ici seule la branche
// "pas de compte dans le contexte" etait testee directement.
func TestServiceViewerProfileIDWithContextAccount(t *testing.T) {
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	accountID := uuid.New()
	token, err := security.SignAccessToken(accountID, middleware.RoleUser, time.Hour)
	if err != nil {
		t.Fatalf("SignAccessToken() unexpected error: %v", err)
	}

	t.Run("profile lookup succeeds", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		RegisterRoutes(router, handler)

		profileID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		mock.ExpectQuery(`FROM posts\.posts AS p`).WillReturnRows(
			sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}))

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/feed", nil)
		req.Header.Set("Authorization", "Bearer "+token)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("GET /feed status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("profile lookup fails falls back to nil viewer", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		RegisterRoutes(router, handler)

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(errors.New("boom"))
		mock.ExpectQuery(`FROM posts\.posts AS p`).WillReturnRows(
			sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}))

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/feed", nil)
		req.Header.Set("Authorization", "Bearer "+token)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("GET /feed status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})
}

// TestHandlerProfileByUsernameNotFound couvre les branches 404 "profile not
// found" de GetPostsByAuthor, GetRepostsByAuthor et GetRepliesByAuthor,
// jusqu'ici seulement exercees pour la branche 403 (profil prive) ou via une
// base fermee (500 systematique). Un profil inexistant remonte
// gorm.ErrRecordNotFound depuis CanViewProfileContent.
func TestHandlerProfileByUsernameNotFound(t *testing.T) {
	gin.SetMode(gin.TestMode)

	newRouter := func() (*gin.Engine, sqlmock.Sqlmock, *Handler) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		return router, mock, handler
	}

	t.Run("posts by author not found", func(t *testing.T) {
		router, mock, handler := newRouter()
		router.GET("/author/:username", handler.GetPostsByAuthor)
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnError(gorm.ErrRecordNotFound)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/author/ghost", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("GetPostsByAuthor status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("reposts by author not found", func(t *testing.T) {
		router, mock, handler := newRouter()
		router.GET("/author/:username/reposts", handler.GetRepostsByAuthor)
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnError(gorm.ErrRecordNotFound)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/author/ghost/reposts", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("GetRepostsByAuthor status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("replies by author not found", func(t *testing.T) {
		router, mock, handler := newRouter()
		router.GET("/author/:username/replies", handler.GetRepliesByAuthor)
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnError(gorm.ErrRecordNotFound)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/author/ghost/replies", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("GetRepliesByAuthor status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})
}

// TestHandlerGetTrendingTagsServiceError couvre la branche 500 de
// Handler.GetTrendingTags, jusqu'ici seulement exercee via base fermee (qui
// echoue avant meme la requete) ou le chemin de succes.
func TestHandlerGetTrendingTagsServiceError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newPostMockDB(t)
	handler := NewHandler(db)
	router := gin.New()
	router.GET("/tags/trending", handler.GetTrendingTags)

	mock.ExpectQuery(`FROM posts\.tags AS t`).WillReturnError(errors.New("boom"))

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/tags/trending", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("GetTrendingTags status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerGetTrendingTagsValidLimit couvre la branche "limit = parsedLimit"
// de Handler.GetTrendingTags (query param limit valide), jusqu'ici seulement
// exercee avec la valeur par defaut (limit absent) ou un limit invalide.
func TestHandlerGetTrendingTagsValidLimit(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newPostMockDB(t)
	handler := NewHandler(db)
	router := gin.New()
	router.GET("/tags/trending", handler.GetTrendingTags)

	mock.ExpectQuery(`FROM posts\.tags AS t`).WillReturnRows(
		sqlmock.NewRows([]string{"name", "post_count", "like_count", "repost_count"}).
			AddRow("go", 3, 5, 1))

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/tags/trending?limit=5", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("GetTrendingTags status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerGetPostsByTagEmptyTag couvre la branche 400 "invalid tag" de
// Handler.GetPostsByTag lorsque le parametre de route est vide. Le routeur
// gin standard ne permet pas d'atteindre cette branche via :tag (le segment
// vide ne matche jamais la route), donc le handler est invoque directement
// avec un gin.Context construit a la main et Params force a vide.
func TestHandlerGetPostsByTagEmptyTag(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newPostMockDB(t)
	handler := NewHandler(db)

	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodGet, "/tag/", nil)
	c.Params = gin.Params{{Key: "tag", Value: ""}}

	handler.GetPostsByTag(c)
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("GetPostsByTag status = %d, want 400: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerDeletePostNotFound couvre la branche 404 de Handler.DeletePost,
// jusqu'ici seulement exercee pour le succes et le 403 (auteur different).
func TestHandlerDeletePostNotFound(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newPostMockDB(t)
	handler := NewHandler(db)
	accountID := uuid.New()
	postID := uuid.New()
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	router.DELETE("/:id", handler.DeletePost)

	expectProfileLookupByAccountID(mock, accountID, accountID)
	mock.ExpectQuery(`SELECT role FROM "auth"\."accounts"`).WillReturnRows(sqlmock.NewRows([]string{"role"}).AddRow("USER"))
	expectFindPostByIDNotFound(mock)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodDelete, "/"+postID.String(), nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusNotFound {
		t.Fatalf("DeletePost status = %d, want 404: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerLikeRepostBookmarkInvalidIDAndServiceError couvre, pour
// LikePost/Repost/BookmarkPost/UnbookmarkPost, la branche "invalid post id"
// (uuid.Parse echoue) atteinte apres le controle de statut de compte, ainsi
// que la branche 500 generique du service (erreur DB non-NotFound).
func TestHandlerLikeRepostBookmarkInvalidIDAndServiceError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	postID := uuid.New()

	newAuthedRouter := func() (*gin.Engine, sqlmock.Sqlmock, *Handler) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.Use(func(c *gin.Context) {
			c.Set(middleware.ContextAccountID, accountID)
			c.Next()
		})
		return router, mock, handler
	}

	t.Run("like invalid id", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/like", handler.LikePost)
		expectAccountStatus(mock, "ACTIVE")

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/bad/like", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("LikePost status = %d, want 400: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("like service error", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/like", handler.LikePost)
		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, accountID)
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE id`).WillReturnError(errors.New("boom"))

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/like", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("LikePost status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("repost invalid id", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/repost", handler.Repost)
		expectAccountStatus(mock, "ACTIVE")

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/bad/repost", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("Repost status = %d, want 400: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("repost service error", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/repost", handler.Repost)
		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, accountID)
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE id`).WillReturnError(errors.New("boom"))

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/repost", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("Repost status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("bookmark invalid id", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/bookmark", handler.BookmarkPost)
		expectAccountStatus(mock, "ACTIVE")

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/bad/bookmark", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("BookmarkPost status = %d, want 400: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("bookmark service error", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/bookmark", handler.BookmarkPost)
		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, accountID)
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE id`).WillReturnError(errors.New("boom"))

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/bookmark", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("BookmarkPost status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unbookmark invalid id", func(t *testing.T) {
		router, _, handler := newAuthedRouter()
		router.DELETE("/:id/bookmark", handler.UnbookmarkPost)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodDelete, "/bad/bookmark", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("UnbookmarkPost status = %d, want 400: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unbookmark service error", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.DELETE("/:id/bookmark", handler.UnbookmarkPost)
		expectProfileLookupByAccountID(mock, accountID, accountID)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."bookmarks"`)).WillReturnError(errors.New("boom"))
		mock.ExpectRollback()

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodDelete, "/"+postID.String()+"/bookmark", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("UnbookmarkPost status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}
