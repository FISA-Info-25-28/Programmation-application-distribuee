package post

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"breezy/backend/internal/middleware"
	"breezy/backend/internal/models"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// TestHandlerCreatePostHappyPath exerce le chemin de succes complet de
// Handler.CreatePost (jusqu'ici seulement teste via base absente/fermee, qui
// ne depassait jamais le controle du statut de compte), pour couvrir le
// binding JSON, l'appel au service et la reponse 201.
func TestHandlerCreatePostHappyPath(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newPostMockDB(t)
	handler := NewHandler(db)
	accountID := uuid.New()
	authorID := uuid.New()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	router.POST("/", handler.CreatePost)

	expectAccountStatus(mock, "ACTIVE")
	expectProfileLookupByAccountID(mock, accountID, authorID)
	expectProfileIsPrivate(mock, authorID, false)

	mock.ExpectBegin()
	mock.ExpectQuery(qm(`INSERT INTO "posts"`)).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at", "updated_at"}).
			AddRow(uuid.New(), time.Now(), time.Now()))
	mock.ExpectCommit()

	expectEnrichPosts(mock, nil, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/", strings.NewReader(`{"content":"hello world","visibility":"PUBLIC"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusCreated {
		t.Fatalf("CreatePost status = %d, want 201: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerCreatePostSuspendedAccount couvre la branche 403 "account
// suspended" du handler, distincte du test "account status" deja exerce sur
// LikePost.
func TestHandlerCreatePostSuspendedAccount(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newPostMockDB(t)
	handler := NewHandler(db)
	accountID := uuid.New()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	router.POST("/", handler.CreatePost)

	expectAccountStatus(mock, "BANNED")

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/", strings.NewReader(`{"content":"hello"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusForbidden {
		t.Fatalf("CreatePost status = %d, want 403: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerCreatePostInvalidPayload couvre la branche 400 "invalid post
// payload" lorsque le JSON est valide mais que la validation du DTO echoue
// (contenu vide).
func TestHandlerCreatePostInvalidPayload(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newPostMockDB(t)
	handler := NewHandler(db)
	accountID := uuid.New()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	router.POST("/", handler.CreatePost)

	expectAccountStatus(mock, "ACTIVE")

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/", strings.NewReader(`{"content":""}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("CreatePost status = %d, want 400: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerCreatePostServiceErrors couvre le mapping d'erreurs du service
// vers les codes HTTP (case par case du switch de Handler.CreatePost).
func TestHandlerCreatePostServiceErrors(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	authorID := uuid.New()

	newRouter := func() (*gin.Engine, sqlmock.Sqlmock, *Handler) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.Use(func(c *gin.Context) {
			c.Set(middleware.ContextAccountID, accountID)
			c.Next()
		})
		router.POST("/", handler.CreatePost)
		return router, mock, handler
	}

	t.Run("private profile public visibility forbidden", func(t *testing.T) {
		router, mock, _ := newRouter()
		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, authorID)
		expectProfileIsPrivate(mock, authorID, true)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/", strings.NewReader(`{"content":"hi","visibility":"PUBLIC"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("CreatePost status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("parent not found", func(t *testing.T) {
		router, mock, _ := newRouter()
		parentID := uuid.New()
		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, authorID)
		expectProfileIsPrivate(mock, authorID, false)
		expectFindPostByIDNotFound(mock)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/", strings.NewReader(`{"content":"hi","parentId":"`+parentID.String()+`"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("CreatePost status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	// "generic service error" couvre la branche default (500 "failed to create
	// post") du switch, atteinte ici via un echec generique (non-NotFound) de
	// la requete is_private apres la recuperation du profil auteur.
	t.Run("generic service error", func(t *testing.T) {
		router, mock, _ := newRouter()
		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, authorID)
		mock.ExpectQuery(`SELECT id, is_private FROM "profiles"\."profiles" WHERE id`).
			WillReturnError(errors.New("boom"))

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/", strings.NewReader(`{"content":"hi"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("CreatePost status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}

// TestHandlerInteractionHappyPathsExtra complete
// TestPostHandlerInteractionHappyPaths (deja present) avec les chemins de
// succes non encore exerces : DeletePost, UpdatePostVisibility, UnlikePost,
// Unrepost, UnbookmarkPost, VotePoll, ClosePoll, GetBookmarkedPosts, GetPost,
// GetReplies, GetPostsByAuthor, GetRepostsByAuthor, GetRepliesByAuthor,
// GetPostsByTag, GetTrendingTags.
func TestHandlerInteractionHappyPathsExtra(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	postID := uuid.New()

	newAuthedRouter := func() (*gin.Engine, sqlmock.Sqlmock, *Handler) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.Use(func(c *gin.Context) {
			c.Set(middleware.ContextAccountID, accountID)
			c.Next()
		})
		return router, mock, handler
	}

	t.Run("delete post happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.DELETE("/:id", handler.DeletePost)

		expectProfileLookupByAccountID(mock, accountID, accountID)
		mock.ExpectQuery(`SELECT role FROM "auth"\."accounts"`).WillReturnRows(sqlmock.NewRows([]string{"role"}).AddRow("USER"))
		post := models.Post{ID: postID, AuthorID: accountID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`UPDATE "posts"."posts" SET`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodDelete, "/"+postID.String(), nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNoContent {
			t.Fatalf("DeletePost status = %d, want 204: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("delete post forbidden", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.DELETE("/:id", handler.DeletePost)

		otherAuthorID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		mock.ExpectQuery(`SELECT role FROM "auth"\."accounts"`).WillReturnRows(sqlmock.NewRows([]string{"role"}).AddRow("USER"))
		post := models.Post{ID: postID, AuthorID: otherAuthorID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodDelete, "/"+postID.String(), nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("DeletePost status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("update visibility happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.PATCH("/:id/visibility", handler.UpdatePostVisibility)

		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: accountID, Visibility: "FOLLOWERS"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`UPDATE "posts" SET "visibility"`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{accountID: {ID: accountID, Username: "alice"}})

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/"+postID.String()+"/visibility", strings.NewReader(`{"visibility":"PRIVATE"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("UpdatePostVisibility status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unlike post happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.DELETE("/:id/like", handler.UnlikePost)

		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."likes"`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodDelete, "/"+postID.String()+"/like", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNoContent {
			t.Fatalf("UnlikePost status = %d, want 204: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unrepost happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.DELETE("/:id/repost", handler.Unrepost)

		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."reposts"`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodDelete, "/"+postID.String()+"/repost", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNoContent {
			t.Fatalf("Unrepost status = %d, want 204: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unbookmark happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.DELETE("/:id/bookmark", handler.UnbookmarkPost)

		expectProfileLookupByAccountID(mock, accountID, accountID)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."bookmarks"`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodDelete, "/"+postID.String()+"/bookmark", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNoContent {
			t.Fatalf("UnbookmarkPost status = %d, want 204: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unbookmark not found", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.DELETE("/:id/bookmark", handler.UnbookmarkPost)

		expectProfileLookupByAccountID(mock, accountID, accountID)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."bookmarks"`)).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectCommit()

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodDelete, "/"+postID.String()+"/bookmark", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("UnbookmarkPost status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get bookmarked posts happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/bookmarks", handler.GetBookmarkedPosts)

		authorID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		postRows := sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}).
			AddRow(postID, authorID, "PUBLIC", "hi")
		mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p`).WillReturnRows(postRows)
		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/bookmarks", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("GetBookmarkedPosts status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("vote poll happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/poll/vote", handler.VotePoll)

		voterID := uuid.New()
		pollID := uuid.New()
		optionID := uuid.New()

		expectProfileLookupByAccountID(mock, accountID, voterID)
		pollRows := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		optionRows := sqlmock.NewRows([]string{"id", "poll_id"}).AddRow(optionID, pollID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(optionRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnError(gorm.ErrRecordNotFound)

		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "posts"."poll_votes"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "created_at"}).AddRow(uuid.New(), time.Now()))
		mock.ExpectExec(qm(`UPDATE "posts"."poll_options"`)).WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()

		pollRows2 := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows2)
		optionRows2 := sqlmock.NewRows([]string{"id", "poll_id"}).AddRow(optionID, pollID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(optionRows2)
		finalVoteRows := sqlmock.NewRows([]string{"id", "poll_id", "option_id", "user_id"}).AddRow(uuid.New(), pollID, optionID, voterID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnRows(finalVoteRows)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/poll/vote", strings.NewReader(`{"optionId":"`+optionID.String()+`"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("VotePoll status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("close poll happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/poll/close", handler.ClosePoll)

		pollID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: accountID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		pollRows := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id"}))
		mock.ExpectBegin()
		mock.ExpectExec(qm(`UPDATE "posts"."polls"`)).WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnError(gorm.ErrRecordNotFound)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/poll/close", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("ClosePoll status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get post happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/:id", handler.GetPost)

		authorID := uuid.New()
		post := models.Post{ID: postID, AuthorID: authorID, Visibility: "PUBLIC", Content: "hi"}
		expectFindPostByID(mock, post)
		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/"+postID.String(), nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("GetPost status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get post private profile forbidden", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/:id", handler.GetPost)

		authorID := uuid.New()
		post := models.Post{ID: postID, AuthorID: authorID, Visibility: "PUBLIC", Content: "hi"}
		expectFindPostByID(mock, post)
		expectAccessibilityChecks(mock, authorID, true, false, false)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/"+postID.String(), nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("GetPost status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get post not found", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/:id", handler.GetPost)

		expectFindPostByIDNotFound(mock)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/"+postID.String(), nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("GetPost status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get replies happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/:id/replies", handler.GetReplies)

		authorID := uuid.New()
		parent := models.Post{ID: postID, AuthorID: authorID, Visibility: "PUBLIC", Content: "hi"}
		replyID := uuid.New()
		expectFindPostByID(mock, parent)
		expectAccessibilityChecks(mock, authorID, false, false, false)

		replyRows := sqlmock.NewRows([]string{"id", "author_id", "parent_id", "visibility", "content"}).
			AddRow(replyID, authorID, parent.ID, "PUBLIC", "a reply")
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE parent_id IN`).WillReturnRows(replyRows)
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE parent_id IN`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "author_id", "parent_id", "visibility", "content"}))
		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{replyID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/"+postID.String()+"/replies", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("GetReplies status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get posts by author happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/author/:username", handler.GetPostsByAuthor)

		authorID := uuid.New()
		newProfileRows := func() *sqlmock.Rows {
			return sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
				AddRow(authorID, uuid.New(), "alice", false)
		}
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())
		postRows := sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}).
			AddRow(postID, authorID, "PUBLIC", "hi")
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id`).WillReturnRows(postRows)
		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/author/alice", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("GetPostsByAuthor status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get posts by author private profile forbidden", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/author/:username", handler.GetPostsByAuthor)

		profileRows := sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
			AddRow(uuid.New(), uuid.New(), "alice", true)
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(profileRows)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/author/alice", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("GetPostsByAuthor status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get reposts by author happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/author/:username/reposts", handler.GetRepostsByAuthor)

		authorID := uuid.New()
		newProfileRows := func() *sqlmock.Rows {
			return sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
				AddRow(authorID, uuid.New(), "alice", false)
		}
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())
		repostRows := sqlmock.NewRows([]string{"id", "author_id", "visibility", "content", "reposter_id"}).
			AddRow(postID, authorID, "PUBLIC", "hi", authorID)
		mock.ExpectQuery(`FROM posts\.posts AS p`).WillReturnRows(repostRows)
		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/author/alice/reposts", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("GetRepostsByAuthor status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get replies by author happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/author/:username/replies", handler.GetRepliesByAuthor)

		authorID := uuid.New()
		newProfileRows := func() *sqlmock.Rows {
			return sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
				AddRow(authorID, uuid.New(), "alice", false)
		}
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())
		replyRows := sqlmock.NewRows([]string{"id", "author_id", "parent_id", "visibility", "content"}).
			AddRow(postID, authorID, uuid.New(), "PUBLIC", "a reply")
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id`).WillReturnRows(replyRows)
		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/author/alice/replies", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("GetRepliesByAuthor status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get posts by tag happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/tag/:tag", handler.GetPostsByTag)

		mock.ExpectQuery(`FROM posts\.posts AS p`).WillReturnRows(
			sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}))

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/tag/go", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("GetPostsByTag status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("get trending tags happy path", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/tags/trending", handler.GetTrendingTags)

		mock.ExpectQuery(`FROM posts\.tags AS t`).WillReturnRows(
			sqlmock.NewRows([]string{"name", "post_count", "like_count", "repost_count"}).
				AddRow("go", 3, 5, 1))

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/tags/trending", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("GetTrendingTags status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})
}

// TestHandlerHealthWithWorkingDatabase couvre la branche "db: ok" de
// Handler.Health (jusqu'ici seulement exercee avec db nil -> "unavailable").
func TestHandlerHealthWithWorkingDatabase(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := newPostMockDB(t)
	handler := NewHandler(db)
	router := gin.New()
	router.GET("/health", handler.Health)

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/health", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("Health status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), `"db":"ok"`) {
		t.Fatalf("Health body = %s, want db ok", rec.Body.String())
	}
}

// TestHandlerGetPostsEmptyFeed couvre le chemin de succes de
// Handler.GetPosts (jusqu'ici seulement exerce avec une base fermee -> 500).
func TestHandlerGetPostsEmptyFeed(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newPostMockDB(t)
	handler := NewHandler(db)
	router := gin.New()
	router.GET("/feed", handler.GetPosts)

	mock.ExpectQuery(`FROM posts\.posts AS p`).WillReturnRows(
		sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}))

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/feed", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("GetPosts status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerGetFollowingPostsEmptyFeed couvre le chemin de succes de
// Handler.GetFollowingPosts (jusqu'ici seulement exerce avec une base fermee).
func TestHandlerGetFollowingPostsEmptyFeed(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := newPostMockDB(t)
	handler := NewHandler(db)
	accountID := uuid.New()
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	})
	router.GET("/following", handler.GetFollowingPosts)

	expectProfileLookupByAccountID(mock, accountID, accountID)
	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).WillReturnRows(sqlmock.NewRows([]string{"followed_id"}))

	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/following", nil)
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("GetFollowingPosts status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}

// TestHandlerLikeUnlikeRepostBookmarkNotFound couvre les branches 404 "post
// not found" des handlers d'interaction, jusqu'ici seulement exercees via une
// base fermee (qui retourne toujours 500, jamais 404).
func TestHandlerLikeUnlikeRepostBookmarkNotFound(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	postID := uuid.New()

	newAuthedRouter := func() (*gin.Engine, sqlmock.Sqlmock, *Handler) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.Use(func(c *gin.Context) {
			c.Set(middleware.ContextAccountID, accountID)
			c.Next()
		})
		return router, mock, handler
	}

	t.Run("like post not found", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/like", handler.LikePost)
		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, accountID)
		expectFindPostByIDNotFound(mock)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/like", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("LikePost status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unlike post not found", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.DELETE("/:id/like", handler.UnlikePost)
		expectProfileLookupByAccountID(mock, accountID, accountID)
		expectFindPostByIDNotFound(mock)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodDelete, "/"+postID.String()+"/like", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("UnlikePost status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("repost suspended account", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/repost", handler.Repost)
		expectAccountStatus(mock, "SUSPENDED")

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/repost", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("Repost status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("repost not found", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/repost", handler.Repost)
		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, accountID)
		expectFindPostByIDNotFound(mock)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/repost", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("Repost status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unrepost not found", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.DELETE("/:id/repost", handler.Unrepost)
		expectProfileLookupByAccountID(mock, accountID, accountID)
		expectFindPostByIDNotFound(mock)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodDelete, "/"+postID.String()+"/repost", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("Unrepost status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("bookmark suspended account", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/bookmark", handler.BookmarkPost)
		expectAccountStatus(mock, "SUSPENDED")

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/bookmark", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("BookmarkPost status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("bookmark not found", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/bookmark", handler.BookmarkPost)
		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, accountID)
		expectFindPostByIDNotFound(mock)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/bookmark", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("BookmarkPost status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})
}

// TestHandlerUpdatePostVisibilityServiceErrors couvre le mapping d'erreurs du
// service vers les codes HTTP pour Handler.UpdatePostVisibility (jusqu'ici
// seulement exerce via la branche 400 de validation du payload ou via 500 sur
// base fermee).
func TestHandlerUpdatePostVisibilityServiceErrors(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	postID := uuid.New()

	newAuthedRouter := func() (*gin.Engine, sqlmock.Sqlmock, *Handler) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.Use(func(c *gin.Context) {
			c.Set(middleware.ContextAccountID, accountID)
			c.Next()
		})
		router.PATCH("/:id/visibility", handler.UpdatePostVisibility)
		return router, mock, handler
	}

	t.Run("forbidden when not author", func(t *testing.T) {
		router, mock, _ := newAuthedRouter()
		otherAuthorID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: otherAuthorID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/"+postID.String()+"/visibility", strings.NewReader(`{"visibility":"PRIVATE"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("UpdatePostVisibility status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("post not found", func(t *testing.T) {
		router, mock, _ := newAuthedRouter()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		expectFindPostByIDNotFound(mock)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/"+postID.String()+"/visibility", strings.NewReader(`{"visibility":"PRIVATE"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("UpdatePostVisibility status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("private profile cannot go public", func(t *testing.T) {
		router, mock, _ := newAuthedRouter()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: accountID, Visibility: "FOLLOWERS"}
		expectFindPostByID(mock, post)
		expectProfileIsPrivate(mock, accountID, true)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/"+postID.String()+"/visibility", strings.NewReader(`{"visibility":"PUBLIC"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("UpdatePostVisibility status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})
}

// TestHandlerVotePollServiceErrors couvre le mapping d'erreurs du service vers
// les codes HTTP pour Handler.VotePoll (already voted / poll closed / poll
// not found), jusqu'ici seulement exerce via base absente/fermee ou payload
// invalide.
func TestHandlerVotePollServiceErrors(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	postID := uuid.New()
	optionID := uuid.New()

	newAuthedRouter := func() (*gin.Engine, sqlmock.Sqlmock, *Handler) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.Use(func(c *gin.Context) {
			c.Set(middleware.ContextAccountID, accountID)
			c.Next()
		})
		router.POST("/:id/poll/vote", handler.VotePoll)
		return router, mock, handler
	}

	t.Run("already voted", func(t *testing.T) {
		router, mock, _ := newAuthedRouter()
		pollID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		pollRows := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id"}))
		voteRows := sqlmock.NewRows([]string{"id", "poll_id", "user_id"}).AddRow(uuid.New(), pollID, accountID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnRows(voteRows)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/poll/vote", strings.NewReader(`{"optionId":"`+optionID.String()+`"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusConflict {
			t.Fatalf("VotePoll status = %d, want 409: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("poll closed", func(t *testing.T) {
		router, mock, _ := newAuthedRouter()
		pollID := uuid.New()
		closedAt := time.Now()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		pollRows := sqlmock.NewRows([]string{"id", "post_id", "closed_at"}).AddRow(pollID, postID, closedAt)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id"}))

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/poll/vote", strings.NewReader(`{"optionId":"`+optionID.String()+`"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("VotePoll status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("poll not found", func(t *testing.T) {
		router, mock, _ := newAuthedRouter()
		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(gorm.ErrRecordNotFound)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/poll/vote", strings.NewReader(`{"optionId":"`+optionID.String()+`"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("VotePoll status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	// "invalid option" couvre ErrInvalidPoll (400) : optionId bien forme (passe
	// la validation DTO) mais ne correspondant a aucune option du sondage cible.
	t.Run("invalid option", func(t *testing.T) {
		router, mock, _ := newAuthedRouter()
		pollID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		pollRows := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id"}).AddRow(uuid.New(), pollID))
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnError(gorm.ErrRecordNotFound)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/poll/vote", strings.NewReader(`{"optionId":"`+optionID.String()+`"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("VotePoll status = %d, want 400: %s", rec.Code, rec.Body.String())
		}
	})
}

// TestHandlerClosePollServiceErrors couvre le mapping d'erreurs du service
// vers les codes HTTP pour Handler.ClosePoll (forbidden / already closed /
// not found).
func TestHandlerClosePollServiceErrors(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	postID := uuid.New()

	newAuthedRouter := func() (*gin.Engine, sqlmock.Sqlmock, *Handler) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.Use(func(c *gin.Context) {
			c.Set(middleware.ContextAccountID, accountID)
			c.Next()
		})
		router.POST("/:id/poll/close", handler.ClosePoll)
		return router, mock, handler
	}

	t.Run("forbidden when not author", func(t *testing.T) {
		router, mock, _ := newAuthedRouter()
		otherAuthorID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: otherAuthorID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/poll/close", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("ClosePoll status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("already closed", func(t *testing.T) {
		router, mock, _ := newAuthedRouter()
		pollID := uuid.New()
		closedAt := time.Now()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: accountID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		pollRows := sqlmock.NewRows([]string{"id", "post_id", "closed_at"}).AddRow(pollID, postID, closedAt)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id"}))

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/poll/close", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusConflict {
			t.Fatalf("ClosePoll status = %d, want 409: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("post not found", func(t *testing.T) {
		router, mock, _ := newAuthedRouter()
		expectProfileLookupByAccountID(mock, accountID, accountID)
		expectFindPostByIDNotFound(mock)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/poll/close", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("ClosePoll status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})
}

// TestHandlerGetRepostsAndRepliesByAuthorNotFound couvre les branches 403/404
// de GetRepostsByAuthor et GetRepliesByAuthor (private profile / profile not
// found), jusqu'ici seulement exercees via base fermee (500 systematique).
func TestHandlerGetRepostsAndRepliesByAuthorNotFound(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()

	newAuthedRouter := func() (*gin.Engine, sqlmock.Sqlmock, *Handler) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.Use(func(c *gin.Context) {
			c.Set(middleware.ContextAccountID, accountID)
			c.Next()
		})
		return router, mock, handler
	}

	t.Run("reposts by author private profile forbidden", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/author/:username/reposts", handler.GetRepostsByAuthor)
		profileRows := sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
			AddRow(uuid.New(), uuid.New(), "alice", true)
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(profileRows)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/author/alice/reposts", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("GetRepostsByAuthor status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("replies by author private profile forbidden", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.GET("/author/:username/replies", handler.GetRepliesByAuthor)
		profileRows := sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
			AddRow(uuid.New(), uuid.New(), "alice", true)
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(profileRows)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/author/alice/replies", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("GetRepliesByAuthor status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})
}
