package post

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"breezy/backend/internal/middleware"
	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestPostHandlerDatabaseUnavailable(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(nil)
	id := uuid.NewString()

	tests := []struct {
		method string
		path   string
		setup  func(*gin.Engine)
		want   int
	}{
		{method: http.MethodGet, path: "/health", setup: func(r *gin.Engine) { r.GET("/health", handler.Health) }, want: http.StatusOK},
		{method: http.MethodGet, path: "/feed", setup: func(r *gin.Engine) { r.GET("/feed", handler.GetPosts) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/following", setup: func(r *gin.Engine) { r.GET("/following", handler.GetFollowingPosts) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/" + id, setup: func(r *gin.Engine) { r.GET("/:id", handler.GetPost) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/" + id + "/replies", setup: func(r *gin.Engine) { r.GET("/:id/replies", handler.GetReplies) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/tag/go", setup: func(r *gin.Engine) { r.GET("/tag/:tag", handler.GetPostsByTag) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/search?q=go", setup: func(r *gin.Engine) { r.GET("/search", handler.GetPostsByKeyword) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/author/alice", setup: func(r *gin.Engine) { r.GET("/author/:username", handler.GetPostsByAuthor) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/author/alice/reposts", setup: func(r *gin.Engine) { r.GET("/author/:username/reposts", handler.GetRepostsByAuthor) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/author/alice/replies", setup: func(r *gin.Engine) { r.GET("/author/:username/replies", handler.GetRepliesByAuthor) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/tags/trending", setup: func(r *gin.Engine) { r.GET("/tags/trending", handler.GetTrendingTags) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/", setup: func(r *gin.Engine) { r.POST("/", handler.CreatePost) }, want: http.StatusServiceUnavailable},
		{method: http.MethodDelete, path: "/" + id, setup: func(r *gin.Engine) { r.DELETE("/:id", handler.DeletePost) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPatch, path: "/" + id + "/visibility", setup: func(r *gin.Engine) { r.PATCH("/:id/visibility", handler.UpdatePostVisibility) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/" + id + "/like", setup: func(r *gin.Engine) { r.POST("/:id/like", handler.LikePost) }, want: http.StatusServiceUnavailable},
		{method: http.MethodDelete, path: "/" + id + "/like", setup: func(r *gin.Engine) { r.DELETE("/:id/like", handler.UnlikePost) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/" + id + "/repost", setup: func(r *gin.Engine) { r.POST("/:id/repost", handler.Repost) }, want: http.StatusServiceUnavailable},
		{method: http.MethodDelete, path: "/" + id + "/repost", setup: func(r *gin.Engine) { r.DELETE("/:id/repost", handler.Unrepost) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/" + id + "/poll/vote", setup: func(r *gin.Engine) { r.POST("/:id/poll/vote", handler.VotePoll) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/" + id + "/poll/close", setup: func(r *gin.Engine) { r.POST("/:id/poll/close", handler.ClosePoll) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/bookmarks", setup: func(r *gin.Engine) { r.GET("/bookmarks", handler.GetBookmarkedPosts) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/" + id + "/bookmark", setup: func(r *gin.Engine) { r.POST("/:id/bookmark", handler.BookmarkPost) }, want: http.StatusServiceUnavailable},
		{method: http.MethodDelete, path: "/" + id + "/bookmark", setup: func(r *gin.Engine) { r.DELETE("/:id/bookmark", handler.UnbookmarkPost) }, want: http.StatusServiceUnavailable},
	}

	for _, tt := range tests {
		router := gin.New()
		tt.setup(router)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != tt.want {
			t.Fatalf("%s %s status = %d, want %d", tt.method, tt.path, rec.Code, tt.want)
		}
	}
}

func TestRegisterRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	RegisterRoutes(router, NewHandler(nil))

	tests := []struct {
		method string
		path   string
		want   int
	}{
		{method: http.MethodGet, path: "/health", want: http.StatusOK},
		{method: http.MethodGet, path: "/feed", want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/", want: http.StatusUnauthorized},
	}

	for _, tt := range tests {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != tt.want {
			t.Fatalf("%s %s status = %d, want %d", tt.method, tt.path, rec.Code, tt.want)
		}
	}
}

func TestPostHandlerInvalidInputsWithDatabase(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(&gorm.DB{})
	accountID := uuid.New()

	tests := []struct {
		name        string
		method      string
		path        string
		body        string
		withAccount bool
		setup       func(*gin.Engine)
		want        int
	}{
		{name: "get post invalid id", method: http.MethodGet, path: "/bad", setup: func(r *gin.Engine) { r.GET("/:id", handler.GetPost) }, want: http.StatusBadRequest},
		{name: "get replies invalid id", method: http.MethodGet, path: "/bad/replies", setup: func(r *gin.Engine) { r.GET("/:id/replies", handler.GetReplies) }, want: http.StatusBadRequest},
		{name: "trending invalid limit", method: http.MethodGet, path: "/tags/trending?limit=99", setup: func(r *gin.Engine) { r.GET("/tags/trending", handler.GetTrendingTags) }, want: http.StatusBadRequest},
		{name: "search empty query", method: http.MethodGet, path: "/search", setup: func(r *gin.Engine) { r.GET("/search", handler.GetPostsByKeyword) }, want: http.StatusOK},
		{name: "create missing account", method: http.MethodPost, path: "/", body: `{"content":"hello"}`, setup: func(r *gin.Engine) { r.POST("/", handler.CreatePost) }, want: http.StatusInternalServerError},
		{name: "delete invalid id", method: http.MethodDelete, path: "/bad", withAccount: true, setup: func(r *gin.Engine) { r.DELETE("/:id", handler.DeletePost) }, want: http.StatusBadRequest},
		{name: "visibility invalid id", method: http.MethodPatch, path: "/bad/visibility", body: `{"visibility":"PUBLIC"}`, withAccount: true, setup: func(r *gin.Engine) { r.PATCH("/:id/visibility", handler.UpdatePostVisibility) }, want: http.StatusBadRequest},
		{name: "visibility invalid payload", method: http.MethodPatch, path: "/" + uuid.NewString() + "/visibility", body: `{"visibility":"FRIENDS"}`, withAccount: true, setup: func(r *gin.Engine) { r.PATCH("/:id/visibility", handler.UpdatePostVisibility) }, want: http.StatusBadRequest},
		{name: "unlike invalid id", method: http.MethodDelete, path: "/bad/like", withAccount: true, setup: func(r *gin.Engine) { r.DELETE("/:id/like", handler.UnlikePost) }, want: http.StatusBadRequest},
		{name: "unrepost invalid id", method: http.MethodDelete, path: "/bad/repost", withAccount: true, setup: func(r *gin.Engine) { r.DELETE("/:id/repost", handler.Unrepost) }, want: http.StatusBadRequest},
		{name: "vote invalid id", method: http.MethodPost, path: "/bad/poll/vote", withAccount: true, setup: func(r *gin.Engine) { r.POST("/:id/poll/vote", handler.VotePoll) }, want: http.StatusBadRequest},
		{name: "vote invalid payload", method: http.MethodPost, path: "/" + uuid.NewString() + "/poll/vote", body: `{"optionId":"00000000-0000-0000-0000-000000000000"}`, withAccount: true, setup: func(r *gin.Engine) { r.POST("/:id/poll/vote", handler.VotePoll) }, want: http.StatusBadRequest},
		{name: "close poll invalid id", method: http.MethodPost, path: "/bad/poll/close", withAccount: true, setup: func(r *gin.Engine) { r.POST("/:id/poll/close", handler.ClosePoll) }, want: http.StatusBadRequest},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			if tt.withAccount {
				router.Use(func(c *gin.Context) {
					c.Set(middleware.ContextAccountID, accountID)
					c.Next()
				})
			}
			tt.setup(router)
			rec := httptest.NewRecorder()
			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			router.ServeHTTP(rec, req)
			if rec.Code != tt.want {
				t.Fatalf("status = %d, want %d: %s", rec.Code, tt.want, rec.Body.String())
			}
		})
	}
}

func TestPostHandlerDatabaseFailures(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db := closedPostDB(t)
	handler := NewHandler(db)
	accountID := uuid.New()
	postID := uuid.NewString()
	optionID := uuid.NewString()

	tests := []struct {
		name   string
		method string
		path   string
		body   string
		setup  func(*gin.Engine)
	}{
		{name: "feed", method: http.MethodGet, path: "/feed", setup: func(r *gin.Engine) { r.GET("/feed", handler.GetPosts) }},
		{name: "following", method: http.MethodGet, path: "/following", setup: func(r *gin.Engine) { r.GET("/following", handler.GetFollowingPosts) }},
		{name: "post", method: http.MethodGet, path: "/" + postID, setup: func(r *gin.Engine) { r.GET("/:id", handler.GetPost) }},
		{name: "replies", method: http.MethodGet, path: "/" + postID + "/replies", setup: func(r *gin.Engine) { r.GET("/:id/replies", handler.GetReplies) }},
		{name: "tag", method: http.MethodGet, path: "/tag/go", setup: func(r *gin.Engine) { r.GET("/tag/:tag", handler.GetPostsByTag) }},
		{name: "search", method: http.MethodGet, path: "/search?q=go", setup: func(r *gin.Engine) { r.GET("/search", handler.GetPostsByKeyword) }},
		{name: "author", method: http.MethodGet, path: "/author/alice", setup: func(r *gin.Engine) { r.GET("/author/:username", handler.GetPostsByAuthor) }},
		{name: "author reposts", method: http.MethodGet, path: "/author/alice/reposts", setup: func(r *gin.Engine) { r.GET("/author/:username/reposts", handler.GetRepostsByAuthor) }},
		{name: "author replies", method: http.MethodGet, path: "/author/alice/replies", setup: func(r *gin.Engine) { r.GET("/author/:username/replies", handler.GetRepliesByAuthor) }},
		{name: "trending", method: http.MethodGet, path: "/tags/trending", setup: func(r *gin.Engine) { r.GET("/tags/trending", handler.GetTrendingTags) }},
		{name: "create", method: http.MethodPost, path: "/", body: `{"content":"hello","visibility":"PUBLIC"}`, setup: func(r *gin.Engine) { r.POST("/", handler.CreatePost) }},
		{name: "delete", method: http.MethodDelete, path: "/" + postID, setup: func(r *gin.Engine) { r.DELETE("/:id", handler.DeletePost) }},
		{name: "visibility", method: http.MethodPatch, path: "/" + postID + "/visibility", body: `{"visibility":"PRIVATE"}`, setup: func(r *gin.Engine) { r.PATCH("/:id/visibility", handler.UpdatePostVisibility) }},
		{name: "like", method: http.MethodPost, path: "/" + postID + "/like", setup: func(r *gin.Engine) { r.POST("/:id/like", handler.LikePost) }},
		{name: "unlike", method: http.MethodDelete, path: "/" + postID + "/like", setup: func(r *gin.Engine) { r.DELETE("/:id/like", handler.UnlikePost) }},
		{name: "repost", method: http.MethodPost, path: "/" + postID + "/repost", setup: func(r *gin.Engine) { r.POST("/:id/repost", handler.Repost) }},
		{name: "unrepost", method: http.MethodDelete, path: "/" + postID + "/repost", setup: func(r *gin.Engine) { r.DELETE("/:id/repost", handler.Unrepost) }},
		{name: "vote", method: http.MethodPost, path: "/" + postID + "/poll/vote", body: `{"optionId":"` + optionID + `"}`, setup: func(r *gin.Engine) { r.POST("/:id/poll/vote", handler.VotePoll) }},
		{name: "close poll", method: http.MethodPost, path: "/" + postID + "/poll/close", setup: func(r *gin.Engine) { r.POST("/:id/poll/close", handler.ClosePoll) }},
		{name: "bookmarks", method: http.MethodGet, path: "/bookmarks", setup: func(r *gin.Engine) { r.GET("/bookmarks", handler.GetBookmarkedPosts) }},
		{name: "bookmark", method: http.MethodPost, path: "/" + postID + "/bookmark", setup: func(r *gin.Engine) { r.POST("/:id/bookmark", handler.BookmarkPost) }},
		{name: "unbookmark", method: http.MethodDelete, path: "/" + postID + "/bookmark", setup: func(r *gin.Engine) { r.DELETE("/:id/bookmark", handler.UnbookmarkPost) }},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			router.Use(func(c *gin.Context) {
				c.Set(middleware.ContextAccountID, accountID)
				c.Next()
			})
			tt.setup(router)
			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			rec := httptest.NewRecorder()
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusInternalServerError {
				t.Fatalf("status = %d, want 500: %s", rec.Code, rec.Body.String())
			}
		})
	}
}

// expectAccountStatus programme la requete brute lancee par
// Handler.accountStatus (verification SUSPENDED/BANNED) au tout debut des
// handlers d'interaction (like/repost/bookmark/create).
func expectAccountStatus(mock sqlmock.Sqlmock, status string) {
	mock.ExpectQuery(`SELECT status FROM auth\.accounts WHERE id`).
		WillReturnRows(sqlmock.NewRows([]string{"status"}).AddRow(status))
}

// TestPostHandlerInteractionHappyPaths couvre les chemins de succes des
// handlers d'interaction (like/repost/bookmark), jusqu'ici seulement exerces
// via une base fermee (echec systematique) ou une base absente : la branche
// de reponse 204 n'etait donc jamais atteinte.
func TestPostHandlerInteractionHappyPaths(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()
	postID := uuid.New()

	newAuthedRouter := func() (*gin.Engine, sqlmock.Sqlmock, *Handler) {
		db, mock := newPostMockDB(t)
		handler := NewHandler(db)
		router := gin.New()
		router.Use(func(c *gin.Context) {
			c.Set(middleware.ContextAccountID, accountID)
			c.Next()
		})
		return router, mock, handler
	}

	t.Run("like post", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/like", handler.LikePost)

		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectQuery(`SELECT \* FROM "posts"\."likes"`).WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "posts"\."likes"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectCommit()

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/like", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNoContent {
			t.Fatalf("LikePost status = %d, want 204: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("repost", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/repost", handler.Repost)

		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectQuery(`SELECT \* FROM "posts"\."reposts"`).WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "posts"\."reposts"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectCommit()

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/repost", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNoContent {
			t.Fatalf("Repost status = %d, want 204: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("bookmark", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/bookmark", handler.BookmarkPost)

		expectAccountStatus(mock, "ACTIVE")
		expectProfileLookupByAccountID(mock, accountID, accountID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "posts"\."bookmarks"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectCommit()

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/bookmark", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNoContent {
			t.Fatalf("BookmarkPost status = %d, want 204: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("like account suspended", func(t *testing.T) {
		router, mock, handler := newAuthedRouter()
		router.POST("/:id/like", handler.LikePost)

		expectAccountStatus(mock, "SUSPENDED")

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/"+postID.String()+"/like", nil)
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusForbidden {
			t.Fatalf("LikePost status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})
}

func closedPostDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	mock.ExpectClose()
	if err := sqlDB.Close(); err != nil {
		t.Fatalf("Close() unexpected error: %v", err)
	}
	return db
}
