package post

import (
	"context"
	"errors"
	"sort"
	"strings"
	"time"

	"breezy/backend/internal/models"

	"github.com/google/uuid"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type Repository struct {
	db *gorm.DB
}

func NewRepository(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

func (r *Repository) WithDB(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

func (r *Repository) FindAllPosts(ctx context.Context) ([]models.Post, error) {
	var posts []models.Post

	err := r.db.
		WithContext(ctx).
		Where("deleted_at IS NULL").
		Order("created_at DESC").
		Find(&posts).Error

	return posts, err
}

func (r *Repository) FindFeedPosts(ctx context.Context) ([]models.Post, error) {
	var posts []models.Post

	err := r.db.
		WithContext(ctx).
		Where("parent_id IS NULL AND deleted_at IS NULL").
		Order("created_at DESC").
		Find(&posts).Error

	return posts, err
}

func (r *Repository) FindPostByID(ctx context.Context, postID uuid.UUID) (models.Post, error) {
	var post models.Post

	err := r.db.
		WithContext(ctx).
		First(&post, "id = ? AND deleted_at IS NULL", postID).Error

	return post, err
}

func (r *Repository) FindFollowingPosts(ctx context.Context, profileID uuid.UUID) ([]models.Post, error) {
	var posts []models.Post

	err := r.db.
		WithContext(ctx).
		Table("posts.posts AS p").
		Select("p.*").
		Joins("JOIN social.follows f ON f.followed_id = p.author_id").
		Where("f.follower_id = ? AND p.parent_id IS NULL AND p.deleted_at IS NULL", profileID).
		Order("p.created_at DESC").
		Find(&posts).Error

	return posts, err
}

// FeedPost étend models.Post avec le contexte social (qui a reposté).
type FeedPost struct {
	models.Post
	ReposterID *uuid.UUID `gorm:"column:reposter_id"`
	SortTime   time.Time  `gorm:"column:sort_time"`
}

// repostRow est utilisé pour scanner les reposts depuis la DB.
type repostRow struct {
	PostID    uuid.UUID `gorm:"column:post_id"`
	UserID    uuid.UUID `gorm:"column:user_id"`
	CreatedAt time.Time `gorm:"column:created_at"`
}

// FindFollowingFeedPosts retourne les posts des abonnés + leurs reposts,
// chaque post une seule fois, trié par activité récente.
// Entree : ctx, profileID.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindFollowingFeedPosts(ctx context.Context, profileID uuid.UUID) ([]FeedPost, error) {
	// 1. IDs des utilisateurs suivis
	var followedIDs []uuid.UUID
	if err := r.db.WithContext(ctx).
		Table("social.follows").
		Select("followed_id").
		Where("follower_id = ?", profileID).
		Scan(&followedIDs).Error; err != nil {
		return nil, err
	}
	if len(followedIDs) == 0 {
		return []FeedPost{}, nil
	}

	// 2. Posts publiés par les abonnés (hors viewer, hors réponses)
	var authoredPosts []models.Post
	if err := r.db.WithContext(ctx).
		Where("author_id IN ? AND author_id != ? AND parent_id IS NULL AND deleted_at IS NULL", followedIDs, profileID).
		Find(&authoredPosts).Error; err != nil {
		return nil, err
	}

	// 3. Reposts effectués par les abonnés
	var reposts []repostRow
	if err := r.db.WithContext(ctx).
		Table("posts.reposts").
		Select("post_id, user_id, created_at").
		Where("user_id IN ?", followedIDs).
		Order("created_at DESC").
		Scan(&reposts).Error; err != nil {
		return nil, err
	}

	// Reposter le plus récent par post_id
	latestReposter := make(map[uuid.UUID]repostRow)
	for _, rp := range reposts {
		if _, exists := latestReposter[rp.PostID]; !exists {
			latestReposter[rp.PostID] = rp
		}
	}

	// 4. Posts originaux des reposts non encore chargés
	authoredByID := make(map[uuid.UUID]models.Post, len(authoredPosts))
	for _, p := range authoredPosts {
		authoredByID[p.ID] = p
	}

	var missingIDs []uuid.UUID
	for postID := range latestReposter {
		if _, ok := authoredByID[postID]; !ok {
			missingIDs = append(missingIDs, postID)
		}
	}
	if len(missingIDs) > 0 {
		var extra []models.Post
		if err := r.db.WithContext(ctx).
			Where("id IN ? AND author_id != ? AND parent_id IS NULL AND deleted_at IS NULL", missingIDs, profileID).
			Find(&extra).Error; err != nil {
			return nil, err
		}
		for _, p := range extra {
			authoredByID[p.ID] = p
		}
	}

	// 5. Fusion + dédoublonnage par post_id
	feedByID := make(map[uuid.UUID]FeedPost, len(authoredByID))
	for _, p := range authoredPosts {
		feedByID[p.ID] = FeedPost{Post: p, SortTime: p.CreatedAt}
	}
	for postID, rp := range latestReposter {
		p, ok := authoredByID[postID]
		if !ok {
			continue
		}
		reposterID := rp.UserID
		existing, exists := feedByID[postID]
		if !exists || rp.CreatedAt.After(existing.SortTime) {
			feedByID[postID] = FeedPost{Post: p, ReposterID: &reposterID, SortTime: rp.CreatedAt}
		}
	}

	// 6. Tri décroissant + limite 100
	rows := make([]FeedPost, 0, len(feedByID))
	for _, fp := range feedByID {
		rows = append(rows, fp)
	}
	sort.Slice(rows, func(i, j int) bool {
		return rows[i].SortTime.After(rows[j].SortTime)
	})
	if len(rows) > 100 {
		rows = rows[:100]
	}

	return rows, nil
}

// FindGlobalFeedPosts retourne tous les posts + reposts, triés par activité récente.
// Entree : ctx, viewerProfileID.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindGlobalFeedPosts(ctx context.Context, viewerProfileID uuid.UUID) ([]FeedPost, error) {
	// 1. Tous les posts top-level
	var posts []models.Post
	if err := r.db.WithContext(ctx).
		Table("posts.posts AS p").
		Select("p.*").
		Joins("JOIN profiles.profiles AS author_profile ON author_profile.id = p.author_id").
		Joins("LEFT JOIN social.follows AS author_follow ON author_follow.followed_id = author_profile.id AND author_follow.follower_id = ?", viewerProfileID).
		Where("p.parent_id IS NULL AND p.deleted_at IS NULL").
		Where("author_profile.is_private = false OR author_profile.id = ? OR author_follow.id IS NOT NULL", viewerProfileID).
		Where("p.visibility = 'PUBLIC' OR (p.visibility = 'FOLLOWERS' AND (p.author_id = ? OR author_follow.id IS NOT NULL)) OR (p.visibility = 'PRIVATE' AND p.author_id = ?)", viewerProfileID, viewerProfileID).
		Where("NOT EXISTS (SELECT 1 FROM social.blocks b WHERE b.blocker_id = p.author_id AND b.blocked_id = ?)", viewerProfileID).
		Find(&posts).Error; err != nil {
		return nil, err
	}
	if len(posts) == 0 {
		return []FeedPost{}, nil
	}

	postIDs := make([]uuid.UUID, len(posts))
	for i, p := range posts {
		postIDs[i] = p.ID
	}

	// 2. Reposts de ces posts (pour connaître sort_time et reposter)
	var reposts []repostRow
	if err := r.db.WithContext(ctx).
		Table("posts.reposts AS r").
		Select("r.post_id, r.user_id, r.created_at").
		Joins("JOIN profiles.profiles AS reposter_profile ON reposter_profile.id = r.user_id").
		Joins("LEFT JOIN social.follows AS reposter_follow ON reposter_follow.followed_id = reposter_profile.id AND reposter_follow.follower_id = ?", viewerProfileID).
		Where("r.post_id IN ?", postIDs).
		Where("reposter_profile.is_private = false OR reposter_profile.id = ? OR reposter_follow.id IS NOT NULL", viewerProfileID).
		Where("NOT EXISTS (SELECT 1 FROM social.blocks b WHERE b.blocker_id = r.user_id AND b.blocked_id = ?)", viewerProfileID).
		Order("r.created_at DESC").
		Scan(&reposts).Error; err != nil {
		return nil, err
	}

	// Reposter le plus récent par post_id
	latestReposter := make(map[uuid.UUID]repostRow)
	for _, rp := range reposts {
		if _, exists := latestReposter[rp.PostID]; !exists {
			latestReposter[rp.PostID] = rp
		}
	}

	// 3. Construction des FeedPost avec sort_time
	rows := make([]FeedPost, 0, len(posts))
	for _, p := range posts {
		fp := FeedPost{Post: p, SortTime: p.CreatedAt}
		if rp, ok := latestReposter[p.ID]; ok && rp.CreatedAt.After(p.CreatedAt) {
			reposterID := rp.UserID
			fp.ReposterID = &reposterID
			fp.SortTime = rp.CreatedAt
		}
		rows = append(rows, fp)
	}

	// 4. Tri décroissant + limite 100
	sort.Slice(rows, func(i, j int) bool {
		return rows[i].SortTime.After(rows[j].SortTime)
	})
	if len(rows) > 100 {
		rows = rows[:100]
	}

	return rows, nil
}

func (r *Repository) FindProfilesByUsernames(ctx context.Context, usernames []string) ([]models.Profile, error) {
	if len(usernames) == 0 {
		return []models.Profile{}, nil
	}

	var profiles []models.Profile
	err := r.db.
		WithContext(ctx).
		Table("profiles.profiles").
		Where("lower(username) IN ?", usernames).
		Find(&profiles).Error

	return profiles, err
}

// FindProfileByDisplayName recupere un profil a partir de son nom affiche.
// Entree : ctx, displayName.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindProfileByDisplayName(ctx context.Context, displayName string) (models.Profile, error) {
	var profile models.Profile
	err := r.db.
		WithContext(ctx).
		Table("profiles.profiles").
		Where("lower(display_name) = lower(?)", strings.TrimSpace(displayName)).
		Limit(1).
		First(&profile).Error

	return profile, err
}

func (r *Repository) CreateNotification(ctx context.Context, notification *models.Notification) error {
	return r.db.
		WithContext(ctx).
		Table("social.notifications").
		Create(notification).Error
}

func (r *Repository) FindRepliesByParentID(ctx context.Context, parentID uuid.UUID) ([]models.Post, error) {
	posts := make([]models.Post, 0)
	parentIDs := []uuid.UUID{parentID}
	seen := map[uuid.UUID]struct{}{parentID: {}}

	for len(parentIDs) > 0 {
		var replies []models.Post
		if err := r.db.
			WithContext(ctx).
			Where("parent_id IN ? AND deleted_at IS NULL", parentIDs).
			Find(&replies).Error; err != nil {
			return nil, err
		}

		parentIDs = parentIDs[:0]
		for _, reply := range replies {
			if _, exists := seen[reply.ID]; exists {
				continue
			}

			seen[reply.ID] = struct{}{}
			posts = append(posts, reply)
			parentIDs = append(parentIDs, reply.ID)
		}
	}

	sort.SliceStable(posts, func(i, j int) bool {
		return posts[i].CreatedAt.Before(posts[j].CreatedAt)
	})

	return posts, nil
}

// FindRepliesByAuthorID retourne toutes les réponses (posts avec parent_id) écrites
// par un auteur donné, les plus récentes en premier.
// Entree : ctx, authorID.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindRepliesByAuthorID(ctx context.Context, authorID uuid.UUID) ([]models.Post, error) {
	var posts []models.Post

	err := r.db.
		WithContext(ctx).
		Where("author_id = ? AND parent_id IS NOT NULL", authorID).
		Order("created_at DESC").
		Find(&posts).Error

	return posts, err
}

// FindPostsByIDs récupère un lot de posts par leurs identifiants (utilisé pour
// charger les posts parents d'un ensemble de réponses).
// Entree : ctx, ids.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindPostsByIDs(ctx context.Context, ids []uuid.UUID) ([]models.Post, error) {
	if len(ids) == 0 {
		return []models.Post{}, nil
	}

	var posts []models.Post

	err := r.db.
		WithContext(ctx).
		Where("id IN ?", ids).
		Find(&posts).Error

	return posts, err
}

// FindProfileIDByUsername résout l'identifiant de profil à partir d'un username.
// Entree : ctx, username.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindProfileIDByUsername(ctx context.Context, username string) (uuid.UUID, error) {
	var row struct {
		ID uuid.UUID
	}

	err := r.db.
		WithContext(ctx).
		Table("profiles.profiles").
		Select("id").
		Where("username = ?", username).
		Limit(1).
		Scan(&row).Error
	if err != nil {
		return uuid.Nil, err
	}
	if row.ID == uuid.Nil {
		return uuid.Nil, gorm.ErrRecordNotFound
	}

	return row.ID, nil
}

func (r *Repository) FindProfileIDByAccountID(ctx context.Context, accountID uuid.UUID) (uuid.UUID, error) {
	var row struct {
		ID uuid.UUID
	}

	err := r.db.
		WithContext(ctx).
		Table("profiles.profiles").
		Select("id").
		Where("account_id = ?", accountID).
		Limit(1).
		Scan(&row).Error
	if err != nil {
		return uuid.Nil, err
	}
	if row.ID == uuid.Nil {
		return uuid.Nil, gorm.ErrRecordNotFound
	}

	return row.ID, nil
}

func (r *Repository) ProfileIsPrivate(ctx context.Context, profileID uuid.UUID) (bool, error) {
	var row struct {
		ID        uuid.UUID
		IsPrivate bool
	}

	err := r.db.
		WithContext(ctx).
		Table("profiles.profiles").
		Select("id, is_private").
		Where("id = ?", profileID).
		Limit(1).
		Scan(&row).Error
	if err != nil {
		return false, err
	}
	if row.ID == uuid.Nil {
		return false, gorm.ErrRecordNotFound
	}

	return row.IsPrivate, nil
}

func (r *Repository) FindFollowedProfileIDs(ctx context.Context, followerID uuid.UUID, followedIDs []uuid.UUID) (map[uuid.UUID]bool, error) {
	if followerID == uuid.Nil || len(followedIDs) == 0 {
		return map[uuid.UUID]bool{}, nil
	}

	var rows []struct {
		FollowedID uuid.UUID `gorm:"column:followed_id"`
	}

	if err := r.db.
		WithContext(ctx).
		Table("social.follows").
		Select("followed_id").
		Where("follower_id = ? AND followed_id IN ?", followerID, followedIDs).
		Scan(&rows).Error; err != nil {
		return nil, err
	}

	result := make(map[uuid.UUID]bool, len(rows))
	for _, row := range rows {
		result[row.FollowedID] = true
	}

	return result, nil
}

func (r *Repository) FindAccountRole(ctx context.Context, accountID uuid.UUID) (string, error) {
	var row struct {
		Role string
	}

	err := r.db.
		WithContext(ctx).
		Table("auth.accounts").
		Select("role").
		Where("id = ?", accountID).
		Limit(1).
		Scan(&row).Error
	if err != nil {
		return "", err
	}
	if row.Role == "" {
		return "", gorm.ErrRecordNotFound
	}

	return row.Role, nil
}

func (r *Repository) CreatePost(ctx context.Context, post *models.Post) error {
	return r.db.WithContext(ctx).Create(post).Error
}

func (r *Repository) UpdatePostVisibility(ctx context.Context, postID uuid.UUID, visibility string) error {
	return r.db.
		WithContext(ctx).
		Model(&models.Post{}).
		Where("id = ?", postID).
		Update("visibility", visibility).Error
}

func (r *Repository) CreateMedia(ctx context.Context, media []models.Media) error {
	if len(media) == 0 {
		return nil
	}
	return r.db.WithContext(ctx).Table("posts.media").Create(&media).Error
}

func (r *Repository) FindMediaByPostIDs(ctx context.Context, postIDs []uuid.UUID) (map[uuid.UUID][]models.Media, error) {
	if len(postIDs) == 0 {
		return map[uuid.UUID][]models.Media{}, nil
	}

	var media []models.Media
	if err := r.db.WithContext(ctx).
		Table("posts.media").
		Where("post_id IN ?", postIDs).
		Order("created_at ASC").
		Find(&media).Error; err != nil {
		return nil, err
	}

	byPostID := make(map[uuid.UUID][]models.Media, len(postIDs))
	for _, item := range media {
		byPostID[item.PostID] = append(byPostID[item.PostID], item)
	}
	return byPostID, nil
}

func (r *Repository) DeletePost(ctx context.Context, postID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Table("posts.posts").
		Where("id = ? AND deleted_at IS NULL", postID).
		Updates(map[string]any{
			"deleted_at": time.Now(),
			"updated_at": time.Now(),
		}).Error
}

func (r *Repository) CreateLike(ctx context.Context, like *models.Like) error {
	return r.db.
		WithContext(ctx).
		Table("posts.likes").
		Clauses(clause.OnConflict{DoNothing: true}).
		Create(like).Error
}

func (r *Repository) DeleteLike(ctx context.Context, postID, userID uuid.UUID) error {
	result := r.db.
		WithContext(ctx).
		Table("posts.likes").
		Delete(&models.Like{}, "post_id = ? AND user_id = ?", postID, userID)
	if result.Error != nil {
		return result.Error
	}
	if result.RowsAffected == 0 {
		return gorm.ErrRecordNotFound
	}

	return nil
}

func (r *Repository) CreateRepost(ctx context.Context, repost *models.Repost) error {
	return r.db.
		WithContext(ctx).
		Table("posts.reposts").
		Clauses(clause.OnConflict{DoNothing: true}).
		Create(repost).Error
}

func (r *Repository) DeleteRepost(ctx context.Context, postID, userID uuid.UUID) error {
	result := r.db.
		WithContext(ctx).
		Table("posts.reposts").
		Delete(&models.Repost{}, "post_id = ? AND user_id = ?", postID, userID)
	if result.Error != nil {
		return result.Error
	}
	if result.RowsAffected == 0 {
		return gorm.ErrRecordNotFound
	}

	return nil
}

func (r *Repository) HasLike(ctx context.Context, postID, userID uuid.UUID) (bool, error) {
	var like models.Like
	err := r.db.
		WithContext(ctx).
		Table("posts.likes").
		Limit(1).
		First(&like, "post_id = ? AND user_id = ?", postID, userID).Error
	if err == nil {
		return true, nil
	}
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return false, nil
	}

	return false, err
}

func (r *Repository) HasRepost(ctx context.Context, postID, userID uuid.UUID) (bool, error) {
	var repost models.Repost
	err := r.db.
		WithContext(ctx).
		Table("posts.reposts").
		Limit(1).
		First(&repost, "post_id = ? AND user_id = ?", postID, userID).Error
	if err == nil {
		return true, nil
	}
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return false, nil
	}

	return false, err
}

func (r *Repository) FindProfilesByIDs(ctx context.Context, profileIDs []uuid.UUID) (map[uuid.UUID]models.Profile, error) {
	if len(profileIDs) == 0 {
		return map[uuid.UUID]models.Profile{}, nil
	}

	var profiles []models.Profile
	err := r.db.
		WithContext(ctx).
		Table("profiles.profiles").
		Where("id IN ?", profileIDs).
		Find(&profiles).Error
	if err != nil {
		return nil, err
	}

	byID := make(map[uuid.UUID]models.Profile, len(profiles))
	for _, profile := range profiles {
		byID[profile.ID] = profile
	}

	return byID, nil
}

func (r *Repository) CountLikesByPostIDs(ctx context.Context, postIDs []uuid.UUID) (map[uuid.UUID]int64, error) {
	return r.countByPostID(ctx, (&models.Like{}), "post_id", "post_id IN ?", postIDs)
}

func (r *Repository) CountRepostsByPostIDs(ctx context.Context, postIDs []uuid.UUID) (map[uuid.UUID]int64, error) {
	if len(postIDs) == 0 {
		return map[uuid.UUID]int64{}, nil
	}

	var rows []struct {
		PostID uuid.UUID
		Count  int64
	}

	err := r.db.
		WithContext(ctx).
		Table("posts.reposts").
		Select("post_id, COUNT(*) AS count").
		Where("post_id IN ?", postIDs).
		Group("post_id").
		Scan(&rows).Error
	if err != nil {
		return nil, err
	}

	counts := make(map[uuid.UUID]int64, len(rows))
	for _, row := range rows {
		counts[row.PostID] = row.Count
	}

	return counts, nil
}

func (r *Repository) FindLikedPostIDsByUserID(ctx context.Context, userID uuid.UUID, postIDs []uuid.UUID) (map[uuid.UUID]bool, error) {
	if userID == uuid.Nil || len(postIDs) == 0 {
		return map[uuid.UUID]bool{}, nil
	}

	var rows []struct {
		PostID uuid.UUID
	}

	err := r.db.
		WithContext(ctx).
		Table("posts.likes").
		Select("post_id").
		Where("user_id = ? AND post_id IN ?", userID, postIDs).
		Scan(&rows).Error
	if err != nil {
		return nil, err
	}

	liked := make(map[uuid.UUID]bool, len(rows))
	for _, row := range rows {
		liked[row.PostID] = true
	}

	return liked, nil
}

func (r *Repository) FindRepostedPostIDsByUserID(ctx context.Context, userID uuid.UUID, postIDs []uuid.UUID) (map[uuid.UUID]bool, error) {
	if userID == uuid.Nil || len(postIDs) == 0 {
		return map[uuid.UUID]bool{}, nil
	}

	var rows []struct {
		PostID uuid.UUID
	}

	err := r.db.
		WithContext(ctx).
		Table("posts.reposts").
		Select("post_id").
		Where("user_id = ? AND post_id IN ?", userID, postIDs).
		Scan(&rows).Error
	if err != nil {
		return nil, err
	}

	reposted := make(map[uuid.UUID]bool, len(rows))
	for _, row := range rows {
		reposted[row.PostID] = true
	}

	return reposted, nil
}

func (r *Repository) CountRepliesByPostIDs(ctx context.Context, postIDs []uuid.UUID) (map[uuid.UUID]int64, error) {
	return r.countByPostID(ctx, (&models.Post{}), "parent_id", "parent_id IN ?", postIDs)
}

func (r *Repository) FindTagsByPostIDs(ctx context.Context, postIDs []uuid.UUID) (map[uuid.UUID][]string, error) {
	if len(postIDs) == 0 {
		return map[uuid.UUID][]string{}, nil
	}

	var rows []struct {
		PostID uuid.UUID
		Name   string
	}

	err := r.db.
		WithContext(ctx).
		Table("post_tags").
		Select("post_tags.post_id, tags.name").
		Joins("JOIN tags ON tags.id = post_tags.tag_id").
		Where("post_tags.post_id IN ?", postIDs).
		Scan(&rows).Error
	if err != nil {
		return nil, err
	}

	tagsByPostID := make(map[uuid.UUID][]string, len(postIDs))
	for _, row := range rows {
		tagsByPostID[row.PostID] = append(tagsByPostID[row.PostID], row.Name)
	}

	return tagsByPostID, nil
}

func (r *Repository) FindPostsByTag(ctx context.Context, tag string, viewerProfileID uuid.UUID) ([]models.Post, error) {
	var posts []models.Post

	err := r.db.
		WithContext(ctx).
		Table("posts.posts AS p").
		Select("p.*").
		Joins("JOIN posts.post_tags pt ON pt.post_id = p.id").
		Joins("JOIN posts.tags t ON t.id = pt.tag_id").
		Joins("JOIN profiles.profiles AS author_profile ON author_profile.id = p.author_id").
		Joins("LEFT JOIN social.follows AS author_follow ON author_follow.followed_id = author_profile.id AND author_follow.follower_id = ?", viewerProfileID).
		Where("LOWER(t.name) = ?", strings.ToLower(strings.TrimSpace(tag))).
		Where("p.deleted_at IS NULL").
		Where("author_profile.is_private = false OR author_profile.id = ? OR author_follow.id IS NOT NULL", viewerProfileID).
		Where("p.visibility = 'PUBLIC' OR (p.visibility = 'FOLLOWERS' AND (p.author_id = ? OR author_follow.id IS NOT NULL)) OR (p.visibility = 'PRIVATE' AND p.author_id = ?)", viewerProfileID, viewerProfileID).
		Where("NOT EXISTS (SELECT 1 FROM social.blocks b WHERE b.blocker_id = p.author_id AND b.blocked_id = ?)", viewerProfileID).
		Order("p.created_at DESC").
		Find(&posts).Error

	return posts, err
}

func (r *Repository) FindPostsByKeyword(ctx context.Context, query string, viewerProfileID uuid.UUID) ([]models.Post, error) {
	var posts []models.Post

	trimmed := strings.TrimSpace(query)
	if trimmed == "" {
		return []models.Post{}, nil
	}

	err := r.db.
		WithContext(ctx).
		Table("posts.posts AS p").
		Select("p.*").
		Joins("JOIN profiles.profiles AS author_profile ON author_profile.id = p.author_id").
		Joins("LEFT JOIN social.follows AS author_follow ON author_follow.followed_id = author_profile.id AND author_follow.follower_id = ?", viewerProfileID).
		Where("LOWER(p.content) LIKE ?", "%"+strings.ToLower(trimmed)+"%").
		Where("p.deleted_at IS NULL").
		Where("author_profile.is_private = false OR author_profile.id = ? OR author_follow.id IS NOT NULL", viewerProfileID).
		Where("p.visibility = 'PUBLIC' OR (p.visibility = 'FOLLOWERS' AND (p.author_id = ? OR author_follow.id IS NOT NULL)) OR (p.visibility = 'PRIVATE' AND p.author_id = ?)", viewerProfileID, viewerProfileID).
		Where("NOT EXISTS (SELECT 1 FROM social.blocks b WHERE b.blocker_id = p.author_id AND b.blocked_id = ?)", viewerProfileID).
		Order("p.created_at DESC").
		Find(&posts).Error

	return posts, err
}

func (r *Repository) FindPostsByAuthorUsername(ctx context.Context, username string) ([]models.Post, error) {
	var profile models.Profile
	if err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("lower(username) = lower(?)", strings.TrimSpace(username)).
		First(&profile).Error; err != nil {
		return nil, err
	}

	// La date du like determine l'ordre d'affichage dans l'onglet "likes" du profil.
	var posts []models.Post
	err := r.db.WithContext(ctx).
		Where("author_id = ? AND parent_id IS NULL AND deleted_at IS NULL", profile.ID).
		Order("created_at DESC").
		Find(&posts).Error
	return posts, err
}

func (r *Repository) FindRepliesByAuthorUsername(ctx context.Context, username string) ([]models.Post, error) {
	var profile models.Profile
	if err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("lower(username) = lower(?)", strings.TrimSpace(username)).
		First(&profile).Error; err != nil {
		return nil, err
	}

	var posts []models.Post
	err := r.db.WithContext(ctx).
		Where("author_id = ? AND parent_id IS NOT NULL AND deleted_at IS NULL", profile.ID).
		Order("created_at DESC").
		Find(&posts).Error
	return posts, err
}

func (r *Repository) CanViewProfileContent(ctx context.Context, username string, viewerAccountID uuid.UUID) (bool, error) {
	var profile models.Profile
	if err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("lower(username) = lower(?)", strings.TrimSpace(username)).
		First(&profile).Error; err != nil {
		return false, err
	}
	if profile.AccountID == viewerAccountID {
		return true, nil
	}
	if viewerAccountID == uuid.Nil {
		return !profile.IsPrivate, nil
	}
	blocked, err := r.ProfileBlocksAccount(ctx, profile.ID, viewerAccountID)
	if err != nil || blocked {
		return false, err
	}
	if !profile.IsPrivate {
		return true, nil
	}

	var count int64
	err = r.db.WithContext(ctx).
		Table("social.follows AS f").
		Joins("JOIN profiles.profiles AS viewer ON viewer.id = f.follower_id").
		Where("viewer.account_id = ? AND f.followed_id = ?", viewerAccountID, profile.ID).
		Count(&count).Error
	return count > 0, err
}

func (r *Repository) CanViewProfileContentByID(ctx context.Context, profileID, viewerAccountID uuid.UUID) (bool, error) {
	var profile models.Profile
	if err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		First(&profile, "id = ?", profileID).Error; err != nil {
		return false, err
	}
	if profile.AccountID == viewerAccountID {
		return true, nil
	}
	if viewerAccountID == uuid.Nil {
		return !profile.IsPrivate, nil
	}
	blocked, err := r.ProfileBlocksAccount(ctx, profile.ID, viewerAccountID)
	if err != nil || blocked {
		return false, err
	}
	if !profile.IsPrivate {
		return true, nil
	}

	var count int64
	err = r.db.WithContext(ctx).
		Table("social.follows AS f").
		Joins("JOIN profiles.profiles AS viewer ON viewer.id = f.follower_id").
		Where("viewer.account_id = ? AND f.followed_id = ?", viewerAccountID, profile.ID).
		Count(&count).Error
	return count > 0, err
}

func (r *Repository) ProfileBlocksAccount(ctx context.Context, profileID, accountID uuid.UUID) (bool, error) {
	if accountID == uuid.Nil {
		return false, nil
	}
	var count int64
	err := r.db.WithContext(ctx).Table("social.blocks AS b").
		Joins("JOIN profiles.profiles AS viewer ON viewer.account_id = ?", accountID).
		Where("b.blocker_id = ? AND b.blocked_id = viewer.id", profileID).
		Count(&count).Error
	return count > 0, err
}

func (r *Repository) FindBlockedProfileIDs(ctx context.Context, viewerID uuid.UUID, profileIDs []uuid.UUID) (map[uuid.UUID]bool, error) {
	blocked := map[uuid.UUID]bool{}
	if viewerID == uuid.Nil || len(profileIDs) == 0 {
		return blocked, nil
	}
	var rows []struct{ ProfileID uuid.UUID }
	err := r.db.WithContext(ctx).Raw(`
		SELECT blocker_id AS profile_id
		FROM social.blocks
		WHERE blocked_id = ? AND blocker_id IN ?
	`, viewerID, profileIDs).Scan(&rows).Error
	for _, row := range rows {
		blocked[row.ProfileID] = true
	}
	return blocked, err
}

func (r *Repository) FindRepostsByAuthorUsername(ctx context.Context, username string) ([]FeedPost, error) {
	var profile models.Profile
	if err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("lower(username) = lower(?)", strings.TrimSpace(username)).
		First(&profile).Error; err != nil {
		return nil, err
	}

	var rows []FeedPost
	err := r.db.WithContext(ctx).
		Table("posts.posts AS p").
		Select("p.*, ? AS reposter_id, r.created_at AS sort_time", profile.ID).
		Joins("JOIN posts.reposts AS r ON r.post_id = p.id").
		Where("r.user_id = ? AND p.parent_id IS NULL AND p.deleted_at IS NULL", profile.ID).
		Order("r.created_at DESC").
		Scan(&rows).Error
	return rows, err
}

// FindLikedPostsByAuthorUsername recupere les posts likes par un profil.
// Entree : ctx, username.
// Sortie : posts tries du like le plus recent au plus ancien et erreur eventuelle.
func (r *Repository) FindLikedPostsByAuthorUsername(ctx context.Context, username string) ([]models.Post, error) {
	var profile models.Profile
	if err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("lower(username) = lower(?)", strings.TrimSpace(username)).
		First(&profile).Error; err != nil {
		return nil, err
	}

	var posts []models.Post
	err := r.db.WithContext(ctx).
		Table("posts.posts AS p").
		Select("p.*").
		Joins("JOIN posts.likes AS l ON l.post_id = p.id").
		Where("l.user_id = ? AND p.deleted_at IS NULL", profile.ID).
		Order("l.created_at DESC").
		Find(&posts).Error
	return posts, err
}

func (r *Repository) UpsertTags(ctx context.Context, names []string) (map[string]uuid.UUID, error) {
	if len(names) == 0 {
		return map[string]uuid.UUID{}, nil
	}

	tags := make([]models.Tag, 0, len(names))
	for _, name := range names {
		tags = append(tags, models.Tag{Name: name})
	}

	if err := r.db.
		WithContext(ctx).
		Table("posts.tags").
		Clauses(clause.OnConflict{Columns: []clause.Column{{Name: "name"}}, DoNothing: true}).
		Create(&tags).Error; err != nil {
		return nil, err
	}

	var persisted []models.Tag
	if err := r.db.
		WithContext(ctx).
		Table("posts.tags").
		Where("name IN ?", names).
		Find(&persisted).Error; err != nil {
		return nil, err
	}

	idsByName := make(map[string]uuid.UUID, len(persisted))
	for _, tag := range persisted {
		idsByName[tag.Name] = tag.ID
	}

	return idsByName, nil
}

func (r *Repository) AttachTagsToPost(ctx context.Context, postID uuid.UUID, tagIDs []uuid.UUID) error {
	if len(tagIDs) == 0 {
		return nil
	}

	links := make([]models.PostTag, 0, len(tagIDs))
	for _, tagID := range tagIDs {
		links = append(links, models.PostTag{PostID: postID, TagID: tagID})
	}

	return r.db.
		WithContext(ctx).
		Table("posts.post_tags").
		Clauses(clause.OnConflict{DoNothing: true}).
		Create(&links).Error
}

func (r *Repository) FindTrendingTags(ctx context.Context, limit int, viewerProfileID uuid.UUID) ([]trendingTagResponse, error) {
	if limit <= 0 {
		limit = 6
	}

	var trends []trendingTagResponse

	err := r.db.
		WithContext(ctx).
		Table("posts.tags AS t").
		Select(`
			t.name,
			COUNT(DISTINCT p.id) AS post_count,
			COALESCE(SUM(l.like_count), 0) AS like_count,
			COALESCE(SUM(r.repost_count), 0) AS repost_count
		`).
		Joins("JOIN posts.post_tags pt ON pt.tag_id = t.id").
		Joins("JOIN posts.posts p ON p.id = pt.post_id").
		Joins("JOIN profiles.profiles author_profile ON author_profile.id = p.author_id").
		Joins("LEFT JOIN social.follows author_follow ON author_follow.followed_id = p.author_id AND author_follow.follower_id = ?", viewerProfileID).
		Joins(`
			LEFT JOIN (
				SELECT post_id, COUNT(*) AS like_count
				FROM posts.likes
				GROUP BY post_id
			) l ON l.post_id = p.id
		`).
		Joins(`
			LEFT JOIN (
				SELECT post_id, COUNT(*) AS repost_count
				FROM posts.reposts
				GROUP BY post_id
			) r ON r.post_id = p.id
		`).
		Where("p.parent_id IS NULL AND p.deleted_at IS NULL").
		Where("author_profile.is_private = false OR author_profile.id = ? OR author_follow.id IS NOT NULL", viewerProfileID).
		Where("p.visibility = 'PUBLIC' OR (p.visibility = 'FOLLOWERS' AND (p.author_id = ? OR author_follow.id IS NOT NULL)) OR (p.visibility = 'PRIVATE' AND p.author_id = ?)", viewerProfileID, viewerProfileID).
		Where("NOT EXISTS (SELECT 1 FROM social.blocks b WHERE b.blocker_id = p.author_id AND b.blocked_id = ?)", viewerProfileID).
		Where("p.created_at >= NOW() - INTERVAL '7 days'").
		Group("t.id, t.name").
		Order("post_count DESC, like_count DESC, t.name ASC").
		Limit(limit).
		Scan(&trends).Error
	if err != nil {
		return nil, err
	}

	return trends, nil
}

func (r *Repository) countByPostID(ctx context.Context, model any, field string, condition string, postIDs []uuid.UUID) (map[uuid.UUID]int64, error) {
	if len(postIDs) == 0 {
		return map[uuid.UUID]int64{}, nil
	}

	var rows []struct {
		PostID uuid.UUID
		Count  int64
	}

	err := r.db.
		WithContext(ctx).
		Model(model).
		Select(field+" AS post_id, COUNT(*) AS count").
		Where(condition, postIDs).
		Group(field).
		Scan(&rows).Error
	if err != nil {
		return nil, err
	}

	counts := make(map[uuid.UUID]int64, len(rows))
	for _, row := range rows {
		counts[row.PostID] = row.Count
	}

	return counts, nil
}

func (r *Repository) Transaction(ctx context.Context, fn func(txRepo *Repository) error) error {
	return r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		return fn(r.WithDB(tx))
	})
}

// Poll

func (r *Repository) CreatePoll(ctx context.Context, poll *models.Poll) error {
	return r.db.WithContext(ctx).Table("posts.polls").Create(poll).Error
}

func (r *Repository) CreatePollOptions(ctx context.Context, options []models.PollOption) error {
	return r.db.WithContext(ctx).Table("posts.poll_options").Create(&options).Error
}

func (r *Repository) FindPollByPostID(ctx context.Context, postID uuid.UUID) (models.Poll, error) {
	var poll models.Poll
	err := r.db.WithContext(ctx).
		Table("posts.polls").
		Preload("Options", func(db *gorm.DB) *gorm.DB {
			return db.Table("posts.poll_options").Order("position ASC")
		}).
		First(&poll, "post_id = ?", postID).Error
	return poll, err
}

func (r *Repository) FindPollsByPostIDs(ctx context.Context, postIDs []uuid.UUID) (map[uuid.UUID]models.Poll, error) {
	if len(postIDs) == 0 {
		return map[uuid.UUID]models.Poll{}, nil
	}

	var polls []models.Poll
	if err := r.db.WithContext(ctx).
		Table("posts.polls").
		Where("post_id IN ?", postIDs).
		Find(&polls).Error; err != nil {
		return nil, err
	}

	pollIDs := make([]uuid.UUID, 0, len(polls))
	for _, p := range polls {
		pollIDs = append(pollIDs, p.ID)
	}

	var options []models.PollOption
	if len(pollIDs) > 0 {
		if err := r.db.WithContext(ctx).
			Table("posts.poll_options").
			Where("poll_id IN ?", pollIDs).
			Order("position ASC").
			Find(&options).Error; err != nil {
			return nil, err
		}
	}

	optsByPollID := make(map[uuid.UUID][]models.PollOption)
	for _, opt := range options {
		optsByPollID[opt.PollID] = append(optsByPollID[opt.PollID], opt)
	}

	byPostID := make(map[uuid.UUID]models.Poll, len(polls))
	for _, p := range polls {
		p.Options = optsByPollID[p.ID]
		byPostID[p.PostID] = p
	}

	return byPostID, nil
}

func (r *Repository) FindVoteByPollAndUser(ctx context.Context, pollID, userID uuid.UUID) (models.PollVote, error) {
	var vote models.PollVote
	err := r.db.WithContext(ctx).
		Table("posts.poll_votes").
		First(&vote, "poll_id = ? AND user_id = ?", pollID, userID).Error
	return vote, err
}

func (r *Repository) FindVotesByPollIDsAndUser(ctx context.Context, pollIDs []uuid.UUID, userID uuid.UUID) (map[uuid.UUID]models.PollVote, error) {
	if len(pollIDs) == 0 || userID == uuid.Nil {
		return map[uuid.UUID]models.PollVote{}, nil
	}

	var votes []models.PollVote
	if err := r.db.WithContext(ctx).
		Table("posts.poll_votes").
		Where("poll_id IN ? AND user_id = ?", pollIDs, userID).
		Find(&votes).Error; err != nil {
		return nil, err
	}

	byPollID := make(map[uuid.UUID]models.PollVote, len(votes))
	for _, v := range votes {
		byPollID[v.PollID] = v
	}

	return byPollID, nil
}

func (r *Repository) CreatePollVote(ctx context.Context, vote *models.PollVote) error {
	return r.db.WithContext(ctx).Table("posts.poll_votes").
		Clauses(clause.OnConflict{DoNothing: true}).
		Create(vote).Error
}

func (r *Repository) IncrementPollOptionVote(ctx context.Context, optionID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Table("posts.poll_options").
		Where("id = ?", optionID).
		UpdateColumn("vote_count", gorm.Expr("vote_count + 1")).Error
}

func (r *Repository) FindPollByID(ctx context.Context, pollID uuid.UUID) (models.Poll, error) {
	var poll models.Poll
	err := r.db.WithContext(ctx).
		Table("posts.polls").
		Preload("Options", func(db *gorm.DB) *gorm.DB {
			return db.Table("posts.poll_options").Order("position ASC")
		}).
		First(&poll, "id = ?", pollID).Error
	return poll, err
}

func (r *Repository) ClosePoll(ctx context.Context, pollID uuid.UUID, closedAt time.Time) error {
	return r.db.WithContext(ctx).
		Table("posts.polls").
		Where("id = ?", pollID).
		Update("closed_at", closedAt).Error
}

// Bookmarks

func (r *Repository) CreateBookmark(ctx context.Context, userID, postID uuid.UUID) error {
	bm := models.Bookmark{PostID: postID, UserID: userID}
	return r.db.WithContext(ctx).
		Table("posts.bookmarks").
		Clauses(clause.OnConflict{DoNothing: true}).
		Create(&bm).Error
}

func (r *Repository) DeleteBookmark(ctx context.Context, userID, postID uuid.UUID) error {
	result := r.db.WithContext(ctx).
		Table("posts.bookmarks").
		Delete(&models.Bookmark{}, "post_id = ? AND user_id = ?", postID, userID)
	if result.Error != nil {
		return result.Error
	}
	if result.RowsAffected == 0 {
		return gorm.ErrRecordNotFound
	}
	return nil
}

func (r *Repository) FindBookmarkedPostIDsByUserID(ctx context.Context, userID uuid.UUID, postIDs []uuid.UUID) (map[uuid.UUID]bool, error) {
	if userID == uuid.Nil || len(postIDs) == 0 {
		return map[uuid.UUID]bool{}, nil
	}
	var rows []struct{ PostID uuid.UUID }
	err := r.db.WithContext(ctx).
		Table("posts.bookmarks").
		Select("post_id").
		Where("user_id = ? AND post_id IN ?", userID, postIDs).
		Scan(&rows).Error
	if err != nil {
		return nil, err
	}
	bookmarked := make(map[uuid.UUID]bool, len(rows))
	for _, row := range rows {
		bookmarked[row.PostID] = true
	}
	return bookmarked, nil
}

func (r *Repository) FindBookmarkedPostsByUserID(ctx context.Context, userID uuid.UUID) ([]models.Post, error) {
	var posts []models.Post
	err := r.db.WithContext(ctx).
		Table("posts.posts AS p").
		Select("p.*").
		Joins("JOIN posts.bookmarks bm ON bm.post_id = p.id").
		Where("bm.user_id = ? AND p.deleted_at IS NULL", userID).
		Order("bm.created_at DESC").
		Find(&posts).Error
	return posts, err
}
