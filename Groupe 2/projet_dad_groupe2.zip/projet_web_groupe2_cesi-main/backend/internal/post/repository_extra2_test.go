package post

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
)

// TestFindFollowingFeedPosts_RepostedPostMissingAfterExtraLookup couvre la
// branche "continue" de FindFollowingFeedPosts (repository.go ~168) : un
// repost reference un post_id qui reste absent de authoredByID meme apres la
// requete "extra" (par ex. parce qu'il s'agit en realite d'une reponse ou
// d'un post supprime filtre par la clause WHERE), donc il doit etre ignore
// silencieusement plutot que de produire un FeedPost avec un Post zero-value.
func TestFindFollowingFeedPosts_RepostedPostMissingAfterExtraLookup(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	authorID := uuid.New()
	postID := uuid.New()
	orphanRepostedID := uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
		WillReturnRows(sqlmock.NewRows([]string{"followed_id"}).AddRow(authorID))

	authoredRows := sqlmock.NewRows(postRows())
	addPostRow(authoredRows, postID, authorID, "hello", now)
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id IN`).
		WillReturnRows(authoredRows)

	repostRows := sqlmock.NewRows([]string{"post_id", "user_id", "created_at"}).
		AddRow(orphanRepostedID, authorID, now.Add(time.Hour))
	mock.ExpectQuery(`SELECT post_id, user_id, created_at FROM "posts"\."reposts"`).
		WillReturnRows(repostRows)

	// La requete "extra" ne retourne aucune ligne : orphanRepostedID reste
	// absent de authoredByID (ex: c'est une reponse, filtree par parent_id IS NULL).
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE id IN`).
		WillReturnRows(sqlmock.NewRows(postRows()))

	got, err := repo.FindFollowingFeedPosts(context.Background(), profileID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 1 {
		t.Fatalf("expected 1 feed post (orphan repost ignored), got %d: %+v", len(got), got)
	}
	if got[0].Post.ID != postID {
		t.Fatalf("expected only the authored post, got %v", got[0].Post.ID)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations: %v", err)
	}
}

// TestProfileBlocksAccount_NilAccountID couvre le court-circuit
// "accountID == uuid.Nil" de ProfileBlocksAccount (visiteur anonyme : aucune
// requete SQL n'est emise, le resultat est false).
func TestProfileBlocksAccount_NilAccountID(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()

	blocked, err := repo.ProfileBlocksAccount(context.Background(), profileID, uuid.Nil)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if blocked {
		t.Fatal("expected false for nil accountID")
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations (should be none): %v", err)
	}
}

// TestFindRepostsByAuthorUsername_ProfileNotFoundOrError couvre la propagation
// d'erreur lorsque le profil de l'auteur recherche n'existe pas (ou que la
// requete echoue), avant meme d'interroger les reposts.
func TestFindRepostsByAuthorUsername_ProfileNotFoundOrError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)

	mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).
		WillReturnError(errors.New("boom"))

	_, err := repo.FindRepostsByAuthorUsername(context.Background(), "ghost")
	if err == nil {
		t.Fatal("expected error when author profile lookup fails")
	}
}

// TestFindPostsByKeyword_BlankQuery couvre le court-circuit "trimmed == """
// de FindPostsByKeyword : aucune requete SQL n'est emise, le resultat est une
// slice vide sans erreur.
func TestFindPostsByKeyword_BlankQuery(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	viewerID := uuid.New()

	posts, err := repo.FindPostsByKeyword(context.Background(), "   ", viewerID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(posts) != 0 {
		t.Fatalf("expected empty result for blank query, got %d posts", len(posts))
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations (should be none): %v", err)
	}
}
