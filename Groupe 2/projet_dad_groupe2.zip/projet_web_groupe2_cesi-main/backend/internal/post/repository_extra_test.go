package post

import (
	"context"
	"errors"
	"testing"
	"time"

	"breezy/backend/internal/models"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// realMockDB ouvre une connexion GORM (non-DryRun) adossée à sqlmock, pour
// exécuter réellement les requêtes générées et exercer toutes les branches
// (contrairement au mode DryRun utilisé par TestPostRepositoryQueriesDryRun
// qui s'arrête avant l'exécution SQL).
func realMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

func postRows() []string {
	return []string{"id", "author_id", "content", "lang", "parent_id", "visibility", "original_visibility", "created_at", "updated_at", "deleted_at"}
}

func addPostRow(rows *sqlmock.Rows, id, authorID uuid.UUID, content string, now time.Time) *sqlmock.Rows {
	return rows.AddRow(id, authorID, content, "", nil, "PUBLIC", nil, now, now, nil)
}

// ---------------------------------------------------------------------------
// FindFollowingFeedPosts
// ---------------------------------------------------------------------------

func TestFindFollowingFeedPosts_NoFollowed(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()

	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
		WillReturnRows(sqlmock.NewRows([]string{"followed_id"}))

	got, err := repo.FindFollowingFeedPosts(context.Background(), profileID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 0 {
		t.Fatalf("expected empty feed, got %d", len(got))
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations: %v", err)
	}
}

func TestFindFollowingFeedPosts_ErrorOnFollowedIDs(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()

	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
		WillReturnError(errors.New("db down"))

	_, err := repo.FindFollowingFeedPosts(context.Background(), profileID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindFollowingFeedPosts_ErrorOnAuthoredPosts(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	authorID := uuid.New()

	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
		WillReturnRows(sqlmock.NewRows([]string{"followed_id"}).AddRow(authorID))
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id IN`).
		WillReturnError(errors.New("boom"))

	_, err := repo.FindFollowingFeedPosts(context.Background(), profileID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindFollowingFeedPosts_ErrorOnReposts(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	authorID := uuid.New()
	postID := uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
		WillReturnRows(sqlmock.NewRows([]string{"followed_id"}).AddRow(authorID))
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id IN`).
		WillReturnRows(addPostRow(sqlmock.NewRows(postRows()), postID, authorID, "hello", now))
	mock.ExpectQuery(`SELECT post_id, user_id, created_at FROM "posts"\."reposts"`).
		WillReturnError(errors.New("boom"))

	_, err := repo.FindFollowingFeedPosts(context.Background(), profileID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindFollowingFeedPosts_ErrorOnMissingExtra(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	authorID := uuid.New()
	repostedPostID := uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
		WillReturnRows(sqlmock.NewRows([]string{"followed_id"}).AddRow(authorID))
	// Aucun post directement écrit par les abonnés.
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id IN`).
		WillReturnRows(sqlmock.NewRows(postRows()))
	mock.ExpectQuery(`SELECT post_id, user_id, created_at FROM "posts"\."reposts"`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id", "user_id", "created_at"}).
			AddRow(repostedPostID, authorID, now))
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE id IN`).
		WillReturnError(errors.New("boom"))

	_, err := repo.FindFollowingFeedPosts(context.Background(), profileID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindFollowingFeedPosts_HappyPathWithRepostMergeAndLimit(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	authorID := uuid.New()
	postID := uuid.New()
	repostedOnlyID := uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
		WillReturnRows(sqlmock.NewRows([]string{"followed_id"}).AddRow(authorID))

	authoredRows := sqlmock.NewRows(postRows())
	addPostRow(authoredRows, postID, authorID, "hello", now)
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id IN`).
		WillReturnRows(authoredRows)

	// Deux reposts pour le même post_id : on garde le plus ancien rencontré
	// (latestReposter ne retient que la première occurrence par post_id, et
	// l'ordre est garanti par "ORDER BY created_at DESC").
	repostRows := sqlmock.NewRows([]string{"post_id", "user_id", "created_at"}).
		AddRow(postID, authorID, now.Add(2*time.Hour)).
		AddRow(repostedOnlyID, authorID, now.Add(time.Hour))
	mock.ExpectQuery(`SELECT post_id, user_id, created_at FROM "posts"\."reposts"`).
		WillReturnRows(repostRows)

	extraRows := sqlmock.NewRows(postRows())
	addPostRow(extraRows, repostedOnlyID, authorID, "reposted-only", now)
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE id IN`).
		WillReturnRows(extraRows)

	got, err := repo.FindFollowingFeedPosts(context.Background(), profileID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 2 {
		t.Fatalf("expected 2 feed posts, got %d", len(got))
	}
	// Le post reposté le plus récemment (postID, repost à +2h) doit être en tête.
	if got[0].Post.ID != postID {
		t.Fatalf("expected most recent activity first, got %v", got[0].Post.ID)
	}
	if got[0].ReposterID == nil || *got[0].ReposterID != authorID {
		t.Fatalf("expected reposter id set on first row")
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations: %v", err)
	}
}

func TestFindFollowingFeedPosts_MoreThan100Rows(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()
	authorID := uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
		WillReturnRows(sqlmock.NewRows([]string{"followed_id"}).AddRow(authorID))

	authoredRows := sqlmock.NewRows(postRows())
	for i := 0; i < 105; i++ {
		addPostRow(authoredRows, uuid.New(), authorID, "hello", now.Add(time.Duration(i)*time.Minute))
	}
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id IN`).
		WillReturnRows(authoredRows)
	mock.ExpectQuery(`SELECT post_id, user_id, created_at FROM "posts"\."reposts"`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id", "user_id", "created_at"}))

	got, err := repo.FindFollowingFeedPosts(context.Background(), profileID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 100 {
		t.Fatalf("expected feed truncated to 100, got %d", len(got))
	}
}

// ---------------------------------------------------------------------------
// FindGlobalFeedPosts
// ---------------------------------------------------------------------------

func TestFindGlobalFeedPosts_NoPosts(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	viewerID := uuid.New()

	mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p`).
		WillReturnRows(sqlmock.NewRows(postRows()))

	got, err := repo.FindGlobalFeedPosts(context.Background(), viewerID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 0 {
		t.Fatalf("expected empty feed, got %d", len(got))
	}
}

func TestFindGlobalFeedPosts_ErrorOnPosts(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	viewerID := uuid.New()

	mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p`).
		WillReturnError(errors.New("boom"))

	_, err := repo.FindGlobalFeedPosts(context.Background(), viewerID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindGlobalFeedPosts_ErrorOnReposts(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	viewerID := uuid.New()
	authorID := uuid.New()
	postID := uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p`).
		WillReturnRows(addPostRow(sqlmock.NewRows(postRows()), postID, authorID, "hello", now))
	mock.ExpectQuery(`SELECT r\.post_id, r\.user_id, r\.created_at FROM posts\.reposts AS r`).
		WillReturnError(errors.New("boom"))

	_, err := repo.FindGlobalFeedPosts(context.Background(), viewerID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindGlobalFeedPosts_HappyPathRepostNewerThanPost(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	viewerID := uuid.New()
	authorID := uuid.New()
	reposterID := uuid.New()
	postID := uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p`).
		WillReturnRows(addPostRow(sqlmock.NewRows(postRows()), postID, authorID, "hello", now))
	mock.ExpectQuery(`SELECT r\.post_id, r\.user_id, r\.created_at FROM posts\.reposts AS r`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id", "user_id", "created_at"}).
			AddRow(postID, reposterID, now.Add(time.Hour)))

	got, err := repo.FindGlobalFeedPosts(context.Background(), viewerID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 1 {
		t.Fatalf("expected 1 feed post, got %d", len(got))
	}
	if got[0].ReposterID == nil || *got[0].ReposterID != reposterID {
		t.Fatalf("expected reposter id to be set when repost is newer than post")
	}
	if !got[0].SortTime.Equal(now.Add(time.Hour)) {
		t.Fatalf("expected sort time to use repost time")
	}
}

func TestFindGlobalFeedPosts_RepostOlderThanPostIgnored(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	viewerID := uuid.New()
	authorID := uuid.New()
	reposterID := uuid.New()
	postID := uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p`).
		WillReturnRows(addPostRow(sqlmock.NewRows(postRows()), postID, authorID, "hello", now))
	mock.ExpectQuery(`SELECT r\.post_id, r\.user_id, r\.created_at FROM posts\.reposts AS r`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id", "user_id", "created_at"}).
			AddRow(postID, reposterID, now.Add(-time.Hour)))

	got, err := repo.FindGlobalFeedPosts(context.Background(), viewerID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 1 {
		t.Fatalf("expected 1 feed post, got %d", len(got))
	}
	if got[0].ReposterID != nil {
		t.Fatalf("expected no reposter id when repost is older than the post itself")
	}
}

func TestFindGlobalFeedPosts_MoreThan100Rows(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	viewerID := uuid.New()
	authorID := uuid.New()
	now := time.Now()

	rows := sqlmock.NewRows(postRows())
	for i := 0; i < 105; i++ {
		addPostRow(rows, uuid.New(), authorID, "hello", now.Add(time.Duration(i)*time.Minute))
	}
	mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p`).
		WillReturnRows(rows)
	mock.ExpectQuery(`SELECT r\.post_id, r\.user_id, r\.created_at FROM posts\.reposts AS r`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id", "user_id", "created_at"}))

	got, err := repo.FindGlobalFeedPosts(context.Background(), viewerID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 100 {
		t.Fatalf("expected feed truncated to 100, got %d", len(got))
	}
}

// ---------------------------------------------------------------------------
// FindRepliesByParentID (BFS multi-niveaux)
// ---------------------------------------------------------------------------

func TestFindRepliesByParentID_MultiLevelAndDedup(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	parentID := uuid.New()
	child1 := uuid.New()
	child2 := uuid.New()
	grandchild := uuid.New()
	now := time.Now()

	// Premier niveau : deux réponses, dont un doublon du parent (ignoré car
	// déjà "seen") ne s'applique pas ici, donc on simule juste 2 enfants.
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE parent_id IN`).
		WillReturnRows(
			addPostRow(addPostRow(sqlmock.NewRows(postRows()), child1, parentID, "c1", now), child2, parentID, "c2", now.Add(time.Minute)),
		)
	// Deuxième niveau : une réponse à child1 ou child2.
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE parent_id IN`).
		WillReturnRows(addPostRow(sqlmock.NewRows(postRows()), grandchild, child1, "gc", now.Add(2*time.Minute)))
	// Troisième niveau : plus rien.
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE parent_id IN`).
		WillReturnRows(sqlmock.NewRows(postRows()))

	got, err := repo.FindRepliesByParentID(context.Background(), parentID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 3 {
		t.Fatalf("expected 3 replies total, got %d", len(got))
	}
}

func TestFindRepliesByParentID_Error(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	parentID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE parent_id IN`).
		WillReturnError(errors.New("boom"))

	_, err := repo.FindRepliesByParentID(context.Background(), parentID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// FindProfileIDByUsername / FindProfileIDByAccountID / ProfileIsPrivate /
// FindAccountRole : happy path + not found + erreur SQL.
// ---------------------------------------------------------------------------

func TestFindProfileIDByUsername_HappyAndNotFoundAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	id := uuid.New()

	mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE username`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(id))
	got, err := repo.FindProfileIDByUsername(context.Background(), "alice")
	if err != nil || got != id {
		t.Fatalf("got %v, %v; want %v, nil", got, err, id)
	}

	mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE username`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}))
	_, err = repo.FindProfileIDByUsername(context.Background(), "ghost")
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}

	mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE username`).
		WillReturnError(errors.New("boom"))
	_, err = repo.FindProfileIDByUsername(context.Background(), "alice")
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindProfileIDByAccountID_HappyAndNotFoundAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	accountID := uuid.New()
	id := uuid.New()

	mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(id))
	got, err := repo.FindProfileIDByAccountID(context.Background(), accountID)
	if err != nil || got != id {
		t.Fatalf("got %v, %v; want %v, nil", got, err, id)
	}

	mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}))
	_, err = repo.FindProfileIDByAccountID(context.Background(), accountID)
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}

	mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
		WillReturnError(errors.New("boom"))
	_, err = repo.FindProfileIDByAccountID(context.Background(), accountID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestProfileIsPrivate_HappyAndNotFoundAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()

	mock.ExpectQuery(`SELECT id, is_private FROM "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "is_private"}).AddRow(profileID, true))
	got, err := repo.ProfileIsPrivate(context.Background(), profileID)
	if err != nil || got != true {
		t.Fatalf("got %v, %v; want true, nil", got, err)
	}

	mock.ExpectQuery(`SELECT id, is_private FROM "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "is_private"}).AddRow(profileID, false))
	got, err = repo.ProfileIsPrivate(context.Background(), profileID)
	if err != nil || got != false {
		t.Fatalf("got %v, %v; want false, nil", got, err)
	}

	mock.ExpectQuery(`SELECT id, is_private FROM "profiles"\."profiles"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "is_private"}))
	_, err = repo.ProfileIsPrivate(context.Background(), profileID)
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}

	mock.ExpectQuery(`SELECT id, is_private FROM "profiles"\."profiles"`).
		WillReturnError(errors.New("boom"))
	_, err = repo.ProfileIsPrivate(context.Background(), profileID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindAccountRole_HappyAndNotFoundAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	accountID := uuid.New()

	mock.ExpectQuery(`SELECT role FROM "auth"\."accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"role"}).AddRow("ADMIN"))
	got, err := repo.FindAccountRole(context.Background(), accountID)
	if err != nil || got != "ADMIN" {
		t.Fatalf("got %v, %v; want ADMIN, nil", got, err)
	}

	mock.ExpectQuery(`SELECT role FROM "auth"\."accounts"`).
		WillReturnRows(sqlmock.NewRows([]string{"role"}).AddRow(""))
	_, err = repo.FindAccountRole(context.Background(), accountID)
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}

	mock.ExpectQuery(`SELECT role FROM "auth"\."accounts"`).
		WillReturnError(errors.New("boom"))
	_, err = repo.FindAccountRole(context.Background(), accountID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// FindFollowedProfileIDs
// ---------------------------------------------------------------------------

func TestFindFollowedProfileIDs_HappyAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	followerID := uuid.New()
	followedID := uuid.New()

	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
		WillReturnRows(sqlmock.NewRows([]string{"followed_id"}).AddRow(followedID))
	got, err := repo.FindFollowedProfileIDs(context.Background(), followerID, []uuid.UUID{followedID})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !got[followedID] {
		t.Fatalf("expected followedID present in result map")
	}

	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
		WillReturnError(errors.New("boom"))
	_, err = repo.FindFollowedProfileIDs(context.Background(), followerID, []uuid.UUID{followedID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// DeleteLike / DeleteRepost / DeleteBookmark : RowsAffected == 0 -> NotFound
// ---------------------------------------------------------------------------

func TestDeleteLike_HappyNotFoundAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID, userID := uuid.New(), uuid.New()

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "posts"\."likes"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()
	if err := repo.DeleteLike(context.Background(), postID, userID); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "posts"\."likes"`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectCommit()
	if err := repo.DeleteLike(context.Background(), postID, userID); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "posts"\."likes"`).WillReturnError(errors.New("boom"))
	mock.ExpectRollback()
	if err := repo.DeleteLike(context.Background(), postID, userID); err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestDeleteRepost_HappyNotFoundAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID, userID := uuid.New(), uuid.New()

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "posts"\."reposts"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()
	if err := repo.DeleteRepost(context.Background(), postID, userID); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "posts"\."reposts"`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectCommit()
	if err := repo.DeleteRepost(context.Background(), postID, userID); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "posts"\."reposts"`).WillReturnError(errors.New("boom"))
	mock.ExpectRollback()
	if err := repo.DeleteRepost(context.Background(), postID, userID); err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestDeleteBookmark_HappyNotFoundAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID, userID := uuid.New(), uuid.New()

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "posts"\."bookmarks"`).WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()
	if err := repo.DeleteBookmark(context.Background(), userID, postID); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "posts"\."bookmarks"`).WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectCommit()
	if err := repo.DeleteBookmark(context.Background(), userID, postID); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}

	mock.ExpectBegin()
	mock.ExpectExec(`DELETE FROM "posts"\."bookmarks"`).WillReturnError(errors.New("boom"))
	mock.ExpectRollback()
	if err := repo.DeleteBookmark(context.Background(), userID, postID); err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// HasLike / HasRepost : trouvé, non trouvé (ErrRecordNotFound -> false,nil),
// erreur SQL générique.
// ---------------------------------------------------------------------------

func TestHasLike_FoundNotFoundAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID, userID := uuid.New(), uuid.New()
	likeID := uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."likes"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "user_id", "created_at"}).AddRow(likeID, postID, userID, now))
	got, err := repo.HasLike(context.Background(), postID, userID)
	if err != nil || !got {
		t.Fatalf("got %v, %v; want true, nil", got, err)
	}

	mock.ExpectQuery(`SELECT \* FROM "posts"\."likes"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "user_id", "created_at"}))
	got, err = repo.HasLike(context.Background(), postID, userID)
	if err != nil || got {
		t.Fatalf("got %v, %v; want false, nil", got, err)
	}

	mock.ExpectQuery(`SELECT \* FROM "posts"\."likes"`).
		WillReturnError(errors.New("boom"))
	_, err = repo.HasLike(context.Background(), postID, userID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestHasRepost_FoundNotFoundAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID, userID := uuid.New(), uuid.New()
	repostID := uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."reposts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "user_id", "created_at"}).AddRow(repostID, postID, userID, now))
	got, err := repo.HasRepost(context.Background(), postID, userID)
	if err != nil || !got {
		t.Fatalf("got %v, %v; want true, nil", got, err)
	}

	mock.ExpectQuery(`SELECT \* FROM "posts"\."reposts"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "user_id", "created_at"}))
	got, err = repo.HasRepost(context.Background(), postID, userID)
	if err != nil || got {
		t.Fatalf("got %v, %v; want false, nil", got, err)
	}

	mock.ExpectQuery(`SELECT \* FROM "posts"\."reposts"`).
		WillReturnError(errors.New("boom"))
	_, err = repo.HasRepost(context.Background(), postID, userID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// UpsertTags
// ---------------------------------------------------------------------------

func TestUpsertTags_HappyPath(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	tagID1, tagID2 := uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "posts"\."tags"`).
		WillReturnRows(sqlmock.NewRows([]string{}))
	mock.ExpectCommit()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."tags" WHERE name IN`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "name", "created_at"}).
			AddRow(tagID1, "go", now).
			AddRow(tagID2, "breezy", now))

	got, err := repo.UpsertTags(context.Background(), []string{"go", "breezy"})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if got["go"] != tagID1 || got["breezy"] != tagID2 {
		t.Fatalf("unexpected map content: %+v", got)
	}
}

func TestUpsertTags_ErrorOnInsert(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)

	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "posts"\."tags"`).WillReturnError(errors.New("boom"))
	mock.ExpectRollback()

	_, err := repo.UpsertTags(context.Background(), []string{"go"})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestUpsertTags_ErrorOnFind(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)

	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "posts"\."tags"`).
		WillReturnRows(sqlmock.NewRows([]string{}))
	mock.ExpectCommit()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."tags" WHERE name IN`).
		WillReturnError(errors.New("boom"))

	_, err := repo.UpsertTags(context.Background(), []string{"go"})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// countByPostID (via CountLikesByPostIDs / CountRepliesByPostIDs)
// ---------------------------------------------------------------------------

func TestCountByPostID_HappyAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()

	mock.ExpectQuery(`SELECT post_id AS post_id, COUNT\(\*\) AS count FROM "likes"`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}).AddRow(postID, int64(3)))
	got, err := repo.CountLikesByPostIDs(context.Background(), []uuid.UUID{postID})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if got[postID] != 3 {
		t.Fatalf("expected count 3, got %d", got[postID])
	}

	mock.ExpectQuery(`SELECT post_id AS post_id, COUNT\(\*\) AS count FROM "likes"`).
		WillReturnError(errors.New("boom"))
	_, err = repo.CountLikesByPostIDs(context.Background(), []uuid.UUID{postID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// Transaction : commit, rollback sur erreur du fn.
// ---------------------------------------------------------------------------

func TestTransaction_CommitAndRollback(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)

	mock.ExpectBegin()
	mock.ExpectCommit()
	if err := repo.Transaction(context.Background(), func(txRepo *Repository) error { return nil }); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	wantErr := errors.New("boom")
	mock.ExpectBegin()
	mock.ExpectRollback()
	err := repo.Transaction(context.Background(), func(txRepo *Repository) error { return wantErr })
	if !errors.Is(err, wantErr) {
		t.Fatalf("got %v want %v", err, wantErr)
	}
}

// ---------------------------------------------------------------------------
// DeleteBookmark / FindBookmarkedPostIDsByUserID
// ---------------------------------------------------------------------------

func TestFindBookmarkedPostIDsByUserID_HappyAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	userID, postID := uuid.New(), uuid.New()

	mock.ExpectQuery(`SELECT post_id FROM "posts"\."bookmarks"`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id"}).AddRow(postID))
	got, err := repo.FindBookmarkedPostIDsByUserID(context.Background(), userID, []uuid.UUID{postID})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !got[postID] {
		t.Fatalf("expected postID marked bookmarked")
	}

	mock.ExpectQuery(`SELECT post_id FROM "posts"\."bookmarks"`).
		WillReturnError(errors.New("boom"))
	_, err = repo.FindBookmarkedPostIDsByUserID(context.Background(), userID, []uuid.UUID{postID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// CanViewProfileContentByID / CanViewProfileContent : toutes les branches.
// ---------------------------------------------------------------------------

func profileRows() []string {
	return []string{
		"id", "account_id", "username", "display_name", "bio", "avatar_url", "banner_url",
		"is_private", "pinned_post_id", "original_username", "original_display_name",
		"created_at", "updated_at",
	}
}

func addProfileRow(rows *sqlmock.Rows, id, accountID uuid.UUID, username string, isPrivate bool, now time.Time) *sqlmock.Rows {
	return rows.AddRow(id, accountID, username, nil, nil, nil, nil, isPrivate, nil, nil, nil, now, now)
}

func TestCanViewProfileContentByID_OwnerSeesOwnProfile(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, accountID := uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, accountID, "alice", true, now))

	got, err := repo.CanViewProfileContentByID(context.Background(), profileID, accountID)
	if err != nil || !got {
		t.Fatalf("got %v, %v; want true, nil", got, err)
	}
}

func TestCanViewProfileContentByID_ErrorOnProfileLookup(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, viewerID := uuid.New(), uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).WillReturnError(errors.New("boom"))

	_, err := repo.CanViewProfileContentByID(context.Background(), profileID, viewerID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestCanViewProfileContentByID_AnonymousViewerPublicProfile(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, ownerAccountID := uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", false, now))

	got, err := repo.CanViewProfileContentByID(context.Background(), profileID, uuid.Nil)
	if err != nil || !got {
		t.Fatalf("got %v, %v; want true, nil (public profile, anonymous viewer)", got, err)
	}
}

func TestCanViewProfileContentByID_AnonymousViewerPrivateProfile(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, ownerAccountID := uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", true, now))

	got, err := repo.CanViewProfileContentByID(context.Background(), profileID, uuid.Nil)
	if err != nil || got {
		t.Fatalf("got %v, %v; want false, nil (private profile, anonymous viewer)", got, err)
	}
}

func TestCanViewProfileContentByID_BlockedViewer(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, ownerAccountID, viewerID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", false, now))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.blocks AS b`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(1))

	got, err := repo.CanViewProfileContentByID(context.Background(), profileID, viewerID)
	if err != nil || got {
		t.Fatalf("got %v, %v; want false, nil (blocked viewer)", got, err)
	}
}

func TestCanViewProfileContentByID_ErrorOnBlockCheck(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, ownerAccountID, viewerID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", false, now))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.blocks AS b`).
		WillReturnError(errors.New("boom"))

	_, err := repo.CanViewProfileContentByID(context.Background(), profileID, viewerID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestCanViewProfileContentByID_NotBlockedPublicProfile(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, ownerAccountID, viewerID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", false, now))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.blocks AS b`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))

	got, err := repo.CanViewProfileContentByID(context.Background(), profileID, viewerID)
	if err != nil || !got {
		t.Fatalf("got %v, %v; want true, nil (public profile, not blocked)", got, err)
	}
}

func TestCanViewProfileContentByID_PrivateProfileFollowedByViewer(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, ownerAccountID, viewerID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", true, now))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.blocks AS b`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.follows AS f`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(1))

	got, err := repo.CanViewProfileContentByID(context.Background(), profileID, viewerID)
	if err != nil || !got {
		t.Fatalf("got %v, %v; want true, nil (private profile, followed)", got, err)
	}
}

func TestCanViewProfileContentByID_PrivateProfileNotFollowedByViewer(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, ownerAccountID, viewerID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", true, now))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.blocks AS b`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.follows AS f`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))

	got, err := repo.CanViewProfileContentByID(context.Background(), profileID, viewerID)
	if err != nil || got {
		t.Fatalf("got %v, %v; want false, nil (private profile, not followed)", got, err)
	}
}

func TestCanViewProfileContentByID_ErrorOnFollowCheck(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, ownerAccountID, viewerID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", true, now))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.blocks AS b`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.follows AS f`).
		WillReturnError(errors.New("boom"))

	_, err := repo.CanViewProfileContentByID(context.Background(), profileID, viewerID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestCanViewProfileContent_OwnerAndNotFound(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, accountID := uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, accountID, "alice", true, now))
	got, err := repo.CanViewProfileContent(context.Background(), "alice", accountID)
	if err != nil || !got {
		t.Fatalf("got %v, %v; want true, nil (owner)", got, err)
	}

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE`).
		WillReturnError(gorm.ErrRecordNotFound)
	_, err = repo.CanViewProfileContent(context.Background(), "ghost", accountID)
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}
}

func TestCanViewProfileContent_AnonymousPublicAndPrivate(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, ownerAccountID := uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", false, now))
	got, err := repo.CanViewProfileContent(context.Background(), "alice", uuid.Nil)
	if err != nil || !got {
		t.Fatalf("got %v, %v; want true, nil (anonymous, public)", got, err)
	}

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", true, now))
	got, err = repo.CanViewProfileContent(context.Background(), "alice", uuid.Nil)
	if err != nil || got {
		t.Fatalf("got %v, %v; want false, nil (anonymous, private)", got, err)
	}
}

func TestCanViewProfileContent_BlockedAndFollowedBranches(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, ownerAccountID, viewerID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	// Bloqué.
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", false, now))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.blocks AS b`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(1))
	got, err := repo.CanViewProfileContent(context.Background(), "alice", viewerID)
	if err != nil || got {
		t.Fatalf("got %v, %v; want false, nil (blocked)", got, err)
	}

	// Profil public, pas bloqué.
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", false, now))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.blocks AS b`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	got, err = repo.CanViewProfileContent(context.Background(), "alice", viewerID)
	if err != nil || !got {
		t.Fatalf("got %v, %v; want true, nil (public, not blocked)", got, err)
	}

	// Profil privé, suivi.
	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles" WHERE`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, ownerAccountID, "alice", true, now))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.blocks AS b`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`SELECT count\(\*\) FROM social\.follows AS f`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(1))
	got, err = repo.CanViewProfileContent(context.Background(), "alice", viewerID)
	if err != nil || !got {
		t.Fatalf("got %v, %v; want true, nil (private, followed)", got, err)
	}
}

// ---------------------------------------------------------------------------
// FindRepostsByAuthorUsername / FindPostsByAuthorUsername /
// FindRepliesByAuthorUsername : erreur de lookup de profil.
// ---------------------------------------------------------------------------

func TestFindPostsByAuthorUsername_ProfileNotFound(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).WillReturnError(gorm.ErrRecordNotFound)

	_, err := repo.FindPostsByAuthorUsername(context.Background(), "ghost")
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}
}

func TestFindRepliesByAuthorUsername_ProfileNotFound(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).WillReturnError(gorm.ErrRecordNotFound)

	_, err := repo.FindRepliesByAuthorUsername(context.Background(), "ghost")
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}
}

// ---------------------------------------------------------------------------
// FindPollByPostID / FindPollByID : avec et sans options (Preload).
// ---------------------------------------------------------------------------

func TestFindPollByPostID_WithOptionsAndNotFound(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID, pollID, optionID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."polls"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "ends_at", "closed_at", "created_at"}).
			AddRow(pollID, postID, nil, nil, now))
	mock.ExpectQuery(`SELECT \* FROM "posts"\."poll_options"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id", "text", "position", "vote_count"}).
			AddRow(optionID, pollID, "Option A", 0, 5))

	got, err := repo.FindPollByPostID(context.Background(), postID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got.Options) != 1 {
		t.Fatalf("expected 1 option preloaded, got %d", len(got.Options))
	}

	mock.ExpectQuery(`SELECT \* FROM "posts"\."polls"`).WillReturnError(gorm.ErrRecordNotFound)
	_, err = repo.FindPollByPostID(context.Background(), postID)
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}
}

func TestFindPollByID_WithOptionsAndNotFound(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID, pollID, optionID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."polls"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "ends_at", "closed_at", "created_at"}).
			AddRow(pollID, postID, nil, nil, now))
	mock.ExpectQuery(`SELECT \* FROM "posts"\."poll_options"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id", "text", "position", "vote_count"}).
			AddRow(optionID, pollID, "Option A", 0, 5))

	got, err := repo.FindPollByID(context.Background(), pollID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got.Options) != 1 {
		t.Fatalf("expected 1 option preloaded, got %d", len(got.Options))
	}

	mock.ExpectQuery(`SELECT \* FROM "posts"\."polls"`).WillReturnError(gorm.ErrRecordNotFound)
	_, err = repo.FindPollByID(context.Background(), pollID)
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("expected ErrRecordNotFound, got %v", err)
	}
}

// ---------------------------------------------------------------------------
// FindPollsByPostIDs : avec polls+options, sans polls (pollIDs vide -> skip
// la requête options), et erreurs sur chaque étape.
// ---------------------------------------------------------------------------

func TestFindPollsByPostIDs_HappyPathWithOptions(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID, pollID, optionID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."polls" WHERE post_id IN`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "ends_at", "closed_at", "created_at"}).
			AddRow(pollID, postID, nil, nil, now))
	mock.ExpectQuery(`SELECT \* FROM "posts"\."poll_options" WHERE poll_id IN`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id", "text", "position", "vote_count"}).
			AddRow(optionID, pollID, "Option A", 0, 5))

	got, err := repo.FindPollsByPostIDs(context.Background(), []uuid.UUID{postID})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	poll, ok := got[postID]
	if !ok || len(poll.Options) != 1 {
		t.Fatalf("expected poll with 1 option for postID, got %+v", got)
	}
}

func TestFindPollsByPostIDs_NoPollsSkipsOptionsQuery(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."polls" WHERE post_id IN`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "ends_at", "closed_at", "created_at"}))

	got, err := repo.FindPollsByPostIDs(context.Background(), []uuid.UUID{postID})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 0 {
		t.Fatalf("expected empty map, got %+v", got)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations: %v", err)
	}
}

func TestFindPollsByPostIDs_ErrorOnPolls(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."polls" WHERE post_id IN`).WillReturnError(errors.New("boom"))

	_, err := repo.FindPollsByPostIDs(context.Background(), []uuid.UUID{postID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindPollsByPostIDs_ErrorOnOptions(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID, pollID := uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."polls" WHERE post_id IN`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "ends_at", "closed_at", "created_at"}).
			AddRow(pollID, postID, nil, nil, now))
	mock.ExpectQuery(`SELECT \* FROM "posts"\."poll_options" WHERE poll_id IN`).WillReturnError(errors.New("boom"))

	_, err := repo.FindPollsByPostIDs(context.Background(), []uuid.UUID{postID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// CountRepostsByPostIDs / FindLikedPostIDsByUserID / FindRepostedPostIDsByUserID
// / FindTagsByPostIDs : happy path + erreur SQL.
// ---------------------------------------------------------------------------

func TestCountRepostsByPostIDs_HappyAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()

	mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}).AddRow(postID, int64(2)))
	got, err := repo.CountRepostsByPostIDs(context.Background(), []uuid.UUID{postID})
	if err != nil || got[postID] != 2 {
		t.Fatalf("got %v, %v; want 2, nil", got, err)
	}

	mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).WillReturnError(errors.New("boom"))
	_, err = repo.CountRepostsByPostIDs(context.Background(), []uuid.UUID{postID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindLikedPostIDsByUserID_HappyAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	userID, postID := uuid.New(), uuid.New()

	mock.ExpectQuery(`SELECT post_id FROM "posts"\."likes"`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id"}).AddRow(postID))
	got, err := repo.FindLikedPostIDsByUserID(context.Background(), userID, []uuid.UUID{postID})
	if err != nil || !got[postID] {
		t.Fatalf("got %v, %v; want postID liked, nil", got, err)
	}

	mock.ExpectQuery(`SELECT post_id FROM "posts"\."likes"`).WillReturnError(errors.New("boom"))
	_, err = repo.FindLikedPostIDsByUserID(context.Background(), userID, []uuid.UUID{postID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindRepostedPostIDsByUserID_HappyAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	userID, postID := uuid.New(), uuid.New()

	mock.ExpectQuery(`SELECT post_id FROM "posts"\."reposts"`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id"}).AddRow(postID))
	got, err := repo.FindRepostedPostIDsByUserID(context.Background(), userID, []uuid.UUID{postID})
	if err != nil || !got[postID] {
		t.Fatalf("got %v, %v; want postID reposted, nil", got, err)
	}

	mock.ExpectQuery(`SELECT post_id FROM "posts"\."reposts"`).WillReturnError(errors.New("boom"))
	_, err = repo.FindRepostedPostIDsByUserID(context.Background(), userID, []uuid.UUID{postID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

func TestFindTagsByPostIDs_HappyAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID := uuid.New()

	mock.ExpectQuery(`SELECT post_tags\.post_id, tags\.name FROM "post_tags"`).
		WillReturnRows(sqlmock.NewRows([]string{"post_id", "name"}).AddRow(postID, "go"))
	got, err := repo.FindTagsByPostIDs(context.Background(), []uuid.UUID{postID})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got[postID]) != 1 || got[postID][0] != "go" {
		t.Fatalf("unexpected tags: %+v", got)
	}

	mock.ExpectQuery(`SELECT post_tags\.post_id, tags\.name FROM "post_tags"`).WillReturnError(errors.New("boom"))
	_, err = repo.FindTagsByPostIDs(context.Background(), []uuid.UUID{postID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// FindMediaByPostIDs : erreur SQL (le happy path est déjà couvert par
// TestPostRepositoryQueriesDryRun, mais sans données ; on ajoute une variante
// avec lignes ainsi qu'une variante d'erreur).
// ---------------------------------------------------------------------------

func TestFindMediaByPostIDs_HappyAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	postID, mediaID := uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."media"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "media_type", "url", "created_at"}).
			AddRow(mediaID, postID, "IMAGE", "/api/media/files/a.png", now))
	got, err := repo.FindMediaByPostIDs(context.Background(), []uuid.UUID{postID})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got[postID]) != 1 {
		t.Fatalf("expected 1 media item, got %+v", got)
	}

	mock.ExpectQuery(`SELECT \* FROM "posts"\."media"`).WillReturnError(errors.New("boom"))
	_, err = repo.FindMediaByPostIDs(context.Background(), []uuid.UUID{postID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// FindProfilesByIDs : erreur SQL (happy path déjà couvert ailleurs).
// ---------------------------------------------------------------------------

func TestFindProfilesByIDs_Error(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID := uuid.New()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).WillReturnError(errors.New("boom"))

	_, err := repo.FindProfilesByIDs(context.Background(), []uuid.UUID{profileID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// FindBookmarkedPostsByUserID / FindRepostsByAuthorUsername happy path avec
// données (pour couvrir le scan complet, pas seulement DryRun vide).
// ---------------------------------------------------------------------------

func TestFindBookmarkedPostsByUserID_HappyPath(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	userID, postID, authorID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p`).
		WillReturnRows(addPostRow(sqlmock.NewRows(postRows()), postID, authorID, "hello", now))

	got, err := repo.FindBookmarkedPostsByUserID(context.Background(), userID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 1 {
		t.Fatalf("expected 1 bookmarked post, got %d", len(got))
	}
}

func TestFindRepostsByAuthorUsername_HappyPath(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	profileID, postID, accountID := uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "profiles"\."profiles"`).
		WillReturnRows(addProfileRow(sqlmock.NewRows(profileRows()), profileID, accountID, "alice", false, now))
	mock.ExpectQuery(`SELECT p\.\*`).
		WillReturnRows(sqlmock.NewRows(append(postRows(), "reposter_id", "sort_time")).
			AddRow(postID, profileID, "hello", "", nil, "PUBLIC", nil, now, now, nil, profileID, now))

	got, err := repo.FindRepostsByAuthorUsername(context.Background(), "alice")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(got) != 1 {
		t.Fatalf("expected 1 repost row, got %d", len(got))
	}
}

// ---------------------------------------------------------------------------
// FindVotesByPollIDsAndUser : happy path avec données + erreur SQL.
// ---------------------------------------------------------------------------

func TestFindVotesByPollIDsAndUser_HappyAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	pollID, optionID, userID, voteID := uuid.New(), uuid.New(), uuid.New(), uuid.New()
	now := time.Now()

	mock.ExpectQuery(`SELECT \* FROM "posts"\."poll_votes"`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id", "option_id", "user_id", "created_at"}).
			AddRow(voteID, pollID, optionID, userID, now))
	got, err := repo.FindVotesByPollIDsAndUser(context.Background(), []uuid.UUID{pollID}, userID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if _, ok := got[pollID]; !ok {
		t.Fatalf("expected vote present for pollID, got %+v", got)
	}

	mock.ExpectQuery(`SELECT \* FROM "posts"\."poll_votes"`).WillReturnError(errors.New("boom"))
	_, err = repo.FindVotesByPollIDsAndUser(context.Background(), []uuid.UUID{pollID}, userID)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// FindBlockedProfileIDs : erreur SQL (happy path déjà couvert dans DryRun
// mais sans données utiles ; on confirme ici le comportement avec lignes).
// ---------------------------------------------------------------------------

func TestFindBlockedProfileIDs_HappyAndError(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	viewerID, blockerID := uuid.New(), uuid.New()

	mock.ExpectQuery(`SELECT blocker_id AS profile_id`).
		WillReturnRows(sqlmock.NewRows([]string{"profile_id"}).AddRow(blockerID))
	got, err := repo.FindBlockedProfileIDs(context.Background(), viewerID, []uuid.UUID{blockerID})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !got[blockerID] {
		t.Fatalf("expected blockerID flagged as blocked")
	}

	mock.ExpectQuery(`SELECT blocker_id AS profile_id`).WillReturnError(errors.New("boom"))
	_, err = repo.FindBlockedProfileIDs(context.Background(), viewerID, []uuid.UUID{blockerID})
	if err == nil {
		t.Fatal("expected error, got nil")
	}
}

// ---------------------------------------------------------------------------
// Garde-fou : s'assurer que la struct models.Bookmark créée par CreateBookmark
// reste utilisable (sanity, pas de logique additionnelle).
// ---------------------------------------------------------------------------

func TestCreateBookmark_Smoke(t *testing.T) {
	db, mock := realMockDB(t)
	repo := NewRepository(db)
	userID, postID := uuid.New(), uuid.New()

	mock.ExpectBegin()
	mock.ExpectQuery(`INSERT INTO "posts"\."bookmarks"`).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
	mock.ExpectCommit()

	if err := repo.CreateBookmark(context.Background(), userID, postID); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	_ = models.Bookmark{}
}
