package post

import (
	"context"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestRepositoryWithDB(t *testing.T) {
	repo := NewRepository(&gorm.DB{})
	nextDB := &gorm.DB{}
	next := repo.WithDB(nextDB)
	if next == repo {
		t.Fatal("WithDB() should return a new repository")
	}
	if next.db != nextDB {
		t.Fatal("WithDB() did not use provided DB")
	}
}

func TestPostRepositoryQueriesDryRun(t *testing.T) {
	repo := NewRepository(postDryRunDB(t))
	ctx := context.Background()
	postID := uuid.New()
	userID := uuid.New()
	profileID := uuid.New()
	otherID := uuid.New()
	pollID := uuid.New()
	optionID := uuid.New()
	now := time.Now()

	_, _ = repo.FindAllPosts(ctx)
	_, _ = repo.FindFeedPosts(ctx)
	_, _ = repo.FindPostByID(ctx, postID)
	_, _ = repo.FindFollowingPosts(ctx, profileID)
	_, _ = repo.FindFollowingFeedPosts(ctx, profileID)
	_, _ = repo.FindGlobalFeedPosts(ctx, profileID)
	_, _ = repo.FindProfilesByUsernames(ctx, nil)
	_, _ = repo.FindProfilesByUsernames(ctx, []string{"alice"})
	_, _ = repo.FindProfileByDisplayName(ctx, "Alice")
	_ = repo.CreateNotification(ctx, &models.Notification{RecipientID: profileID, ActorID: otherID, Type: "LIKE"})
	_, _ = repo.FindRepliesByParentID(ctx, postID)
	_, _ = repo.FindRepliesByAuthorID(ctx, profileID)
	_, _ = repo.FindPostsByIDs(ctx, nil)
	_, _ = repo.FindPostsByIDs(ctx, []uuid.UUID{postID})
	_, _ = repo.FindProfileIDByUsername(ctx, "alice")
	_, _ = repo.FindProfileIDByAccountID(ctx, userID)
	_, _ = repo.ProfileIsPrivate(ctx, profileID)
	_, _ = repo.FindFollowedProfileIDs(ctx, profileID, nil)
	_, _ = repo.FindFollowedProfileIDs(ctx, profileID, []uuid.UUID{otherID})
	_, _ = repo.FindAccountRole(ctx, userID)
	_ = repo.CreatePost(ctx, &models.Post{ID: postID, AuthorID: profileID, Content: "hello", Visibility: "PUBLIC"})
	_ = repo.UpdatePostVisibility(ctx, postID, "FOLLOWERS")
	_ = repo.CreateMedia(ctx, nil)
	_ = repo.CreateMedia(ctx, []models.Media{{PostID: postID, MediaType: "IMAGE", URL: "/api/media/files/a.png"}})
	_, _ = repo.FindMediaByPostIDs(ctx, nil)
	_, _ = repo.FindMediaByPostIDs(ctx, []uuid.UUID{postID})
	_ = repo.DeletePost(ctx, postID)
	_ = repo.CreateLike(ctx, &models.Like{PostID: postID, UserID: userID})
	_ = repo.DeleteLike(ctx, postID, userID)
	_ = repo.CreateRepost(ctx, &models.Repost{PostID: postID, UserID: userID})
	_ = repo.DeleteRepost(ctx, postID, userID)
	_, _ = repo.HasLike(ctx, postID, userID)
	_, _ = repo.HasRepost(ctx, postID, userID)
	_, _ = repo.FindProfilesByIDs(ctx, nil)
	_, _ = repo.FindProfilesByIDs(ctx, []uuid.UUID{profileID})
	_, _ = repo.CountLikesByPostIDs(ctx, nil)
	_, _ = repo.CountLikesByPostIDs(ctx, []uuid.UUID{postID})
	_, _ = repo.CountRepostsByPostIDs(ctx, nil)
	_, _ = repo.CountRepostsByPostIDs(ctx, []uuid.UUID{postID})
	_, _ = repo.FindLikedPostIDsByUserID(ctx, userID, nil)
	_, _ = repo.FindLikedPostIDsByUserID(ctx, userID, []uuid.UUID{postID})
	_, _ = repo.FindRepostedPostIDsByUserID(ctx, userID, nil)
	_, _ = repo.FindRepostedPostIDsByUserID(ctx, userID, []uuid.UUID{postID})
	_, _ = repo.CountRepliesByPostIDs(ctx, nil)
	_, _ = repo.CountRepliesByPostIDs(ctx, []uuid.UUID{postID})
	_, _ = repo.FindTagsByPostIDs(ctx, nil)
	_, _ = repo.FindTagsByPostIDs(ctx, []uuid.UUID{postID})
	_, _ = repo.FindPostsByTag(ctx, "go", profileID)
	_, _ = repo.FindPostsByKeyword(ctx, "hello", profileID)
	_, _ = repo.FindPostsByAuthorUsername(ctx, "alice")
	_, _ = repo.FindRepliesByAuthorUsername(ctx, "alice")
	_, _ = repo.CanViewProfileContent(ctx, "alice", userID)
	_, _ = repo.CanViewProfileContentByID(ctx, profileID, userID)
	_, _ = repo.ProfileBlocksAccount(ctx, profileID, userID)
	_, _ = repo.FindBlockedProfileIDs(ctx, profileID, nil)
	_, _ = repo.FindBlockedProfileIDs(ctx, profileID, []uuid.UUID{otherID})
	_, _ = repo.FindRepostsByAuthorUsername(ctx, "alice")
	_, _ = repo.UpsertTags(ctx, nil)
	_, _ = repo.UpsertTags(ctx, []string{"go", "breezy"})
	_ = repo.AttachTagsToPost(ctx, postID, nil)
	_ = repo.AttachTagsToPost(ctx, postID, []uuid.UUID{uuid.New()})
	_, _ = repo.FindTrendingTags(ctx, 0, profileID)
	_, _ = repo.FindTrendingTags(ctx, 10, profileID)
	_ = repo.Transaction(ctx, func(txRepo *Repository) error { return nil })
	_ = repo.CreatePoll(ctx, &models.Poll{ID: pollID, PostID: postID})
	_ = repo.CreatePollOptions(ctx, []models.PollOption{{ID: optionID, PollID: pollID, Text: "A"}})
	_, _ = repo.FindPollByPostID(ctx, postID)
	_, _ = repo.FindPollsByPostIDs(ctx, nil)
	_, _ = repo.FindPollsByPostIDs(ctx, []uuid.UUID{postID})
	_, _ = repo.FindVoteByPollAndUser(ctx, pollID, userID)
	_, _ = repo.FindVotesByPollIDsAndUser(ctx, nil, userID)
	_, _ = repo.FindVotesByPollIDsAndUser(ctx, []uuid.UUID{pollID}, userID)
	_ = repo.CreatePollVote(ctx, &models.PollVote{PollID: pollID, OptionID: optionID, UserID: userID})
	_ = repo.IncrementPollOptionVote(ctx, optionID)
	_, _ = repo.FindPollByID(ctx, pollID)
	_ = repo.ClosePoll(ctx, pollID, now)
	_ = repo.CreateBookmark(ctx, userID, postID)
	_ = repo.DeleteBookmark(ctx, userID, postID)
	_, _ = repo.FindBookmarkedPostIDsByUserID(ctx, userID, nil)
	_, _ = repo.FindBookmarkedPostIDsByUserID(ctx, userID, []uuid.UUID{postID})
	_, _ = repo.FindBookmarkedPostsByUserID(ctx, userID)
}

func postDryRunDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{DryRun: true})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db
}
