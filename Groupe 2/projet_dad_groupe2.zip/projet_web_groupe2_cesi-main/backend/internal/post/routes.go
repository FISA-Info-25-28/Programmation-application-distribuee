package post

import (
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
)

func RegisterRoutes(router *gin.Engine, handler *Handler) {
	router.Use(middleware.JSONBody())
	router.Use(middleware.AuthOptional())
	router.GET("/health", handler.Health)

	router.GET("/feed", handler.GetPosts)
	router.GET("/following", middleware.AuthRequired(), handler.GetFollowingPosts)
	router.GET("/tags/trending", handler.GetTrendingTags)
	router.GET("/search", handler.GetPostsByKeyword)
	router.GET("/tag/:tag", handler.GetPostsByTag)
	router.GET("/author/:username/replies", handler.GetRepliesByAuthor)
	router.GET("/author/:username/reposts", handler.GetRepostsByAuthor)
	router.GET("/author/:username/likes", handler.GetLikedPostsByAuthor)
	router.GET("/author/:username", handler.GetPostsByAuthor)
	router.GET("/:id/replies", handler.GetReplies)
	router.GET("/:id", handler.GetPost)

	authenticated := router.Group("/")
	authenticated.Use(middleware.AuthRequired())
	authenticated.GET("/bookmarks", handler.GetBookmarkedPosts)
	authenticated.POST("/", handler.CreatePost)
	authenticated.PATCH("/:id/visibility", handler.UpdatePostVisibility)
	authenticated.DELETE("/:id", handler.DeletePost)
	authenticated.POST("/:id/like", handler.LikePost)
	authenticated.DELETE("/:id/like", handler.UnlikePost)
	authenticated.POST("/:id/repost", handler.Repost)
	authenticated.DELETE("/:id/repost", handler.Unrepost)
	authenticated.POST("/:id/bookmark", handler.BookmarkPost)
	authenticated.DELETE("/:id/bookmark", handler.UnbookmarkPost)
	authenticated.POST("/:id/poll/vote", handler.VotePoll)
	authenticated.POST("/:id/poll/close", handler.ClosePoll)
}
