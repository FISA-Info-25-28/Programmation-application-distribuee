package post

import (
	"context"
	"errors"
	"regexp"
	"slices"
	"strings"
	"time"

	"breezy/backend/internal/middleware"
	"breezy/backend/internal/models"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Service struct {
	repo *Repository
}

var hashtagPattern = regexp.MustCompile(`(?i)#([\p{L}\p{N}_]+)`)
var mentionPattern = regexp.MustCompile(`(?i)@([a-z0-9_]{3,30})`)
var testKeywordPattern = regexp.MustCompile(`(?i)\bTEST\b`)

var (
	frAccentRe = regexp.MustCompile(`[éèêëàâùûüôîïçœæÉÈÊËÀÂÙÛÜÔÎÏÇŒÆ]`)
	cyrillicRe = regexp.MustCompile(`\p{Cyrillic}`)
	arabicRe   = regexp.MustCompile(`\p{Arabic}`)
	cjkRe      = regexp.MustCompile(`[\p{Han}\p{Hiragana}\p{Katakana}]`)
	hangulRe   = regexp.MustCompile(`\p{Hangul}`)
	hebrewRe   = regexp.MustCompile(`\p{Hebrew}`)
	frWordRe   = regexp.MustCompile(`(?i)\b(le|la|les|de|du|des|un|une|est|et|je|tu|il|elle|nous|vous|ils|pour|dans|sur|avec|qui|que|mon|ton|son|pas|plus|cette|tout|bien|comme|mais|donc|car|si|ou)\b`)
	enWordRe   = regexp.MustCompile(`(?i)\b(the|is|are|was|were|have|has|be|do|does|will|would|could|should|this|that|and|but|for|with|not|you|they|we|my|your|his|her|its|our|their|at|by|from|just|so|or|if|no)\b`)
)

// detectLang estime la langue principale du texte a partir de caracteres et mots courants.
// Entree : text.
// Sortie : valeur retour de type string.
func detectLang(text string) string {
	if strings.TrimSpace(text) == "" {
		return ""
	}
	if frAccentRe.MatchString(text) {
		return "fr"
	}
	if cyrillicRe.MatchString(text) {
		return "ru"
	}
	if arabicRe.MatchString(text) {
		return "ar"
	}
	if cjkRe.MatchString(text) {
		return "zh"
	}
	if hangulRe.MatchString(text) {
		return "ko"
	}
	if hebrewRe.MatchString(text) {
		return "he"
	}
	frScore := len(frWordRe.FindAllString(text, -1))
	enScore := len(enWordRe.FindAllString(text, -1))
	if frScore == 0 && enScore == 0 {
		return ""
	}
	if frScore > enScore {
		return "fr"
	}
	return "en"
}

// NewService construit le service post autour de son repository.
// Entree : repo.
// Sortie : valeur retour de type *Service.
func NewService(repo *Repository) *Service {
	return &Service{
		repo: repo,
	}
}

// GetPosts récupère le feed global : tous les posts + reposts, triés par activité.
// Entree : ctx.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetPosts(ctx context.Context) ([]postResponse, error) {
	feedPosts, err := s.repo.FindGlobalFeedPosts(ctx, viewerProfileID(ctx, s.repo))
	if err != nil {
		return nil, err
	}
	feedPosts, err = s.filterAccessibleFeedPosts(ctx, feedPosts)
	if err != nil {
		return nil, err
	}

	return s.enrichFeedPosts(ctx, feedPosts)
}

// GetPostByID recupere un post unique, verifie son accessibilite, puis l'enrichit.
// Entree : ctx, postID.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetPostByID(ctx context.Context, postID uuid.UUID) (postResponse, error) {
	post, err := s.repo.FindPostByID(ctx, postID)
	if err != nil {
		return postResponse{}, err
	}

	canView, err := s.canViewPost(ctx, post)
	if err != nil {
		return postResponse{}, err
	}
	if !canView {
		return postResponse{}, ErrPrivateProfile
	}

	posts, err := s.enrichPosts(ctx, []models.Post{post})
	if err != nil {
		return postResponse{}, err
	}
	if len(posts) == 0 {
		return postResponse{}, gorm.ErrRecordNotFound
	}

	return posts[0], nil
}

// GetRepliesByParentID recupere les reponses visibles d'un post parent accessible.
// Entree : ctx, parentID.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetRepliesByParentID(ctx context.Context, parentID uuid.UUID) ([]postResponse, error) {
	parent, err := s.repo.FindPostByID(ctx, parentID)
	if err != nil {
		return nil, err
	}
	canView, err := s.canViewPost(ctx, parent)
	if err != nil {
		return nil, err
	}
	if !canView {
		return nil, ErrPrivateProfile
	}

	posts, err := s.repo.FindRepliesByParentID(ctx, parentID)
	if err != nil {
		return nil, err
	}
	posts, err = s.filterAccessiblePosts(ctx, posts)
	if err != nil {
		return nil, err
	}

	return s.enrichPosts(ctx, posts)
}

// GetPostsByTag recupere les posts visibles associes a un tag.
// Entree : ctx, tag.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetPostsByTag(ctx context.Context, tag string) ([]postResponse, error) {
	posts, err := s.repo.FindPostsByTag(ctx, tag, viewerProfileID(ctx, s.repo))
	if err != nil {
		return nil, err
	}
	posts, err = s.filterAccessiblePosts(ctx, posts)
	if err != nil {
		return nil, err
	}

	return s.enrichPosts(ctx, posts)
}

// SearchPostsByKeyword recupere les posts visibles correspondant a une recherche texte.
// Entree : ctx, query.
// Sortie : valeurs retour de la fonction.
func (s *Service) SearchPostsByKeyword(ctx context.Context, query string) ([]postResponse, error) {
	posts, err := s.repo.FindPostsByKeyword(ctx, query, viewerProfileID(ctx, s.repo))
	if err != nil {
		return nil, err
	}
	posts, err = s.filterAccessiblePosts(ctx, posts)
	if err != nil {
		return nil, err
	}

	return s.enrichPosts(ctx, posts)
}

// GetPostsByAuthor recupere les posts visibles d'un auteur apres verification de profil.
// Entree : ctx, username.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetPostsByAuthor(ctx context.Context, username string) ([]postResponse, error) {
	if strings.TrimSpace(username) == "" {
		return nil, gorm.ErrRecordNotFound
	}
	canView, err := s.repo.CanViewProfileContent(ctx, username, requestAccountID(ctx))
	if err != nil {
		return nil, err
	}
	if !canView {
		return nil, ErrPrivateProfile
	}
	posts, err := s.repo.FindPostsByAuthorUsername(ctx, username)
	if err != nil {
		return nil, err
	}
	posts, err = s.filterAccessiblePosts(ctx, posts)
	if err != nil {
		return nil, err
	}
	return s.enrichPosts(ctx, posts)
}

// GetRepostsByAuthor recupere les reposts visibles effectues par un auteur.
// Entree : ctx, username.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetRepostsByAuthor(ctx context.Context, username string) ([]postResponse, error) {
	if strings.TrimSpace(username) == "" {
		return nil, gorm.ErrRecordNotFound
	}
	canView, err := s.repo.CanViewProfileContent(ctx, username, requestAccountID(ctx))
	if err != nil {
		return nil, err
	}
	if !canView {
		return nil, ErrPrivateProfile
	}
	posts, err := s.repo.FindRepostsByAuthorUsername(ctx, username)
	if err != nil {
		return nil, err
	}
	posts, err = s.filterAccessibleFeedPosts(ctx, posts)
	if err != nil {
		return nil, err
	}
	return s.enrichFeedPosts(ctx, posts)
}

// GetLikedPostsByAuthor recupere les posts visibles likes par un auteur.
// Entree : ctx, username.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetLikedPostsByAuthor(ctx context.Context, username string) ([]postResponse, error) {
	if strings.TrimSpace(username) == "" {
		return nil, gorm.ErrRecordNotFound
	}
	canView, err := s.repo.CanViewProfileContent(ctx, username, requestAccountID(ctx))
	if err != nil {
		return nil, err
	}
	if !canView {
		return nil, ErrPrivateProfile
	}
	// On part des likes de l'auteur, puis on applique les filtres de visibilite du viewer.
	posts, err := s.repo.FindLikedPostsByAuthorUsername(ctx, username)
	if err != nil {
		return nil, err
	}
	posts, err = s.filterAccessiblePosts(ctx, posts)
	if err != nil {
		return nil, err
	}
	return s.enrichPosts(ctx, posts)
}

// GetRepliesByAuthor recupere les reponses visibles publiees par un auteur.
// Entree : ctx, username.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetRepliesByAuthor(ctx context.Context, username string) ([]postResponse, error) {
	if strings.TrimSpace(username) == "" {
		return nil, gorm.ErrRecordNotFound
	}
	canView, err := s.repo.CanViewProfileContent(ctx, username, requestAccountID(ctx))
	if err != nil {
		return nil, err
	}
	if !canView {
		return nil, ErrPrivateProfile
	}
	posts, err := s.repo.FindRepliesByAuthorUsername(ctx, username)
	if err != nil {
		return nil, err
	}
	posts, err = s.filterAccessiblePosts(ctx, posts)
	if err != nil {
		return nil, err
	}
	return s.enrichPosts(ctx, posts)
}

// GetTrendingTags recupere les tags tendances visibles pour le lecteur courant.
// Entree : ctx, limit.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetTrendingTags(ctx context.Context, limit int) ([]trendingTagResponse, error) {
	return s.repo.FindTrendingTags(ctx, limit, viewerProfileID(ctx, s.repo))
}

// enrichPosts ajoute auteurs, compteurs, medias, sondages et etats utilisateur aux posts.
// Entree : ctx, posts.
// Sortie : valeurs retour de la fonction.
func (s *Service) enrichPosts(ctx context.Context, posts []models.Post) ([]postResponse, error) {
	postIDs := make([]uuid.UUID, 0, len(posts))
	authorIDs := make([]uuid.UUID, 0, len(posts))
	for _, p := range posts {
		postIDs = append(postIDs, p.ID)
		if !slices.Contains(authorIDs, p.AuthorID) {
			authorIDs = append(authorIDs, p.AuthorID)
		}
	}

	likesMap, err := s.repo.CountLikesByPostIDs(ctx, postIDs)
	if err != nil {
		return nil, err
	}

	commentsMap, err := s.repo.CountRepliesByPostIDs(ctx, postIDs)
	if err != nil {
		return nil, err
	}

	likedMap, err := s.repo.FindLikedPostIDsByUserID(ctx, viewerProfileID(ctx, s.repo), postIDs)
	if err != nil {
		return nil, err
	}

	repostsMap, err := s.repo.CountRepostsByPostIDs(ctx, postIDs)
	if err != nil {
		return nil, err
	}

	repostedMap, err := s.repo.FindRepostedPostIDsByUserID(ctx, viewerProfileID(ctx, s.repo), postIDs)
	if err != nil {
		return nil, err
	}

	authorsByID, err := s.repo.FindProfilesByIDs(ctx, authorIDs)
	if err != nil {
		return nil, err
	}

	mediaByPostID, err := s.repo.FindMediaByPostIDs(ctx, postIDs)
	if err != nil {
		return nil, err
	}

	pollsByPostID, err := s.repo.FindPollsByPostIDs(ctx, postIDs)
	if err != nil {
		return nil, err
	}

	pollIDs := make([]uuid.UUID, 0, len(pollsByPostID))
	for _, p := range pollsByPostID {
		pollIDs = append(pollIDs, p.ID)
	}

	viewerID := viewerProfileID(ctx, s.repo)
	votesByPollID, err := s.repo.FindVotesByPollIDsAndUser(ctx, pollIDs, viewerID)
	if err != nil {
		return nil, err
	}

	bookmarkedMap, err := s.repo.FindBookmarkedPostIDsByUserID(ctx, viewerID, postIDs)
	if err != nil {
		return nil, err
	}

	return mapPostsToResponse(posts, authorsByID, likesMap, commentsMap, repostsMap, likedMap, repostedMap, bookmarkedMap, mediaByPostID, pollsByPostID, votesByPollID), nil
}

// mapPostsToResponse transforme les modeles de posts en DTO API enrichis.
// Entree : posts, authors, likes, comments, reposts, liked, reposted, bookmarked, mediaByPostID, pollsByPostID, votesByPollID.
// Sortie : valeur retour de type []postResponse.
func mapPostsToResponse(
	posts []models.Post,
	authors map[uuid.UUID]models.Profile,
	likes map[uuid.UUID]int64,
	comments map[uuid.UUID]int64,
	reposts map[uuid.UUID]int64,
	liked map[uuid.UUID]bool,
	reposted map[uuid.UUID]bool,
	bookmarked map[uuid.UUID]bool,
	mediaByPostID map[uuid.UUID][]models.Media,
	pollsByPostID map[uuid.UUID]models.Poll,
	votesByPollID map[uuid.UUID]models.PollVote,
) []postResponse {

	if len(posts) == 0 {
		return []postResponse{}
	}

	result := make([]postResponse, 0, len(posts))

	for _, p := range posts {
		author := authorSummaryResponse{ID: p.AuthorID}
		if profile, ok := authors[p.AuthorID]; ok {
			displayName := profile.Username
			if profile.DisplayName != nil && strings.TrimSpace(*profile.DisplayName) != "" {
				displayName = strings.TrimSpace(*profile.DisplayName)
			}

			author = authorSummaryResponse{
				ID:          profile.ID,
				Username:    profile.Username,
				DisplayName: displayName,
				AvatarURL:   profile.AvatarURL,
			}
		}

		media := mediaToResponse(mediaByPostID[p.ID])
		resp := postResponse{
			ID:         p.ID,
			AuthorID:   p.AuthorID,
			Author:     author,
			Content:    p.Content,
			Lang:       p.Lang,
			ParentID:   p.ParentID,
			Visibility: p.Visibility,

			CreatedAt: p.CreatedAt,
			UpdatedAt: p.UpdatedAt,

			LikesCount:    likes[p.ID],
			CommentsCount: comments[p.ID],
			RepostCount:   reposts[p.ID],
			IsLiked:       liked[p.ID],
			IsReposted:    reposted[p.ID],
			IsBookmarked:  bookmarked[p.ID],

			HasMedia: len(media) > 0,
			Media:    media,
		}

		if poll, ok := pollsByPostID[p.ID]; ok {
			vote := votesByPollID[poll.ID]
			hasVoted := vote.ID != uuid.Nil
			var votedOptionID *uuid.UUID
			if hasVoted {
				votedOptionID = &vote.OptionID
			}
			pr := buildPollResponse(poll, hasVoted, votedOptionID)
			resp.Poll = &pr
		}

		result = append(result, resp)
	}

	return result
}

// IsNotFound indique si une erreur correspond a une absence d'enregistrement.
// Entree : err.
// Sortie : valeur retour de type bool.
func IsNotFound(err error) bool {
	return errors.Is(err, gorm.ErrRecordNotFound)
}

// CreatePost valide la requete, cree le post et ses pieces jointes, puis renvoie le DTO enrichi.
// Entree : ctx, accountID, req.
// Sortie : valeurs retour de la fonction.
func (s *Service) CreatePost(ctx context.Context, accountID uuid.UUID, req createPostRequest) (postResponse, error) {
	authorID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return postResponse{}, err
	}
	authorIsPrivate, err := s.repo.ProfileIsPrivate(ctx, authorID)
	if err != nil {
		return postResponse{}, err
	}

	content := strings.TrimSpace(req.Content)
	if content == "" && len(req.Media) == 0 && req.Poll == nil {
		return postResponse{}, ErrInvalidContent
	}
	if len([]rune(content)) > 280 {
		return postResponse{}, ErrContentTooLong
	}

	visibility := strings.ToUpper(strings.TrimSpace(req.Visibility))
	visibility, err = normalizePostVisibility(visibility, authorIsPrivate)
	if err != nil {
		return postResponse{}, err
	}
	if len(req.Media) > 4 || !validMedia(req.Media) {
		return postResponse{}, ErrInvalidMedia
	}
	if req.Poll != nil {
		if err := validatePollRequest(req.Poll); err != nil {
			return postResponse{}, err
		}
	}

	if req.ParentID != nil {
		if _, err := s.repo.FindPostByID(ctx, *req.ParentID); err != nil {
			return postResponse{}, err
		}
	}

	post := models.Post{
		AuthorID:   authorID,
		Content:    content,
		Lang:       detectLang(content),
		ParentID:   req.ParentID,
		Visibility: visibility,
	}

	tags := extractHashtags(content)

	if err := s.repo.Transaction(ctx, func(txRepo *Repository) error {
		if err := txRepo.CreatePost(ctx, &post); err != nil {
			return err
		}

		if len(req.Media) > 0 {
			media := make([]models.Media, 0, len(req.Media))
			for _, item := range req.Media {
				media = append(media, models.Media{
					PostID:    post.ID,
					MediaType: strings.ToUpper(strings.TrimSpace(item.Type)),
					URL:       strings.TrimSpace(item.URL),
				})
			}
			if err := txRepo.CreateMedia(ctx, media); err != nil {
				return err
			}
		}

		if req.Poll != nil {
			poll := models.Poll{PostID: post.ID}
			if req.Poll.DurationHours != nil && *req.Poll.DurationHours > 0 {
				t := time.Now().Add(time.Duration(float64(time.Hour) * (*req.Poll.DurationHours)))
				poll.EndsAt = &t
			}
			if err := txRepo.CreatePoll(ctx, &poll); err != nil {
				return err
			}
			options := make([]models.PollOption, 0, len(req.Poll.Options))
			for i, text := range req.Poll.Options {
				options = append(options, models.PollOption{
					PollID:   poll.ID,
					Text:     strings.TrimSpace(text),
					Position: i,
				})
			}
			if err := txRepo.CreatePollOptions(ctx, options); err != nil {
				return err
			}
		}

		if len(tags) > 0 {
			tagIDsByName, err := txRepo.UpsertTags(ctx, tags)
			if err != nil {
				return err
			}

			tagIDs := make([]uuid.UUID, 0, len(tagIDsByName))
			for _, tag := range tags {
				if tagID, ok := tagIDsByName[tag]; ok {
					tagIDs = append(tagIDs, tagID)
				}
			}
			return txRepo.AttachTagsToPost(ctx, post.ID, tagIDs)
		}
		return nil
	}); err != nil {
		return postResponse{}, err
	}

	posts, err := s.enrichPosts(ctx, []models.Post{post})
	if err != nil {
		return postResponse{}, err
	}

	s.notifyPostInteractions(ctx, post)

	return posts[0], nil
}

// VotePoll enregistre le vote d'un utilisateur sur une option de sondage.
// Entree : ctx, accountID, postID, optionID.
// Sortie : valeurs retour de la fonction.
func (s *Service) VotePoll(ctx context.Context, accountID uuid.UUID, postID, optionID uuid.UUID) (pollResponse, error) {
	voterID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return pollResponse{}, err
	}

	poll, err := s.repo.FindPollByPostID(ctx, postID)
	if err != nil {
		return pollResponse{}, err
	}

	if isPollClosed(poll) {
		return pollResponse{}, ErrPollClosed
	}

	if _, err := s.repo.FindVoteByPollAndUser(ctx, poll.ID, voterID); err == nil {
		return pollResponse{}, ErrAlreadyVoted
	}

	// Vérifie que l'optionID appartient bien à ce sondage
	validOption := false
	for _, opt := range poll.Options {
		if opt.ID == optionID {
			validOption = true
			break
		}
	}
	if !validOption {
		return pollResponse{}, ErrInvalidPoll
	}

	if err := s.repo.Transaction(ctx, func(txRepo *Repository) error {
		vote := models.PollVote{PollID: poll.ID, OptionID: optionID, UserID: voterID}
		if err := txRepo.CreatePollVote(ctx, &vote); err != nil {
			return err
		}
		return txRepo.IncrementPollOptionVote(ctx, optionID)
	}); err != nil {
		return pollResponse{}, err
	}

	// Recharger le poll avec les vrais compteurs
	poll, err = s.repo.FindPollByPostID(ctx, postID)
	if err != nil {
		return pollResponse{}, err
	}

	vote, _ := s.repo.FindVoteByPollAndUser(ctx, poll.ID, voterID)
	return buildPollResponse(poll, true, &vote.OptionID), nil
}

// ClosePoll ferme un sondage appartenant a l'auteur du post.
// Entree : ctx, accountID, postID.
// Sortie : valeurs retour de la fonction.
func (s *Service) ClosePoll(ctx context.Context, accountID uuid.UUID, postID uuid.UUID) (pollResponse, error) {
	authorID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return pollResponse{}, err
	}

	post, err := s.repo.FindPostByID(ctx, postID)
	if err != nil {
		return pollResponse{}, err
	}
	if post.AuthorID != authorID {
		return pollResponse{}, ErrForbiddenPoll
	}

	poll, err := s.repo.FindPollByPostID(ctx, postID)
	if err != nil {
		return pollResponse{}, err
	}
	if isPollClosed(poll) {
		return pollResponse{}, ErrPollClosed
	}

	now := time.Now()
	if err := s.repo.ClosePoll(ctx, poll.ID, now); err != nil {
		return pollResponse{}, err
	}
	poll.ClosedAt = &now

	voterID, _ := s.repo.FindProfileIDByAccountID(ctx, accountID)
	vote, _ := s.repo.FindVoteByPollAndUser(ctx, poll.ID, voterID)
	hasVoted := vote.ID != uuid.Nil
	var votedOptionID *uuid.UUID
	if hasVoted {
		votedOptionID = &vote.OptionID
	}
	return buildPollResponse(poll, hasVoted, votedOptionID), nil
}

// GetFollowingPosts recupere le feed des profils suivis par l'utilisateur courant.
// Entree : ctx, accountID.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetFollowingPosts(ctx context.Context, accountID uuid.UUID) ([]postResponse, error) {
	profileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return nil, err
	}

	feedPosts, err := s.repo.FindFollowingFeedPosts(ctx, profileID)
	if err != nil {
		return nil, err
	}

	feedPosts, err = s.filterAccessibleFeedPosts(ctx, feedPosts)
	if err != nil {
		return nil, err
	}

	return s.enrichFeedPosts(ctx, feedPosts)
}

// enrichFeedPosts enrichit les posts de feed avec auteurs, reposteurs, medias, sondages et etats utilisateur.
// Entree : ctx, feedPosts.
// Sortie : valeurs retour de la fonction.
func (s *Service) enrichFeedPosts(ctx context.Context, feedPosts []FeedPost) ([]postResponse, error) {
	if len(feedPosts) == 0 {
		return []postResponse{}, nil
	}

	postIDs := make([]uuid.UUID, 0, len(feedPosts))
	authorIDs := make([]uuid.UUID, 0)
	reposterIDs := make([]uuid.UUID, 0)

	for _, fp := range feedPosts {
		postIDs = append(postIDs, fp.Post.ID)
		if !slices.Contains(authorIDs, fp.Post.AuthorID) {
			authorIDs = append(authorIDs, fp.Post.AuthorID)
		}
		if fp.ReposterID != nil && !slices.Contains(reposterIDs, *fp.ReposterID) {
			reposterIDs = append(reposterIDs, *fp.ReposterID)
		}
	}

	likesMap, err := s.repo.CountLikesByPostIDs(ctx, postIDs)
	if err != nil {
		return nil, err
	}
	commentsMap, err := s.repo.CountRepliesByPostIDs(ctx, postIDs)
	if err != nil {
		return nil, err
	}
	likedMap, err := s.repo.FindLikedPostIDsByUserID(ctx, viewerProfileID(ctx, s.repo), postIDs)
	if err != nil {
		return nil, err
	}
	repostsMap, err := s.repo.CountRepostsByPostIDs(ctx, postIDs)
	if err != nil {
		return nil, err
	}
	repostedMap, err := s.repo.FindRepostedPostIDsByUserID(ctx, viewerProfileID(ctx, s.repo), postIDs)
	if err != nil {
		return nil, err
	}

	allProfileIDs := make([]uuid.UUID, 0, len(authorIDs)+len(reposterIDs))
	allProfileIDs = append(allProfileIDs, authorIDs...)
	for _, rid := range reposterIDs {
		if !slices.Contains(allProfileIDs, rid) {
			allProfileIDs = append(allProfileIDs, rid)
		}
	}
	profilesByID, err := s.repo.FindProfilesByIDs(ctx, allProfileIDs)
	if err != nil {
		return nil, err
	}
	mediaByPostID, err := s.repo.FindMediaByPostIDs(ctx, postIDs)
	if err != nil {
		return nil, err
	}

	pollsByPostID, err := s.repo.FindPollsByPostIDs(ctx, postIDs)
	if err != nil {
		return nil, err
	}

	feedPollIDs := make([]uuid.UUID, 0, len(pollsByPostID))
	for _, p := range pollsByPostID {
		feedPollIDs = append(feedPollIDs, p.ID)
	}

	feedViewerID := viewerProfileID(ctx, s.repo)
	feedVotesByPollID, err := s.repo.FindVotesByPollIDsAndUser(ctx, feedPollIDs, feedViewerID)
	if err != nil {
		return nil, err
	}

	feedBookmarkedMap, err := s.repo.FindBookmarkedPostIDsByUserID(ctx, feedViewerID, postIDs)
	if err != nil {
		return nil, err
	}

	result := make([]postResponse, 0, len(feedPosts))
	for _, fp := range feedPosts {
		p := fp.Post
		author := authorSummaryResponse{ID: p.AuthorID}
		if profile, ok := profilesByID[p.AuthorID]; ok {
			displayName := profile.Username
			if profile.DisplayName != nil && strings.TrimSpace(*profile.DisplayName) != "" {
				displayName = strings.TrimSpace(*profile.DisplayName)
			}
			author = authorSummaryResponse{
				ID:          profile.ID,
				Username:    profile.Username,
				DisplayName: displayName,
				AvatarURL:   profile.AvatarURL,
			}
		}

		media := mediaToResponse(mediaByPostID[p.ID])
		resp := postResponse{
			ID:            p.ID,
			AuthorID:      p.AuthorID,
			Author:        author,
			Content:       p.Content,
			Lang:          p.Lang,
			ParentID:      p.ParentID,
			Visibility:    p.Visibility,
			CreatedAt:     p.CreatedAt,
			UpdatedAt:     p.UpdatedAt,
			LikesCount:    likesMap[p.ID],
			CommentsCount: commentsMap[p.ID],
			RepostCount:   repostsMap[p.ID],
			IsLiked:       likedMap[p.ID],
			IsReposted:    repostedMap[p.ID],
			IsBookmarked:  feedBookmarkedMap[p.ID],
			HasMedia:      len(media) > 0,
			Media:         media,
		}

		if fp.ReposterID != nil {
			if profile, ok := profilesByID[*fp.ReposterID]; ok {
				displayName := profile.Username
				if profile.DisplayName != nil && strings.TrimSpace(*profile.DisplayName) != "" {
					displayName = strings.TrimSpace(*profile.DisplayName)
				}
				resp.RepostedBy = &authorSummaryResponse{
					ID:          profile.ID,
					Username:    profile.Username,
					DisplayName: displayName,
					AvatarURL:   profile.AvatarURL,
				}
			}
		}

		if poll, ok := pollsByPostID[p.ID]; ok {
			vote := feedVotesByPollID[poll.ID]
			hasVoted := vote.ID != uuid.Nil
			var votedOptionID *uuid.UUID
			if hasVoted {
				votedOptionID = &vote.OptionID
			}
			pr := buildPollResponse(poll, hasVoted, votedOptionID)
			resp.Poll = &pr
		}

		result = append(result, resp)
	}

	return result, nil
}

// BookmarkPost ajoute un post aux favoris de l'utilisateur courant.
// Entree : ctx, accountID, postID.
// Sortie : erreur eventuelle.
func (s *Service) BookmarkPost(ctx context.Context, accountID, postID uuid.UUID) error {
	profileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return err
	}
	if _, err := s.repo.FindPostByID(ctx, postID); err != nil {
		return err
	}
	return s.repo.CreateBookmark(ctx, profileID, postID)
}

// UnbookmarkPost retire un post des favoris de l'utilisateur courant.
// Entree : ctx, accountID, postID.
// Sortie : erreur eventuelle.
func (s *Service) UnbookmarkPost(ctx context.Context, accountID, postID uuid.UUID) error {
	profileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return err
	}
	return s.repo.DeleteBookmark(ctx, profileID, postID)
}

// GetBookmarkedPosts recupere les posts favoris visibles de l'utilisateur courant.
// Entree : ctx, accountID.
// Sortie : valeurs retour de la fonction.
func (s *Service) GetBookmarkedPosts(ctx context.Context, accountID uuid.UUID) ([]postResponse, error) {
	profileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return nil, err
	}
	posts, err := s.repo.FindBookmarkedPostsByUserID(ctx, profileID)
	if err != nil {
		return nil, err
	}
	posts, err = s.filterAccessiblePosts(ctx, posts)
	if err != nil {
		return nil, err
	}
	return s.enrichPosts(ctx, posts)
}

var (
	ErrInvalidContent                 = errors.New("invalid content")
	ErrContentTooLong                 = errors.New("content too long")
	ErrInvalidVisibility              = errors.New("invalid visibility")
	ErrForbiddenPost                  = errors.New("forbidden post")
	ErrInvalidMedia                   = errors.New("invalid media")
	ErrPrivateProfile                 = errors.New("private profile")
	ErrPrivateProfilePublicVisibility = errors.New("private profile cannot publish public posts")
	ErrInvalidPoll                    = errors.New("invalid poll: need 2-4 non-empty options")
	ErrAlreadyVoted                   = errors.New("already voted")
	ErrPollClosed                     = errors.New("poll is closed")
	ErrForbiddenPoll                  = errors.New("only the post author can close this poll")
)

// isValidVisibility verifie que la visibilite demandee est supportee.
// Entree : visibility.
// Sortie : valeur retour de type bool.
func isValidVisibility(visibility string) bool {
	switch visibility {
	case "PUBLIC", "FOLLOWERS", "PRIVATE":
		return true
	default:
		return false
	}
}

func normalizePostVisibility(visibility string, authorIsPrivate bool) (string, error) {
	visibility = strings.ToUpper(strings.TrimSpace(visibility))
	if visibility == "" {
		if authorIsPrivate {
			return "FOLLOWERS", nil
		}
		return "PUBLIC", nil
	}
	if !isValidVisibility(visibility) {
		return "", ErrInvalidVisibility
	}
	if authorIsPrivate && visibility == "PUBLIC" {
		return "", ErrPrivateProfilePublicVisibility
	}
	return visibility, nil
}

// filterAccessiblePosts retire les posts bloques ou non visibles pour le lecteur courant.
// Entree : ctx, posts.
// Sortie : valeurs retour de la fonction.
func (s *Service) filterAccessiblePosts(ctx context.Context, posts []models.Post) ([]models.Post, error) {
	if len(posts) == 0 {
		return []models.Post{}, nil
	}

	viewerID := viewerProfileID(ctx, s.repo)
	authorIDs := make([]uuid.UUID, 0, len(posts))
	for _, post := range posts {
		if !slices.Contains(authorIDs, post.AuthorID) {
			authorIDs = append(authorIDs, post.AuthorID)
		}
	}
	blockedProfiles, err := s.repo.FindBlockedProfileIDs(ctx, viewerID, authorIDs)
	if err != nil {
		return nil, err
	}

	followedByViewer, err := s.repo.FindFollowedProfileIDs(ctx, viewerID, authorIDs)
	if err != nil {
		return nil, err
	}
	authorsByID, err := s.repo.FindProfilesByIDs(ctx, authorIDs)
	if err != nil {
		return nil, err
	}

	filtered := make([]models.Post, 0, len(posts))
	for _, post := range posts {
		author := authorsByID[post.AuthorID]
		if !blockedProfiles[post.AuthorID] && canViewPost(post, viewerID, followedByViewer, author.IsPrivate) {
			filtered = append(filtered, post)
		}
	}

	return filtered, nil
}

// canViewPost verifie l'accessibilite d'un post via les regles completes du service.
// Entree : ctx, post.
// Sortie : valeurs retour de la fonction.
func (s *Service) canViewPost(ctx context.Context, post models.Post) (bool, error) {
	posts, err := s.filterAccessiblePosts(ctx, []models.Post{post})
	if err != nil {
		return false, err
	}
	return len(posts) == 1, nil
}

// filterAccessibleFeedPosts applique les regles de visibilite aux posts de feed.
// Entree : ctx, feedPosts.
// Sortie : valeurs retour de la fonction.
func (s *Service) filterAccessibleFeedPosts(ctx context.Context, feedPosts []FeedPost) ([]FeedPost, error) {
	if len(feedPosts) == 0 {
		return []FeedPost{}, nil
	}

	posts := make([]models.Post, 0, len(feedPosts))
	for _, feedPost := range feedPosts {
		posts = append(posts, feedPost.Post)
	}

	allowedPosts, err := s.filterAccessiblePosts(ctx, posts)
	if err != nil {
		return nil, err
	}

	allowedByID := make(map[uuid.UUID]bool, len(allowedPosts))
	for _, post := range allowedPosts {
		allowedByID[post.ID] = true
	}

	filtered := make([]FeedPost, 0, len(feedPosts))
	for _, feedPost := range feedPosts {
		if allowedByID[feedPost.ID] {
			filtered = append(filtered, feedPost)
		}
	}

	return filtered, nil
}

// canViewPost applique les regles de visibilite simples avec le statut prive de l'auteur.
// Entree : post, viewerID, followedByViewer, authorIsPrivate.
// Sortie : valeur retour de type bool.
func canViewPost(post models.Post, viewerID uuid.UUID, followedByViewer map[uuid.UUID]bool, authorIsPrivate bool) bool {
	if authorIsPrivate && post.AuthorID != viewerID && !followedByViewer[post.AuthorID] {
		return false
	}

	switch post.Visibility {
	case "PUBLIC":
		return true
	case "FOLLOWERS":
		return post.AuthorID == viewerID || followedByViewer[post.AuthorID]
	case "PRIVATE":
		return post.AuthorID == viewerID
	default:
		return false
	}
}

// validMedia verifie que les medias fournis sont de type autorise et servis par l'API media.
// Entree : media.
// Sortie : valeur retour de type bool.
func validMedia(media []mediaRequest) bool {
	for _, item := range media {
		mediaType := strings.ToUpper(strings.TrimSpace(item.Type))
		url := strings.TrimSpace(item.URL)
		if (mediaType != "IMAGE" && mediaType != "VIDEO") || !strings.Contains(url, "/api/media/files/") {
			return false
		}
	}
	return true
}

// mediaToResponse transforme les modeles media en DTO API.
// Entree : media.
// Sortie : valeur retour de type []mediaResponse.
func mediaToResponse(media []models.Media) []mediaResponse {
	result := make([]mediaResponse, 0, len(media))
	for _, item := range media {
		result = append(result, mediaResponse{ID: item.ID, Type: item.MediaType, URL: item.URL})
	}
	return result
}

// DeletePost supprime un post si l'utilisateur est auteur, admin ou moderateur.
// Entree : ctx, accountID, postID.
// Sortie : erreur eventuelle.
func (s *Service) DeletePost(ctx context.Context, accountID, postID uuid.UUID) error {
	authorID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return err
	}

	role, err := s.repo.FindAccountRole(ctx, accountID)
	if err != nil {
		return err
	}

	post, err := s.repo.FindPostByID(ctx, postID)
	if err != nil {
		return err
	}

	if post.AuthorID != authorID && role != "ADMIN" && role != "MODERATOR" {
		return ErrForbiddenPost
	}

	return s.repo.DeletePost(ctx, postID)
}

// UpdatePostVisibility change la visibilite d'un post appartenant a l'utilisateur.
// Entree : ctx, accountID, postID, visibility.
// Sortie : valeurs retour de la fonction.
func (s *Service) UpdatePostVisibility(ctx context.Context, accountID, postID uuid.UUID, visibility string) (postResponse, error) {
	authorID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return postResponse{}, err
	}

	post, err := s.repo.FindPostByID(ctx, postID)
	if err != nil {
		return postResponse{}, err
	}

	if post.AuthorID != authorID {
		return postResponse{}, ErrForbiddenPost
	}

	nextVisibility := strings.ToUpper(strings.TrimSpace(visibility))
	if !isValidVisibility(nextVisibility) {
		return postResponse{}, ErrInvalidVisibility
	}
	if nextVisibility == "PUBLIC" {
		authorIsPrivate, err := s.repo.ProfileIsPrivate(ctx, authorID)
		if err != nil {
			return postResponse{}, err
		}
		if authorIsPrivate {
			return postResponse{}, ErrPrivateProfilePublicVisibility
		}
	}

	if err := s.repo.UpdatePostVisibility(ctx, postID, nextVisibility); err != nil {
		return postResponse{}, err
	}

	post.Visibility = nextVisibility
	posts, err := s.enrichPosts(ctx, []models.Post{post})
	if err != nil {
		return postResponse{}, err
	}
	if len(posts) == 0 {
		return postResponse{}, gorm.ErrRecordNotFound
	}

	return posts[0], nil
}

// LikePost ajoute un like idempotent et notifie l'auteur si necessaire.
// Entree : ctx, accountID, postID.
// Sortie : erreur eventuelle.
func (s *Service) LikePost(ctx context.Context, accountID, postID uuid.UUID) error {
	profileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return err
	}

	post, err := s.repo.FindPostByID(ctx, postID)
	if err != nil {
		return err
	}

	alreadyLiked, err := s.repo.HasLike(ctx, postID, profileID)
	if err != nil {
		return err
	}
	if alreadyLiked {
		return nil
	}

	like := models.Like{
		PostID: postID,
		UserID: profileID,
	}

	if err := s.repo.CreateLike(ctx, &like); err != nil {
		return err
	}

	if post.AuthorID != profileID {
		_ = s.repo.CreateNotification(ctx, &models.Notification{
			RecipientID: post.AuthorID,
			ActorID:     profileID,
			Type:        "LIKE",
			PostID:      &post.ID,
		})
	}

	return nil
}

// UnlikePost retire le like de l'utilisateur courant sur un post existant.
// Entree : ctx, accountID, postID.
// Sortie : erreur eventuelle.
func (s *Service) UnlikePost(ctx context.Context, accountID, postID uuid.UUID) error {
	profileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return err
	}

	if _, err := s.repo.FindPostByID(ctx, postID); err != nil {
		return err
	}

	return s.repo.DeleteLike(ctx, postID, profileID)
}

// Repost cree un repost idempotent pour l'utilisateur courant.
// Entree : ctx, accountID, postID.
// Sortie : erreur eventuelle.
func (s *Service) Repost(ctx context.Context, accountID, postID uuid.UUID) error {
	profileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return err
	}

	if _, err := s.repo.FindPostByID(ctx, postID); err != nil {
		return err
	}

	alreadyReposted, err := s.repo.HasRepost(ctx, postID, profileID)
	if err != nil {
		return err
	}
	if alreadyReposted {
		return nil
	}

	repost := models.Repost{
		PostID: postID,
		UserID: profileID,
	}

	if err := s.repo.CreateRepost(ctx, &repost); err != nil {
		return err
	}

	return nil
}

// Unrepost retire le repost de l'utilisateur courant.
// Entree : ctx, accountID, postID.
// Sortie : erreur eventuelle.
func (s *Service) Unrepost(ctx context.Context, accountID, postID uuid.UUID) error {
	profileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return err
	}

	if _, err := s.repo.FindPostByID(ctx, postID); err != nil {
		return err
	}

	return s.repo.DeleteRepost(ctx, postID, profileID)
}

// viewerProfileID extrait le profil du lecteur depuis le contexte de requete.
// Entree : ctx, repo.
// Sortie : valeur retour de type uuid.UUID.
func viewerProfileID(ctx context.Context, repo *Repository) uuid.UUID {
	accountID, ok := middleware.RequestAccountID(ctx)
	if !ok {
		return uuid.Nil
	}

	profileID, err := repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return uuid.Nil
	}

	return profileID
}

// requestAccountID extrait l'identifiant de compte depuis le contexte de requete.
// Entree : ctx.
// Sortie : valeur retour de type uuid.UUID.
func requestAccountID(ctx context.Context) uuid.UUID {
	accountID, _ := middleware.RequestAccountID(ctx)
	return accountID
}

// extractHashtags extrait les hashtags uniques et normalises du contenu.
// Entree : content.
// Sortie : valeur retour de type []string.
func extractHashtags(content string) []string {
	matches := hashtagPattern.FindAllStringSubmatch(content, -1)
	if len(matches) == 0 {
		return nil
	}

	tags := make([]string, 0, len(matches))
	for _, match := range matches {
		if len(match) < 2 {
			continue
		}

		tag := strings.ToLower(strings.TrimSpace(match[1]))
		if tag == "" || slices.Contains(tags, tag) {
			continue
		}
		tags = append(tags, tag)
	}

	return tags
}

// notifyPostInteractions cree les notifications liees a un nouveau post :
// reponse, mention et notification speciale de test.
// Entree : ctx, post.
// Sortie : aucune valeur.
func (s *Service) notifyPostInteractions(ctx context.Context, post models.Post) {
	// Un post prive n'est visible que par l'auteur : aucune notification.
	if post.Visibility == "PRIVATE" {
		return
	}

	s.notifyTestCedricIfNeeded(ctx, post)

	if post.ParentID != nil {
		parent, err := s.repo.FindPostByID(ctx, *post.ParentID)
		if err == nil && parent.AuthorID != post.AuthorID {
			canNotify := post.Visibility == "PUBLIC"
			if !canNotify {
				followed, err := s.repo.FindFollowedProfileIDs(ctx, parent.AuthorID, []uuid.UUID{post.AuthorID})
				canNotify = err == nil && followed[post.AuthorID]
			}
			if canNotify {
				_ = s.repo.CreateNotification(ctx, &models.Notification{
					RecipientID: parent.AuthorID,
					ActorID:     post.AuthorID,
					Type:        "REPLY",
					PostID:      post.ParentID,
				})
			}
		}
	}

	for _, profile := range s.mentionedProfiles(ctx, post.Content) {
		if profile.ID == post.AuthorID {
			continue
		}
		if post.Visibility == "FOLLOWERS" {
			followed, err := s.repo.FindFollowedProfileIDs(ctx, profile.ID, []uuid.UUID{post.AuthorID})
			if err != nil || !followed[post.AuthorID] {
				continue
			}
		}
		_ = s.repo.CreateNotification(ctx, &models.Notification{
			RecipientID: profile.ID,
			ActorID:     post.AuthorID,
			Type:        "MENTION",
			PostID:      &post.ID,
		})
	}
}

// notifyTestCedricIfNeeded envoie une notification fictive a l'auteur quand un
// post contient le mot exact TEST.
// Entree : ctx, post.
// Sortie : aucune valeur.
// La fonction s'arrete silencieusement si la condition n'est pas remplie ou si
// la notification ne peut pas etre creee.
func (s *Service) notifyTestCedricIfNeeded(ctx context.Context, post models.Post) {
	if !testKeywordPattern.MatchString(post.Content) {
		return
	}

	_ = s.repo.CreateNotification(ctx, &models.Notification{
		RecipientID: post.AuthorID,
		ActorID:     post.AuthorID,
		Type:        "TEST",
		PostID:      &post.ID,
	})
}

// mentionedProfiles resout les profils mentionnes dans le contenu.
// Entree : ctx, content.
// Sortie : valeur retour de type []models.Profile.
func (s *Service) mentionedProfiles(ctx context.Context, content string) []models.Profile {
	usernames := extractMentions(content)
	if len(usernames) == 0 {
		return nil
	}

	profiles, err := s.repo.FindProfilesByUsernames(ctx, usernames)
	if err != nil {
		return nil
	}

	return profiles
}

// validatePollRequest verifie le nombre et le contenu des options d'un sondage.
// Entree : req.
// Sortie : erreur eventuelle.
func validatePollRequest(req *createPollRequest) error {
	if len(req.Options) < 2 || len(req.Options) > 4 {
		return ErrInvalidPoll
	}
	for _, opt := range req.Options {
		if strings.TrimSpace(opt) == "" {
			return ErrInvalidPoll
		}
	}
	return nil
}

// isPollClosed indique si un sondage est ferme manuellement ou expire.
// Entree : poll.
// Sortie : valeur retour de type bool.
func isPollClosed(poll models.Poll) bool {
	if poll.ClosedAt != nil {
		return true
	}
	if poll.EndsAt != nil && time.Now().After(*poll.EndsAt) {
		return true
	}
	return false
}

// buildPollResponse construit le DTO de sondage avec etat de vote utilisateur.
// Entree : poll, hasVoted, votedOptionID.
// Sortie : valeur retour de type pollResponse.
func buildPollResponse(poll models.Poll, hasVoted bool, votedOptionID *uuid.UUID) pollResponse {
	total := 0
	for _, opt := range poll.Options {
		total += opt.VoteCount
	}

	options := make([]pollOptionResponse, 0, len(poll.Options))
	for _, opt := range poll.Options {
		options = append(options, pollOptionResponse{
			ID:        opt.ID,
			Text:      opt.Text,
			VoteCount: opt.VoteCount,
			Position:  opt.Position,
		})
	}

	return pollResponse{
		ID:            poll.ID,
		Options:       options,
		TotalVotes:    total,
		EndsAt:        poll.EndsAt,
		ClosedAt:      poll.ClosedAt,
		IsClosed:      isPollClosed(poll),
		HasVoted:      hasVoted,
		VotedOptionID: votedOptionID,
	}
}

// extractMentions extrait les noms d'utilisateur uniques mentionnes dans le contenu.
// Entree : content.
// Sortie : valeur retour de type []string.
func extractMentions(content string) []string {
	matches := mentionPattern.FindAllStringSubmatch(content, -1)
	if len(matches) == 0 {
		return nil
	}

	usernames := make([]string, 0, len(matches))
	for _, match := range matches {
		if len(match) < 2 {
			continue
		}

		username := strings.ToLower(strings.TrimSpace(match[1]))
		if username == "" || slices.Contains(usernames, username) {
			continue
		}
		usernames = append(usernames, username)
	}

	return usernames
}
