package post

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"breezy/backend/internal/middleware"
	"breezy/backend/internal/models"
	"breezy/backend/internal/security"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

// authenticatedContext construit un context.Context portant un accountID
// authentifie au sens de middleware.RequestAccountID (utilise par
// viewerProfileID), en passant par le vrai middleware AuthOptional via une
// requete HTTP -- la cle interne du contexte n'etant pas exportee, c'est le
// seul moyen d'injecter un accountID depuis le package post. Programme aussi
// la requete de lookup de profil correspondante sur le mock fourni.
func authenticatedContext(t *testing.T, mock sqlmock.Sqlmock, accountID uuid.UUID) context.Context {
	t.Helper()
	gin.SetMode(gin.TestMode)
	t.Setenv("JWT_SECRET", "test-secret")
	token, err := security.SignAccessToken(accountID, middleware.RoleUser, time.Hour)
	if err != nil {
		t.Fatalf("SignAccessToken() unexpected error: %v", err)
	}

	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodGet, "/", nil)
	c.Request.Header.Set("Authorization", "Bearer "+token)
	middleware.AuthOptional()(c)

	expectProfileLookupByAccountID(mock, accountID, accountID)
	return c.Request.Context()
}

// TestServiceEnrichPostsPropagatesEachRepositoryError couvre, pour chaque
// requete de Service.enrichPosts, la propagation d'erreur lorsque la requete
// correspondante echoue. Jusqu'ici seul le chemin de succes complet (via
// expectEnrichPosts) etait exerce : aucune des 8 verifications d'erreur de la
// fonction n'etait jamais atteinte.
func TestServiceEnrichPostsPropagatesEachRepositoryError(t *testing.T) {
	authorID := uuid.New()
	post := models.Post{ID: uuid.New(), AuthorID: authorID, Visibility: "PUBLIC", Content: "hi"}

	newServiceWithAccessiblePost := func(t *testing.T) (*Service, sqlmock.Sqlmock) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		expectFindPostByID(mock, post)
		expectAccessibilityChecks(mock, authorID, false, false, false)
		return service, mock
	}

	t.Run("likes count error", func(t *testing.T) {
		service, mock := newServiceWithAccessiblePost(t)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPostByID(context.Background(), post.ID); err == nil {
			t.Fatal("expected error from CountLikesByPostIDs")
		}
	})

	t.Run("comments count error", func(t *testing.T) {
		service, mock := newServiceWithAccessiblePost(t)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPostByID(context.Background(), post.ID); err == nil {
			t.Fatal("expected error from CountRepliesByPostIDs")
		}
	})

	t.Run("liked-by-user lookup error", func(t *testing.T) {
		service, mock := newServiceWithAccessiblePost(t)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		// FindLikedPostIDsByUserID est court-circuite quand viewerProfileID()
		// renvoie uuid.Nil (pas de compte authentifie). On utilise donc un
		// contexte authentifie pour forcer la requete SQL et simuler l'echec.
		ctx := authenticatedContext(t, mock, post.AuthorID)
		mock.ExpectQuery(`FROM "posts"\."likes" WHERE user_id`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPostByID(ctx, post.ID); err == nil {
			t.Fatal("expected error from FindLikedPostIDsByUserID")
		}
	})

	t.Run("reposts count error", func(t *testing.T) {
		service, mock := newServiceWithAccessiblePost(t)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPostByID(context.Background(), post.ID); err == nil {
			t.Fatal("expected error from CountRepostsByPostIDs")
		}
	})

	t.Run("reposted-by-user lookup error", func(t *testing.T) {
		service, mock := newServiceWithAccessiblePost(t)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		ctx := authenticatedContext(t, mock, post.AuthorID)
		mock.ExpectQuery(`FROM "posts"\."likes" WHERE user_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id"}))
		mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`FROM "posts"\."reposts" WHERE user_id`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPostByID(ctx, post.ID); err == nil {
			t.Fatal("expected error from FindRepostedPostIDsByUserID")
		}
	})

	t.Run("authors lookup error", func(t *testing.T) {
		service, mock := newServiceWithAccessiblePost(t)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE id IN`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPostByID(context.Background(), post.ID); err == nil {
			t.Fatal("expected error from FindProfilesByIDs")
		}
	})

	t.Run("media lookup error", func(t *testing.T) {
		service, mock := newServiceWithAccessiblePost(t)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE id IN`).WillReturnRows(sqlmock.NewRows([]string{"id", "username", "is_private"}))
		mock.ExpectQuery(`FROM "posts"\."media"`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPostByID(context.Background(), post.ID); err == nil {
			t.Fatal("expected error from FindMediaByPostIDs")
		}
	})

	t.Run("polls lookup error", func(t *testing.T) {
		service, mock := newServiceWithAccessiblePost(t)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE id IN`).WillReturnRows(sqlmock.NewRows([]string{"id", "username", "is_private"}))
		mock.ExpectQuery(`FROM "posts"\."media"`).WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "media_type", "url"}))
		mock.ExpectQuery(`FROM "posts"\."polls"`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPostByID(context.Background(), post.ID); err == nil {
			t.Fatal("expected error from FindPollsByPostIDs")
		}
	})

	t.Run("votes lookup error with non-empty poll ids", func(t *testing.T) {
		service, mock := newServiceWithAccessiblePost(t)
		pollID := uuid.New()
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		ctx := authenticatedContext(t, mock, post.AuthorID)
		mock.ExpectQuery(`FROM "posts"\."likes" WHERE user_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id"}))
		mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`FROM "posts"\."reposts" WHERE user_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id"}))
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE id IN`).WillReturnRows(sqlmock.NewRows([]string{"id", "username", "is_private"}))
		mock.ExpectQuery(`FROM "posts"\."media"`).WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "media_type", "url"}))
		mock.ExpectQuery(`FROM "posts"\."polls"`).WillReturnRows(
			sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, post.ID))
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id"}))
		mock.ExpectQuery(`FROM "posts"\."poll_votes" WHERE poll_id IN`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPostByID(ctx, post.ID); err == nil {
			t.Fatal("expected error from FindVotesByPollIDsAndUser")
		}
	})

	t.Run("feed: likes count error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`FROM posts\.posts AS p`).WillReturnRows(
			sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}).
				AddRow(post.ID, authorID, "PUBLIC", "hi"))
		expectAccessibilityChecks(mock, authorID, false, false, false)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPosts(context.Background()); err == nil {
			t.Fatal("expected error from enrichFeedPosts CountLikesByPostIDs")
		}
	})

	t.Run("feed: comments count error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`FROM posts\.posts AS p`).WillReturnRows(
			sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}).
				AddRow(post.ID, authorID, "PUBLIC", "hi"))
		expectAccessibilityChecks(mock, authorID, false, false, false)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPosts(context.Background()); err == nil {
			t.Fatal("expected error from enrichFeedPosts CountRepliesByPostIDs")
		}
	})

	t.Run("feed: liked-by-user lookup error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`FROM posts\.posts AS p`).WillReturnRows(
			sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}).
				AddRow(post.ID, authorID, "PUBLIC", "hi"))
		expectAccessibilityChecks(mock, authorID, false, false, false)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		ctx := authenticatedContext(t, mock, authorID)
		mock.ExpectQuery(`FROM "posts"\."likes" WHERE user_id`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPosts(ctx); err == nil {
			t.Fatal("expected error from enrichFeedPosts FindLikedPostIDsByUserID")
		}
	})

	t.Run("bookmarked lookup error", func(t *testing.T) {
		service, mock := newServiceWithAccessiblePost(t)
		mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE id IN`).WillReturnRows(sqlmock.NewRows([]string{"id", "username", "is_private"}))
		mock.ExpectQuery(`FROM "posts"\."media"`).WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "media_type", "url"}))
		mock.ExpectQuery(`FROM "posts"\."polls"`).WillReturnRows(sqlmock.NewRows([]string{"id", "post_id"}))
		ctx := authenticatedContext(t, mock, post.AuthorID)
		mock.ExpectQuery(`FROM "posts"\."bookmarks" WHERE user_id`).WillReturnError(errors.New("boom"))
		if _, err := service.GetPostByID(ctx, post.ID); err == nil {
			t.Fatal("expected error from FindBookmarkedPostIDsByUserID")
		}
	})
}
