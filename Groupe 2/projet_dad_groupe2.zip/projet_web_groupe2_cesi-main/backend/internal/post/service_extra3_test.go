package post

// service_extra3_test.go — couverture supplementaire des fonctions sous-testees :
// GetPostsByAuthor, GetRepliesByAuthor, GetRepliesByParentID,
// GetFollowingPosts, GetBookmarkedPosts, Repost, enrichFeedPosts.

import (
	"context"
	"errors"
	"testing"

	"breezy/backend/internal/models"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// --- helpers locaux reutilisables ---

func newProfileRowsForUsername(authorID uuid.UUID, username string, private bool) *sqlmock.Rows {
	return sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
		AddRow(authorID, uuid.New(), username, private)
}

// --- GetPostsByAuthor : branches d'erreur manquantes ---

func TestServiceGetPostsByAuthorErrors(t *testing.T) {
	ctx := context.Background()

	t.Run("CanViewProfileContent returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnError(dbErr)

		if _, err := service.GetPostsByAuthor(ctx, "alice"); !errors.Is(err, dbErr) {
			t.Fatalf("GetPostsByAuthor(canView error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("FindPostsByAuthorUsername returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		// CanViewProfileContent OK (public profile)
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnRows(newProfileRowsForUsername(uuid.New(), "alice", false))
		// FindPostsByAuthorUsername (lit aussi le profil par username pour obtenir account_id)
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnRows(newProfileRowsForUsername(uuid.New(), "alice", false))
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id`).
			WillReturnError(dbErr)

		if _, err := service.GetPostsByAuthor(ctx, "alice"); !errors.Is(err, dbErr) {
			t.Fatalf("GetPostsByAuthor(FindPosts error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("empty username shortcircuits", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))

		if _, err := service.GetPostsByAuthor(ctx, "  "); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("GetPostsByAuthor(blank) error = %v, want gorm.ErrRecordNotFound", err)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unexpected SQL calls: %v", err)
		}
	})

	t.Run("private profile is rejected", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))

		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnRows(newProfileRowsForUsername(uuid.New(), "alice", true))

		if _, err := service.GetPostsByAuthor(ctx, "alice"); !errors.Is(err, ErrPrivateProfile) {
			t.Fatalf("GetPostsByAuthor(private) error = %v, want ErrPrivateProfile", err)
		}
	})
}

// --- GetRepliesByAuthor : branches d'erreur manquantes ---

func TestServiceGetRepliesByAuthorErrors(t *testing.T) {
	ctx := context.Background()

	t.Run("empty username shortcircuits", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))

		if _, err := service.GetRepliesByAuthor(ctx, "  "); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("GetRepliesByAuthor(blank) error = %v, want gorm.ErrRecordNotFound", err)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unexpected SQL calls: %v", err)
		}
	})

	t.Run("private profile is rejected", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))

		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnRows(newProfileRowsForUsername(uuid.New(), "alice", true))

		if _, err := service.GetRepliesByAuthor(ctx, "alice"); !errors.Is(err, ErrPrivateProfile) {
			t.Fatalf("GetRepliesByAuthor(private) error = %v, want ErrPrivateProfile", err)
		}
	})

	t.Run("CanViewProfileContent returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnError(dbErr)

		if _, err := service.GetRepliesByAuthor(ctx, "alice"); !errors.Is(err, dbErr) {
			t.Fatalf("GetRepliesByAuthor(canView error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("FindRepliesByAuthorUsername returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		authorID := uuid.New()
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnRows(newProfileRowsForUsername(authorID, "alice", false))
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).
			WillReturnRows(newProfileRowsForUsername(authorID, "alice", false))
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id`).
			WillReturnError(dbErr)

		if _, err := service.GetRepliesByAuthor(ctx, "alice"); !errors.Is(err, dbErr) {
			t.Fatalf("GetRepliesByAuthor(FindReplies error) error = %v, want %v", err, dbErr)
		}
	})
}

// --- GetRepliesByParentID : branches d'erreur manquantes ---

func TestServiceGetRepliesByParentIDErrors(t *testing.T) {
	ctx := context.Background()
	parentPost := models.Post{ID: uuid.New(), AuthorID: uuid.New(), Visibility: "PUBLIC"}

	t.Run("FindPostByID returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE id`).WillReturnError(dbErr)

		if _, err := service.GetRepliesByParentID(ctx, parentPost.ID); !errors.Is(err, dbErr) {
			t.Fatalf("GetRepliesByParentID(FindPost error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("parent post is private (canView false)", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))

		// Post prive dont l'auteur est un compte distinct du viewer (uuid.Nil = anon)
		privatePost := models.Post{ID: uuid.New(), AuthorID: uuid.New(), Visibility: "PRIVATE"}
		expectFindPostByID(mock, privatePost)
		// filterAccessiblePosts : aucun bloc, aucun follow, auteur public (is_private=false)
		// mais la visibilite PRIVATE empeche l'acces au viewer anon
		blockRows := sqlmock.NewRows([]string{"profile_id"})
		mock.ExpectQuery(`FROM "social"\."blocks"`).WillReturnRows(blockRows)
		followRows := sqlmock.NewRows([]string{"followed_id"})
		mock.ExpectQuery(`FROM "social"\."follows"`).WillReturnRows(followRows)
		profileRows := sqlmock.NewRows([]string{"id", "username", "is_private"}).
			AddRow(privatePost.AuthorID, "author", false)
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE id IN`).WillReturnRows(profileRows)

		if _, err := service.GetRepliesByParentID(ctx, privatePost.ID); !errors.Is(err, ErrPrivateProfile) {
			t.Fatalf("GetRepliesByParentID(private parent) error = %v, want ErrPrivateProfile", err)
		}
	})

	t.Run("FindRepliesByParentID returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		expectFindPostByID(mock, parentPost)
		expectAccessibilityChecks(mock, parentPost.AuthorID, false, false, false)
		// FindRepliesByParentID utilise parent_id IN ? (requete recursive)
		mock.ExpectQuery(`WHERE parent_id IN`).WillReturnError(dbErr)

		if _, err := service.GetRepliesByParentID(ctx, parentPost.ID); !errors.Is(err, dbErr) {
			t.Fatalf("GetRepliesByParentID(FindReplies error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("happy path returns enriched replies", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		replyID := uuid.New()

		expectFindPostByID(mock, parentPost)
		expectAccessibilityChecks(mock, parentPost.AuthorID, false, false, false)

		// Premiere iteration de la boucle : renvoie une reponse
		replyRows := sqlmock.NewRows([]string{"id", "author_id", "parent_id", "visibility", "content"}).
			AddRow(replyID, parentPost.AuthorID, parentPost.ID, "PUBLIC", "a reply")
		mock.ExpectQuery(`WHERE parent_id IN`).WillReturnRows(replyRows)

		// Deuxieme iteration : aucune sous-reponse (fin de recursion)
		mock.ExpectQuery(`WHERE parent_id IN`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "author_id", "parent_id", "visibility", "content"}))

		expectAccessibilityChecks(mock, parentPost.AuthorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{replyID}, map[uuid.UUID]models.Profile{
			parentPost.AuthorID: {ID: parentPost.AuthorID, Username: "author"},
		})

		got, err := service.GetRepliesByParentID(ctx, parentPost.ID)
		if err != nil {
			t.Fatalf("GetRepliesByParentID() unexpected error: %v", err)
		}
		if len(got) != 1 || got[0].ID != replyID {
			t.Fatalf("GetRepliesByParentID() = %+v, want one reply", got)
		}
	})
}

// --- GetFollowingPosts : branches d'erreur manquantes ---

func TestServiceGetFollowingPostsErrors(t *testing.T) {
	ctx := context.Background()
	accountID := uuid.New()
	profileID := uuid.New()

	t.Run("FindProfileIDByAccountID returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
			WillReturnError(dbErr)

		if _, err := service.GetFollowingPosts(ctx, accountID); !errors.Is(err, dbErr) {
			t.Fatalf("GetFollowingPosts(profile error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("FindFollowingFeedPosts returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
		// FindFollowingFeedPosts
		mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
			WillReturnError(dbErr)

		if _, err := service.GetFollowingPosts(ctx, accountID); !errors.Is(err, dbErr) {
			t.Fatalf("GetFollowingPosts(FindFollowing error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("happy path with empty feed returns empty slice", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
		// FindFollowingFeedPosts : aucun abonnement
		mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).
			WillReturnRows(sqlmock.NewRows([]string{"followed_id"}))
		// Pas d'authored posts, pas de reposts
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id IN`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}))
		mock.ExpectQuery(`SELECT post_id, user_id, created_at FROM "posts"\."reposts"`).
			WillReturnRows(sqlmock.NewRows([]string{"post_id", "user_id", "created_at"}))

		got, err := service.GetFollowingPosts(ctx, accountID)
		if err != nil {
			t.Fatalf("GetFollowingPosts() unexpected error: %v", err)
		}
		if len(got) != 0 {
			t.Fatalf("GetFollowingPosts() = %+v, want empty", got)
		}
	})
}

// --- GetBookmarkedPosts : branches d'erreur manquantes ---

func TestServiceGetBookmarkedPostsErrors(t *testing.T) {
	ctx := context.Background()
	accountID := uuid.New()
	profileID := uuid.New()

	t.Run("FindProfileIDByAccountID returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
			WillReturnError(dbErr)

		if _, err := service.GetBookmarkedPosts(ctx, accountID); !errors.Is(err, dbErr) {
			t.Fatalf("GetBookmarkedPosts(profile error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("FindBookmarkedPostsByUserID returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
		// La requete reelle est un SELECT avec JOIN sur posts.bookmarks
		mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p JOIN posts\.bookmarks`).
			WillReturnError(dbErr)

		if _, err := service.GetBookmarkedPosts(ctx, accountID); !errors.Is(err, dbErr) {
			t.Fatalf("GetBookmarkedPosts(FindBookmarks error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("happy path with no bookmarks returns empty slice", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
		mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p JOIN posts\.bookmarks`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}))

		got, err := service.GetBookmarkedPosts(ctx, accountID)
		if err != nil {
			t.Fatalf("GetBookmarkedPosts() unexpected error: %v", err)
		}
		if len(got) != 0 {
			t.Fatalf("GetBookmarkedPosts() = %+v, want empty", got)
		}
	})
}

// --- Repost : branches d'erreur et chemin already-reposted ---

func TestServiceRepostErrors(t *testing.T) {
	ctx := context.Background()
	accountID := uuid.New()
	profileID := uuid.New()
	postID := uuid.New()

	t.Run("FindProfileIDByAccountID returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
			WillReturnError(dbErr)

		if err := service.Repost(ctx, accountID, postID); !errors.Is(err, dbErr) {
			t.Fatalf("Repost(profile error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("FindPostByID returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE id`).
			WillReturnError(gorm.ErrRecordNotFound)

		if err := service.Repost(ctx, accountID, postID); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("Repost(post not found) error = %v, want gorm.ErrRecordNotFound", err)
		}
	})

	t.Run("HasRepost returns error", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		dbErr := errors.New("db boom")
		post := models.Post{ID: postID, AuthorID: profileID, Visibility: "PUBLIC"}

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
		expectFindPostByID(mock, post)
		mock.ExpectQuery(`SELECT \* FROM "posts"\."reposts" WHERE`).
			WillReturnError(dbErr)

		if err := service.Repost(ctx, accountID, postID); !errors.Is(err, dbErr) {
			t.Fatalf("Repost(HasRepost error) error = %v, want %v", err, dbErr)
		}
	})

	t.Run("already reposted returns nil without creating repost", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		service := NewService(NewRepository(db))
		post := models.Post{ID: postID, AuthorID: profileID, Visibility: "PUBLIC"}

		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
		expectFindPostByID(mock, post)
		// HasRepost : renvoie une ligne (deja reposte)
		mock.ExpectQuery(`SELECT \* FROM "posts"\."reposts" WHERE`).
			WillReturnRows(sqlmock.NewRows([]string{"post_id", "user_id"}).AddRow(postID, profileID))

		if err := service.Repost(ctx, accountID, postID); err != nil {
			t.Fatalf("Repost(already reposted) unexpected error: %v", err)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unexpected extra SQL calls: %v", err)
		}
	})
}

// --- enrichFeedPosts : branche reposterID absent de profilesByID ---

func TestServiceEnrichFeedPostsReposterIDNotInProfileMap(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	authorID := uuid.New()
	reposterID := uuid.New()
	postID := uuid.New()

	// Simule un FeedPost avec un ReposterID qui n'est PAS dans la map de profils.
	// Cela couvre la branche "if profile, ok := profilesByID[*fp.ReposterID]; ok"
	// lorsque ok == false.
	feedPosts := []FeedPost{
		{
			Post:       models.Post{ID: postID, AuthorID: authorID, Visibility: "PUBLIC"},
			ReposterID: &reposterID,
		},
	}

	likesRows := sqlmock.NewRows([]string{"post_id", "count"})
	mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(likesRows)

	commentRows := sqlmock.NewRows([]string{"post_id", "count"})
	mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(commentRows)

	repostCountRows := sqlmock.NewRows([]string{"post_id", "count"})
	mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).WillReturnRows(repostCountRows)

	// FindProfilesByIDs : renvoie uniquement l'auteur, PAS le reposter
	profileRows := sqlmock.NewRows([]string{"id", "username", "is_private"}).
		AddRow(authorID, "author", false)
	mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE id IN`).WillReturnRows(profileRows)

	mediaRows := sqlmock.NewRows([]string{"id", "post_id", "media_type", "url"})
	mock.ExpectQuery(`FROM "posts"\."media"`).WillReturnRows(mediaRows)

	pollRows := sqlmock.NewRows([]string{"id", "post_id"})
	mock.ExpectQuery(`FROM "posts"\."polls"`).WillReturnRows(pollRows)

	got, err := service.enrichFeedPosts(ctx, feedPosts)
	if err != nil {
		t.Fatalf("enrichFeedPosts() unexpected error: %v", err)
	}
	if len(got) != 1 {
		t.Fatalf("enrichFeedPosts() = %d posts, want 1", len(got))
	}
	// RepostedBy doit etre nil car le reposter n'est pas dans la map
	if got[0].RepostedBy != nil {
		t.Fatalf("enrichFeedPosts() RepostedBy = %+v, want nil when reposter not in profile map", got[0].RepostedBy)
	}
}
