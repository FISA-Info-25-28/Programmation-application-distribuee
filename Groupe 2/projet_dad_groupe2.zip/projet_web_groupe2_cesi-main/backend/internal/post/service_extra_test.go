package post

import (
	"context"
	"errors"
	"regexp"
	"testing"
	"time"

	"breezy/backend/internal/models"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// newPostMockDB construit une base sqlmock non ordonnee (les requetes peuvent
// arriver dans des ordres legerement differents selon le runtime Go/Gorm) pour
// piloter precisement les reponses du Repository sans dependre de l'ordre
// d'execution interne du service.
func newPostMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	mock.MatchExpectationsInOrder(false)

	db, err := gorm.Open(postgres.New(postgres.Config{
		Conn:                 sqlDB,
		PreferSimpleProtocol: true,
	}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}

	return db, mock
}

func qm(sql string) string {
	return regexp.QuoteMeta(sql)
}

// expectEmptyEnrichment programme toutes les requetes lancees par enrichPosts/
// enrichFeedPosts lorsqu'aucun post n'est en entree (cas trivial mais
// neanmoins requis car le service interroge systematiquement les maps de
// likes/comments/reposts/medias/sondages avant de construire la reponse).
func expectProfileLookupByAccountID(mock sqlmock.Sqlmock, accountID, profileID uuid.UUID) {
	rows := sqlmock.NewRows([]string{"id"}).AddRow(profileID)
	mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnRows(rows)
}

func expectProfileIsPrivate(mock sqlmock.Sqlmock, profileID uuid.UUID, private bool) {
	rows := sqlmock.NewRows([]string{"id", "is_private"}).AddRow(profileID, private)
	mock.ExpectQuery(`SELECT id, is_private FROM "profiles"\."profiles" WHERE id`).WillReturnRows(rows)
}

func expectFindPostByID(mock sqlmock.Sqlmock, post models.Post) {
	rows := sqlmock.NewRows([]string{"id", "author_id", "content", "lang", "parent_id", "visibility", "created_at", "updated_at"}).
		AddRow(post.ID, post.AuthorID, post.Content, post.Lang, post.ParentID, post.Visibility, post.CreatedAt, post.UpdatedAt)
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE id`).WillReturnRows(rows)
}

func expectFindPostByIDNotFound(mock sqlmock.Sqlmock) {
	mock.ExpectQuery(`SELECT \* FROM "posts" WHERE id`).WillReturnError(gorm.ErrRecordNotFound)
}

// expectAccessibilityChecks programme les requetes de filterAccessiblePosts
// pour un unique post (blocked / followed / profils auteurs).
func expectAccessibilityChecks(mock sqlmock.Sqlmock, authorID uuid.UUID, authorPrivate bool, blocked bool, followed bool) {
	blockRows := sqlmock.NewRows([]string{"profile_id"})
	if blocked {
		blockRows.AddRow(authorID)
	}
	mock.ExpectQuery(`FROM "social"\."blocks"`).WillReturnRows(blockRows)

	followRows := sqlmock.NewRows([]string{"followed_id"})
	if followed {
		followRows.AddRow(authorID)
	}
	mock.ExpectQuery(`FROM "social"\."follows"`).WillReturnRows(followRows)

	profileRows := sqlmock.NewRows([]string{"id", "username", "is_private"}).
		AddRow(authorID, "author", authorPrivate)
	mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE id IN`).WillReturnRows(profileRows)
}

func expectEnrichPosts(mock sqlmock.Sqlmock, postIDs []uuid.UUID, authors map[uuid.UUID]models.Profile) {
	// Note : ces tests appellent le service avec context.Background() (aucun
	// compte authentifie dans le contexte), donc viewerProfileID() renvoie
	// systematiquement uuid.Nil sans requete SQL. FindLikedPostIDsByUserID et
	// FindRepostedPostIDsByUserID court-circuitent alors immediatement
	// (userID == uuid.Nil) sans toucher la base : on ne doit donc PAS attendre
	// de requete "is liked" / "is reposted" par l'utilisateur ici.
	likeRows := sqlmock.NewRows([]string{"post_id", "count"})
	mock.ExpectQuery(`FROM "likes" WHERE post_id`).WillReturnRows(likeRows)

	commentRows := sqlmock.NewRows([]string{"post_id", "count"})
	mock.ExpectQuery(`SELECT parent_id AS post_id, COUNT\(\*\) AS count FROM "posts"`).WillReturnRows(commentRows)

	repostCountRows := sqlmock.NewRows([]string{"post_id", "count"})
	mock.ExpectQuery(`SELECT post_id, COUNT\(\*\) AS count FROM "posts"\."reposts"`).WillReturnRows(repostCountRows)

	profileRows := sqlmock.NewRows([]string{"id", "username", "is_private"})
	for id, profile := range authors {
		profileRows.AddRow(id, profile.Username, profile.IsPrivate)
	}
	mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE id IN`).WillReturnRows(profileRows)

	mediaRows := sqlmock.NewRows([]string{"id", "post_id", "media_type", "url"})
	mock.ExpectQuery(`FROM "posts"\."media"`).WillReturnRows(mediaRows)

	pollRows := sqlmock.NewRows([]string{"id", "post_id"})
	mock.ExpectQuery(`FROM "posts"\."polls"`).WillReturnRows(pollRows)

	// FindVotesByPollIDsAndUser et FindBookmarkedPostIDsByUserID court-circuitent
	// eux aussi (userID == uuid.Nil) sans requete SQL puisqu'aucun compte n'est
	// present dans le contexte de ces tests.
}

func TestServiceCreatePostHappyPathTextOnly(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	accountID := uuid.New()
	authorID := uuid.New()

	expectProfileLookupByAccountID(mock, accountID, authorID)
	expectProfileIsPrivate(mock, authorID, false)

	mock.ExpectBegin()
	mock.ExpectQuery(qm(`INSERT INTO "posts"`)).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at", "updated_at"}).
			AddRow(uuid.New(), time.Now(), time.Now()))
	mock.ExpectCommit()

	expectEnrichPosts(mock, nil, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

	// notifyPostInteractions: pas de mot-cle TEST, pas de parent, pas de mention
	// -> aucune requete SQL supplementaire (court-circuit immediat).
	resp, err := service.CreatePost(ctx, accountID, createPostRequest{Content: "hello world", Visibility: "PUBLIC"})
	if err != nil {
		t.Fatalf("CreatePost() unexpected error: %v", err)
	}
	if resp.Content != "hello world" {
		t.Fatalf("CreatePost() content = %q, want %q", resp.Content, "hello world")
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestServiceCreatePostValidationErrors(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()
	accountID := uuid.New()
	authorID := uuid.New()

	t.Run("empty content media and poll", func(t *testing.T) {
		expectProfileLookupByAccountID(mock, accountID, authorID)
		expectProfileIsPrivate(mock, authorID, false)
		if _, err := service.CreatePost(ctx, accountID, createPostRequest{}); !errors.Is(err, ErrInvalidContent) {
			t.Fatalf("CreatePost() error = %v, want ErrInvalidContent", err)
		}
	})

	t.Run("content too long", func(t *testing.T) {
		expectProfileLookupByAccountID(mock, accountID, authorID)
		expectProfileIsPrivate(mock, authorID, false)
		longContent := make([]byte, 281)
		for i := range longContent {
			longContent[i] = 'a'
		}
		if _, err := service.CreatePost(ctx, accountID, createPostRequest{Content: string(longContent)}); !errors.Is(err, ErrContentTooLong) {
			t.Fatalf("CreatePost() error = %v, want ErrContentTooLong", err)
		}
	})

	t.Run("invalid visibility", func(t *testing.T) {
		expectProfileLookupByAccountID(mock, accountID, authorID)
		expectProfileIsPrivate(mock, authorID, false)
		if _, err := service.CreatePost(ctx, accountID, createPostRequest{Content: "hi", Visibility: "FRIENDS"}); !errors.Is(err, ErrInvalidVisibility) {
			t.Fatalf("CreatePost() error = %v, want ErrInvalidVisibility", err)
		}
	})

	t.Run("private profile cannot post public", func(t *testing.T) {
		expectProfileLookupByAccountID(mock, accountID, authorID)
		expectProfileIsPrivate(mock, authorID, true)
		if _, err := service.CreatePost(ctx, accountID, createPostRequest{Content: "hi", Visibility: "PUBLIC"}); !errors.Is(err, ErrPrivateProfilePublicVisibility) {
			t.Fatalf("CreatePost() error = %v, want ErrPrivateProfilePublicVisibility", err)
		}
	})

	t.Run("invalid media", func(t *testing.T) {
		expectProfileLookupByAccountID(mock, accountID, authorID)
		expectProfileIsPrivate(mock, authorID, false)
		if _, err := service.CreatePost(ctx, accountID, createPostRequest{
			Content: "hi",
			Media:   []mediaRequest{{Type: "AUDIO", URL: "/api/media/files/a.mp3"}},
		}); !errors.Is(err, ErrInvalidMedia) {
			t.Fatalf("CreatePost() error = %v, want ErrInvalidMedia", err)
		}
	})

	t.Run("invalid poll", func(t *testing.T) {
		expectProfileLookupByAccountID(mock, accountID, authorID)
		expectProfileIsPrivate(mock, authorID, false)
		if _, err := service.CreatePost(ctx, accountID, createPostRequest{
			Content: "hi",
			Poll:    &createPollRequest{Options: []string{"only one"}},
		}); !errors.Is(err, ErrInvalidPoll) {
			t.Fatalf("CreatePost() error = %v, want ErrInvalidPoll", err)
		}
	})

	t.Run("parent not found", func(t *testing.T) {
		parentID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, authorID)
		expectProfileIsPrivate(mock, authorID, false)
		expectFindPostByIDNotFound(mock)
		if _, err := service.CreatePost(ctx, accountID, createPostRequest{Content: "hi", ParentID: &parentID}); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("CreatePost() error = %v, want gorm.ErrRecordNotFound", err)
		}
	})

	t.Run("author profile not found", func(t *testing.T) {
		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(gorm.ErrRecordNotFound)
		if _, err := service.CreatePost(ctx, accountID, createPostRequest{Content: "hi"}); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("CreatePost() error = %v, want gorm.ErrRecordNotFound", err)
		}
	})

	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestServiceCreatePostWithMediaPollAndTagsTransaction(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()
	accountID := uuid.New()
	authorID := uuid.New()
	postID := uuid.New()
	pollID := uuid.New()
	duration := 2.0

	expectProfileLookupByAccountID(mock, accountID, authorID)
	expectProfileIsPrivate(mock, authorID, false)

	mock.ExpectBegin()
	mock.ExpectQuery(qm(`INSERT INTO "posts"`)).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at", "updated_at"}).
			AddRow(postID, time.Now(), time.Now()))
	mock.ExpectQuery(qm(`INSERT INTO "posts"."media"`)).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at"}).AddRow(uuid.New(), time.Now()))
	mock.ExpectQuery(qm(`INSERT INTO "posts"."polls"`)).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at"}).AddRow(pollID, time.Now()))
	mock.ExpectQuery(qm(`INSERT INTO "posts"."poll_options"`)).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()).AddRow(uuid.New()))
	tagID := uuid.New()
	mock.ExpectQuery(qm(`INSERT INTO "posts"."tags"`)).
		WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(tagID))
	mock.ExpectQuery(`FROM "posts"\."tags" WHERE name IN`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "name"}).AddRow(tagID, "go"))
	mock.ExpectExec(qm(`INSERT INTO "posts"."post_tags"`)).WillReturnResult(sqlmock.NewResult(1, 1))
	mock.ExpectCommit()

	expectEnrichPosts(mock, nil, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})
	mock.ExpectQuery(qm("FROM \"profiles\".\"profiles\"")).WillReturnError(gorm.ErrRecordNotFound)

	req := createPostRequest{
		Content: "vote please #go",
		Media:   []mediaRequest{{Type: "IMAGE", URL: "/api/media/files/a.png"}},
		Poll:    &createPollRequest{Options: []string{"A", "B"}, DurationHours: &duration},
	}

	resp, err := service.CreatePost(ctx, accountID, req)
	if err != nil {
		t.Fatalf("CreatePost() unexpected error: %v", err)
	}
	if resp.ID != postID {
		t.Fatalf("CreatePost() id = %v, want %v", resp.ID, postID)
	}
}

func TestServiceCreatePostTransactionFailureRollsBack(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()
	accountID := uuid.New()
	authorID := uuid.New()

	expectProfileLookupByAccountID(mock, accountID, authorID)
	expectProfileIsPrivate(mock, authorID, false)

	mock.ExpectBegin()
	mock.ExpectQuery(qm(`INSERT INTO "posts"`)).WillReturnError(errors.New("db is down"))
	mock.ExpectRollback()

	if _, err := service.CreatePost(ctx, accountID, createPostRequest{Content: "hello"}); err == nil {
		t.Fatal("CreatePost() expected error on transaction failure")
	}
}

func TestServiceNotifyPostInteractionsPrivatePostSkipsNotifications(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	post := models.Post{ID: uuid.New(), AuthorID: uuid.New(), Content: "secret", Visibility: "PRIVATE"}
	service.notifyPostInteractions(ctx, post)

	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("expected no SQL calls for private post, got: %v", err)
	}
}

func TestServiceNotifyPostInteractionsReplyNotification(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	parentID := uuid.New()
	parentAuthorID := uuid.New()
	authorID := uuid.New()
	post := models.Post{ID: uuid.New(), AuthorID: authorID, Content: "a reply", Visibility: "PUBLIC", ParentID: &parentID}

	// notifyTestCedricIfNeeded : pas de mot TEST -> aucune requete.
	// recherche du post parent.
	parentRows := sqlmock.NewRows([]string{"id", "author_id", "content", "visibility"}).
		AddRow(parentID, parentAuthorID, "parent content", "PUBLIC")
	mock.ExpectQuery(qm(`SELECT * FROM "posts"`)).WillReturnRows(parentRows)

	mock.ExpectBegin()
	mock.ExpectQuery(qm(`INSERT INTO "social"."notifications"`)).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at"}).AddRow(uuid.New(), time.Now()))
	mock.ExpectCommit()

	service.notifyPostInteractions(ctx, post)

	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestServiceNotifyPostInteractionsReplyFollowersVisibilityRequiresFollow(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	parentID := uuid.New()
	parentAuthorID := uuid.New()
	authorID := uuid.New()
	post := models.Post{ID: uuid.New(), AuthorID: authorID, Content: "a reply", Visibility: "FOLLOWERS", ParentID: &parentID}

	parentRows := sqlmock.NewRows([]string{"id", "author_id", "content", "visibility"}).
		AddRow(parentID, parentAuthorID, "parent content", "PUBLIC")
	mock.ExpectQuery(qm(`SELECT * FROM "posts"`)).WillReturnRows(parentRows)

	// Le parent author ne suit pas l'auteur du reply => pas de notif.
	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).WillReturnRows(sqlmock.NewRows([]string{"followed_id"}))

	service.notifyPostInteractions(ctx, post)

	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestServiceNotifyPostInteractionsSkipsSelfReply(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	authorID := uuid.New()
	parentID := uuid.New()
	post := models.Post{ID: uuid.New(), AuthorID: authorID, Content: "self reply", Visibility: "PUBLIC", ParentID: &parentID}

	// Le parent appartient au meme auteur -> pas de notification de reponse.
	parentRows := sqlmock.NewRows([]string{"id", "author_id", "content", "visibility"}).
		AddRow(parentID, authorID, "parent content", "PUBLIC")
	mock.ExpectQuery(qm(`SELECT * FROM "posts"`)).WillReturnRows(parentRows)

	service.notifyPostInteractions(ctx, post)

	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestServiceNotifyPostInteractionsParentLookupErrorIsIgnored(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	parentID := uuid.New()
	post := models.Post{ID: uuid.New(), AuthorID: uuid.New(), Content: "a reply", Visibility: "PUBLIC", ParentID: &parentID}

	mock.ExpectQuery(qm(`SELECT * FROM "posts"`)).WillReturnError(gorm.ErrRecordNotFound)

	service.notifyPostInteractions(ctx, post)

	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestServiceNotifyPostInteractionsMentionNotification(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	authorID := uuid.New()
	mentionedID := uuid.New()
	post := models.Post{ID: uuid.New(), AuthorID: authorID, Content: "hello @bob", Visibility: "PUBLIC"}

	mentionRows := sqlmock.NewRows([]string{"id", "username"}).AddRow(mentionedID, "bob")
	mock.ExpectQuery(qm("SELECT * FROM \"profiles\".\"profiles\" WHERE lower(username) IN")).WillReturnRows(mentionRows)

	mock.ExpectBegin()
	mock.ExpectQuery(qm(`INSERT INTO "social"."notifications"`)).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at"}).AddRow(uuid.New(), time.Now()))
	mock.ExpectCommit()

	service.notifyPostInteractions(ctx, post)

	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestServiceNotifyPostInteractionsMentionSkipsAuthorAndFollowersGate(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	authorID := uuid.New()
	otherMentionedID := uuid.New()
	// Le contenu mentionne l'auteur lui-meme (ignore) et un autre profil non suiveur (FOLLOWERS gate).
	post := models.Post{ID: uuid.New(), AuthorID: authorID, Content: "hello @self @bob", Visibility: "FOLLOWERS"}

	mentionRows := sqlmock.NewRows([]string{"id", "username"}).
		AddRow(authorID, "self").
		AddRow(otherMentionedID, "bob")
	mock.ExpectQuery(qm("SELECT * FROM \"profiles\".\"profiles\" WHERE lower(username) IN")).WillReturnRows(mentionRows)

	// bob ne suit pas l'auteur -> aucune notif pour bob.
	mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).WillReturnRows(sqlmock.NewRows([]string{"followed_id"}))

	service.notifyPostInteractions(ctx, post)

	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestServiceNotifyTestCedricIfNeeded(t *testing.T) {
	t.Run("no TEST keyword skips lookup", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		post := models.Post{ID: uuid.New(), AuthorID: uuid.New(), Content: "hello world", Visibility: "PUBLIC"}
		service.notifyTestCedricIfNeeded(context.Background(), post)
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet SQL expectations: %v", err)
		}
	})

	t.Run("cedric profile missing", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		post := models.Post{ID: uuid.New(), AuthorID: uuid.New(), Content: "this is a TEST", Visibility: "PUBLIC"}
		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "social"."notifications"`)).
			WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectRollback()
		service.notifyTestCedricIfNeeded(context.Background(), post)
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet SQL expectations: %v", err)
		}
	})

	t.Run("cedric is the author skips notification", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		authorID := uuid.New()
		post := models.Post{ID: uuid.New(), AuthorID: authorID, Content: "this is a TEST", Visibility: "PUBLIC"}
		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "social"."notifications"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "created_at"}).AddRow(uuid.New(), time.Now()))
		mock.ExpectCommit()
		service.notifyTestCedricIfNeeded(context.Background(), post)
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet SQL expectations: %v", err)
		}
	})

	t.Run("public post notifies cedric", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		post := models.Post{ID: uuid.New(), AuthorID: uuid.New(), Content: "this is a TEST", Visibility: "PUBLIC"}
		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "social"."notifications"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "created_at"}).AddRow(uuid.New(), time.Now()))
		mock.ExpectCommit()
		service.notifyTestCedricIfNeeded(context.Background(), post)
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet SQL expectations: %v", err)
		}
	})

	t.Run("followers post requires cedric to follow author", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		post := models.Post{ID: uuid.New(), AuthorID: uuid.New(), Content: "this is a TEST", Visibility: "FOLLOWERS"}
		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "social"."notifications"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "created_at"}).AddRow(uuid.New(), time.Now()))
		mock.ExpectCommit()
		service.notifyTestCedricIfNeeded(context.Background(), post)
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet SQL expectations: %v", err)
		}
	})
}

func TestServiceMentionedProfiles(t *testing.T) {
	t.Run("no mentions returns nil without query", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		got := service.mentionedProfiles(context.Background(), "no mentions here")
		if got != nil {
			t.Fatalf("mentionedProfiles() = %+v, want nil", got)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet SQL expectations: %v", err)
		}
	})

	t.Run("resolves mentioned profiles", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		bobID := uuid.New()
		rows := sqlmock.NewRows([]string{"id", "username"}).AddRow(bobID, "bob")
		mock.ExpectQuery(qm("SELECT * FROM \"profiles\".\"profiles\" WHERE lower(username) IN")).WillReturnRows(rows)
		got := service.mentionedProfiles(context.Background(), "hi @bob")
		if len(got) != 1 || got[0].ID != bobID {
			t.Fatalf("mentionedProfiles() = %+v, want bob", got)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet SQL expectations: %v", err)
		}
	})

	t.Run("repository error returns nil", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(qm("SELECT * FROM \"profiles\".\"profiles\" WHERE lower(username) IN")).WillReturnError(errors.New("boom"))
		got := service.mentionedProfiles(context.Background(), "hi @bob")
		if got != nil {
			t.Fatalf("mentionedProfiles() = %+v, want nil on error", got)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet SQL expectations: %v", err)
		}
	})
}

func TestServiceMapPostsToResponse(t *testing.T) {
	postID := uuid.New()
	authorID := uuid.New()
	pollID := uuid.New()
	optionID := uuid.New()
	displayName := "Alice A"
	avatar := "https://x/a.png"

	authors := map[uuid.UUID]models.Profile{
		authorID: {ID: authorID, Username: "alice", DisplayName: &displayName, AvatarURL: &avatar},
	}
	likes := map[uuid.UUID]int64{postID: 3}
	comments := map[uuid.UUID]int64{postID: 1}
	reposts := map[uuid.UUID]int64{postID: 2}
	liked := map[uuid.UUID]bool{postID: true}
	repostedMap := map[uuid.UUID]bool{postID: true}
	bookmarked := map[uuid.UUID]bool{postID: true}
	mediaByPostID := map[uuid.UUID][]models.Media{postID: {{ID: uuid.New(), PostID: postID, MediaType: "IMAGE", URL: "/api/media/files/a.png"}}}
	poll := models.Poll{ID: pollID, Options: []models.PollOption{{ID: optionID, Text: "A", VoteCount: 1}}}
	pollsByPostID := map[uuid.UUID]models.Poll{postID: poll}
	votesByPollID := map[uuid.UUID]models.PollVote{pollID: {ID: uuid.New(), PollID: pollID, OptionID: optionID}}

	posts := []models.Post{{ID: postID, AuthorID: authorID, Content: "hi", Visibility: "PUBLIC"}}

	result := mapPostsToResponse(posts, authors, likes, comments, reposts, liked, repostedMap, bookmarked, mediaByPostID, pollsByPostID, votesByPollID)
	if len(result) != 1 {
		t.Fatalf("mapPostsToResponse() len = %d, want 1", len(result))
	}
	got := result[0]
	if got.Author.DisplayName != displayName {
		t.Fatalf("mapPostsToResponse() author display name = %q, want %q", got.Author.DisplayName, displayName)
	}
	if got.LikesCount != 3 || got.CommentsCount != 1 || got.RepostCount != 2 {
		t.Fatalf("mapPostsToResponse() counts = %+v, want 3/1/2", got)
	}
	if !got.IsLiked || !got.IsReposted || !got.IsBookmarked {
		t.Fatalf("mapPostsToResponse() flags = %+v, want all true", got)
	}
	if !got.HasMedia || len(got.Media) != 1 {
		t.Fatalf("mapPostsToResponse() media = %+v, want one item", got.Media)
	}
	if got.Poll == nil || !got.Poll.HasVoted || got.Poll.VotedOptionID == nil || *got.Poll.VotedOptionID != optionID {
		t.Fatalf("mapPostsToResponse() poll = %+v, want voted option %v", got.Poll, optionID)
	}

	t.Run("empty input returns empty slice", func(t *testing.T) {
		empty := mapPostsToResponse(nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil)
		if empty == nil || len(empty) != 0 {
			t.Fatalf("mapPostsToResponse(empty) = %#v, want empty slice", empty)
		}
	})

	t.Run("unknown author falls back to id only", func(t *testing.T) {
		unknownAuthor := uuid.New()
		unknownPost := uuid.New()
		result := mapPostsToResponse([]models.Post{{ID: unknownPost, AuthorID: unknownAuthor, Visibility: "PUBLIC"}},
			map[uuid.UUID]models.Profile{}, nil, nil, nil, nil, nil, nil, nil, nil, nil)
		if len(result) != 1 || result[0].Author.ID != unknownAuthor || result[0].Author.Username != "" {
			t.Fatalf("mapPostsToResponse(unknown author) = %+v", result)
		}
	})

	t.Run("author with blank display name falls back to username", func(t *testing.T) {
		blank := "   "
		authorID2 := uuid.New()
		post2 := uuid.New()
		result := mapPostsToResponse([]models.Post{{ID: post2, AuthorID: authorID2, Visibility: "PUBLIC"}},
			map[uuid.UUID]models.Profile{authorID2: {ID: authorID2, Username: "carol", DisplayName: &blank}},
			nil, nil, nil, nil, nil, nil, nil, nil, nil)
		if result[0].Author.DisplayName != "carol" {
			t.Fatalf("mapPostsToResponse(blank display name) = %q, want carol", result[0].Author.DisplayName)
		}
	})
}

func TestServiceGetPostByID(t *testing.T) {
	t.Run("not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		expectFindPostByIDNotFound(mock)
		if _, err := service.GetPostByID(context.Background(), uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("GetPostByID() error = %v, want gorm.ErrRecordNotFound", err)
		}
	})

	t.Run("private profile blocks access", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		authorID := uuid.New()
		post := models.Post{ID: uuid.New(), AuthorID: authorID, Visibility: "PUBLIC", Content: "hi"}
		expectFindPostByID(mock, post)
		expectAccessibilityChecks(mock, authorID, true, false, false)
		if _, err := service.GetPostByID(context.Background(), post.ID); !errors.Is(err, ErrPrivateProfile) {
			t.Fatalf("GetPostByID() error = %v, want ErrPrivateProfile", err)
		}
	})

	t.Run("happy path enriches post", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		authorID := uuid.New()
		post := models.Post{ID: uuid.New(), AuthorID: authorID, Visibility: "PUBLIC", Content: "hi"}
		expectFindPostByID(mock, post)
		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{post.ID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})
		got, err := service.GetPostByID(context.Background(), post.ID)
		if err != nil {
			t.Fatalf("GetPostByID() unexpected error: %v", err)
		}
		if got.ID != post.ID {
			t.Fatalf("GetPostByID() id = %v, want %v", got.ID, post.ID)
		}
	})
}

func TestServiceGetRepliesByParentID(t *testing.T) {
	t.Run("parent not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		expectFindPostByIDNotFound(mock)
		if _, err := service.GetRepliesByParentID(context.Background(), uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("GetRepliesByParentID() error = %v, want not found", err)
		}
	})

	t.Run("parent private blocks access", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		authorID := uuid.New()
		parent := models.Post{ID: uuid.New(), AuthorID: authorID, Visibility: "PUBLIC", Content: "hi"}
		expectFindPostByID(mock, parent)
		expectAccessibilityChecks(mock, authorID, true, false, false)
		if _, err := service.GetRepliesByParentID(context.Background(), parent.ID); !errors.Is(err, ErrPrivateProfile) {
			t.Fatalf("GetRepliesByParentID() error = %v, want ErrPrivateProfile", err)
		}
	})

	t.Run("happy path returns enriched replies", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		authorID := uuid.New()
		parent := models.Post{ID: uuid.New(), AuthorID: authorID, Visibility: "PUBLIC", Content: "hi"}
		replyID := uuid.New()
		expectFindPostByID(mock, parent)
		expectAccessibilityChecks(mock, authorID, false, false, false)

		replyRows := sqlmock.NewRows([]string{"id", "author_id", "parent_id", "visibility", "content"}).
			AddRow(replyID, authorID, parent.ID, "PUBLIC", "a reply")
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE parent_id IN`).WillReturnRows(replyRows)
		// FindRepliesByParentID boucle ensuite sur les enfants du reply trouve
		// (recherche multi-niveaux) : il faut programmer ce deuxieme appel, qui
		// ne renvoie aucune sous-reponse pour arreter la recursion.
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE parent_id IN`).
			WillReturnRows(sqlmock.NewRows([]string{"id", "author_id", "parent_id", "visibility", "content"}))

		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{replyID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		got, err := service.GetRepliesByParentID(context.Background(), parent.ID)
		if err != nil {
			t.Fatalf("GetRepliesByParentID() unexpected error: %v", err)
		}
		if len(got) != 1 || got[0].ID != replyID {
			t.Fatalf("GetRepliesByParentID() = %+v, want one reply", got)
		}
	})
}

func TestServiceVotePoll(t *testing.T) {
	ctx := context.Background()

	t.Run("voter profile not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(gorm.ErrRecordNotFound)
		if _, err := service.VotePoll(ctx, uuid.New(), uuid.New(), uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("VotePoll() error = %v, want not found", err)
		}
	})

	t.Run("poll closed", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		voterID := uuid.New()
		postID := uuid.New()
		pollID := uuid.New()
		closedAt := time.Now()

		expectProfileLookupByAccountID(mock, accountID, voterID)
		pollRows := sqlmock.NewRows([]string{"id", "post_id", "closed_at"}).AddRow(pollID, postID, closedAt)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id"}))

		if _, err := service.VotePoll(ctx, accountID, postID, uuid.New()); !errors.Is(err, ErrPollClosed) {
			t.Fatalf("VotePoll() error = %v, want ErrPollClosed", err)
		}
	})

	t.Run("already voted", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		voterID := uuid.New()
		postID := uuid.New()
		pollID := uuid.New()

		expectProfileLookupByAccountID(mock, accountID, voterID)
		pollRows := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id"}))

		voteRows := sqlmock.NewRows([]string{"id", "poll_id", "user_id"}).AddRow(uuid.New(), pollID, voterID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnRows(voteRows)

		if _, err := service.VotePoll(ctx, accountID, postID, uuid.New()); !errors.Is(err, ErrAlreadyVoted) {
			t.Fatalf("VotePoll() error = %v, want ErrAlreadyVoted", err)
		}
	})

	t.Run("invalid option", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		voterID := uuid.New()
		postID := uuid.New()
		pollID := uuid.New()
		optionID := uuid.New()

		expectProfileLookupByAccountID(mock, accountID, voterID)
		pollRows := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		optionRows := sqlmock.NewRows([]string{"id", "poll_id"}).AddRow(optionID, pollID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(optionRows)

		mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnError(gorm.ErrRecordNotFound)

		if _, err := service.VotePoll(ctx, accountID, postID, uuid.New()); !errors.Is(err, ErrInvalidPoll) {
			t.Fatalf("VotePoll() error = %v, want ErrInvalidPoll", err)
		}
	})

	t.Run("happy path", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		voterID := uuid.New()
		postID := uuid.New()
		pollID := uuid.New()
		optionID := uuid.New()

		expectProfileLookupByAccountID(mock, accountID, voterID)
		pollRows := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		optionRows := sqlmock.NewRows([]string{"id", "poll_id"}).AddRow(optionID, pollID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(optionRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnError(gorm.ErrRecordNotFound)

		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "posts"."poll_votes"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "created_at"}).AddRow(uuid.New(), time.Now()))
		mock.ExpectExec(qm(`UPDATE "posts"."poll_options"`)).WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()

		pollRows2 := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows2)
		optionRows2 := sqlmock.NewRows([]string{"id", "poll_id"}).AddRow(optionID, pollID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(optionRows2)

		finalVoteRows := sqlmock.NewRows([]string{"id", "poll_id", "option_id", "user_id"}).AddRow(uuid.New(), pollID, optionID, voterID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnRows(finalVoteRows)

		got, err := service.VotePoll(ctx, accountID, postID, optionID)
		if err != nil {
			t.Fatalf("VotePoll() unexpected error: %v", err)
		}
		if !got.HasVoted || got.VotedOptionID == nil || *got.VotedOptionID != optionID {
			t.Fatalf("VotePoll() = %+v, want voted on %v", got, optionID)
		}
	})
}

func TestServiceClosePoll(t *testing.T) {
	ctx := context.Background()

	t.Run("forbidden when not author", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		authorID := uuid.New()
		otherAuthorID := uuid.New()
		postID := uuid.New()

		expectProfileLookupByAccountID(mock, accountID, authorID)
		post := models.Post{ID: postID, AuthorID: otherAuthorID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)

		if _, err := service.ClosePoll(ctx, accountID, postID); !errors.Is(err, ErrForbiddenPoll) {
			t.Fatalf("ClosePoll() error = %v, want ErrForbiddenPoll", err)
		}
	})

	t.Run("already closed", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		authorID := uuid.New()
		postID := uuid.New()
		pollID := uuid.New()
		closedAt := time.Now()

		expectProfileLookupByAccountID(mock, accountID, authorID)
		post := models.Post{ID: postID, AuthorID: authorID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)

		pollRows := sqlmock.NewRows([]string{"id", "post_id", "closed_at"}).AddRow(pollID, postID, closedAt)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id"}))

		if _, err := service.ClosePoll(ctx, accountID, postID); !errors.Is(err, ErrPollClosed) {
			t.Fatalf("ClosePoll() error = %v, want ErrPollClosed", err)
		}
	})

	t.Run("happy path closes poll", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		authorID := uuid.New()
		postID := uuid.New()
		pollID := uuid.New()

		expectProfileLookupByAccountID(mock, accountID, authorID)
		post := models.Post{ID: postID, AuthorID: authorID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)

		pollRows := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
		mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_options\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id"}))

		mock.ExpectBegin()
		mock.ExpectExec(qm(`UPDATE "posts"."polls"`)).WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()

		expectProfileLookupByAccountID(mock, accountID, authorID)
		mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnError(gorm.ErrRecordNotFound)

		got, err := service.ClosePoll(ctx, accountID, postID)
		if err != nil {
			t.Fatalf("ClosePoll() unexpected error: %v", err)
		}
		if !got.IsClosed {
			t.Fatalf("ClosePoll() = %+v, want closed poll", got)
		}
	})
}

func TestServiceGetFollowingPosts(t *testing.T) {
	ctx := context.Background()

	t.Run("profile not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(gorm.ErrRecordNotFound)
		if _, err := service.GetFollowingPosts(ctx, uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("GetFollowingPosts() error = %v, want not found", err)
		}
	})

	t.Run("no followed profiles returns empty", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		mock.ExpectQuery(`SELECT followed_id FROM "social"\."follows"`).WillReturnRows(sqlmock.NewRows([]string{"followed_id"}))

		got, err := service.GetFollowingPosts(ctx, accountID)
		if err != nil {
			t.Fatalf("GetFollowingPosts() unexpected error: %v", err)
		}
		if len(got) != 0 {
			t.Fatalf("GetFollowingPosts() = %+v, want empty", got)
		}
	})
}

func TestServiceEnrichFeedPostsWithReposterAndPoll(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	postID := uuid.New()
	authorID := uuid.New()
	reposterID := uuid.New()
	pollID := uuid.New()
	optionID := uuid.New()

	feedPosts := []FeedPost{
		{Post: models.Post{ID: postID, AuthorID: authorID, Content: "hi", Visibility: "PUBLIC"}, ReposterID: &reposterID},
	}

	mock.ExpectQuery(qm(`FROM "likes"`)).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
	mock.ExpectQuery(qm(`SELECT parent_id AS post_id, COUNT(*) AS count FROM "posts"`)).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
	mock.ExpectQuery(qm("SELECT post_id FROM posts.likes")).WillReturnRows(sqlmock.NewRows([]string{"post_id"}))
	mock.ExpectQuery(qm("FROM \"posts\".\"reposts\"")).WillReturnRows(sqlmock.NewRows([]string{"post_id", "count"}))
	mock.ExpectQuery(qm("SELECT post_id FROM posts.reposts")).WillReturnRows(sqlmock.NewRows([]string{"post_id"}))

	profileRows := sqlmock.NewRows([]string{"id", "username"}).
		AddRow(authorID, "alice").
		AddRow(reposterID, "bob")
	mock.ExpectQuery(qm(`SELECT * FROM "profiles"`)).WillReturnRows(profileRows)

	mock.ExpectQuery(qm("FROM \"posts\".\"media\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "post_id", "media_type", "url"}))

	pollRows := sqlmock.NewRows([]string{"id", "post_id"}).AddRow(pollID, postID)
	mock.ExpectQuery(qm("FROM \"posts\".\"polls\"")).WillReturnRows(pollRows)
	// FindPollsByPostIDs charge ensuite les options du sondage trouve via une
	// deuxieme requete sur "posts"."poll_options".
	mock.ExpectQuery(qm(`SELECT * FROM "posts"."poll_options" WHERE poll_id IN`)).
		WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id", "text", "position", "vote_count"}))

	mock.ExpectQuery(qm("FROM \"posts\".\"poll_votes\"")).WillReturnRows(sqlmock.NewRows([]string{"id", "poll_id", "option_id", "user_id"}))
	mock.ExpectQuery(qm("FROM \"posts\".\"bookmarks\"")).WillReturnRows(sqlmock.NewRows([]string{"post_id"}))

	_ = optionID
	got, err := service.enrichFeedPosts(ctx, feedPosts)
	if err != nil {
		t.Fatalf("enrichFeedPosts() unexpected error: %v", err)
	}
	if len(got) != 1 {
		t.Fatalf("enrichFeedPosts() len = %d, want 1", len(got))
	}
	if got[0].RepostedBy == nil || got[0].RepostedBy.Username != "bob" {
		t.Fatalf("enrichFeedPosts() repostedBy = %+v, want bob", got[0].RepostedBy)
	}
	if got[0].Poll == nil || got[0].Poll.ID != pollID {
		t.Fatalf("enrichFeedPosts() poll = %+v, want poll %v", got[0].Poll, pollID)
	}
}

func TestServiceEnrichFeedPostsEmptyReturnsEmptySlice(t *testing.T) {
	db, _ := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	got, err := service.enrichFeedPosts(context.Background(), nil)
	if err != nil || len(got) != 0 {
		t.Fatalf("enrichFeedPosts(nil) = %+v, %v, want empty slice", got, err)
	}
}

func TestServiceBookmarkPost(t *testing.T) {
	ctx := context.Background()

	t.Run("profile not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(gorm.ErrRecordNotFound)
		if err := service.BookmarkPost(ctx, uuid.New(), uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("BookmarkPost() error = %v, want not found", err)
		}
	})

	t.Run("post not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		expectFindPostByIDNotFound(mock)
		if err := service.BookmarkPost(ctx, accountID, uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("BookmarkPost() error = %v, want not found", err)
		}
	})

	t.Run("happy path creates bookmark", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "posts"."bookmarks"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectCommit()
		if err := service.BookmarkPost(ctx, accountID, postID); err != nil {
			t.Fatalf("BookmarkPost() unexpected error: %v", err)
		}
	})
}

func TestServiceUnbookmarkPost(t *testing.T) {
	ctx := context.Background()

	t.Run("profile not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(gorm.ErrRecordNotFound)
		if err := service.UnbookmarkPost(ctx, uuid.New(), uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("UnbookmarkPost() error = %v, want not found", err)
		}
	})

	t.Run("bookmark not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."bookmarks"`)).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectCommit()
		if err := service.UnbookmarkPost(ctx, accountID, uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("UnbookmarkPost() error = %v, want not found", err)
		}
	})

	t.Run("happy path removes bookmark", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."bookmarks"`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		if err := service.UnbookmarkPost(ctx, accountID, uuid.New()); err != nil {
			t.Fatalf("UnbookmarkPost() unexpected error: %v", err)
		}
	})
}

func TestServiceGetBookmarkedPosts(t *testing.T) {
	ctx := context.Background()

	t.Run("profile not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(gorm.ErrRecordNotFound)
		if _, err := service.GetBookmarkedPosts(ctx, uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("GetBookmarkedPosts() error = %v, want not found", err)
		}
	})

	t.Run("happy path returns enriched bookmarks", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		authorID := uuid.New()

		expectProfileLookupByAccountID(mock, accountID, profileID)
		postRows := sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}).
			AddRow(postID, authorID, "PUBLIC", "hi")
		mock.ExpectQuery(`SELECT p\.\* FROM posts\.posts AS p`).WillReturnRows(postRows)

		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		got, err := service.GetBookmarkedPosts(ctx, accountID)
		if err != nil {
			t.Fatalf("GetBookmarkedPosts() unexpected error: %v", err)
		}
		if len(got) != 1 || got[0].ID != postID {
			t.Fatalf("GetBookmarkedPosts() = %+v, want one bookmark", got)
		}
	})
}

func TestServiceDeletePost(t *testing.T) {
	ctx := context.Background()

	t.Run("profile not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(gorm.ErrRecordNotFound)
		if err := service.DeletePost(ctx, uuid.New(), uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("DeletePost() error = %v, want not found", err)
		}
	})

	t.Run("post not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		mock.ExpectQuery(`SELECT role FROM "auth"\."accounts"`).WillReturnRows(sqlmock.NewRows([]string{"role"}).AddRow("USER"))
		expectFindPostByIDNotFound(mock)
		if err := service.DeletePost(ctx, accountID, uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("DeletePost() error = %v, want not found", err)
		}
	})

	t.Run("forbidden for non author non moderator", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		otherAuthorID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		mock.ExpectQuery(`SELECT role FROM "auth"\."accounts"`).WillReturnRows(sqlmock.NewRows([]string{"role"}).AddRow("USER"))
		post := models.Post{ID: postID, AuthorID: otherAuthorID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		if err := service.DeletePost(ctx, accountID, postID); !errors.Is(err, ErrForbiddenPost) {
			t.Fatalf("DeletePost() error = %v, want ErrForbiddenPost", err)
		}
	})

	t.Run("moderator can delete others post", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		otherAuthorID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		mock.ExpectQuery(`SELECT role FROM "auth"\."accounts"`).WillReturnRows(sqlmock.NewRows([]string{"role"}).AddRow("MODERATOR"))
		post := models.Post{ID: postID, AuthorID: otherAuthorID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`UPDATE "posts"."posts" SET`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		if err := service.DeletePost(ctx, accountID, postID); err != nil {
			t.Fatalf("DeletePost() unexpected error: %v", err)
		}
	})

	t.Run("author deletes own post", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		mock.ExpectQuery(`SELECT role FROM "auth"\."accounts"`).WillReturnRows(sqlmock.NewRows([]string{"role"}).AddRow("USER"))
		post := models.Post{ID: postID, AuthorID: profileID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`UPDATE "posts"."posts" SET`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		if err := service.DeletePost(ctx, accountID, postID); err != nil {
			t.Fatalf("DeletePost() unexpected error: %v", err)
		}
	})
}

func TestServiceUpdatePostVisibility(t *testing.T) {
	ctx := context.Background()

	t.Run("profile not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(gorm.ErrRecordNotFound)
		if _, err := service.UpdatePostVisibility(ctx, uuid.New(), uuid.New(), "PUBLIC"); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("UpdatePostVisibility() error = %v, want not found", err)
		}
	})

	t.Run("forbidden when not author", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		otherAuthorID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: otherAuthorID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		if _, err := service.UpdatePostVisibility(ctx, accountID, postID, "PRIVATE"); !errors.Is(err, ErrForbiddenPost) {
			t.Fatalf("UpdatePostVisibility() error = %v, want ErrForbiddenPost", err)
		}
	})

	t.Run("invalid visibility", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: profileID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		if _, err := service.UpdatePostVisibility(ctx, accountID, postID, "FRIENDS"); !errors.Is(err, ErrInvalidVisibility) {
			t.Fatalf("UpdatePostVisibility() error = %v, want ErrInvalidVisibility", err)
		}
	})

	t.Run("private profile cannot go public", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: profileID, Visibility: "FOLLOWERS"}
		expectFindPostByID(mock, post)
		expectProfileIsPrivate(mock, profileID, true)
		if _, err := service.UpdatePostVisibility(ctx, accountID, postID, "PUBLIC"); !errors.Is(err, ErrPrivateProfilePublicVisibility) {
			t.Fatalf("UpdatePostVisibility() error = %v, want ErrPrivateProfilePublicVisibility", err)
		}
	})

	t.Run("happy path updates and enriches", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: profileID, Visibility: "FOLLOWERS"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`UPDATE "posts" SET "visibility"`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{profileID: {ID: profileID, Username: "alice"}})
		got, err := service.UpdatePostVisibility(ctx, accountID, postID, "PRIVATE")
		if err != nil {
			t.Fatalf("UpdatePostVisibility() unexpected error: %v", err)
		}
		if got.Visibility != "PRIVATE" {
			t.Fatalf("UpdatePostVisibility() visibility = %q, want PRIVATE", got.Visibility)
		}
	})
}

func TestServiceLikePost(t *testing.T) {
	ctx := context.Background()

	t.Run("profile not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		mock.ExpectQuery(`SELECT id FROM "profiles"\."profiles" WHERE account_id`).WillReturnError(gorm.ErrRecordNotFound)
		if err := service.LikePost(ctx, uuid.New(), uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("LikePost() error = %v, want not found", err)
		}
	})

	t.Run("post not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		expectFindPostByIDNotFound(mock)
		if err := service.LikePost(ctx, accountID, uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("LikePost() error = %v, want not found", err)
		}
	})

	t.Run("already liked is a no-op", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		likeRows := sqlmock.NewRows([]string{"id", "post_id", "user_id"}).AddRow(uuid.New(), postID, profileID)
		mock.ExpectQuery(qm(`SELECT * FROM "posts"."likes"`)).WillReturnRows(likeRows)
		if err := service.LikePost(ctx, accountID, postID); err != nil {
			t.Fatalf("LikePost() unexpected error: %v", err)
		}
	})

	t.Run("happy path notifies author", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		authorID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: authorID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectQuery(qm(`SELECT * FROM "posts"."likes"`)).WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "posts"."likes"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectCommit()
		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "social"."notifications"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "created_at"}).AddRow(uuid.New(), time.Now()))
		mock.ExpectCommit()
		if err := service.LikePost(ctx, accountID, postID); err != nil {
			t.Fatalf("LikePost() unexpected error: %v", err)
		}
	})

	t.Run("liking own post skips notification", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: profileID, Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectQuery(qm(`SELECT * FROM "posts"."likes"`)).WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "posts"."likes"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectCommit()
		if err := service.LikePost(ctx, accountID, postID); err != nil {
			t.Fatalf("LikePost() unexpected error: %v", err)
		}
	})
}

func TestServiceUnlikePost(t *testing.T) {
	ctx := context.Background()

	t.Run("post not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		expectFindPostByIDNotFound(mock)
		if err := service.UnlikePost(ctx, accountID, uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("UnlikePost() error = %v, want not found", err)
		}
	})

	t.Run("happy path removes like", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."likes"`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		if err := service.UnlikePost(ctx, accountID, postID); err != nil {
			t.Fatalf("UnlikePost() unexpected error: %v", err)
		}
	})

	t.Run("like not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."likes"`)).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectCommit()
		if err := service.UnlikePost(ctx, accountID, postID); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("UnlikePost() error = %v, want not found", err)
		}
	})
}

func TestServiceRepost(t *testing.T) {
	ctx := context.Background()

	t.Run("post not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		expectFindPostByIDNotFound(mock)
		if err := service.Repost(ctx, accountID, uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("Repost() error = %v, want not found", err)
		}
	})

	t.Run("already reposted is a no-op", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		repostRows := sqlmock.NewRows([]string{"id", "post_id", "user_id"}).AddRow(uuid.New(), postID, profileID)
		mock.ExpectQuery(qm(`SELECT * FROM "posts"."reposts"`)).WillReturnRows(repostRows)
		if err := service.Repost(ctx, accountID, postID); err != nil {
			t.Fatalf("Repost() unexpected error: %v", err)
		}
	})

	t.Run("happy path creates repost", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectQuery(qm(`SELECT * FROM "posts"."reposts"`)).WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectBegin()
		mock.ExpectQuery(qm(`INSERT INTO "posts"."reposts"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectCommit()
		if err := service.Repost(ctx, accountID, postID); err != nil {
			t.Fatalf("Repost() unexpected error: %v", err)
		}
	})
}

func TestServiceUnrepost(t *testing.T) {
	ctx := context.Background()

	t.Run("post not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		expectFindPostByIDNotFound(mock)
		if err := service.Unrepost(ctx, accountID, uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("Unrepost() error = %v, want not found", err)
		}
	})

	t.Run("happy path removes repost", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."reposts"`)).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		if err := service.Unrepost(ctx, accountID, postID); err != nil {
			t.Fatalf("Unrepost() unexpected error: %v", err)
		}
	})

	t.Run("repost not found", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		accountID := uuid.New()
		profileID := uuid.New()
		postID := uuid.New()
		expectProfileLookupByAccountID(mock, accountID, profileID)
		post := models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"}
		expectFindPostByID(mock, post)
		mock.ExpectBegin()
		mock.ExpectExec(qm(`DELETE FROM "posts"."reposts"`)).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectCommit()
		if err := service.Unrepost(ctx, accountID, postID); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("Unrepost() error = %v, want not found", err)
		}
	})
}

func TestServiceViewerProfileIDWithoutContextAccount(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	got := viewerProfileID(context.Background(), repo)
	if got != uuid.Nil {
		t.Fatalf("viewerProfileID() = %v, want uuid.Nil when no account in context", got)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unexpected SQL calls without account in context: %v", err)
	}
}

func TestServiceFilterAccessibleFeedPostsEmptyShortCircuits(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	got, err := service.filterAccessibleFeedPosts(context.Background(), nil)
	if err != nil || len(got) != 0 {
		t.Fatalf("filterAccessibleFeedPosts(nil) = %+v, %v, want empty", got, err)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unexpected SQL calls: %v", err)
	}
}

// TestServiceFilterAccessibleFeedPostsKeepsAllowedAndDropsBlocked couvre le
// chemin non trivial de filterAccessibleFeedPosts (jusqu'ici uniquement
// exerce sur l'entree vide), en verifiant qu'un FeedPost reste present quand
// l'auteur est public et non bloque.
func TestServiceFilterAccessibleFeedPostsKeepsAllowedAndDropsBlocked(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	authorID := uuid.New()
	postID := uuid.New()
	feedPosts := []FeedPost{
		{Post: models.Post{ID: postID, AuthorID: authorID, Visibility: "PUBLIC"}},
	}

	expectAccessibilityChecks(mock, authorID, false, false, false)

	got, err := service.filterAccessibleFeedPosts(ctx, feedPosts)
	if err != nil {
		t.Fatalf("filterAccessibleFeedPosts() unexpected error: %v", err)
	}
	if len(got) != 1 || got[0].ID != postID {
		t.Fatalf("filterAccessibleFeedPosts() = %+v, want one allowed feed post", got)
	}
}

func TestServiceGetRepostsByAuthor(t *testing.T) {
	ctx := context.Background()

	t.Run("empty username is rejected", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		if _, err := service.GetRepostsByAuthor(ctx, "   "); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("GetRepostsByAuthor() error = %v, want not found", err)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unexpected SQL calls for blank username: %v", err)
		}
	})

	t.Run("private profile is rejected", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		profileRows := sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
			AddRow(uuid.New(), uuid.New(), "alice", true)
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(profileRows)
		if _, err := service.GetRepostsByAuthor(ctx, "alice"); !errors.Is(err, ErrPrivateProfile) {
			t.Fatalf("GetRepostsByAuthor() error = %v, want ErrPrivateProfile", err)
		}
	})

	t.Run("happy path returns enriched reposts", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		authorID := uuid.New()
		postID := uuid.New()

		// CanViewProfileContent puis FindRepostsByAuthorUsername interrogent chacun
		// le profil par username : deux requetes identiques a programmer.
		newProfileRows := func() *sqlmock.Rows {
			return sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
				AddRow(authorID, uuid.New(), "alice", false)
		}
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())

		repostRows := sqlmock.NewRows([]string{"id", "author_id", "visibility", "content", "reposter_id"}).
			AddRow(postID, authorID, "PUBLIC", "hi", authorID)
		mock.ExpectQuery(`FROM posts\.posts AS p`).WillReturnRows(repostRows)

		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		got, err := service.GetRepostsByAuthor(ctx, "alice")
		if err != nil {
			t.Fatalf("GetRepostsByAuthor() unexpected error: %v", err)
		}
		if len(got) != 1 || got[0].ID != postID {
			t.Fatalf("GetRepostsByAuthor() = %+v, want one repost", got)
		}
	})
}

func TestServiceGetPostsByAuthor(t *testing.T) {
	ctx := context.Background()

	t.Run("happy path returns enriched posts", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		authorID := uuid.New()
		postID := uuid.New()

		newProfileRows := func() *sqlmock.Rows {
			return sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
				AddRow(authorID, uuid.New(), "alice", false)
		}
		// CanViewProfileContent puis FindPostsByAuthorUsername interrogent chacun
		// le profil par username.
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())

		postRows := sqlmock.NewRows([]string{"id", "author_id", "visibility", "content"}).
			AddRow(postID, authorID, "PUBLIC", "hi")
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id`).WillReturnRows(postRows)

		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		got, err := service.GetPostsByAuthor(ctx, "alice")
		if err != nil {
			t.Fatalf("GetPostsByAuthor() unexpected error: %v", err)
		}
		if len(got) != 1 || got[0].ID != postID {
			t.Fatalf("GetPostsByAuthor() = %+v, want one post", got)
		}
	})
}

func TestServiceGetRepliesByAuthor(t *testing.T) {
	ctx := context.Background()

	t.Run("happy path returns enriched replies", func(t *testing.T) {
		db, mock := newPostMockDB(t)
		repo := NewRepository(db)
		service := NewService(repo)
		authorID := uuid.New()
		postID := uuid.New()

		newProfileRows := func() *sqlmock.Rows {
			return sqlmock.NewRows([]string{"id", "account_id", "username", "is_private"}).
				AddRow(authorID, uuid.New(), "alice", false)
		}
		// CanViewProfileContent puis FindRepliesByAuthorUsername interrogent chacun
		// le profil par username.
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())
		mock.ExpectQuery(`FROM "profiles"\."profiles" WHERE lower\(username\)`).WillReturnRows(newProfileRows())

		replyRows := sqlmock.NewRows([]string{"id", "author_id", "parent_id", "visibility", "content"}).
			AddRow(postID, authorID, uuid.New(), "PUBLIC", "a reply")
		mock.ExpectQuery(`SELECT \* FROM "posts" WHERE author_id`).WillReturnRows(replyRows)

		expectAccessibilityChecks(mock, authorID, false, false, false)
		expectEnrichPosts(mock, []uuid.UUID{postID}, map[uuid.UUID]models.Profile{authorID: {ID: authorID, Username: "alice"}})

		got, err := service.GetRepliesByAuthor(ctx, "alice")
		if err != nil {
			t.Fatalf("GetRepliesByAuthor() unexpected error: %v", err)
		}
		if len(got) != 1 || got[0].ID != postID {
			t.Fatalf("GetRepliesByAuthor() = %+v, want one reply", got)
		}
	})
}

// TestServiceCanViewPostMethod couvre la methode Service.canViewPost
// (distincte de la fonction libre canViewPost deja testee), qui delegue a
// filterAccessiblePosts et n'etait jusqu'ici exercee qu'en dry-run.
func TestServiceCanViewPostMethod(t *testing.T) {
	db, mock := newPostMockDB(t)
	repo := NewRepository(db)
	service := NewService(repo)
	ctx := context.Background()

	authorID := uuid.New()
	post := models.Post{ID: uuid.New(), AuthorID: authorID, Visibility: "PUBLIC"}
	expectAccessibilityChecks(mock, authorID, false, false, false)

	got, err := service.canViewPost(ctx, post)
	if err != nil {
		t.Fatalf("canViewPost() unexpected error: %v", err)
	}
	if !got {
		t.Fatalf("canViewPost() = %v, want true for public post", got)
	}
}
