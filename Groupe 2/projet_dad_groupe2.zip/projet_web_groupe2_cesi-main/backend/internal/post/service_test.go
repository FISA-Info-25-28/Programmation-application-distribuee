package post

import (
	"context"
	"errors"
	"testing"

	"breezy/backend/internal/models"

	"github.com/google/uuid"
)

func TestCanViewPost(t *testing.T) {
	authorID := uuid.New()
	followerID := uuid.New()
	otherID := uuid.New()
	followedByFollower := map[uuid.UUID]bool{authorID: true}

	tests := []struct {
		name       string
		visibility string
		viewerID   uuid.UUID
		followed   map[uuid.UUID]bool
		private    bool
		want       bool
	}{
		{name: "public post is visible", visibility: "PUBLIC", viewerID: otherID, want: true},
		{name: "public post by private author is hidden from other user", visibility: "PUBLIC", viewerID: otherID, private: true, want: false},
		{name: "public post by private author is visible to follower", visibility: "PUBLIC", viewerID: followerID, followed: followedByFollower, private: true, want: true},
		{name: "followers post is visible to author", visibility: "FOLLOWERS", viewerID: authorID, want: true},
		{name: "followers post is visible to follower", visibility: "FOLLOWERS", viewerID: followerID, followed: followedByFollower, want: true},
		{name: "private post is visible to author", visibility: "PRIVATE", viewerID: authorID, want: true},
		{name: "private post is hidden from follower", visibility: "PRIVATE", viewerID: followerID, followed: followedByFollower, want: false},
		{name: "private post is hidden from other user", visibility: "PRIVATE", viewerID: otherID, want: false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			post := models.Post{AuthorID: authorID, Visibility: tt.visibility}
			if got := canViewPost(post, tt.viewerID, tt.followed, tt.private); got != tt.want {
				t.Fatalf("canViewPost() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestNormalizePostVisibility(t *testing.T) {
	tests := []struct {
		name       string
		visibility string
		private    bool
		want       string
		wantErr    error
	}{
		{name: "public profile defaults to public", visibility: "", want: "PUBLIC"},
		{name: "private profile defaults to followers", visibility: "", private: true, want: "FOLLOWERS"},
		{name: "private profile can publish followers", visibility: "followers", private: true, want: "FOLLOWERS"},
		{name: "private profile can publish private", visibility: "PRIVATE", private: true, want: "PRIVATE"},
		{name: "private profile cannot publish public", visibility: "PUBLIC", private: true, wantErr: ErrPrivateProfilePublicVisibility},
		{name: "invalid visibility is rejected", visibility: "friends", wantErr: ErrInvalidVisibility},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := normalizePostVisibility(tt.visibility, tt.private)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("normalizePostVisibility() error = %v, want %v", err, tt.wantErr)
			}
			if got != tt.want {
				t.Fatalf("normalizePostVisibility() = %q, want %q", got, tt.want)
			}
		})
	}
}

func TestPostServiceWorkflowsDryRun(t *testing.T) {
	service := NewService(NewRepository(postDryRunDB(t)))
	ctx := context.Background()
	accountID := uuid.New()
	postID := uuid.New()
	optionID := uuid.New()
	duration := 1.0

	_, _ = service.GetPosts(ctx)
	_, _ = service.GetPostByID(ctx, postID)
	_, _ = service.GetRepliesByParentID(ctx, postID)
	_, _ = service.GetPostsByTag(ctx, "go")
	_, _ = service.SearchPostsByKeyword(ctx, "hello")
	_, _ = service.GetPostsByAuthor(ctx, "alice")
	_, _ = service.GetRepostsByAuthor(ctx, "alice")
	_, _ = service.GetRepliesByAuthor(ctx, "alice")
	_, _ = service.GetTrendingTags(ctx, 10)
	_, _ = service.GetFollowingPosts(ctx, accountID)
	_, _ = service.GetBookmarkedPosts(ctx, accountID)

	_, _ = service.CreatePost(ctx, accountID, createPostRequest{Content: "hello #go", Visibility: "followers"})
	_, _ = service.CreatePost(ctx, accountID, createPostRequest{
		Content: "poll",
		Poll:    &createPollRequest{Options: []string{"A", "B"}, DurationHours: &duration},
		Media:   []mediaRequest{{Type: "IMAGE", URL: "/api/media/files/a.png"}},
	})
	_, _ = service.CreatePost(ctx, accountID, createPostRequest{})
	_, _ = service.VotePoll(ctx, accountID, postID, optionID)
	_, _ = service.ClosePoll(ctx, accountID, postID)
	_ = service.BookmarkPost(ctx, accountID, postID)
	_ = service.UnbookmarkPost(ctx, accountID, postID)
	_ = service.DeletePost(ctx, accountID, postID)
	_, _ = service.UpdatePostVisibility(ctx, accountID, postID, "followers")
	_ = service.LikePost(ctx, accountID, postID)
	_ = service.UnlikePost(ctx, accountID, postID)
	_ = service.Repost(ctx, accountID, postID)
	_ = service.Unrepost(ctx, accountID, postID)

	_, _ = service.enrichPosts(ctx, nil)
	_, _ = service.enrichFeedPosts(ctx, nil)
	_, _ = service.filterAccessiblePosts(ctx, nil)
	_, _ = service.filterAccessibleFeedPosts(ctx, nil)
	_, _ = service.canViewPost(ctx, models.Post{ID: postID, AuthorID: uuid.New(), Visibility: "PUBLIC"})
	_ = requestAccountID(ctx)
}
