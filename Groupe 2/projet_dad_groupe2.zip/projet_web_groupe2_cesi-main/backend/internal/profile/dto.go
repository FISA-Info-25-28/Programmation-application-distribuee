package profile

import (
	"encoding/base64"
	"errors"
	"strings"
	"time"

	"breezy/backend/internal/validation"
	"github.com/google/uuid"
)

// profileResponse représente les informations affichées dans l'en-tête de la page profil.
// Les abonnements et les posts ne sont pas gérés ici : ils appartiennent à des services dédiés.
type profileResponse struct {
	ID             uuid.UUID  `json:"id"`
	AccountID      uuid.UUID  `json:"accountId"`
	Username       string     `json:"username"`
	DisplayName    string     `json:"displayName"`
	Bio            *string    `json:"bio"`
	AvatarURL      *string    `json:"avatarUrl"`
	BannerURL      *string    `json:"bannerUrl"`
	FollowersCount int64      `json:"followersCount"`
	FollowingCount int64      `json:"followingCount"`
	PostsCount     int64      `json:"postsCount"`
	IsFollowing    bool       `json:"isFollowing"`
	RequestPending bool       `json:"requestPending"`
	IsPrivate      bool       `json:"isPrivate"`
	CanViewContent bool       `json:"canViewContent"`
	IsBlocked      bool       `json:"isBlocked"`
	PinnedPostID   *uuid.UUID `json:"pinnedPostId"`
	PublicKey      *string    `json:"publicKey"`
	CreatedAt      time.Time  `json:"createdAt"`
}

// updateProfileRequest représente les données modifiables depuis la page profil.
// Les pointeurs permettent de distinguer un champ absent d'un champ volontairement vide.
type updateProfileRequest struct {
	DisplayName *string `json:"displayName" binding:"omitempty,min=1,max=30"`
	Bio         *string `json:"bio" binding:"omitempty,max=160"`
	AvatarURL   *string `json:"avatarUrl" binding:"omitempty,max=2048"`
	BannerURL   *string `json:"bannerUrl" binding:"omitempty,max=2048"`
	IsPrivate   *bool   `json:"isPrivate"`
	// PublicKey est la cle publique X25519 (32 octets encodes en base64 standard)
	// generee cote client pour le chiffrement de bout en bout des messages.
	PublicKey *string `json:"publicKey" binding:"omitempty,max=64"`
}

func (r updateProfileRequest) Validate() error {
	if r.DisplayName != nil {
		if _, err := validation.TrimmedRequired(*r.DisplayName, 30, "displayName"); err != nil {
			return err
		}
	}
	if err := validation.OptionalText(r.Bio, 160, "bio"); err != nil {
		return err
	}
	if r.AvatarURL != nil && strings.TrimSpace(*r.AvatarURL) != "" {
		if err := validation.URL(*r.AvatarURL, "avatarUrl"); err != nil {
			return err
		}
	}
	if r.BannerURL != nil && strings.TrimSpace(*r.BannerURL) != "" {
		if err := validation.URL(*r.BannerURL, "bannerUrl"); err != nil {
			return err
		}
	}
	if r.PublicKey != nil {
		decoded, err := base64.StdEncoding.DecodeString(strings.TrimSpace(*r.PublicKey))
		if err != nil || len(decoded) != 32 {
			return errors.New("publicKey must be a base64-encoded 32-byte X25519 key")
		}
	}
	return nil
}

// preferencesResponse représente les préférences privées de l'utilisateur connecté.
type preferencesResponse struct {
	Theme              string `json:"theme"`
	Language           string `json:"language"`
	EmailNotifications bool   `json:"emailNotifications"`
	PushNotifications  bool   `json:"pushNotifications"`
}

// updatePreferencesRequest représente les préférences modifiables.
// Les pointeurs permettent de modifier uniquement les champs présents dans la requête.
type updatePreferencesRequest struct {
	Theme              *string `json:"theme" binding:"omitempty,oneof=system light dark"`
	Language           *string `json:"language" binding:"omitempty,oneof=fr en"`
	EmailNotifications *bool   `json:"emailNotifications"`
	PushNotifications  *bool   `json:"pushNotifications"`
}

func (r updatePreferencesRequest) Validate() error {
	if r.Theme != nil {
		if err := validation.OneOf(*r.Theme, "SYSTEM", "LIGHT", "DARK"); err != nil {
			return err
		}
	}
	if r.Language != nil {
		if err := validation.OneOf(*r.Language, "FR", "EN"); err != nil {
			return err
		}
	}
	return nil
}
