package profile

import (
	"strings"
	"testing"
)

func strPtr(value string) *string { return &value }

func TestUpdateProfileRequestValidate(t *testing.T) {
	req := updateProfileRequest{
		DisplayName: strPtr(" Breezy "),
		Bio:         strPtr("hello"),
		AvatarURL:   strPtr("https://example.com/avatar.png"),
		BannerURL:   strPtr("https://example.com/banner.png"),
	}
	if err := req.Validate(); err != nil {
		t.Fatalf("updateProfileRequest.Validate() unexpected error: %v", err)
	}

	tests := []updateProfileRequest{
		{DisplayName: strPtr("")},
		{DisplayName: strPtr(strings.Repeat("a", 31))},
		{Bio: strPtr(strings.Repeat("b", 161))},
		{AvatarURL: strPtr("not-a-url")},
		{BannerURL: strPtr("/relative/path")},
	}
	for _, req := range tests {
		if err := req.Validate(); err == nil {
			t.Fatalf("updateProfileRequest.Validate(%+v) expected error", req)
		}
	}
}

func TestUpdatePreferencesRequestValidate(t *testing.T) {
	req := updatePreferencesRequest{Theme: strPtr("dark"), Language: strPtr("fr")}
	if err := req.Validate(); err != nil {
		t.Fatalf("updatePreferencesRequest.Validate() unexpected error: %v", err)
	}

	if err := (updatePreferencesRequest{Theme: strPtr("blue")}).Validate(); err == nil {
		t.Fatal("updatePreferencesRequest.Validate() expected invalid theme error")
	}
	if err := (updatePreferencesRequest{Language: strPtr("pt")}).Validate(); err == nil {
		t.Fatal("updatePreferencesRequest.Validate() expected invalid language error")
	}
}
