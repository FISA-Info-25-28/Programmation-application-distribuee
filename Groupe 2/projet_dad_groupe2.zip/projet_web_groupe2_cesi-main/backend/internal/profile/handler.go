package profile

import (
	"breezy/backend/internal/config"
	"breezy/backend/internal/middleware"
	"errors"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// Handler reçoit les requêtes HTTP du profile-service.
// Il vérifie les entrées, appelle le service métier, puis retourne une réponse JSON.
type Handler struct {
	db      *gorm.DB
	service *Service
}

// NewHandler construit le handler profil avec son repository et son service.
// Entree : db.
// Sortie : valeur retour de type *Handler.
func NewHandler(db *gorm.DB) *Handler {
	repo := NewRepository(db)
	return &Handler{
		db:      db,
		service: NewService(repo),
	}
}

// Health vérifie l'état du service profil et de la connexion à la base de données.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) Health(c *gin.Context) {
	dbStatus := "ok"
	if h.db == nil {
		dbStatus = "unavailable"
	} else if sqlDB, err := h.db.DB(); err != nil || sqlDB.PingContext(c.Request.Context()) != nil {
		dbStatus = "error"
	}

	c.JSON(http.StatusOK, gin.H{
		"service": config.Env("SERVICE_NAME", "profile-service"),
		"status":  "ok",
		"db":      dbStatus,
	})
}

// Me retourne le profil de l'utilisateur connecté.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) Me(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	response, err := h.service.Me(c.Request.Context(), accountID)
	if err != nil {
		h.handleProfileError(c, err, "profile lookup failed")
		return
	}

	c.JSON(http.StatusOK, response)
}

// Show retourne le profil public demandé dans l'URL.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) Show(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	username := c.Param("username")
	accountID, _ := middleware.AccountID(c)
	response, err := h.service.Show(c.Request.Context(), username, accountID)

	if err != nil {
		h.handleProfileError(c, err, "profile lookup failed")
		return
	}

	c.JSON(http.StatusOK, response)
}

// UpdateMe modifie les informations du profil connecté.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) UpdateMe(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	var req updateProfileRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid profile payload"})
		return
	}

	response, err := h.service.UpdateMe(c.Request.Context(), accountID, req)
	if err != nil {
		h.handleProfileError(c, err, "profile update failed")
		return
	}

	c.JSON(http.StatusOK, response)
}

// Preferences retourne les préférences privées de l'utilisateur connecté.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) Preferences(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	response, err := h.service.Preferences(c.Request.Context(), accountID)
	if err != nil {
		h.handleProfileError(c, err, "preferences lookup failed")
		return
	}

	c.JSON(http.StatusOK, response)
}

// UpdatePreferences modifie les préférences privées de l'utilisateur connecté.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) UpdatePreferences(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	var req updatePreferencesRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid preferences payload"})
		return
	}

	response, err := h.service.UpdatePreferences(c.Request.Context(), accountID, req)
	if err != nil {
		h.handleProfileError(c, err, "preferences update failed")
		return
	}

	c.JSON(http.StatusOK, response)
}

// PinPost épingle un post sur le profil de l'utilisateur connecté.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) PinPost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	postID, err := uuid.Parse(c.Param("postId"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid post id"})
		return
	}
	if err := h.service.PinPost(c.Request.Context(), accountID, postID); err != nil {
		if errors.Is(err, ErrNotPostOwner) {
			c.JSON(http.StatusForbidden, gin.H{"error": "you can only pin your own posts"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "pin failed"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"pinned": true})
}

// UnpinPost supprime le post épinglé du profil de l'utilisateur connecté.
// Entree : c.
// Sortie : aucune valeur.
func (h *Handler) UnpinPost(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	if err := h.service.UnpinPost(c.Request.Context(), accountID); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "unpin failed"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"pinned": false})
}

// databaseAvailable évite d'exécuter une requête métier si PostgreSQL est indisponible.
// Entree : c.
// Sortie : valeur retour de type bool.
func (h *Handler) databaseAvailable(c *gin.Context) bool {
	if h.db != nil {
		return true
	}

	c.JSON(http.StatusServiceUnavailable, gin.H{"error": "database unavailable"})
	return false
}

// handleProfileError centralise la traduction des erreurs métier en réponses HTTP.
// Entree : c, err, fallbackMessage.
// Sortie : aucune valeur.
func (h *Handler) handleProfileError(c *gin.Context, err error, fallbackMessage string) {
	if errors.Is(err, gorm.ErrRecordNotFound) {
		c.JSON(http.StatusNotFound, gin.H{"error": "profile not found"})
		return
	}

	if errors.Is(err, ErrInvalidDisplayName) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "display name cannot be empty"})
		return
	}

	if errors.Is(err, ErrInvalidUsername) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "username is required"})
		return
	}

	c.JSON(http.StatusInternalServerError, gin.H{"error": fallbackMessage})
}
