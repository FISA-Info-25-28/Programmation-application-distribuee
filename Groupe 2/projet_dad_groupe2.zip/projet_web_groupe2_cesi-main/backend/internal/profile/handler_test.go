package profile

import (
	"database/sql"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"breezy/backend/internal/middleware"
	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// gormResult fabrique un sql.Result generique pour les UPDATE/EXEC simules.
func gormResult() sql.Result {
	return sqlmock.NewResult(0, 1)
}

// sqlmockPreferencesRows construit les lignes attendues pour une lecture de
// profiles.preferences.
func sqlmockPreferencesRows(profileID uuid.UUID, locale, theme string) *sqlmock.Rows {
	return sqlmock.NewRows([]string{"profile_id", "locale", "theme", "updated_at"}).
		AddRow(profileID, locale, theme, time.Now())
}

func TestProfileHandlerDatabaseUnavailable(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(nil)

	tests := []struct {
		method string
		path   string
		setup  func(*gin.Engine)
		want   int
	}{
		{method: http.MethodGet, path: "/health", setup: func(r *gin.Engine) { r.GET("/health", handler.Health) }, want: http.StatusOK},
		{method: http.MethodGet, path: "/me", setup: func(r *gin.Engine) { r.GET("/me", handler.Me) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/alice", setup: func(r *gin.Engine) { r.GET("/:username", handler.Show) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPatch, path: "/me", setup: func(r *gin.Engine) { r.PATCH("/me", handler.UpdateMe) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/preferences", setup: func(r *gin.Engine) { r.GET("/preferences", handler.Preferences) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPatch, path: "/preferences", setup: func(r *gin.Engine) { r.PATCH("/preferences", handler.UpdatePreferences) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/me/pin/bad", setup: func(r *gin.Engine) { r.POST("/me/pin/:postId", handler.PinPost) }, want: http.StatusServiceUnavailable},
		{method: http.MethodDelete, path: "/me/pin", setup: func(r *gin.Engine) { r.DELETE("/me/pin", handler.UnpinPost) }, want: http.StatusServiceUnavailable},
	}

	for _, tt := range tests {
		router := gin.New()
		tt.setup(router)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != tt.want {
			t.Fatalf("%s %s status = %d, want %d", tt.method, tt.path, rec.Code, tt.want)
		}
	}
}

func TestHandleProfileError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := &Handler{}

	tests := []struct {
		err  error
		want int
	}{
		{err: gorm.ErrRecordNotFound, want: http.StatusNotFound},
		{err: ErrInvalidDisplayName, want: http.StatusBadRequest},
		{err: ErrInvalidUsername, want: http.StatusBadRequest},
		{err: assertErr("boom"), want: http.StatusInternalServerError},
	}

	for _, tt := range tests {
		rec := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(rec)
		handler.handleProfileError(c, tt.err, "fallback")
		if rec.Code != tt.want {
			t.Fatalf("handleProfileError(%v) status = %d, want %d", tt.err, rec.Code, tt.want)
		}
	}
}

type assertErr string

func (e assertErr) Error() string { return string(e) }

func TestRegisterRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	RegisterRoutes(router, NewHandler(nil))

	tests := []struct {
		method string
		path   string
		want   int
	}{
		{method: http.MethodGet, path: "/health", want: http.StatusOK},
		{method: http.MethodGet, path: "/me", want: http.StatusUnauthorized},
		{method: http.MethodPatch, path: "/me", want: http.StatusUnauthorized},
		{method: http.MethodGet, path: "/preferences", want: http.StatusUnauthorized},
	}

	for _, tt := range tests {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != tt.want {
			t.Fatalf("%s %s status = %d, want %d", tt.method, tt.path, rec.Code, tt.want)
		}
	}
}

func TestProfileHandlerInvalidInputsWithDatabase(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(&gorm.DB{})
	accountID := uuid.New()

	tests := []struct {
		name        string
		method      string
		path        string
		body        string
		withAccount bool
		setup       func(*gin.Engine)
		want        int
	}{
		{name: "me missing account", method: http.MethodGet, path: "/me", setup: func(r *gin.Engine) { r.GET("/me", handler.Me) }, want: http.StatusInternalServerError},
		{name: "update missing account", method: http.MethodPatch, path: "/me", body: `{}`, setup: func(r *gin.Engine) { r.PATCH("/me", handler.UpdateMe) }, want: http.StatusInternalServerError},
		{name: "preferences missing account", method: http.MethodGet, path: "/preferences", setup: func(r *gin.Engine) { r.GET("/preferences", handler.Preferences) }, want: http.StatusInternalServerError},
		{name: "update preferences invalid payload", method: http.MethodPatch, path: "/preferences", body: `{"theme":"blue"}`, withAccount: true, setup: func(r *gin.Engine) { r.PATCH("/preferences", handler.UpdatePreferences) }, want: http.StatusBadRequest},
		{name: "pin missing account", method: http.MethodPost, path: "/me/pin/" + uuid.NewString(), setup: func(r *gin.Engine) { r.POST("/me/pin/:postId", handler.PinPost) }, want: http.StatusInternalServerError},
		{name: "pin invalid id", method: http.MethodPost, path: "/me/pin/bad", withAccount: true, setup: func(r *gin.Engine) { r.POST("/me/pin/:postId", handler.PinPost) }, want: http.StatusBadRequest},
		{name: "unpin missing account", method: http.MethodDelete, path: "/me/pin", setup: func(r *gin.Engine) { r.DELETE("/me/pin", handler.UnpinPost) }, want: http.StatusInternalServerError},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			if tt.withAccount {
				router.Use(func(c *gin.Context) {
					c.Set(middleware.ContextAccountID, accountID)
					c.Next()
				})
			}
			tt.setup(router)
			rec := httptest.NewRecorder()
			req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(tt.body))
			if tt.body != "" {
				req.Header.Set("Content-Type", "application/json")
			}
			router.ServeHTTP(rec, req)
			if rec.Code != tt.want {
				t.Fatalf("status = %d, want %d: %s", rec.Code, tt.want, rec.Body.String())
			}
		})
	}
}

// withAccountMiddleware injecte un accountID dans le contexte Gin comme le ferait
// le middleware d'authentification reel, pour pouvoir tester les handlers proteges.
func withAccountMiddleware(accountID uuid.UUID) gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	}
}

// TestProfileHandlerHappyPathsWithMock exerce les chemins de succes des handlers
// (Me, Show, UpdateMe, Preferences, UpdatePreferences, PinPost, UnpinPost) via une
// connexion GORM pilotee par sqlmock, afin de couvrir le passage HTTP -> service ->
// repository complet (au-dela des seuls tests directs sur Service).
func TestProfileHandlerHappyPathsWithMock(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("Me success", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		expectProfileCounts(mock, 0, 0, 0)

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.GET("/me", handler.Me)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/me", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Me() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("Me service error", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnError(gorm.ErrRecordNotFound)

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.GET("/me", handler.Me)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/me", nil))
		if rec.Code != http.StatusNotFound {
			t.Fatalf("Me() status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("Show success", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		target := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "bob"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(target))
		expectProfileCounts(mock, 1, 2, 3)

		router := gin.New()
		router.GET("/:username", handler.Show)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/bob", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Show() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("Show not found", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnError(gorm.ErrRecordNotFound)

		router := gin.New()
		router.GET("/:username", handler.Show)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/ghost", nil))
		if rec.Code != http.StatusNotFound {
			t.Fatalf("Show() status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("UpdateMe success", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnResult(gormResult())
		mock.ExpectCommit()
		expectProfileCounts(mock, 0, 0, 0)

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.PATCH("/me", handler.UpdateMe)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/me", strings.NewReader(`{"bio":"hello"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("UpdateMe() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("Preferences success", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."preferences"`).
			WillReturnRows(sqlmockPreferencesRows(profile.ID, "en", "dark"))

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.GET("/preferences", handler.Preferences)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/preferences", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Preferences() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("UpdatePreferences success", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."preferences"`).
			WillReturnRows(sqlmockPreferencesRows(profile.ID, "fr", "light"))
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles"\."preferences"`).WillReturnResult(gormResult())
		mock.ExpectCommit()

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.PATCH("/preferences", handler.UpdatePreferences)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/preferences", strings.NewReader(`{"theme":"dark"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusOK {
			t.Fatalf("UpdatePreferences() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("PinPost success", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()
		postID := uuid.New()

		mock.ExpectQuery(`SELECT count\(\*\) FROM posts\.posts`).WillReturnRows(countRows(1))
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnResult(gormResult())
		mock.ExpectCommit()

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.POST("/me/pin/:postId", handler.PinPost)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/me/pin/"+postID.String(), nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("PinPost() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("PinPost forbidden when not owner", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()
		postID := uuid.New()

		mock.ExpectQuery(`SELECT count\(\*\) FROM posts\.posts`).WillReturnRows(countRows(0))

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.POST("/me/pin/:postId", handler.PinPost)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/me/pin/"+postID.String(), nil))
		if rec.Code != http.StatusForbidden {
			t.Fatalf("PinPost() status = %d, want 403: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("UnpinPost success", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()

		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnResult(gormResult())
		mock.ExpectCommit()

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.DELETE("/me/pin", handler.UnpinPost)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodDelete, "/me/pin", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("UnpinPost() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("UnpinPost failure", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()

		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnError(assertErr("boom"))
		mock.ExpectRollback()

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.DELETE("/me/pin", handler.UnpinPost)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodDelete, "/me/pin", nil))
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("UnpinPost() status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("Health db error", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		_ = mock

		router := gin.New()
		router.GET("/health", handler.Health)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Health() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("Health db ping error", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		// Ferme la connexion sous-jacente : PingContext echouera, ce qui declenche
		// la branche dbStatus = "error" de Health().
		sqlDB, err := db.DB()
		if err != nil {
			t.Fatalf("db.DB() unexpected error: %v", err)
		}
		_ = sqlDB.Close()
		_ = mock

		router := gin.New()
		router.GET("/health", handler.Health)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Health() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
		if !strings.Contains(rec.Body.String(), `"db":"error"`) {
			t.Fatalf("Health() body = %s, want db status error", rec.Body.String())
		}
	})

	t.Run("UpdateMe invalid JSON body", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		_ = mock
		accountID := uuid.New()

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.PATCH("/me", handler.UpdateMe)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/me", strings.NewReader(`{invalid`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("UpdateMe() status = %d, want 400: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("UpdateMe service error", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnError(gorm.ErrRecordNotFound)

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.PATCH("/me", handler.UpdateMe)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/me", strings.NewReader(`{"bio":"hello"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("UpdateMe() status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("Preferences service error", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnError(gorm.ErrRecordNotFound)

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.GET("/preferences", handler.Preferences)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/preferences", nil))
		if rec.Code != http.StatusNotFound {
			t.Fatalf("Preferences() status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("UpdatePreferences missing account", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		_ = mock

		router := gin.New()
		router.PATCH("/preferences", handler.UpdatePreferences)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/preferences", strings.NewReader(`{"theme":"dark"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("UpdatePreferences() status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("UpdatePreferences service error", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnError(gorm.ErrRecordNotFound)

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.PATCH("/preferences", handler.UpdatePreferences)

		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPatch, "/preferences", strings.NewReader(`{"theme":"dark"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("UpdatePreferences() status = %d, want 404: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("PinPost service error other than not owner", func(t *testing.T) {
		db, mock := profileMockDB(t)
		handler := NewHandler(db)
		accountID := uuid.New()
		postID := uuid.New()

		mock.ExpectQuery(`SELECT count\(\*\) FROM posts\.posts`).WillReturnError(assertErr("boom"))

		router := gin.New()
		router.Use(withAccountMiddleware(accountID))
		router.POST("/me/pin/:postId", handler.PinPost)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/me/pin/"+postID.String(), nil))
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("PinPost() status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}
