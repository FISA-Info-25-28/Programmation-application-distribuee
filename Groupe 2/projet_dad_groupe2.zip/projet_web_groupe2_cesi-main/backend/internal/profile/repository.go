package profile

import (
	"context"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// Repository centralise les échanges avec la base de données pour le service profil.
// Il suit le même principe que le repository du package auth.
type Repository struct {
	db *gorm.DB
}

// NewRepository crée un repository profil à partir de la connexion GORM.
// Entree : db.
// Sortie : valeur retour de type *Repository.
func NewRepository(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

// FindByAccountID récupère le profil associé au compte connecté.
// Entree : ctx, accountID.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindByAccountID(ctx context.Context, accountID uuid.UUID) (models.Profile, error) {
	var profile models.Profile

	err := r.db.WithContext(ctx).
		Where("account_id = ?", accountID).
		First(&profile).
		Error

	return profile, err
}

// FindByUsername récupère un profil public à partir de son nom d'utilisateur.
// Entree : ctx, username.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindByUsername(ctx context.Context, username string) (models.Profile, error) {
	var profile models.Profile

	err := r.db.WithContext(ctx).
		Where("lower(username) = lower(?)", username).
		First(&profile).
		Error

	return profile, err
}

// UpdateProfile met à jour les informations modifiables du profil.
// On passe par une map explicite pour éviter que GORM ne tente de mettre à jour
// des colonnes comme pinned_post_id qui peuvent ne pas exister encore en base.
// Entree : ctx, profile.
// Sortie : erreur eventuelle.
func (r *Repository) UpdateProfile(ctx context.Context, profile *models.Profile) error {
	return r.db.WithContext(ctx).
		Model(profile).
		Updates(map[string]interface{}{
			"display_name": profile.DisplayName,
			"bio":          profile.Bio,
			"avatar_url":   profile.AvatarURL,
			"banner_url":   profile.BannerURL,
			"is_private":   profile.IsPrivate,
			"public_key":   profile.PublicKey,
		}).Error
}

// CountFollowers retourne le nombre de profils qui suivent le profil donne.
// Entree : ctx, profileID.
// Sortie : valeurs retour de la fonction.
func (r *Repository) CountFollowers(ctx context.Context, profileID uuid.UUID) (int64, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("social.follows").
		Where("followed_id = ?", profileID).
		Count(&count).
		Error

	return count, err
}

// CountFollowing retourne le nombre de profils suivis par le profil donne.
// Entree : ctx, profileID.
// Sortie : valeurs retour de la fonction.
func (r *Repository) CountFollowing(ctx context.Context, profileID uuid.UUID) (int64, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("social.follows").
		Where("follower_id = ?", profileID).
		Count(&count).
		Error

	return count, err
}

func (r *Repository) CountPosts(ctx context.Context, profileID uuid.UUID) (int64, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("posts.posts").
		Where("author_id = ? AND parent_id IS NULL AND deleted_at IS NULL", profileID).
		Count(&count).
		Error
	return count, err
}

func (r *Repository) IsFollowing(ctx context.Context, viewerAccountID, targetProfileID uuid.UUID) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("social.follows AS f").
		Joins("JOIN profiles.profiles AS viewer ON viewer.id = f.follower_id").
		Where("viewer.account_id = ? AND f.followed_id = ?", viewerAccountID, targetProfileID).
		Count(&count).
		Error
	return count > 0, err
}

func (r *Repository) HasPendingFollowRequest(ctx context.Context, viewerAccountID, targetProfileID uuid.UUID) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("social.follow_requests AS request").
		Joins("JOIN profiles.profiles AS viewer ON viewer.id = request.requester_id").
		Where("viewer.account_id = ? AND request.target_id = ?", viewerAccountID, targetProfileID).
		Count(&count).
		Error
	return count > 0, err
}

func (r *Repository) BlockStatus(ctx context.Context, viewerAccountID, targetProfileID uuid.UUID) (viewerBlockedTarget, targetBlockedViewer bool, err error) {
	if viewerAccountID == uuid.Nil {
		return false, false, nil
	}
	var row struct{ ID uuid.UUID }
	if err = r.db.WithContext(ctx).Table("profiles.profiles").Select("id").Where("account_id = ?", viewerAccountID).Take(&row).Error; err != nil {
		return false, false, err
	}
	var blocks []struct {
		BlockerID uuid.UUID
		BlockedID uuid.UUID
	}
	err = r.db.WithContext(ctx).Table("social.blocks").
		Where("(blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)", row.ID, targetProfileID, targetProfileID, row.ID).
		Scan(&blocks).Error
	for _, block := range blocks {
		viewerBlockedTarget = viewerBlockedTarget || (block.BlockerID == row.ID && block.BlockedID == targetProfileID)
		targetBlockedViewer = targetBlockedViewer || (block.BlockerID == targetProfileID && block.BlockedID == row.ID)
	}
	return
}

// SetPinnedPost enregistre l'ID du post épinglé sur le profil du compte donné.
// Entree : ctx, accountID, postID.
// Sortie : erreur eventuelle.
func (r *Repository) SetPinnedPost(ctx context.Context, accountID, postID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Model(&models.Profile{}).
		Where("account_id = ?", accountID).
		Update("pinned_post_id", postID).Error
}

// ClearPinnedPost supprime le post épinglé du profil du compte donné.
// Entree : ctx, accountID.
// Sortie : erreur eventuelle.
func (r *Repository) ClearPinnedPost(ctx context.Context, accountID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Model(&models.Profile{}).
		Where("account_id = ?", accountID).
		Update("pinned_post_id", nil).Error
}

// CheckPostOwnership vérifie qu'un post appartient bien au compte donné (cross-schema query).
// Entree : ctx, accountID, postID.
// Sortie : valeurs retour de la fonction.
func (r *Repository) CheckPostOwnership(ctx context.Context, accountID, postID uuid.UUID) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("posts.posts AS p").
		Joins("JOIN profiles.profiles AS pr ON pr.id = p.author_id").
		Where("pr.account_id = ? AND p.id = ? AND p.deleted_at IS NULL", accountID, postID).
		Count(&count).Error
	return count > 0, err
}

// FindPreferencesByProfileID recupere les preferences du profil connecte.
// Entree : ctx, profileID.
// Sortie : valeurs retour de la fonction.
func (r *Repository) FindPreferencesByProfileID(ctx context.Context, profileID uuid.UUID) (models.UserPreference, error) {
	var preferences models.UserPreference

	err := r.db.WithContext(ctx).
		Where("profile_id = ?", profileID).
		First(&preferences).
		Error

	return preferences, err
}

// CreatePreferences crée les préférences par défaut d'un utilisateur.
// Entree : ctx, preferences.
// Sortie : erreur eventuelle.
func (r *Repository) CreatePreferences(ctx context.Context, preferences *models.UserPreference) error {
	return r.db.WithContext(ctx).Create(preferences).Error
}

// UpdatePreferences met à jour les préférences utilisateur.
// Entree : ctx, preferences.
// Sortie : erreur eventuelle.
func (r *Repository) UpdatePreferences(ctx context.Context, preferences *models.UserPreference) error {
	return r.db.WithContext(ctx).Save(preferences).Error
}
