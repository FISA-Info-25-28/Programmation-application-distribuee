package profile

import (
	"context"
	"testing"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestProfileRepositoryConstructor(t *testing.T) {
	repo := NewRepository(nil)
	if repo == nil || repo.db != nil {
		t.Fatalf("NewRepository(nil) = %+v, want repository with nil db", repo)
	}
}

func TestProfileRepositoryQueriesDryRun(t *testing.T) {
	repo := NewRepository(profileDryRunDB(t))
	ctx := context.Background()
	accountID := uuid.New()
	profileID := uuid.New()
	postID := uuid.New()

	_, _ = repo.FindByAccountID(ctx, accountID)
	_, _ = repo.FindByUsername(ctx, "alice")
	_ = repo.UpdateProfile(ctx, &models.Profile{ID: profileID, AccountID: accountID, Username: "alice"})
	_, _ = repo.CountFollowers(ctx, profileID)
	_, _ = repo.CountFollowing(ctx, profileID)
	_, _ = repo.CountPosts(ctx, profileID)
	_, _ = repo.IsFollowing(ctx, accountID, profileID)
	_, _ = repo.HasPendingFollowRequest(ctx, accountID, profileID)
	_, _, _ = repo.BlockStatus(ctx, accountID, profileID)
	_, _, _ = repo.BlockStatus(ctx, uuid.Nil, profileID)
	_ = repo.SetPinnedPost(ctx, accountID, postID)
	_ = repo.ClearPinnedPost(ctx, accountID)
	_, _ = repo.CheckPostOwnership(ctx, accountID, postID)
	_, _ = repo.FindPreferencesByProfileID(ctx, profileID)
	_ = repo.CreatePreferences(ctx, &models.UserPreference{ProfileID: profileID})
	_ = repo.UpdatePreferences(ctx, &models.UserPreference{ProfileID: profileID, Locale: "fr", Theme: "light"})
}

func profileDryRunDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{DryRun: true})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db
}
