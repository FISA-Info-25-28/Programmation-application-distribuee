package profile

import (
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
)

// RegisterRoutes déclare les routes HTTP du profile-service.
// Toutes les routes sont protégées car la page profil appartient à l'espace connecté.
// Entree : router, handler.
// Sortie : aucune valeur.
func RegisterRoutes(router *gin.Engine, handler *Handler) {
	router.Use(middleware.JSONBody())

	router.GET("/health", handler.Health)

	authenticated := router.Group("/")

	// Cette route est protégée par le middleware d'authentification.
	authenticated.Use(middleware.AuthRequired())

	// Utilisateur connecté
	authenticated.GET("/me", handler.Me)
	authenticated.PATCH("/me", handler.UpdateMe)
	authenticated.POST("/me/pin/:postId", handler.PinPost)
	authenticated.DELETE("/me/pin", handler.UnpinPost)

	// Préférences utilisateur
	authenticated.GET("/preferences", handler.Preferences)
	authenticated.PATCH("/preferences", handler.UpdatePreferences)

	// Utilisateur X : consultable publiquement, l'auth (optionnelle) permet
	// au service de distinguer le propriétaire pour les contenus privés.
	public := router.Group("/")
	public.Use(middleware.AuthOptional())
	public.GET("/:username", handler.Show)
}
