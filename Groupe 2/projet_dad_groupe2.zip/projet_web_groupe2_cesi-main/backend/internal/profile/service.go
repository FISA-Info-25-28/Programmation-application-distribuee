package profile

import (
	"context"
	"errors"
	"strings"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

var (
	ErrInvalidDisplayName = errors.New("display name cannot be empty")
	ErrInvalidUsername    = errors.New("username is required")
	ErrNotPostOwner       = errors.New("you can only pin your own posts")
)

// Service contient la logique métier liée à la page profil.
// Il transforme les données de la base en réponses directement exploitables par le front.
type Service struct {
	repo *Repository
}

// NewService crée le service profil à partir de son repository.
// Entree : repo.
// Sortie : valeur retour de type *Service.
func NewService(repo *Repository) *Service {
	return &Service{repo: repo}
}

// Me retourne le profil de l'utilisateur connecté.
// Entree : ctx, accountID.
// Sortie : valeurs retour de la fonction.
func (s *Service) Me(ctx context.Context, accountID uuid.UUID) (profileResponse, error) {
	currentProfile, err := s.repo.FindByAccountID(ctx, accountID)
	if err != nil {
		return profileResponse{}, err
	}

	response, err := s.profileToResponse(ctx, currentProfile)
	if err != nil {
		return profileResponse{}, err
	}
	response.CanViewContent = true
	return response, nil
}

// Show retourne le profil public demandé par username.
// Entree : ctx, username, viewerAccountID.
// Sortie : valeurs retour de la fonction.
func (s *Service) Show(ctx context.Context, username string, viewerAccountID uuid.UUID) (profileResponse, error) {
	username = strings.TrimSpace(username)
	if username == "" {
		return profileResponse{}, ErrInvalidUsername
	}

	targetProfile, err := s.repo.FindByUsername(ctx, username)
	if err != nil {
		return profileResponse{}, err
	}
	viewerBlockedTarget, targetBlockedViewer, err := s.repo.BlockStatus(ctx, viewerAccountID, targetProfile.ID)
	if err != nil {
		return profileResponse{}, err
	}
	if targetBlockedViewer {
		return profileResponse{}, gorm.ErrRecordNotFound
	}

	response, err := s.profileToResponse(ctx, targetProfile)
	if err != nil {
		return profileResponse{}, err
	}
	response.IsBlocked = viewerBlockedTarget
	if viewerAccountID != uuid.Nil && viewerAccountID != targetProfile.AccountID {
		response.IsFollowing, err = s.repo.IsFollowing(ctx, viewerAccountID, targetProfile.ID)
		if err != nil {
			return profileResponse{}, err
		}
		if !response.IsFollowing {
			response.RequestPending, err = s.repo.HasPendingFollowRequest(ctx, viewerAccountID, targetProfile.ID)
			if err != nil {
				return profileResponse{}, err
			}
		}
	}
	response.CanViewContent = !targetProfile.IsPrivate ||
		viewerAccountID == targetProfile.AccountID ||
		response.IsFollowing
	return response, nil
}

// UpdateMe met à jour le profil de l'utilisateur connecté.
// Entree : ctx, accountID, req.
// Sortie : valeurs retour de la fonction.
func (s *Service) UpdateMe(ctx context.Context, accountID uuid.UUID, req updateProfileRequest) (profileResponse, error) {
	currentProfile, err := s.repo.FindByAccountID(ctx, accountID)
	if err != nil {
		return profileResponse{}, err
	}

	if req.DisplayName != nil {
		value := strings.TrimSpace(*req.DisplayName)
		if value == "" {
			return profileResponse{}, ErrInvalidDisplayName
		}
		currentProfile.DisplayName = &value
	}

	if req.Bio != nil {
		value := strings.TrimSpace(*req.Bio)
		currentProfile.Bio = &value
	}

	if req.AvatarURL != nil {
		value := strings.TrimSpace(*req.AvatarURL)
		currentProfile.AvatarURL = &value
	}
	if req.BannerURL != nil {
		value := strings.TrimSpace(*req.BannerURL)
		currentProfile.BannerURL = &value
	}
	if req.IsPrivate != nil {
		currentProfile.IsPrivate = *req.IsPrivate
	}
	if req.PublicKey != nil {
		value := strings.TrimSpace(*req.PublicKey)
		currentProfile.PublicKey = &value
	}

	if err := s.repo.UpdateProfile(ctx, &currentProfile); err != nil {
		return profileResponse{}, err
	}

	response, err := s.profileToResponse(ctx, currentProfile)
	if err != nil {
		return profileResponse{}, err
	}
	response.CanViewContent = true
	return response, nil
}

// Preferences retourne les préférences privées de l'utilisateur connecté.
// Si elles n'existent pas encore, elles sont créées avec les valeurs par défaut.
// Entree : ctx, accountID.
// Sortie : valeurs retour de la fonction.
func (s *Service) Preferences(ctx context.Context, accountID uuid.UUID) (preferencesResponse, error) {
	currentProfile, err := s.repo.FindByAccountID(ctx, accountID)
	if err != nil {
		return preferencesResponse{}, err
	}

	preferences, err := s.repo.FindPreferencesByProfileID(ctx, currentProfile.ID)
	if err != nil {
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			return preferencesResponse{}, err
		}

		preferences = defaultPreferences(currentProfile.ID)
		if err := s.repo.CreatePreferences(ctx, &preferences); err != nil {
			return preferencesResponse{}, err
		}
	}

	return preferencesToResponse(preferences), nil
}

// UpdatePreferences modifie les préférences privées de l'utilisateur connecté.
// Entree : ctx, accountID, req.
// Sortie : valeurs retour de la fonction.
func (s *Service) UpdatePreferences(ctx context.Context, accountID uuid.UUID, req updatePreferencesRequest) (preferencesResponse, error) {
	currentProfile, err := s.repo.FindByAccountID(ctx, accountID)
	if err != nil {
		return preferencesResponse{}, err
	}

	preferences, err := s.repo.FindPreferencesByProfileID(ctx, currentProfile.ID)
	if err != nil {
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			return preferencesResponse{}, err
		}

		preferences = defaultPreferences(currentProfile.ID)
	}

	if req.Theme != nil {
		preferences.Theme = strings.TrimSpace(*req.Theme)
	}

	if req.Language != nil {
		preferences.Locale = strings.TrimSpace(*req.Language)
	}

	if preferences.ProfileID == uuid.Nil {
		if err := s.repo.CreatePreferences(ctx, &preferences); err != nil {
			return preferencesResponse{}, err
		}
	} else {
		if err := s.repo.UpdatePreferences(ctx, &preferences); err != nil {
			return preferencesResponse{}, err
		}
	}

	return preferencesToResponse(preferences), nil
}

// PinPost épingle un post sur le profil de l'utilisateur connecté.
// Vérifie que le post appartient bien à ce compte avant de l'épingler.
// Entree : ctx, accountID, postID.
// Sortie : erreur eventuelle.
func (s *Service) PinPost(ctx context.Context, accountID, postID uuid.UUID) error {
	owns, err := s.repo.CheckPostOwnership(ctx, accountID, postID)
	if err != nil {
		return err
	}
	if !owns {
		return ErrNotPostOwner
	}
	return s.repo.SetPinnedPost(ctx, accountID, postID)
}

// UnpinPost supprime le post épinglé du profil de l'utilisateur connecté.
// Entree : ctx, accountID.
// Sortie : erreur eventuelle.
func (s *Service) UnpinPost(ctx context.Context, accountID uuid.UUID) error {
	return s.repo.ClearPinnedPost(ctx, accountID)
}

// profileToResponse construit la réponse attendue par l'en-tête de profil.
// Entree : ctx, targetProfile.
// Sortie : valeurs retour de la fonction.
func (s *Service) profileToResponse(ctx context.Context, targetProfile models.Profile) (profileResponse, error) {
	displayName := targetProfile.Username
	if targetProfile.DisplayName != nil && strings.TrimSpace(*targetProfile.DisplayName) != "" {
		displayName = *targetProfile.DisplayName
	}

	followersCount, err := s.repo.CountFollowers(ctx, targetProfile.ID)
	if err != nil {
		return profileResponse{}, err
	}

	followingCount, err := s.repo.CountFollowing(ctx, targetProfile.ID)
	if err != nil {
		return profileResponse{}, err
	}

	postsCount, err := s.repo.CountPosts(ctx, targetProfile.ID)
	if err != nil {
		return profileResponse{}, err
	}

	return profileResponse{
		ID:             targetProfile.ID,
		AccountID:      targetProfile.AccountID,
		Username:       targetProfile.Username,
		DisplayName:    displayName,
		Bio:            targetProfile.Bio,
		AvatarURL:      targetProfile.AvatarURL,
		BannerURL:      targetProfile.BannerURL,
		FollowersCount: followersCount,
		FollowingCount: followingCount,
		PostsCount:     postsCount,
		IsPrivate:      targetProfile.IsPrivate,
		PinnedPostID:   targetProfile.PinnedPostID,
		PublicKey:      targetProfile.PublicKey,
		CreatedAt:      targetProfile.CreatedAt,
	}, nil
}

// defaultPreferences construit les preferences par defaut d'un profil.
// Entree : profileID.
// Sortie : valeur retour de type models.UserPreference.
func defaultPreferences(profileID uuid.UUID) models.UserPreference {
	return models.UserPreference{
		ProfileID: profileID,
		Theme:     "light",
		Locale:    "fr",
	}
}

// preferencesToResponse transforme les preferences stockees en DTO API.
// Entree : preferences.
// Sortie : valeur retour de type preferencesResponse.
func preferencesToResponse(preferences models.UserPreference) preferencesResponse {
	return preferencesResponse{
		Theme:              preferences.Theme,
		Language:           preferences.Locale,
		EmailNotifications: true,
		PushNotifications:  true,
	}
}
