package profile

import (
	"context"
	"errors"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// profileMockDB ouvre une connexion GORM pilotee par sqlmock (pas de DryRun) afin
// de pouvoir simuler des resultats precis (lignes trouvees, ErrRecordNotFound,
// erreurs SQL) pour les tests de branchement du service profil.
func profileMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })

	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

func profileRows(p models.Profile) *sqlmock.Rows {
	return sqlmock.NewRows([]string{
		"id", "account_id", "username", "display_name", "bio", "avatar_url", "banner_url",
		"is_private", "pinned_post_id", "original_username", "original_display_name", "created_at", "updated_at",
	}).AddRow(
		p.ID, p.AccountID, p.Username, p.DisplayName, p.Bio, p.AvatarURL, p.BannerURL,
		p.IsPrivate, p.PinnedPostID, p.OriginalUsername, p.OriginalDisplayName, time.Now(), time.Now(),
	)
}

func countRows(count int64) *sqlmock.Rows {
	return sqlmock.NewRows([]string{"count"}).AddRow(count)
}

// expectProfileCounts couvre les trois comptages enchaines par profileToResponse :
// followers, following, posts.
func expectProfileCounts(mock sqlmock.Sqlmock, followers, following, posts int64) {
	mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnRows(countRows(followers))
	mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnRows(countRows(following))
	mock.ExpectQuery(`SELECT count\(\*\) FROM "posts"\."posts"`).WillReturnRows(countRows(posts))
}

func TestServiceMeWithMock(t *testing.T) {
	ctx := context.Background()

	t.Run("happy path", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		expectProfileCounts(mock, 3, 4, 5)

		resp, err := service.Me(ctx, accountID)
		if err != nil {
			t.Fatalf("Me() unexpected error: %v", err)
		}
		if !resp.CanViewContent {
			t.Fatalf("Me() CanViewContent = false, want true")
		}
		if resp.FollowersCount != 3 || resp.FollowingCount != 4 || resp.PostsCount != 5 {
			t.Fatalf("Me() counts = %+v, want 3/4/5", resp)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet expectations: %v", err)
		}
	})

	t.Run("profile not found", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnError(gorm.ErrRecordNotFound)

		_, err := service.Me(ctx, accountID)
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("Me() error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("counts query fails", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnError(errors.New("boom"))

		_, err := service.Me(ctx, accountID)
		if err == nil {
			t.Fatal("Me() expected error when followers count query fails")
		}
	})
}

func TestServiceShowWithMock(t *testing.T) {
	ctx := context.Background()

	t.Run("happy path anonymous viewer", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		target := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "bob"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(target))
		// BlockStatus avec viewerAccountID == uuid.Nil retourne immediatement sans requete.
		expectProfileCounts(mock, 1, 2, 3)

		resp, err := service.Show(ctx, "bob", uuid.Nil)
		if err != nil {
			t.Fatalf("Show() unexpected error: %v", err)
		}
		if resp.IsBlocked {
			t.Fatalf("Show() IsBlocked = true, want false for anonymous viewer")
		}
		if !resp.CanViewContent {
			t.Fatalf("Show() CanViewContent = false, want true for public profile")
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet expectations: %v", err)
		}
	})

	t.Run("empty username", func(t *testing.T) {
		db, _ := profileMockDB(t)
		service := NewService(NewRepository(db))

		_, err := service.Show(ctx, "   ", uuid.Nil)
		if !errors.Is(err, ErrInvalidUsername) {
			t.Fatalf("Show() error = %v, want ErrInvalidUsername", err)
		}
	})

	t.Run("target not found", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnError(gorm.ErrRecordNotFound)

		_, err := service.Show(ctx, "ghost", uuid.Nil)
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("Show() error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("target blocked viewer returns not found", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		viewerAccountID := uuid.New()
		viewerProfileID := uuid.New()
		target := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "bob"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(target))
		mock.ExpectQuery(`SELECT "id" FROM "profiles"\."profiles"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(viewerProfileID))
		mock.ExpectQuery(`SELECT \* FROM "social"\."blocks"`).
			WillReturnRows(sqlmock.NewRows([]string{"blocker_id", "blocked_id"}).
				AddRow(target.ID, viewerProfileID))

		_, err := service.Show(ctx, "bob", viewerAccountID)
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("Show() error = %v, want ErrRecordNotFound when target blocked viewer", err)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet expectations: %v", err)
		}
	})

	t.Run("viewer blocked target still visible with flag", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		viewerAccountID := uuid.New()
		viewerProfileID := uuid.New()
		target := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "bob"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(target))
		mock.ExpectQuery(`SELECT "id" FROM "profiles"\."profiles"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(viewerProfileID))
		mock.ExpectQuery(`SELECT \* FROM "social"\."blocks"`).
			WillReturnRows(sqlmock.NewRows([]string{"blocker_id", "blocked_id"}).
				AddRow(viewerProfileID, target.ID))
		expectProfileCounts(mock, 0, 0, 0)
		mock.ExpectQuery(`JOIN profiles\.profiles AS viewer`).
			WillReturnRows(countRows(0))
		mock.ExpectQuery(`social\.follow_requests`).
			WillReturnRows(countRows(0))

		resp, err := service.Show(ctx, "bob", viewerAccountID)
		if err != nil {
			t.Fatalf("Show() unexpected error: %v", err)
		}
		if !resp.IsBlocked {
			t.Fatalf("Show() IsBlocked = false, want true when viewer blocked target")
		}
		if !resp.CanViewContent {
			t.Fatalf("Show() CanViewContent = false, want true: target profile is public")
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet expectations: %v", err)
		}
	})

	t.Run("private profile not followed cannot view content", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		viewerAccountID := uuid.New()
		target := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "bob", IsPrivate: true}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(target))
		mock.ExpectQuery(`SELECT "id" FROM "profiles"\."profiles"`).
			WillReturnError(gorm.ErrRecordNotFound)

		_, err := service.Show(ctx, "bob", viewerAccountID)
		if err == nil {
			t.Fatal("Show() expected error when viewer profile lookup fails inside BlockStatus")
		}
	})

	t.Run("is following query error propagates", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		viewerAccountID := uuid.New()
		viewerProfileID := uuid.New()
		target := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "bob", IsPrivate: true}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(target))
		mock.ExpectQuery(`SELECT "id" FROM "profiles"\."profiles"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(viewerProfileID))
		mock.ExpectQuery(`SELECT \* FROM "social"\."blocks"`).
			WillReturnRows(sqlmock.NewRows([]string{"blocker_id", "blocked_id"}))
		expectProfileCounts(mock, 0, 0, 0)
		mock.ExpectQuery(`JOIN profiles\.profiles AS viewer`).
			WillReturnError(errors.New("boom"))

		_, err := service.Show(ctx, "bob", viewerAccountID)
		if err == nil {
			t.Fatal("Show() expected error when IsFollowing query fails")
		}
	})

	t.Run("pending follow request query error propagates", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		viewerAccountID := uuid.New()
		viewerProfileID := uuid.New()
		target := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "bob", IsPrivate: true}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(target))
		mock.ExpectQuery(`SELECT "id" FROM "profiles"\."profiles"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(viewerProfileID))
		mock.ExpectQuery(`SELECT \* FROM "social"\."blocks"`).
			WillReturnRows(sqlmock.NewRows([]string{"blocker_id", "blocked_id"}))
		expectProfileCounts(mock, 0, 0, 0)
		mock.ExpectQuery(`JOIN profiles\.profiles AS viewer`).
			WillReturnRows(countRows(0))
		mock.ExpectQuery(`social\.follow_requests`).
			WillReturnError(errors.New("boom"))

		_, err := service.Show(ctx, "bob", viewerAccountID)
		if err == nil {
			t.Fatal("Show() expected error when HasPendingFollowRequest query fails")
		}
	})

	t.Run("profileToResponse error propagates after block status check", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		target := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "bob"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(target))
		// viewerAccountID == uuid.Nil donc BlockStatus retourne immediatement (false, false, nil),
		// puis profileToResponse echoue sur le premier comptage : la branche d'erreur
		// "response, err := s.profileToResponse(...)" / "if err != nil" de Show() est exercee.
		mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnError(errors.New("boom"))

		_, err := service.Show(ctx, "bob", uuid.Nil)
		if err == nil {
			t.Fatal("Show() expected error when profileToResponse fails")
		}
	})

	t.Run("following private profile can view content", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		viewerAccountID := uuid.New()
		viewerProfileID := uuid.New()
		target := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "bob", IsPrivate: true}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(target))
		mock.ExpectQuery(`SELECT "id" FROM "profiles"\."profiles"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(viewerProfileID))
		mock.ExpectQuery(`SELECT \* FROM "social"\."blocks"`).
			WillReturnRows(sqlmock.NewRows([]string{"blocker_id", "blocked_id"}))
		expectProfileCounts(mock, 1, 1, 1)
		mock.ExpectQuery(`JOIN profiles\.profiles AS viewer`).
			WillReturnRows(countRows(1))

		resp, err := service.Show(ctx, "bob", viewerAccountID)
		if err != nil {
			t.Fatalf("Show() unexpected error: %v", err)
		}
		if !resp.IsFollowing || !resp.CanViewContent {
			t.Fatalf("Show() = %+v, want IsFollowing=true CanViewContent=true", resp)
		}
	})
}

func TestServiceUpdateMeWithMock(t *testing.T) {
	ctx := context.Background()

	t.Run("happy path updates all fields", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}
		displayName := " Alice "
		bio := " hello "
		avatar := " https://x/a.png "
		banner := " https://x/b.png "
		isPrivate := true

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		expectProfileCounts(mock, 0, 0, 0)

		resp, err := service.UpdateMe(ctx, accountID, updateProfileRequest{
			DisplayName: &displayName, Bio: &bio, AvatarURL: &avatar, BannerURL: &banner, IsPrivate: &isPrivate,
		})
		if err != nil {
			t.Fatalf("UpdateMe() unexpected error: %v", err)
		}
		if !resp.CanViewContent {
			t.Fatalf("UpdateMe() CanViewContent = false, want true")
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet expectations: %v", err)
		}
	})

	t.Run("profile not found", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnError(gorm.ErrRecordNotFound)

		_, err := service.UpdateMe(ctx, accountID, updateProfileRequest{})
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("UpdateMe() error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("empty display name rejected", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}
		blank := "   "

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))

		_, err := service.UpdateMe(ctx, accountID, updateProfileRequest{DisplayName: &blank})
		if !errors.Is(err, ErrInvalidDisplayName) {
			t.Fatalf("UpdateMe() error = %v, want ErrInvalidDisplayName", err)
		}
	})

	t.Run("update exec fails", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}
		bio := "hello"

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnError(errors.New("boom"))
		mock.ExpectRollback()

		_, err := service.UpdateMe(ctx, accountID, updateProfileRequest{Bio: &bio})
		if err == nil {
			t.Fatal("UpdateMe() expected error when UpdateProfile fails")
		}
	})

	t.Run("profileToResponse fails after update", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}
		bio := "hello"

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()
		mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnError(errors.New("boom"))

		_, err := service.UpdateMe(ctx, accountID, updateProfileRequest{Bio: &bio})
		if err == nil {
			t.Fatal("UpdateMe() expected error when profileToResponse fails")
		}
	})
}

func TestServicePreferencesWithMock(t *testing.T) {
	ctx := context.Background()

	t.Run("existing preferences returned", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."preferences"`).
			WillReturnRows(sqlmock.NewRows([]string{"profile_id", "locale", "theme", "updated_at"}).
				AddRow(profile.ID, "en", "dark", time.Now()))

		resp, err := service.Preferences(ctx, accountID)
		if err != nil {
			t.Fatalf("Preferences() unexpected error: %v", err)
		}
		if resp.Theme != "dark" || resp.Language != "en" {
			t.Fatalf("Preferences() = %+v, want dark/en", resp)
		}
	})

	t.Run("profile not found", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnError(gorm.ErrRecordNotFound)

		_, err := service.Preferences(ctx, accountID)
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("Preferences() error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("preferences lookup non-not-found error propagates", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."preferences"`).WillReturnError(errors.New("boom"))

		_, err := service.Preferences(ctx, accountID)
		if err == nil {
			t.Fatal("Preferences() expected error when preferences lookup fails")
		}
	})

	t.Run("missing preferences are created with defaults", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."preferences"`).WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectBegin()
		mock.ExpectExec(`INSERT INTO "profiles"\."preferences"`).
			WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		resp, err := service.Preferences(ctx, accountID)
		if err != nil {
			t.Fatalf("Preferences() unexpected error: %v", err)
		}
		if resp.Theme != "light" || resp.Language != "fr" {
			t.Fatalf("Preferences() = %+v, want default light/fr", resp)
		}
	})

	t.Run("create preferences fails", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."preferences"`).WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectBegin()
		mock.ExpectExec(`INSERT INTO "profiles"\."preferences"`).WillReturnError(errors.New("boom"))
		mock.ExpectRollback()

		_, err := service.Preferences(ctx, accountID)
		if err == nil {
			t.Fatal("Preferences() expected error when CreatePreferences fails")
		}
	})
}

func TestServiceUpdatePreferencesWithMock(t *testing.T) {
	ctx := context.Background()

	t.Run("updates existing preferences", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}
		theme := "dark"
		language := "en"

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."preferences"`).
			WillReturnRows(sqlmock.NewRows([]string{"profile_id", "locale", "theme", "updated_at"}).
				AddRow(profile.ID, "fr", "light", time.Now()))
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles"\."preferences"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		resp, err := service.UpdatePreferences(ctx, accountID, updatePreferencesRequest{Theme: &theme, Language: &language})
		if err != nil {
			t.Fatalf("UpdatePreferences() unexpected error: %v", err)
		}
		if resp.Theme != "dark" || resp.Language != "en" {
			t.Fatalf("UpdatePreferences() = %+v, want dark/en", resp)
		}
	})

	t.Run("creates preferences when missing", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}
		theme := "dark"

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."preferences"`).WillReturnError(gorm.ErrRecordNotFound)
		// NOTE: defaultPreferences() renseigne toujours ProfileID (= currentProfile.ID),
		// donc la branche "preferences.ProfileID == uuid.Nil" dans UpdatePreferences()
		// (service.go) n'est jamais vraie : meme quand les preferences n'existaient pas,
		// le repo execute un UPDATE (Save) et non un CreatePreferences. Code mort cote
		// prod, documente ici plutot que corrige (hors perimetre de cette tache).
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles"\."preferences"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		resp, err := service.UpdatePreferences(ctx, accountID, updatePreferencesRequest{Theme: &theme})
		if err != nil {
			t.Fatalf("UpdatePreferences() unexpected error: %v", err)
		}
		if resp.Theme != "dark" {
			t.Fatalf("UpdatePreferences() = %+v, want theme dark", resp)
		}
	})

	t.Run("profile not found", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnError(gorm.ErrRecordNotFound)

		_, err := service.UpdatePreferences(ctx, accountID, updatePreferencesRequest{})
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("UpdatePreferences() error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("preferences lookup error propagates", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."preferences"`).WillReturnError(errors.New("boom"))

		_, err := service.UpdatePreferences(ctx, accountID, updatePreferencesRequest{})
		if err == nil {
			t.Fatal("UpdatePreferences() expected error when preferences lookup fails")
		}
	})

	t.Run("update exec fails", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		profile := models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"}
		theme := "dark"

		mock.ExpectQuery(`SELECT \* FROM "profiles"`).WillReturnRows(profileRows(profile))
		mock.ExpectQuery(`SELECT \* FROM "profiles"\."preferences"`).
			WillReturnRows(sqlmock.NewRows([]string{"profile_id", "locale", "theme", "updated_at"}).
				AddRow(profile.ID, "fr", "light", time.Now()))
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles"\."preferences"`).WillReturnError(errors.New("boom"))
		mock.ExpectRollback()

		_, err := service.UpdatePreferences(ctx, accountID, updatePreferencesRequest{Theme: &theme})
		if err == nil {
			t.Fatal("UpdatePreferences() expected error when UpdatePreferences fails")
		}
	})
}

func TestServicePinUnpinPostWithMock(t *testing.T) {
	ctx := context.Background()

	t.Run("pin succeeds when owner", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		postID := uuid.New()

		mock.ExpectQuery(`SELECT count\(\*\) FROM posts\.posts`).WillReturnRows(countRows(1))
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		if err := service.PinPost(ctx, accountID, postID); err != nil {
			t.Fatalf("PinPost() unexpected error: %v", err)
		}
	})

	t.Run("pin rejected when not owner", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		postID := uuid.New()

		mock.ExpectQuery(`SELECT count\(\*\) FROM posts\.posts`).WillReturnRows(countRows(0))

		err := service.PinPost(ctx, accountID, postID)
		if !errors.Is(err, ErrNotPostOwner) {
			t.Fatalf("PinPost() error = %v, want ErrNotPostOwner", err)
		}
	})

	t.Run("ownership check fails", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		postID := uuid.New()

		mock.ExpectQuery(`SELECT count\(\*\) FROM posts\.posts`).WillReturnError(errors.New("boom"))

		err := service.PinPost(ctx, accountID, postID)
		if err == nil {
			t.Fatal("PinPost() expected error when ownership check fails")
		}
	})

	t.Run("set pinned post fails", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()
		postID := uuid.New()

		mock.ExpectQuery(`SELECT count\(\*\) FROM posts\.posts`).WillReturnRows(countRows(1))
		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnError(errors.New("boom"))
		mock.ExpectRollback()

		err := service.PinPost(ctx, accountID, postID)
		if err == nil {
			t.Fatal("PinPost() expected error when SetPinnedPost fails")
		}
	})

	t.Run("unpin succeeds", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()

		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		if err := service.UnpinPost(ctx, accountID); err != nil {
			t.Fatalf("UnpinPost() unexpected error: %v", err)
		}
	})

	t.Run("unpin fails", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))
		accountID := uuid.New()

		mock.ExpectBegin()
		mock.ExpectExec(`UPDATE "profiles" `).WillReturnError(errors.New("boom"))
		mock.ExpectRollback()

		if err := service.UnpinPost(ctx, accountID); err == nil {
			t.Fatal("UnpinPost() expected error when ClearPinnedPost fails")
		}
	})
}

func TestServiceProfileToResponseDisplayNameFallback(t *testing.T) {
	db, mock := profileMockDB(t)
	service := NewService(NewRepository(db))
	ctx := context.Background()
	blankDisplayName := "   "
	profile := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "alice", DisplayName: &blankDisplayName}

	expectProfileCounts(mock, 0, 0, 0)

	resp, err := service.profileToResponse(ctx, profile)
	if err != nil {
		t.Fatalf("profileToResponse() unexpected error: %v", err)
	}
	if resp.DisplayName != "alice" {
		t.Fatalf("profileToResponse() DisplayName = %q, want fallback to username", resp.DisplayName)
	}
}

func TestServiceProfileToResponseCountErrors(t *testing.T) {
	ctx := context.Background()
	profile := models.Profile{ID: uuid.New(), AccountID: uuid.New(), Username: "alice"}

	t.Run("following count fails", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))

		mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnRows(countRows(1))
		mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnError(errors.New("boom"))

		_, err := service.profileToResponse(ctx, profile)
		if err == nil {
			t.Fatal("profileToResponse() expected error when CountFollowing fails")
		}
	})

	t.Run("posts count fails", func(t *testing.T) {
		db, mock := profileMockDB(t)
		service := NewService(NewRepository(db))

		mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnRows(countRows(1))
		mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnRows(countRows(2))
		mock.ExpectQuery(`SELECT count\(\*\) FROM "posts"\."posts"`).WillReturnError(errors.New("boom"))

		_, err := service.profileToResponse(ctx, profile)
		if err == nil {
			t.Fatal("profileToResponse() expected error when CountPosts fails")
		}
	})
}
