package profile

import (
	"context"
	"testing"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
)

func TestPreferencesHelpers(t *testing.T) {
	profileID := uuid.New()
	defaults := defaultPreferences(profileID)
	if defaults.ProfileID != profileID || defaults.Theme != "light" || defaults.Locale != "fr" {
		t.Fatalf("defaultPreferences() = %+v, want light/fr", defaults)
	}

	response := preferencesToResponse(models.UserPreference{
		ProfileID: profileID,
		Theme:     "dark",
		Locale:    "en",
	})
	if response.Theme != "dark" || response.Language != "en" || !response.EmailNotifications || !response.PushNotifications {
		t.Fatalf("preferencesToResponse() = %+v, want mapped preferences with notifications enabled", response)
	}
}

func TestProfileServiceWorkflowsDryRun(t *testing.T) {
	service := NewService(NewRepository(profileDryRunDB(t)))
	ctx := context.Background()
	accountID := uuid.New()
	postID := uuid.New()
	displayName := "Alice"
	bio := "hello"
	theme := "dark"
	language := "fr"

	_, _ = service.Me(ctx, accountID)
	_, _ = service.Show(ctx, "alice", accountID)
	_, _ = service.UpdateMe(ctx, accountID, updateProfileRequest{DisplayName: &displayName, Bio: &bio})
	_, _ = service.Preferences(ctx, accountID)
	_, _ = service.UpdatePreferences(ctx, accountID, updatePreferencesRequest{Theme: &theme, Language: &language})
	_ = service.PinPost(ctx, accountID, postID)
	_ = service.UnpinPost(ctx, accountID)
	_, _ = service.profileToResponse(ctx, models.Profile{ID: uuid.New(), AccountID: accountID, Username: "alice"})
}
