// Package sanction porte les effets "secondaires" d'une sanction de moderation :
// pendant qu'un compte est banni ou suspendu, son profil est anonymise (username
// et display_name deviennent "user_<profileId>") et tous ses posts basculent en
// visibilite PRIVATE (donc invisibles a tous sauf a l'auteur, cf. canViewPost).
//
// Les valeurs d'origine sont memorisees dans les colonnes original_* afin d'etre
// restaurees lors de la levee de la sanction (manuelle par un moderateur, ou
// automatique a l'expiration d'une suspension). La logique est isolee ici car
// elle est partagee par le service moderation (application/levee) et le service
// auth (levee automatique d'une suspension expiree).
package sanction

import (
	"context"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// EnsureColumns verifie que les colonnes requises par les sanctions existent.
// Idempotent : sans effet si elles sont deja presentes.
// A appeler au demarrage du service qui execute des sanctions (moderation-service).
// Entree : db.
// Sortie : erreur eventuelle.
func EnsureColumns(db *gorm.DB) error {
	if err := db.Exec(`
		ALTER TABLE profiles.profiles
		  ADD COLUMN IF NOT EXISTS original_username     text,
		  ADD COLUMN IF NOT EXISTS original_display_name text
	`).Error; err != nil {
		return err
	}
	return db.Exec(`
		ALTER TABLE posts.posts
		  ADD COLUMN IF NOT EXISTS original_visibility text
	`).Error
}

// Apply anonymise le profil et masque les posts du compte vise.
// Idempotent : les profils deja anonymises (original_username deja renseigne) et
// les posts deja masques (original_visibility deja renseigne) sont ignores, ce
// qui rend l'enchainement suspension -> bannissement sans danger.
//
// Entree : ctx, db, accountID.
// Sortie : erreur eventuelle.
func Apply(ctx context.Context, db *gorm.DB, accountID uuid.UUID) error {
	if err := db.WithContext(ctx).Exec(`
		UPDATE profiles.profiles
		SET original_username = username,
		    original_display_name = display_name,
		    username = 'user_' || id::text,
		    display_name = 'user_' || id::text
		WHERE account_id = ? AND original_username IS NULL
	`, accountID).Error; err != nil {
		return err
	}

	return db.WithContext(ctx).Exec(`
		UPDATE posts.posts
		SET original_visibility = visibility::text,
		    visibility = 'PRIVATE'
		WHERE author_id IN (SELECT id FROM profiles.profiles WHERE account_id = ?)
		  AND original_visibility IS NULL
		  AND deleted_at IS NULL
	`, accountID).Error
}

// Lift restaure l'identite du profil et la visibilite d'origine des posts.
// Idempotent : sans effet si le compte n'avait pas ete anonymise/masque.
//
// Entree : ctx, db, accountID.
// Sortie : erreur eventuelle.
func Lift(ctx context.Context, db *gorm.DB, accountID uuid.UUID) error {
	if err := db.WithContext(ctx).Exec(`
		UPDATE posts.posts
		SET visibility = original_visibility::posts.post_visibility,
		    original_visibility = NULL
		WHERE author_id IN (SELECT id FROM profiles.profiles WHERE account_id = ?)
		  AND original_visibility IS NOT NULL
	`, accountID).Error; err != nil {
		return err
	}

	return db.WithContext(ctx).Exec(`
		UPDATE profiles.profiles
		SET username = original_username,
		    display_name = original_display_name,
		    original_username = NULL,
		    original_display_name = NULL
		WHERE account_id = ? AND original_username IS NOT NULL
	`, accountID).Error
}
