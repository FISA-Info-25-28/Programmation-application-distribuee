package sanction

import (
	"context"
	"regexp"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func newMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()

	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })

	gdb, err := gorm.Open(postgres.New(postgres.Config{
		Conn:                 sqlDB,
		PreferSimpleProtocol: true,
	}), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}

	return gdb, mock
}

func TestEnsureColumns(t *testing.T) {
	db, mock := newMockDB(t)
	mock.ExpectExec(regexp.QuoteMeta("ALTER TABLE profiles.profiles")).
		WillReturnResult(sqlmock.NewResult(0, 0))
	mock.ExpectExec(regexp.QuoteMeta("ALTER TABLE posts.posts")).
		WillReturnResult(sqlmock.NewResult(0, 0))

	if err := EnsureColumns(db); err != nil {
		t.Fatalf("EnsureColumns() unexpected error: %v", err)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestEnsureColumnsReturnsFirstError(t *testing.T) {
	db, mock := newMockDB(t)
	mock.ExpectExec(regexp.QuoteMeta("ALTER TABLE profiles.profiles")).
		WillReturnError(assertSanctionErr("profiles failed"))

	if err := EnsureColumns(db); err == nil {
		t.Fatal("EnsureColumns() expected first exec error")
	}
}

func TestApply(t *testing.T) {
	db, mock := newMockDB(t)
	accountID := uuid.New()

	mock.ExpectExec(regexp.QuoteMeta("UPDATE profiles.profiles")).
		WithArgs(accountID).
		WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectExec(regexp.QuoteMeta("UPDATE posts.posts")).
		WithArgs(accountID).
		WillReturnResult(sqlmock.NewResult(0, 2))

	if err := Apply(context.Background(), db, accountID); err != nil {
		t.Fatalf("Apply() unexpected error: %v", err)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestApplyReturnsProfileError(t *testing.T) {
	db, mock := newMockDB(t)
	accountID := uuid.New()

	mock.ExpectExec(regexp.QuoteMeta("UPDATE profiles.profiles")).
		WithArgs(accountID).
		WillReturnError(assertSanctionErr("profile update failed"))

	if err := Apply(context.Background(), db, accountID); err == nil {
		t.Fatal("Apply() expected profile update error")
	}
}

func TestLift(t *testing.T) {
	db, mock := newMockDB(t)
	accountID := uuid.New()

	mock.ExpectExec(regexp.QuoteMeta("UPDATE posts.posts")).
		WithArgs(accountID).
		WillReturnResult(sqlmock.NewResult(0, 2))
	mock.ExpectExec(regexp.QuoteMeta("UPDATE profiles.profiles")).
		WithArgs(accountID).
		WillReturnResult(sqlmock.NewResult(0, 1))

	if err := Lift(context.Background(), db, accountID); err != nil {
		t.Fatalf("Lift() unexpected error: %v", err)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations: %v", err)
	}
}

func TestLiftReturnsPostError(t *testing.T) {
	db, mock := newMockDB(t)
	accountID := uuid.New()

	mock.ExpectExec(regexp.QuoteMeta("UPDATE posts.posts")).
		WithArgs(accountID).
		WillReturnError(assertSanctionErr("post update failed"))

	if err := Lift(context.Background(), db, accountID); err == nil {
		t.Fatal("Lift() expected post update error")
	}
}

type assertSanctionErr string

func (e assertSanctionErr) Error() string { return string(e) }
