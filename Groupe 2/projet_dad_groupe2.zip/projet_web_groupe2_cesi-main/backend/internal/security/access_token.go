package security

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"strings"
	"time"

	"breezy/backend/internal/config"
	"github.com/google/uuid"
)

// AccessClaims represente les informations utiles portees par le JWT d'acces.
type AccessClaims struct {
	Subject   string `json:"sub"`
	Role      string `json:"role"`
	ExpiresAt int64  `json:"exp"`
}

// SignAccessToken cree un JWT HMAC-SHA256.
// Entree : accountID, role, ttl.
// validite.
// Sortie : valeurs retour de la fonction.
func SignAccessToken(accountID uuid.UUID, role string, ttl time.Duration) (string, error) {
	now := time.Now().UTC()
	claims := AccessClaims{
		Subject:   accountID.String(),
		Role:      role,
		ExpiresAt: now.Add(ttl).Unix(),
	}

	header := map[string]string{"alg": "HS256", "typ": "JWT"}
	return signJWT(header, claims)
}

// VerifyAccessToken valide un JWT d'acces.
// Entree : token.
// Sortie : valeurs retour de la fonction.
// signature, decodage ou expiration.
func VerifyAccessToken(token string) (AccessClaims, error) {
	var claims AccessClaims

	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return claims, errors.New("invalid token format")
	}

	signingInput := parts[0] + "." + parts[1]
	expectedSignature := hmacSHA256(signingInput, jwtSecret())
	signature, err := base64.RawURLEncoding.DecodeString(parts[2])
	if err != nil {
		return claims, err
	}
	if !hmac.Equal(signature, expectedSignature) {
		return claims, errors.New("invalid token signature")
	}

	payload, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return claims, err
	}
	if err := json.Unmarshal(payload, &claims); err != nil {
		return claims, err
	}
	if time.Now().UTC().Unix() >= claims.ExpiresAt {
		return claims, errors.New("expired token")
	}

	return claims, nil
}

// signJWT assemble un JWT.
// Entree : header, claims.
// Sortie : valeurs retour de la fonction.
func signJWT(header map[string]string, claims AccessClaims) (string, error) {
	headerJSON, err := json.Marshal(header)
	if err != nil {
		return "", err
	}
	claimsJSON, err := json.Marshal(claims)
	if err != nil {
		return "", err
	}

	signingInput := base64.RawURLEncoding.EncodeToString(headerJSON) + "." + base64.RawURLEncoding.EncodeToString(claimsJSON)
	signature := base64.RawURLEncoding.EncodeToString(hmacSHA256(signingInput, jwtSecret()))
	return signingInput + "." + signature, nil
}

// hmacSHA256 calcule une signature HMAC-SHA256.
// Entree : value, secret.
// Sortie : valeur retour de type []byte.
func hmacSHA256(value, secret string) []byte {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(value))
	return mac.Sum(nil)
}

// jwtSecret lit le secret JWT obligatoire.
// Entree : aucune entree directe.
// Sortie : valeur retour de type string.
func jwtSecret() string {
	secret := config.Env("JWT_SECRET", "")
	if secret == "" {
		panic("JWT_SECRET is required")
	}
	return secret
}
