package security

import (
	"encoding/base64"
	"strings"
	"testing"
	"time"

	"github.com/google/uuid"
)

func TestSignAndVerifyAccessToken(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")
	accountID := uuid.New()

	token, err := SignAccessToken(accountID, "ADMIN", time.Hour)
	if err != nil {
		t.Fatalf("SignAccessToken() unexpected error: %v", err)
	}

	claims, err := VerifyAccessToken(token)
	if err != nil {
		t.Fatalf("VerifyAccessToken() unexpected error: %v", err)
	}
	if claims.Subject != accountID.String() || claims.Role != "ADMIN" {
		t.Fatalf("VerifyAccessToken() claims = %+v, want account/role", claims)
	}
}

func TestVerifyAccessTokenRejectsInvalidTokens(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")

	if _, err := VerifyAccessToken("not-a-jwt"); err == nil {
		t.Fatal("VerifyAccessToken() expected format error")
	}

	expired, err := SignAccessToken(uuid.New(), "USER", -time.Hour)
	if err != nil {
		t.Fatalf("SignAccessToken(expired) unexpected error: %v", err)
	}
	if _, err := VerifyAccessToken(expired); err == nil {
		t.Fatal("VerifyAccessToken() expected expired token error")
	}

	token, err := SignAccessToken(uuid.New(), "USER", time.Hour)
	if err != nil {
		t.Fatalf("SignAccessToken() unexpected error: %v", err)
	}
	parts := strings.Split(token, ".")
	parts[2] = "invalid"
	if _, err := VerifyAccessToken(strings.Join(parts, ".")); err == nil {
		t.Fatal("VerifyAccessToken() expected invalid signature error")
	}
}

func TestVerifyAccessTokenRejectsBadSignatureEncoding(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")

	if _, err := VerifyAccessToken("aGVhZGVy.cGF5bG9hZA.not base64!!!"); err == nil {
		t.Fatal("VerifyAccessToken() expected signature decode error")
	}
}

func TestVerifyAccessTokenRejectsBadPayloadEncoding(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")

	header := base64.RawURLEncoding.EncodeToString([]byte(`{"alg":"HS256","typ":"JWT"}`))
	payload := "not base64!!!"
	signingInput := header + "." + payload
	signature := base64.RawURLEncoding.EncodeToString(hmacSHA256(signingInput, "test-secret"))
	token := signingInput + "." + signature

	if _, err := VerifyAccessToken(token); err == nil {
		t.Fatal("VerifyAccessToken() expected payload decode error")
	}
}

func TestVerifyAccessTokenRejectsInvalidPayloadJSON(t *testing.T) {
	t.Setenv("JWT_SECRET", "test-secret")

	header := base64.RawURLEncoding.EncodeToString([]byte(`{"alg":"HS256","typ":"JWT"}`))
	payload := base64.RawURLEncoding.EncodeToString([]byte("not-json"))
	signingInput := header + "." + payload
	signature := base64.RawURLEncoding.EncodeToString(hmacSHA256(signingInput, "test-secret"))
	token := signingInput + "." + signature

	if _, err := VerifyAccessToken(token); err == nil {
		t.Fatal("VerifyAccessToken() expected payload JSON unmarshal error")
	}
}

func TestJWTSecretPanicsWhenMissing(t *testing.T) {
	t.Setenv("JWT_SECRET", "")
	defer func() {
		if recover() == nil {
			t.Fatal("jwtSecret() expected panic")
		}
	}()

	_ = jwtSecret()
}
