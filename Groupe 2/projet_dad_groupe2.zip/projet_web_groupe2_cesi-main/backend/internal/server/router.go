package server

import (
	"log/slog"
	"net/http"

	"github.com/gin-gonic/gin"
)

type errorResponse struct {
	Error string `json:"error"`
}

// NewRouter construit un routeur Gin avec une gestion uniforme des erreurs.
// Entree : aucune entree directe.
// Sortie : valeur retour de type *gin.Engine.
func NewRouter() *gin.Engine {
	router := gin.New()
	router.HandleMethodNotAllowed = true
	router.Use(gin.Logger(), JSONRecovery())
	router.NoRoute(func(c *gin.Context) {
		JSONError(c, http.StatusNotFound, "route not found")
	})
	router.NoMethod(func(c *gin.Context) {
		JSONError(c, http.StatusMethodNotAllowed, "method not allowed")
	})
	return router
}

// JSONError ecrit une erreur HTTP au format commun de l'API.
// Entree : c, status, message.
// Sortie : aucune valeur.
func JSONError(c *gin.Context, status int, message string) {
	c.JSON(status, errorResponse{Error: message})
}

// JSONRecovery transforme les panics applicatifs en erreurs JSON 500.
// Entree : aucune entree directe.
// Sortie : valeur retour de type gin.HandlerFunc.
func JSONRecovery() gin.HandlerFunc {
	return gin.CustomRecovery(func(c *gin.Context, recovered any) {
		slog.Error("panic recovered", "error", recovered)
		JSONError(c, http.StatusInternalServerError, "internal server error")
	})
}
