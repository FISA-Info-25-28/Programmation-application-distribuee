package server

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
)

func TestNewRouterReturnsJSONForUnknownRoute(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := NewRouter()

	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodGet, "/unknown", nil)

	router.ServeHTTP(recorder, request)

	assertJSONError(t, recorder, http.StatusNotFound, `{"error":"route not found"}`)
}

func TestNewRouterReturnsJSONForMethodNotAllowed(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := NewRouter()
	router.HandleMethodNotAllowed = true
	router.GET("/known", func(c *gin.Context) {
		c.Status(http.StatusNoContent)
	})

	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodPost, "/known", nil)

	router.ServeHTTP(recorder, request)

	assertJSONError(t, recorder, http.StatusMethodNotAllowed, `{"error":"method not allowed"}`)
}

func TestNewRouterRecoversPanicsAsJSON(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := NewRouter()
	router.GET("/panic", func(c *gin.Context) {
		panic("boom")
	})

	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodGet, "/panic", nil)

	router.ServeHTTP(recorder, request)

	assertJSONError(t, recorder, http.StatusInternalServerError, `{"error":"internal server error"}`)
}

func assertJSONError(t *testing.T, recorder *httptest.ResponseRecorder, status int, body string) {
	t.Helper()

	if recorder.Code != status {
		t.Fatalf("expected status %d, got %d", status, recorder.Code)
	}
	if contentType := recorder.Header().Get("Content-Type"); contentType != "application/json; charset=utf-8" {
		t.Fatalf("expected JSON content type, got %q", contentType)
	}
	if recorder.Body.String() != body {
		t.Fatalf("expected body %s, got %s", body, recorder.Body.String())
	}
}
