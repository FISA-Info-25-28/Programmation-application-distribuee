package server

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"
)

// Run demarre un serveur HTTP.
// Entree : port, handler.
// Sortie : erreur eventuelle.
// suite a un signal SIGINT/SIGTERM.
func Run(port string, handler http.Handler) error {
	return run(port, handler, "", "")
}

// RunTLS demarre un serveur HTTPS avec le certificat et la cle fournis.
// Utilise par l'api-gateway, seul point d'entree public, pour chiffrer le
// trafic en transit (defense en profondeur en complement du TLS termine par
// nginx en production).
// Entree : port, handler, certFile, keyFile.
// Sortie : erreur eventuelle.
func RunTLS(port string, handler http.Handler, certFile, keyFile string) error {
	return run(port, handler, certFile, keyFile)
}

// run demarre le serveur HTTP(S) et gere l'arret propre sur SIGINT/SIGTERM.
// Si certFile/keyFile sont fournis, le serveur ecoute en TLS.
// Entree : port, handler, certFile, keyFile.
// Sortie : erreur eventuelle.
func run(port string, handler http.Handler, certFile, keyFile string) error {
	srv := &http.Server{
		Addr:              ":" + port,
		Handler:           handler,
		ReadHeaderTimeout: 5 * time.Second,
	}

	errs := make(chan error, 1)
	go func() {
		if certFile != "" && keyFile != "" {
			slog.Info("server started (tls)", "addr", srv.Addr)
			errs <- srv.ListenAndServeTLS(certFile, keyFile)
			return
		}
		slog.Info("server started", "addr", srv.Addr)
		errs <- srv.ListenAndServe()
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)

	select {
	case err := <-errs:
		if errors.Is(err, http.ErrServerClosed) {
			return nil
		}
		return err
	case <-stop:
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		return srv.Shutdown(ctx)
	}
}
