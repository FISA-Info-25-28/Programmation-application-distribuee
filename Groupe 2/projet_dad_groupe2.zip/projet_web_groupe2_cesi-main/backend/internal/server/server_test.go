package server

import (
	"net/http"
	"testing"
)

func TestRunReturnsListenError(t *testing.T) {
	err := Run("bad port", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}))
	if err == nil {
		t.Fatal("Run() expected listen error for invalid port")
	}
}
