package social

import (
	"time"

	"github.com/google/uuid"
)

type userResponse struct {
	ID             uuid.UUID `json:"id"`
	ProfileID      uuid.UUID `json:"profileId"`
	Username       string    `json:"username"`
	DisplayName    string    `json:"displayName"`
	Email          string    `json:"email"`
	Role           string    `json:"role"`
	Bio            *string   `json:"bio"`
	AvatarURL      *string   `json:"avatarUrl"`
	FollowersCount int64     `json:"followersCount"`
	FollowingCount int64     `json:"followingCount"`
	PostsCount     int64     `json:"postsCount"`
	CreatedAt      time.Time `json:"createdAt"`
}

type paginatedUsersResponse struct {
	Users []userResponse `json:"users"`
	Page  int            `json:"page"`
	Limit int            `json:"limit"`
	Total int64          `json:"total"`
}

type followResponse struct {
	Following      bool `json:"following"`
	RequestPending bool `json:"requestPending"`
}

type blockResponse struct {
	Blocked bool `json:"blocked"`
}
