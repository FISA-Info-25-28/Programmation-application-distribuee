package social

import (
	"testing"
	"time"

	"github.com/google/uuid"
)

func TestSocialDTOFields(t *testing.T) {
	id := uuid.New()
	profileID := uuid.New()
	bio := "hello"
	response := userResponse{
		ID:             id,
		ProfileID:      profileID,
		Username:       "alice",
		DisplayName:    "Alice",
		Email:          "a@example.com",
		Role:           "USER",
		Bio:            &bio,
		FollowersCount: 1,
		FollowingCount: 2,
		PostsCount:     3,
		CreatedAt:      time.Now(),
	}
	page := paginatedUsersResponse{Users: []userResponse{response}, Page: 1, Limit: 10, Total: 1}
	if page.Users[0].ID != id || page.Users[0].ProfileID != profileID || page.Total != 1 {
		t.Fatalf("paginatedUsersResponse = %+v, want assigned values", page)
	}

	if !(followResponse{Following: true}).Following || !(blockResponse{Blocked: true}).Blocked {
		t.Fatal("social response DTOs should keep boolean values")
	}
}
