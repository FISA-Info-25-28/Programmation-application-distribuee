package social

import (
	"errors"
	"net/http"
	"strconv"

	"breezy/backend/internal/config"
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Handler struct {
	db      *gorm.DB
	service *Service
}

func NewHandler(db *gorm.DB) *Handler {
	repo := NewRepository(db)
	return &Handler{
		db:      db,
		service: NewService(repo),
	}
}

func (h *Handler) Health(c *gin.Context) {
	dbStatus := "ok"
	if h.db == nil {
		dbStatus = "unavailable"
	} else if sqlDB, err := h.db.DB(); err != nil || sqlDB.PingContext(c.Request.Context()) != nil {
		dbStatus = "error"
	}

	c.JSON(http.StatusOK, gin.H{
		"service": config.Env("SERVICE_NAME", "social-service"),
		"status":  "ok",
		"db":      dbStatus,
	})
}

func (h *Handler) Follow(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	targetProfileID, ok := h.profileIDParam(c)
	if !ok {
		return
	}

	response, err := h.service.Follow(c.Request.Context(), accountID, targetProfileID)
	if err != nil {
		h.handleSocialError(c, err, "failed to follow profile")
		return
	}

	c.JSON(http.StatusCreated, response)
}

func (h *Handler) Unfollow(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	targetProfileID, ok := h.profileIDParam(c)
	if !ok {
		return
	}

	response, err := h.service.Unfollow(c.Request.Context(), accountID, targetProfileID)
	if err != nil {
		h.handleSocialError(c, err, "failed to unfollow profile")
		return
	}

	c.JSON(http.StatusOK, response)
}

func (h *Handler) Block(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	targetProfileID, ok := h.profileIDParam(c)
	if !ok {
		return
	}
	response, err := h.service.Block(c.Request.Context(), accountID, targetProfileID)
	if err != nil {
		h.handleSocialError(c, err, "failed to block profile")
		return
	}
	c.JSON(http.StatusCreated, response)
}

func (h *Handler) Unblock(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	targetProfileID, ok := h.profileIDParam(c)
	if !ok {
		return
	}
	response, err := h.service.Unblock(c.Request.Context(), accountID, targetProfileID)
	if err != nil {
		h.handleSocialError(c, err, "failed to unblock profile")
		return
	}
	c.JSON(http.StatusOK, response)
}

// BlockedProfiles expose la liste paginee des profils bloques par le compte connecte.
// Entree : c.
// Sortie HTTP : JSON pagine contenant les profils bloques.
func (h *Handler) BlockedProfiles(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	response, err := h.service.BlockedProfiles(c.Request.Context(), accountID, queryInt(c, "page", 1), queryInt(c, "limit", 20))
	if err != nil {
		h.handleSocialError(c, err, "failed to fetch blocked profiles")
		return
	}
	c.JSON(http.StatusOK, response)
}

func (h *Handler) AcceptFollowRequest(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	requesterID, ok := h.profileIDParam(c)
	if !ok {
		return
	}
	response, err := h.service.AcceptFollowRequest(c.Request.Context(), accountID, requesterID)
	if err != nil {
		h.handleSocialError(c, err, "failed to accept follow request")
		return
	}
	c.JSON(http.StatusOK, response)
}

func (h *Handler) RejectFollowRequest(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}
	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}
	requesterID, ok := h.profileIDParam(c)
	if !ok {
		return
	}
	if err := h.service.RejectFollowRequest(c.Request.Context(), accountID, requesterID); err != nil {
		h.handleSocialError(c, err, "failed to reject follow request")
		return
	}
	c.JSON(http.StatusOK, gin.H{"ok": true})
}

func (h *Handler) Followers(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	profileID, ok := h.profileIDParam(c)
	if !ok {
		return
	}

	response, err := h.service.Followers(c.Request.Context(), profileID, queryInt(c, "page", 1), queryInt(c, "limit", 20))
	if err != nil {
		h.handleSocialError(c, err, "failed to fetch followers")
		return
	}

	c.JSON(http.StatusOK, response)
}

func (h *Handler) Following(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	profileID, ok := h.profileIDParam(c)
	if !ok {
		return
	}

	response, err := h.service.Following(c.Request.Context(), profileID, queryInt(c, "page", 1), queryInt(c, "limit", 20))
	if err != nil {
		h.handleSocialError(c, err, "failed to fetch following")
		return
	}

	c.JSON(http.StatusOK, response)
}

func (h *Handler) databaseAvailable(c *gin.Context) bool {
	if h.db != nil {
		return true
	}

	c.JSON(http.StatusServiceUnavailable, gin.H{"error": "database unavailable"})
	return false
}

func (h *Handler) profileIDParam(c *gin.Context) (uuid.UUID, bool) {
	profileID, err := uuid.Parse(c.Param("profileId"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid profile id"})
		return uuid.Nil, false
	}

	return profileID, true
}

func (h *Handler) handleSocialError(c *gin.Context, err error, fallbackMessage string) {
	switch {
	case errors.Is(err, ErrCannotFollowSelf):
		c.JSON(http.StatusBadRequest, gin.H{"error": "cannot follow yourself"})
	case errors.Is(err, ErrCannotBlockSelf):
		c.JSON(http.StatusBadRequest, gin.H{"error": "cannot block yourself"})
	case errors.Is(err, ErrBlockedRelation):
		c.JSON(http.StatusConflict, gin.H{"error": "blocked relationship"})
	case IsNotFound(err):
		c.JSON(http.StatusNotFound, gin.H{"error": "profile not found"})
	default:
		c.JSON(http.StatusInternalServerError, gin.H{"error": fallbackMessage})
	}
}

func queryInt(c *gin.Context, key string, fallback int) int {
	value, err := strconv.Atoi(c.Query(key))
	if err != nil {
		return fallback
	}
	return value
}
