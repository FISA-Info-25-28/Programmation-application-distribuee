package social

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"breezy/backend/internal/middleware"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// closedSocialDB ouvre une connexion GORM pilotee par sqlmock puis ferme la
// connexion sous-jacente immediatement : toute requete echoue, ce qui
// permet d'exercer les branches d'erreur 500 des handlers ainsi que la
// branche "db: error" de Health. Meme principe que
// internal/post/handler_test.go (closedPostDB) et
// internal/messages/handler_database_failure_test.go (closedMessagesDB).
func closedSocialDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	mock.ExpectClose()
	if err := sqlDB.Close(); err != nil {
		t.Fatalf("Close() unexpected error: %v", err)
	}
	return db
}

func TestSocialHandlerHealthDatabaseError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(closedSocialDB(t))

	router := gin.New()
	router.GET("/health", handler.Health)

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200", rec.Code)
	}
	if !strings.Contains(rec.Body.String(), `"db":"error"`) {
		t.Fatalf("GET /health body = %s, want db error status", rec.Body.String())
	}
}

func TestSocialHandlerMissingAccount(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(closedSocialDB(t))
	id := uuid.NewString()

	tests := []struct {
		method string
		path   string
		setup  func(*gin.Engine)
	}{
		{method: http.MethodPost, path: "/follow/" + id, setup: func(r *gin.Engine) { r.POST("/follow/:profileId", handler.Follow) }},
		{method: http.MethodDelete, path: "/follow/" + id, setup: func(r *gin.Engine) { r.DELETE("/follow/:profileId", handler.Unfollow) }},
		{method: http.MethodPost, path: "/block/" + id, setup: func(r *gin.Engine) { r.POST("/block/:profileId", handler.Block) }},
		{method: http.MethodDelete, path: "/block/" + id, setup: func(r *gin.Engine) { r.DELETE("/block/:profileId", handler.Unblock) }},
		{method: http.MethodPost, path: "/follow-requests/" + id + "/accept", setup: func(r *gin.Engine) { r.POST("/follow-requests/:profileId/accept", handler.AcceptFollowRequest) }},
		{method: http.MethodDelete, path: "/follow-requests/" + id, setup: func(r *gin.Engine) { r.DELETE("/follow-requests/:profileId", handler.RejectFollowRequest) }},
	}

	for _, tt := range tests {
		router := gin.New()
		tt.setup(router)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("%s %s status = %d, want 500 (missing account)", tt.method, tt.path, rec.Code)
		}
	}
}

func TestSocialHandlerInvalidProfileID(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(closedSocialDB(t))
	accountID := uuid.New()

	router := gin.New()
	router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
	router.POST("/follow/:profileId", handler.Follow)
	router.DELETE("/follow/:profileId", handler.Unfollow)
	router.POST("/block/:profileId", handler.Block)
	router.DELETE("/block/:profileId", handler.Unblock)
	router.POST("/follow-requests/:profileId/accept", handler.AcceptFollowRequest)
	router.DELETE("/follow-requests/:profileId", handler.RejectFollowRequest)
	router.GET("/:profileId/followers", handler.Followers)
	router.GET("/:profileId/following", handler.Following)

	tests := []struct {
		method string
		path   string
	}{
		{method: http.MethodPost, path: "/follow/not-a-uuid"},
		{method: http.MethodDelete, path: "/follow/not-a-uuid"},
		{method: http.MethodPost, path: "/block/not-a-uuid"},
		{method: http.MethodDelete, path: "/block/not-a-uuid"},
		{method: http.MethodPost, path: "/follow-requests/not-a-uuid/accept"},
		{method: http.MethodDelete, path: "/follow-requests/not-a-uuid"},
		{method: http.MethodGet, path: "/not-a-uuid/followers"},
		{method: http.MethodGet, path: "/not-a-uuid/following"},
	}

	for _, tt := range tests {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != http.StatusBadRequest {
			t.Fatalf("%s %s status = %d, want 400", tt.method, tt.path, rec.Code)
		}
	}
}

func TestSocialHandlerDatabaseFailures(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(closedSocialDB(t))
	accountID := uuid.New()
	targetID := uuid.NewString()

	tests := []struct {
		name, method, path string
		setup              func(*gin.Engine)
	}{
		{name: "follow", method: http.MethodPost, path: "/follow/" + targetID, setup: func(r *gin.Engine) { r.POST("/follow/:profileId", handler.Follow) }},
		{name: "unfollow", method: http.MethodDelete, path: "/follow/" + targetID, setup: func(r *gin.Engine) { r.DELETE("/follow/:profileId", handler.Unfollow) }},
		{name: "block", method: http.MethodPost, path: "/block/" + targetID, setup: func(r *gin.Engine) { r.POST("/block/:profileId", handler.Block) }},
		{name: "unblock", method: http.MethodDelete, path: "/block/" + targetID, setup: func(r *gin.Engine) { r.DELETE("/block/:profileId", handler.Unblock) }},
		{name: "accept", method: http.MethodPost, path: "/follow-requests/" + targetID + "/accept", setup: func(r *gin.Engine) { r.POST("/follow-requests/:profileId/accept", handler.AcceptFollowRequest) }},
		{name: "reject", method: http.MethodDelete, path: "/follow-requests/" + targetID, setup: func(r *gin.Engine) { r.DELETE("/follow-requests/:profileId", handler.RejectFollowRequest) }},
		{name: "followers", method: http.MethodGet, path: "/" + targetID + "/followers", setup: func(r *gin.Engine) { r.GET("/:profileId/followers", handler.Followers) }},
		{name: "following", method: http.MethodGet, path: "/" + targetID + "/following", setup: func(r *gin.Engine) { r.GET("/:profileId/following", handler.Following) }},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
			tt.setup(router)
			rec := httptest.NewRecorder()
			router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
			if rec.Code != http.StatusInternalServerError {
				t.Fatalf("%s %s status = %d, want 500: %s", tt.method, tt.path, rec.Code, rec.Body.String())
			}
		})
	}
}
