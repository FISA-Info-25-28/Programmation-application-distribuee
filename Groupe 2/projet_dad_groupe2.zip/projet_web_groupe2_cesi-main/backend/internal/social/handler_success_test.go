package social

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"breezy/backend/internal/middleware"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// newSuccessHandler construit un Handler dont la base de donnees est non nil
// (pour passer databaseAvailable) mais dont le service est pilote par un
// fakeSocialRepo, afin d'exercer les chemins de succes (200/201) des
// handlers HTTP sans dependre d'une vraie base Postgres. La connexion gorm
// n'est jamais sollicitee : seul handler.service (un fakeSocialRepo) execute
// la logique metier.
func newSuccessHandler(t *testing.T, repo *fakeSocialRepo) *Handler {
	t.Helper()
	sqlDB, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return &Handler{db: db, service: &Service{repo: repo}}
}

func TestSocialHandlerSuccessPaths(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()

	t.Run("follow", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		handler := newSuccessHandler(t, repo)

		router := gin.New()
		router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
		router.POST("/follow/:profileId", handler.Follow)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/follow/"+target.String(), nil))
		if rec.Code != http.StatusCreated {
			t.Fatalf("Follow() status = %d, want 201: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unfollow", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.following[pairKey(repo.currentProfileID, target)] = true
		handler := newSuccessHandler(t, repo)

		router := gin.New()
		router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
		router.DELETE("/follow/:profileId", handler.Unfollow)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodDelete, "/follow/"+target.String(), nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Unfollow() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("block", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		handler := newSuccessHandler(t, repo)

		router := gin.New()
		router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
		router.POST("/block/:profileId", handler.Block)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/block/"+target.String(), nil))
		if rec.Code != http.StatusCreated {
			t.Fatalf("Block() status = %d, want 201: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unblock", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.blockedPairs[pairKey(repo.currentProfileID, target)] = true
		handler := newSuccessHandler(t, repo)

		router := gin.New()
		router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
		router.DELETE("/block/:profileId", handler.Unblock)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodDelete, "/block/"+target.String(), nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Unblock() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("accept follow request", func(t *testing.T) {
		repo := newFakeSocialRepo()
		requester := uuid.New()
		repo.pendingRequests[pairKey(requester, repo.currentProfileID)] = true
		handler := newSuccessHandler(t, repo)

		router := gin.New()
		router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
		router.POST("/follow-requests/:profileId/accept", handler.AcceptFollowRequest)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/follow-requests/"+requester.String()+"/accept", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("AcceptFollowRequest() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("reject follow request", func(t *testing.T) {
		repo := newFakeSocialRepo()
		requester := uuid.New()
		repo.pendingRequests[pairKey(requester, repo.currentProfileID)] = true
		handler := newSuccessHandler(t, repo)

		router := gin.New()
		router.Use(func(c *gin.Context) { c.Set(middleware.ContextAccountID, accountID); c.Next() })
		router.DELETE("/follow-requests/:profileId", handler.RejectFollowRequest)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodDelete, "/follow-requests/"+requester.String(), nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("RejectFollowRequest() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("followers", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		handler := newSuccessHandler(t, repo)

		router := gin.New()
		router.GET("/:profileId/followers", handler.Followers)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/"+target.String()+"/followers", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Followers() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("following", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		handler := newSuccessHandler(t, repo)

		router := gin.New()
		router.GET("/:profileId/following", handler.Following)

		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/"+target.String()+"/following", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Following() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})
}
