package social

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

func TestSocialHandlerDatabaseUnavailable(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(nil)
	id := uuid.NewString()

	tests := []struct {
		method string
		path   string
		setup  func(*gin.Engine)
		want   int
	}{
		{method: http.MethodGet, path: "/health", setup: func(r *gin.Engine) { r.GET("/health", handler.Health) }, want: http.StatusOK},
		{method: http.MethodPost, path: "/follow/" + id, setup: func(r *gin.Engine) { r.POST("/follow/:profileId", handler.Follow) }, want: http.StatusServiceUnavailable},
		{method: http.MethodDelete, path: "/follow/" + id, setup: func(r *gin.Engine) { r.DELETE("/follow/:profileId", handler.Unfollow) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/block/" + id, setup: func(r *gin.Engine) { r.POST("/block/:profileId", handler.Block) }, want: http.StatusServiceUnavailable},
		{method: http.MethodDelete, path: "/block/" + id, setup: func(r *gin.Engine) { r.DELETE("/block/:profileId", handler.Unblock) }, want: http.StatusServiceUnavailable},
		{method: http.MethodPost, path: "/follow-requests/" + id + "/accept", setup: func(r *gin.Engine) { r.POST("/follow-requests/:profileId/accept", handler.AcceptFollowRequest) }, want: http.StatusServiceUnavailable},
		{method: http.MethodDelete, path: "/follow-requests/" + id, setup: func(r *gin.Engine) { r.DELETE("/follow-requests/:profileId", handler.RejectFollowRequest) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/" + id + "/followers", setup: func(r *gin.Engine) { r.GET("/:profileId/followers", handler.Followers) }, want: http.StatusServiceUnavailable},
		{method: http.MethodGet, path: "/" + id + "/following", setup: func(r *gin.Engine) { r.GET("/:profileId/following", handler.Following) }, want: http.StatusServiceUnavailable},
	}

	for _, tt := range tests {
		router := gin.New()
		tt.setup(router)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != tt.want {
			t.Fatalf("%s %s status = %d, want %d", tt.method, tt.path, rec.Code, tt.want)
		}
	}
}

func TestSocialHandlerHelpers(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := &Handler{}

	router := gin.New()
	router.GET("/:profileId", func(c *gin.Context) {
		if _, ok := handler.profileIDParam(c); ok {
			t.Fatal("profileIDParam() should reject invalid UUID")
		}
	})
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/bad", nil))
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("profileIDParam status = %d, want 400", rec.Code)
	}

	for _, tt := range []struct {
		err  error
		want int
	}{
		{err: ErrCannotFollowSelf, want: http.StatusBadRequest},
		{err: ErrCannotBlockSelf, want: http.StatusBadRequest},
		{err: ErrBlockedRelation, want: http.StatusConflict},
		{err: gorm.ErrRecordNotFound, want: http.StatusNotFound},
		{err: assertErr("boom"), want: http.StatusInternalServerError},
	} {
		rec := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(rec)
		handler.handleSocialError(c, tt.err, "fallback")
		if rec.Code != tt.want {
			t.Fatalf("handleSocialError(%v) status = %d, want %d", tt.err, rec.Code, tt.want)
		}
	}

	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Request = httptest.NewRequest(http.MethodGet, "/?page=bad&limit=7", nil)
	if got := queryInt(c, "page", 1); got != 1 {
		t.Fatalf("queryInt(invalid) = %d, want fallback", got)
	}
	if got := queryInt(c, "limit", 20); got != 7 {
		t.Fatalf("queryInt(valid) = %d, want 7", got)
	}
}

type assertErr string

func (e assertErr) Error() string { return string(e) }

func TestRegisterRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	RegisterRoutes(router, NewHandler(nil))

	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/health", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("GET /health status = %d, want 200", rec.Code)
	}

	rec = httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/follow/"+uuid.NewString(), nil))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("POST /follow/:id status = %d, want 401", rec.Code)
	}
}
