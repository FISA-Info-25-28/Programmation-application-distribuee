package social

import (
	"context"
	"time"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type Repository struct {
	db *gorm.DB
}

type profileRow struct {
	ID          uuid.UUID
	AccountID   uuid.UUID
	Username    string
	DisplayName *string
	Bio         *string
	AvatarURL   *string
	Email       string
	Role        string
	CreatedAt   time.Time
}

func NewRepository(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

func (r *Repository) FindProfileIDByAccountID(ctx context.Context, accountID uuid.UUID) (uuid.UUID, error) {
	var row struct {
		ID uuid.UUID
	}

	err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Select("id").
		Where("account_id = ?", accountID).
		Limit(1).
		Scan(&row).
		Error
	if err != nil {
		return uuid.Nil, err
	}
	if row.ID == uuid.Nil {
		return uuid.Nil, gorm.ErrRecordNotFound
	}

	return row.ID, nil
}

func (r *Repository) ProfileExists(ctx context.Context, profileID uuid.UUID) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("id = ?", profileID).
		Count(&count).
		Error

	return count > 0, err
}

func (r *Repository) ProfileIsPrivate(ctx context.Context, profileID uuid.UUID) (bool, error) {
	var row struct {
		IsPrivate bool
	}
	err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Select("is_private").
		Where("id = ?", profileID).
		Take(&row).
		Error
	return row.IsPrivate, err
}

func (r *Repository) CreateFollow(ctx context.Context, followerID, followedID uuid.UUID) error {
	follow := models.Follow{
		FollowerID: followerID,
		FollowedID: followedID,
	}

	return r.db.WithContext(ctx).
		Table("social.follows").
		Clauses(clause.OnConflict{Columns: []clause.Column{{Name: "follower_id"}, {Name: "followed_id"}}, DoNothing: true}).
		Create(&follow).
		Error
}

func (r *Repository) HasFollow(ctx context.Context, followerID, followedID uuid.UUID) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("social.follows").
		Where("follower_id = ? AND followed_id = ?", followerID, followedID).
		Count(&count).
		Error

	return count > 0, err
}

func (r *Repository) HasBlockBetween(ctx context.Context, firstID, secondID uuid.UUID) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("social.blocks").
		Where("(blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)", firstID, secondID, secondID, firstID).
		Count(&count).Error
	return count > 0, err
}

func (r *Repository) CreateBlock(ctx context.Context, blockerID, blockedID uuid.UUID) error {
	return r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		block := models.Block{BlockerID: blockerID, BlockedID: blockedID}
		if err := tx.Table("social.blocks").Clauses(clause.OnConflict{
			Columns: []clause.Column{{Name: "blocker_id"}, {Name: "blocked_id"}}, DoNothing: true,
		}).Create(&block).Error; err != nil {
			return err
		}
		if err := tx.Exec("DELETE FROM social.follows WHERE (follower_id = ? AND followed_id = ?) OR (follower_id = ? AND followed_id = ?)", blockerID, blockedID, blockedID, blockerID).Error; err != nil {
			return err
		}
		if err := tx.Exec("DELETE FROM social.follow_requests WHERE (requester_id = ? AND target_id = ?) OR (requester_id = ? AND target_id = ?)", blockerID, blockedID, blockedID, blockerID).Error; err != nil {
			return err
		}
		return tx.Exec("DELETE FROM social.notifications WHERE (recipient_id = ? AND actor_id = ?) OR (recipient_id = ? AND actor_id = ?)", blockerID, blockedID, blockedID, blockerID).Error
	})
}

func (r *Repository) DeleteBlock(ctx context.Context, blockerID, blockedID uuid.UUID) error {
	return r.db.WithContext(ctx).Table("social.blocks").
		Where("blocker_id = ? AND blocked_id = ?", blockerID, blockedID).
		Delete(&models.Block{}).Error
}

func (r *Repository) CreateFollowRequest(ctx context.Context, requesterID, targetID uuid.UUID) error {
	request := models.FollowRequest{
		RequesterID: requesterID,
		TargetID:    targetID,
	}
	return r.db.WithContext(ctx).
		Table("social.follow_requests").
		Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "requester_id"}, {Name: "target_id"}},
			DoNothing: true,
		}).
		Create(&request).
		Error
}

func (r *Repository) HasFollowRequest(ctx context.Context, requesterID, targetID uuid.UUID) (bool, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("social.follow_requests").
		Where("requester_id = ? AND target_id = ?", requesterID, targetID).
		Count(&count).
		Error
	return count > 0, err
}

func (r *Repository) DeleteFollowRequest(ctx context.Context, requesterID, targetID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Table("social.follow_requests").
		Where("requester_id = ? AND target_id = ?", requesterID, targetID).
		Delete(&models.FollowRequest{}).
		Error
}

func (r *Repository) AcceptFollowRequest(ctx context.Context, requesterID, targetID uuid.UUID) error {
	return r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		result := tx.Table("social.follow_requests").
			Where("requester_id = ? AND target_id = ?", requesterID, targetID).
			Delete(&models.FollowRequest{})
		if result.Error != nil {
			return result.Error
		}
		if result.RowsAffected == 0 {
			return gorm.ErrRecordNotFound
		}

		follow := models.Follow{FollowerID: requesterID, FollowedID: targetID}
		return tx.Table("social.follows").
			Clauses(clause.OnConflict{
				Columns:   []clause.Column{{Name: "follower_id"}, {Name: "followed_id"}},
				DoNothing: true,
			}).
			Create(&follow).
			Error
	})
}

func (r *Repository) CreateNotification(ctx context.Context, notification *models.Notification) error {
	return r.db.WithContext(ctx).
		Table("social.notifications").
		Create(notification).
		Error
}

func (r *Repository) DeleteFollowRequestNotification(ctx context.Context, requesterID, targetID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Table("social.notifications").
		Where("recipient_id = ? AND actor_id = ? AND type = ?", targetID, requesterID, "FOLLOW_REQUEST").
		Delete(&models.Notification{}).
		Error
}

func (r *Repository) DeleteFollow(ctx context.Context, followerID, followedID uuid.UUID) error {
	return r.db.WithContext(ctx).
		Table("social.follows").
		Delete(&models.Follow{}, "follower_id = ? AND followed_id = ?", followerID, followedID).
		Error
}

func (r *Repository) CountFollowers(ctx context.Context, profileID uuid.UUID) (int64, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("social.follows").
		Where("followed_id = ?", profileID).
		Count(&count).
		Error

	return count, err
}

func (r *Repository) CountFollowing(ctx context.Context, profileID uuid.UUID) (int64, error) {
	var count int64
	err := r.db.WithContext(ctx).
		Table("social.follows").
		Where("follower_id = ?", profileID).
		Count(&count).
		Error

	return count, err
}

func (r *Repository) FindFollowers(ctx context.Context, profileID uuid.UUID, limit, offset int) ([]profileRow, int64, error) {
	var total int64
	if err := r.db.WithContext(ctx).
		Table("social.follows").
		Where("followed_id = ?", profileID).
		Count(&total).
		Error; err != nil {
		return nil, 0, err
	}

	var rows []profileRow
	err := r.db.WithContext(ctx).
		Table("social.follows AS f").
		Select("p.id, p.account_id, p.username, p.display_name, p.bio, p.avatar_url, p.created_at, a.email, a.role").
		Joins("JOIN profiles.profiles p ON p.id = f.follower_id").
		Joins("LEFT JOIN auth.accounts a ON a.id = p.account_id").
		Where("f.followed_id = ?", profileID).
		Order("f.created_at DESC").
		Limit(limit).
		Offset(offset).
		Scan(&rows).
		Error

	return rows, total, err
}

func (r *Repository) FindFollowing(ctx context.Context, profileID uuid.UUID, limit, offset int) ([]profileRow, int64, error) {
	var total int64
	if err := r.db.WithContext(ctx).
		Table("social.follows").
		Where("follower_id = ?", profileID).
		Count(&total).
		Error; err != nil {
		return nil, 0, err
	}

	var rows []profileRow
	err := r.db.WithContext(ctx).
		Table("social.follows AS f").
		Select("p.id, p.account_id, p.username, p.display_name, p.bio, p.avatar_url, p.created_at, a.email, a.role").
		Joins("JOIN profiles.profiles p ON p.id = f.followed_id").
		Joins("LEFT JOIN auth.accounts a ON a.id = p.account_id").
		Where("f.follower_id = ?", profileID).
		Order("f.created_at DESC").
		Limit(limit).
		Offset(offset).
		Scan(&rows).
		Error

	return rows, total, err
}

// FindBlockedProfiles recupere les profils bloques par un profil.
// Entree : ctx, profileID, limit, offset.
// Sortie : lignes de profils, total et erreur eventuelle.
func (r *Repository) FindBlockedProfiles(ctx context.Context, profileID uuid.UUID, limit, offset int) ([]profileRow, int64, error) {
	var total int64
	if err := r.db.WithContext(ctx).
		Table("social.blocks").
		Where("blocker_id = ?", profileID).
		Count(&total).
		Error; err != nil {
		return nil, 0, err
	}

	var rows []profileRow
	err := r.db.WithContext(ctx).
		Table("social.blocks AS b").
		Select("p.id, p.account_id, p.username, p.display_name, p.bio, p.avatar_url, p.created_at, a.email, a.role").
		Joins("JOIN profiles.profiles p ON p.id = b.blocked_id").
		Joins("LEFT JOIN auth.accounts a ON a.id = p.account_id").
		Where("b.blocker_id = ?", profileID).
		Order("b.created_at DESC").
		Limit(limit).
		Offset(offset).
		Scan(&rows).
		Error

	return rows, total, err
}
