package social

import (
	"context"
	"errors"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// socialMockDB ouvre une connexion GORM pilotee par sqlmock (mode reel, pas
// DryRun) afin de scripter precisement les lignes et erreurs SQL renvoyees,
// pour couvrir les branches d'erreur et de succes du repository social.
// Meme principe que internal/messages/repository_sqlmock_test.go.
func socialMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

func TestRepositoryFindProfileIDByAccountID(t *testing.T) {
	ctx := context.Background()
	accountID := uuid.New()

	t.Run("found", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)
		profileID := uuid.New()

		mock.ExpectQuery(`SELECT id FROM "profiles"."profiles"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))

		got, err := repo.FindProfileIDByAccountID(ctx, accountID)
		if err != nil || got != profileID {
			t.Fatalf("FindProfileIDByAccountID() = %v, %v, want %v, nil", got, err, profileID)
		}
	})

	t.Run("not found", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)

		mock.ExpectQuery(`SELECT id FROM "profiles"."profiles"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}))

		_, err := repo.FindProfileIDByAccountID(ctx, accountID)
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("FindProfileIDByAccountID() error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("query error", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("boom")

		mock.ExpectQuery(`SELECT id FROM "profiles"."profiles"`).WillReturnError(wantErr)

		_, err := repo.FindProfileIDByAccountID(ctx, accountID)
		if err == nil {
			t.Fatal("FindProfileIDByAccountID() expected error, got nil")
		}
	})
}

func TestRepositoryCreateBlock(t *testing.T) {
	ctx := context.Background()
	blockerID, blockedID := uuid.New(), uuid.New()

	t.Run("success", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)

		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "social"\."blocks"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectExec(`DELETE FROM social\.follows`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`DELETE FROM social\.follow_requests`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectExec(`DELETE FROM social\.notifications`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectCommit()

		if err := repo.CreateBlock(ctx, blockerID, blockedID); err != nil {
			t.Fatalf("CreateBlock() unexpected error: %v", err)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet expectations: %v", err)
		}
	})

	t.Run("begin fails", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("begin failed")

		mock.ExpectBegin().WillReturnError(wantErr)

		if err := repo.CreateBlock(ctx, blockerID, blockedID); err == nil {
			t.Fatal("CreateBlock() expected error when Begin fails")
		}
	})

	t.Run("block insert fails", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("insert failed")

		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "social"\."blocks"`).WillReturnError(wantErr)
		mock.ExpectRollback()

		if err := repo.CreateBlock(ctx, blockerID, blockedID); err == nil {
			t.Fatal("CreateBlock() expected error when block insert fails")
		}
	})

	t.Run("delete follows fails", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("delete follows failed")

		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "social"\."blocks"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectExec(`DELETE FROM social\.follows`).WillReturnError(wantErr)
		mock.ExpectRollback()

		if err := repo.CreateBlock(ctx, blockerID, blockedID); err == nil {
			t.Fatal("CreateBlock() expected error when deleting follows fails")
		}
	})

	t.Run("delete follow requests fails", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("delete follow requests failed")

		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "social"\."blocks"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectExec(`DELETE FROM social\.follows`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`DELETE FROM social\.follow_requests`).WillReturnError(wantErr)
		mock.ExpectRollback()

		if err := repo.CreateBlock(ctx, blockerID, blockedID); err == nil {
			t.Fatal("CreateBlock() expected error when deleting follow requests fails")
		}
	})

	t.Run("delete notifications fails", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("delete notifications failed")

		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "social"\."blocks"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectExec(`DELETE FROM social\.follows`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectExec(`DELETE FROM social\.follow_requests`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectExec(`DELETE FROM social\.notifications`).WillReturnError(wantErr)
		mock.ExpectRollback()

		if err := repo.CreateBlock(ctx, blockerID, blockedID); err == nil {
			t.Fatal("CreateBlock() expected error when deleting notifications fails")
		}
	})
}

func TestRepositoryAcceptFollowRequest(t *testing.T) {
	ctx := context.Background()
	requesterID, targetID := uuid.New(), uuid.New()

	t.Run("success", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)

		mock.ExpectBegin()
		mock.ExpectExec(`DELETE FROM "social"\."follow_requests"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectQuery(`INSERT INTO "social"\."follows"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(uuid.New()))
		mock.ExpectCommit()

		if err := repo.AcceptFollowRequest(ctx, requesterID, targetID); err != nil {
			t.Fatalf("AcceptFollowRequest() unexpected error: %v", err)
		}
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Fatalf("unmet expectations: %v", err)
		}
	})

	t.Run("begin fails", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("begin failed")

		mock.ExpectBegin().WillReturnError(wantErr)

		if err := repo.AcceptFollowRequest(ctx, requesterID, targetID); err == nil {
			t.Fatal("AcceptFollowRequest() expected error when Begin fails")
		}
	})

	t.Run("delete fails", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("delete failed")

		mock.ExpectBegin()
		mock.ExpectExec(`DELETE FROM "social"\."follow_requests"`).WillReturnError(wantErr)
		mock.ExpectRollback()

		if err := repo.AcceptFollowRequest(ctx, requesterID, targetID); err == nil {
			t.Fatal("AcceptFollowRequest() expected error when delete fails")
		}
	})

	t.Run("no pending request", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)

		mock.ExpectBegin()
		mock.ExpectExec(`DELETE FROM "social"\."follow_requests"`).WillReturnResult(sqlmock.NewResult(0, 0))
		mock.ExpectRollback()

		err := repo.AcceptFollowRequest(ctx, requesterID, targetID)
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("AcceptFollowRequest() error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("follow insert fails", func(t *testing.T) {
		db, mock := socialMockDB(t)
		repo := NewRepository(db)
		wantErr := errors.New("follow insert failed")

		mock.ExpectBegin()
		mock.ExpectExec(`DELETE FROM "social"\."follow_requests"`).WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectQuery(`INSERT INTO "social"\."follows"`).WillReturnError(wantErr)
		mock.ExpectRollback()

		if err := repo.AcceptFollowRequest(ctx, requesterID, targetID); err == nil {
			t.Fatal("AcceptFollowRequest() expected error when follow insert fails")
		}
	})
}

func TestRepositoryFindFollowersCountError(t *testing.T) {
	db, mock := socialMockDB(t)
	repo := NewRepository(db)
	wantErr := errors.New("count failed")

	mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnError(wantErr)

	_, _, err := repo.FindFollowers(context.Background(), uuid.New(), 10, 0)
	if err == nil {
		t.Fatal("FindFollowers() expected error when count query fails")
	}
}

func TestRepositoryFindFollowersSelectError(t *testing.T) {
	db, mock := socialMockDB(t)
	repo := NewRepository(db)
	wantErr := errors.New("select failed")

	mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`SELECT p\.id`).WillReturnError(wantErr)

	_, _, err := repo.FindFollowers(context.Background(), uuid.New(), 10, 0)
	if err == nil {
		t.Fatal("FindFollowers() expected error when select query fails")
	}
}

func TestRepositoryFindFollowingCountError(t *testing.T) {
	db, mock := socialMockDB(t)
	repo := NewRepository(db)
	wantErr := errors.New("count failed")

	mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).WillReturnError(wantErr)

	_, _, err := repo.FindFollowing(context.Background(), uuid.New(), 10, 0)
	if err == nil {
		t.Fatal("FindFollowing() expected error when count query fails")
	}
}

func TestRepositoryFindFollowingSelectError(t *testing.T) {
	db, mock := socialMockDB(t)
	repo := NewRepository(db)
	wantErr := errors.New("select failed")

	mock.ExpectQuery(`SELECT count\(\*\) FROM "social"\."follows"`).
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
	mock.ExpectQuery(`SELECT p\.id`).WillReturnError(wantErr)

	_, _, err := repo.FindFollowing(context.Background(), uuid.New(), 10, 0)
	if err == nil {
		t.Fatal("FindFollowing() expected error when select query fails")
	}
}
