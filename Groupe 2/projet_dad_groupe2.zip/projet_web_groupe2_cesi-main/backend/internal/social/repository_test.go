package social

import (
	"context"
	"testing"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestSocialRepositoryConstructor(t *testing.T) {
	repo := NewRepository(nil)
	if repo == nil || repo.db != nil {
		t.Fatalf("NewRepository(nil) = %+v, want repository with nil db", repo)
	}
}

func TestSocialRepositoryQueriesDryRun(t *testing.T) {
	repo := NewRepository(socialDryRunDB(t))
	ctx := context.Background()
	firstID := uuid.New()
	secondID := uuid.New()

	_, _ = repo.FindProfileIDByAccountID(ctx, uuid.New())
	_, _ = repo.ProfileExists(ctx, firstID)
	_, _ = repo.ProfileIsPrivate(ctx, firstID)
	_ = repo.CreateFollow(ctx, firstID, secondID)
	_, _ = repo.HasFollow(ctx, firstID, secondID)
	_, _ = repo.HasBlockBetween(ctx, firstID, secondID)
	_ = repo.CreateBlock(ctx, firstID, secondID)
	_ = repo.DeleteBlock(ctx, firstID, secondID)
	_ = repo.CreateFollowRequest(ctx, firstID, secondID)
	_, _ = repo.HasFollowRequest(ctx, firstID, secondID)
	_ = repo.DeleteFollowRequest(ctx, firstID, secondID)
	_ = repo.AcceptFollowRequest(ctx, firstID, secondID)
	_ = repo.CreateNotification(ctx, &models.Notification{RecipientID: secondID, ActorID: firstID, Type: "FOLLOW"})
	_ = repo.DeleteFollowRequestNotification(ctx, firstID, secondID)
	_ = repo.DeleteFollow(ctx, firstID, secondID)
	_, _ = repo.CountFollowers(ctx, secondID)
	_, _ = repo.CountFollowing(ctx, firstID)
	_, _, _ = repo.FindFollowers(ctx, secondID, 10, 0)
	_, _, _ = repo.FindFollowing(ctx, firstID, 10, 0)
}

func socialDryRunDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{DryRun: true})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db
}
