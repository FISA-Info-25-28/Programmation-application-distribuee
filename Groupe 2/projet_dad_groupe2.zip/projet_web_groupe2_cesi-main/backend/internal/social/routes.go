package social

import (
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
)

func RegisterRoutes(router *gin.Engine, handler *Handler) {
	router.Use(middleware.JSONBody())

	router.GET("/health", handler.Health)

	authenticated := router.Group("/")
	authenticated.Use(middleware.AuthRequired())

	authenticated.POST("/follow/:profileId", handler.Follow)
	authenticated.DELETE("/follow/:profileId", handler.Unfollow)
	authenticated.POST("/follow-requests/:profileId/accept", handler.AcceptFollowRequest)
	authenticated.DELETE("/follow-requests/:profileId", handler.RejectFollowRequest)
	authenticated.POST("/block/:profileId", handler.Block)
	authenticated.DELETE("/block/:profileId", handler.Unblock)
	authenticated.GET("/blocked", handler.BlockedProfiles)
	authenticated.GET("/:profileId/followers", handler.Followers)
	authenticated.GET("/:profileId/following", handler.Following)
}
