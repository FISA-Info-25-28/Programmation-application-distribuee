package social

import (
	"context"
	"errors"
	"math"
	"strings"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

var (
	ErrCannotFollowSelf = errors.New("cannot follow yourself")
	ErrCannotBlockSelf  = errors.New("cannot block yourself")
	ErrBlockedRelation  = errors.New("blocked relationship")
	ErrProfileNotFound  = errors.New("profile not found")
)

// socialRepository decrit les operations dont le service a besoin.
// Permet de substituer un faux repository dans les tests unitaires
// (cf. internal/messages/service.go pour le meme principe).
type socialRepository interface {
	FindProfileIDByAccountID(ctx context.Context, accountID uuid.UUID) (uuid.UUID, error)
	ProfileExists(ctx context.Context, profileID uuid.UUID) (bool, error)
	ProfileIsPrivate(ctx context.Context, profileID uuid.UUID) (bool, error)
	CreateFollow(ctx context.Context, followerID, followedID uuid.UUID) error
	HasFollow(ctx context.Context, followerID, followedID uuid.UUID) (bool, error)
	HasBlockBetween(ctx context.Context, firstID, secondID uuid.UUID) (bool, error)
	CreateBlock(ctx context.Context, blockerID, blockedID uuid.UUID) error
	DeleteBlock(ctx context.Context, blockerID, blockedID uuid.UUID) error
	CreateFollowRequest(ctx context.Context, requesterID, targetID uuid.UUID) error
	HasFollowRequest(ctx context.Context, requesterID, targetID uuid.UUID) (bool, error)
	DeleteFollowRequest(ctx context.Context, requesterID, targetID uuid.UUID) error
	AcceptFollowRequest(ctx context.Context, requesterID, targetID uuid.UUID) error
	CreateNotification(ctx context.Context, notification *models.Notification) error
	DeleteFollowRequestNotification(ctx context.Context, requesterID, targetID uuid.UUID) error
	DeleteFollow(ctx context.Context, followerID, followedID uuid.UUID) error
	CountFollowers(ctx context.Context, profileID uuid.UUID) (int64, error)
	CountFollowing(ctx context.Context, profileID uuid.UUID) (int64, error)
	FindFollowers(ctx context.Context, profileID uuid.UUID, limit, offset int) ([]profileRow, int64, error)
	FindFollowing(ctx context.Context, profileID uuid.UUID, limit, offset int) ([]profileRow, int64, error)
	FindBlockedProfiles(ctx context.Context, profileID uuid.UUID, limit, offset int) ([]profileRow, int64, error)
}

type Service struct {
	repo socialRepository
}

// NewService construit le service social autour de son repository.
// Entree : repo.
// Sortie : valeur retour de type *Service.
func NewService(repo *Repository) *Service {
	return &Service{repo: repo}
}

// Follow suit un profil public ou cree une demande pour un profil prive.
// Entree : ctx, accountID, targetProfileID.
// Sortie : valeurs retour de la fonction.
func (s *Service) Follow(ctx context.Context, accountID, targetProfileID uuid.UUID) (followResponse, error) {
	currentProfileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return followResponse{}, err
	}

	if currentProfileID == targetProfileID {
		return followResponse{}, ErrCannotFollowSelf
	}
	blocked, err := s.repo.HasBlockBetween(ctx, currentProfileID, targetProfileID)
	if err != nil {
		return followResponse{}, err
	}
	if blocked {
		return followResponse{}, ErrBlockedRelation
	}

	exists, err := s.repo.ProfileExists(ctx, targetProfileID)
	if err != nil {
		return followResponse{}, err
	}
	if !exists {
		return followResponse{}, ErrProfileNotFound
	}

	alreadyFollowing, err := s.repo.HasFollow(ctx, currentProfileID, targetProfileID)
	if err != nil {
		return followResponse{}, err
	}
	if alreadyFollowing {
		return followResponse{Following: true}, nil
	}

	isPrivate, err := s.repo.ProfileIsPrivate(ctx, targetProfileID)
	if err != nil {
		return followResponse{}, err
	}
	if isPrivate {
		pending, err := s.repo.HasFollowRequest(ctx, currentProfileID, targetProfileID)
		if err != nil {
			return followResponse{}, err
		}
		if pending {
			return followResponse{RequestPending: true}, nil
		}
		if err := s.repo.CreateFollowRequest(ctx, currentProfileID, targetProfileID); err != nil {
			return followResponse{}, err
		}
		_ = s.repo.CreateNotification(ctx, &models.Notification{
			RecipientID: targetProfileID,
			ActorID:     currentProfileID,
			Type:        "FOLLOW_REQUEST",
		})
		return followResponse{RequestPending: true}, nil
	}

	if err := s.repo.CreateFollow(ctx, currentProfileID, targetProfileID); err != nil {
		return followResponse{}, err
	}

	_ = s.repo.CreateNotification(ctx, &models.Notification{
		RecipientID: targetProfileID,
		ActorID:     currentProfileID,
		Type:        "FOLLOW",
	})

	return followResponse{Following: true}, nil
}

// Block bloque un profil cible pour le compte courant.
// Entree : ctx, accountID, targetProfileID.
// Sortie : valeurs retour de la fonction.
func (s *Service) Block(ctx context.Context, accountID, targetProfileID uuid.UUID) (blockResponse, error) {
	currentProfileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return blockResponse{}, err
	}
	if currentProfileID == targetProfileID {
		return blockResponse{}, ErrCannotBlockSelf
	}
	if err := s.ensureProfileExists(ctx, targetProfileID); err != nil {
		return blockResponse{}, err
	}
	if err := s.repo.CreateBlock(ctx, currentProfileID, targetProfileID); err != nil {
		return blockResponse{}, err
	}
	return blockResponse{Blocked: true}, nil
}

// Unblock retire le blocage entre le compte courant et le profil cible.
// Entree : ctx, accountID, targetProfileID.
// Sortie : valeurs retour de la fonction.
func (s *Service) Unblock(ctx context.Context, accountID, targetProfileID uuid.UUID) (blockResponse, error) {
	currentProfileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return blockResponse{}, err
	}
	if err := s.repo.DeleteBlock(ctx, currentProfileID, targetProfileID); err != nil {
		return blockResponse{}, err
	}
	return blockResponse{Blocked: false}, nil
}

// Unfollow annule un suivi ou une demande de suivi en attente.
// Entree : ctx, accountID, targetProfileID.
// Sortie : valeurs retour de la fonction.
func (s *Service) Unfollow(ctx context.Context, accountID, targetProfileID uuid.UUID) (followResponse, error) {
	currentProfileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return followResponse{}, err
	}

	if currentProfileID == targetProfileID {
		return followResponse{}, ErrCannotFollowSelf
	}

	if err := s.repo.DeleteFollow(ctx, currentProfileID, targetProfileID); err != nil {
		return followResponse{}, err
	}
	if err := s.repo.DeleteFollowRequest(ctx, currentProfileID, targetProfileID); err != nil {
		return followResponse{}, err
	}
	_ = s.repo.DeleteFollowRequestNotification(ctx, currentProfileID, targetProfileID)

	return followResponse{Following: false}, nil
}

// AcceptFollowRequest accepte une demande de suivi recue par un profil prive.
// Entree : ctx, accountID, requesterID.
// Sortie : valeurs retour de la fonction.
func (s *Service) AcceptFollowRequest(ctx context.Context, accountID, requesterID uuid.UUID) (followResponse, error) {
	targetID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return followResponse{}, err
	}
	if err := s.repo.AcceptFollowRequest(ctx, requesterID, targetID); err != nil {
		return followResponse{}, err
	}
	_ = s.repo.DeleteFollowRequestNotification(ctx, requesterID, targetID)
	_ = s.repo.CreateNotification(ctx, &models.Notification{
		RecipientID: requesterID,
		ActorID:     targetID,
		Type:        "FOLLOW",
	})
	return followResponse{Following: true}, nil
}

// RejectFollowRequest refuse une demande de suivi recue par un profil prive.
// Entree : ctx, accountID, requesterID.
// Sortie : erreur eventuelle.
func (s *Service) RejectFollowRequest(ctx context.Context, accountID, requesterID uuid.UUID) error {
	targetID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return err
	}
	pending, err := s.repo.HasFollowRequest(ctx, requesterID, targetID)
	if err != nil {
		return err
	}
	if !pending {
		return gorm.ErrRecordNotFound
	}
	if err := s.repo.DeleteFollowRequest(ctx, requesterID, targetID); err != nil {
		return err
	}
	return s.repo.DeleteFollowRequestNotification(ctx, requesterID, targetID)
}

// Followers recupere les abonnes d'un profil avec pagination.
// Entree : ctx, profileID, page, limit.
// Sortie : valeurs retour de la fonction.
func (s *Service) Followers(ctx context.Context, profileID uuid.UUID, page, limit int) (paginatedUsersResponse, error) {
	if err := s.ensureProfileExists(ctx, profileID); err != nil {
		return paginatedUsersResponse{}, err
	}

	page, limit = normalizePagination(page, limit)
	rows, total, err := s.repo.FindFollowers(ctx, profileID, limit, (page-1)*limit)
	if err != nil {
		return paginatedUsersResponse{}, err
	}

	return paginatedUsersResponse{
		Users: s.rowsToUsers(ctx, rows),
		Page:  page,
		Limit: limit,
		Total: total,
	}, nil
}

// Following recupere les profils suivis par un profil avec pagination.
// Entree : ctx, profileID, page, limit.
// Sortie : valeurs retour de la fonction.
func (s *Service) Following(ctx context.Context, profileID uuid.UUID, page, limit int) (paginatedUsersResponse, error) {
	if err := s.ensureProfileExists(ctx, profileID); err != nil {
		return paginatedUsersResponse{}, err
	}

	page, limit = normalizePagination(page, limit)
	rows, total, err := s.repo.FindFollowing(ctx, profileID, limit, (page-1)*limit)
	if err != nil {
		return paginatedUsersResponse{}, err
	}

	return paginatedUsersResponse{
		Users: s.rowsToUsers(ctx, rows),
		Page:  page,
		Limit: limit,
		Total: total,
	}, nil
}

// BlockedProfiles recupere les profils bloques par le compte courant.
// Entree : ctx, accountID, page, limit.
// Sortie : valeurs retour de la fonction.
func (s *Service) BlockedProfiles(ctx context.Context, accountID uuid.UUID, page, limit int) (paginatedUsersResponse, error) {
	currentProfileID, err := s.repo.FindProfileIDByAccountID(ctx, accountID)
	if err != nil {
		return paginatedUsersResponse{}, err
	}

	page, limit = normalizePagination(page, limit)
	rows, total, err := s.repo.FindBlockedProfiles(ctx, currentProfileID, limit, (page-1)*limit)
	if err != nil {
		return paginatedUsersResponse{}, err
	}

	return paginatedUsersResponse{
		Users: s.rowsToUsers(ctx, rows),
		Page:  page,
		Limit: limit,
		Total: total,
	}, nil
}

// ensureProfileExists verifie qu'un profil cible existe.
// Entree : ctx, profileID.
// Sortie : erreur eventuelle.
func (s *Service) ensureProfileExists(ctx context.Context, profileID uuid.UUID) error {
	exists, err := s.repo.ProfileExists(ctx, profileID)
	if err != nil {
		return err
	}
	if !exists {
		return ErrProfileNotFound
	}
	return nil
}

// rowsToUsers transforme les lignes de profils en DTO utilisateur enrichis.
// Entree : ctx, rows.
// Sortie : valeur retour de type []userResponse.
func (s *Service) rowsToUsers(ctx context.Context, rows []profileRow) []userResponse {
	users := make([]userResponse, 0, len(rows))

	for _, row := range rows {
		displayName := row.Username
		if row.DisplayName != nil && strings.TrimSpace(*row.DisplayName) != "" {
			displayName = *row.DisplayName
		}

		followersCount, _ := s.repo.CountFollowers(ctx, row.ID)
		followingCount, _ := s.repo.CountFollowing(ctx, row.ID)

		role := row.Role
		if role == "" {
			role = "USER"
		}

		users = append(users, userResponse{
			ID:             row.ID,
			ProfileID:      row.ID,
			Username:       row.Username,
			DisplayName:    displayName,
			Email:          row.Email,
			Role:           role,
			Bio:            row.Bio,
			AvatarURL:      row.AvatarURL,
			FollowersCount: followersCount,
			FollowingCount: followingCount,
			PostsCount:     0,
			CreatedAt:      row.CreatedAt,
		})
	}

	return users
}

// normalizePagination applique les bornes par defaut et maximale de pagination.
// Entree : page, limit.
// Sortie : valeurs retour de la fonction.
func normalizePagination(page, limit int) (int, int) {
	if page < 1 {
		page = 1
	}
	if limit < 1 {
		limit = 20
	}
	return page, int(math.Min(float64(limit), 50))
}

// IsNotFound indique si une erreur correspond a un profil introuvable.
// Entree : err.
// Sortie : valeur retour de type bool.
func IsNotFound(err error) bool {
	return errors.Is(err, gorm.ErrRecordNotFound) || errors.Is(err, ErrProfileNotFound)
}
