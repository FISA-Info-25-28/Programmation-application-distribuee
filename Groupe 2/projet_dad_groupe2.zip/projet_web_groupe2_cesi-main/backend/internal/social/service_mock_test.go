package social

import (
	"context"
	"errors"
	"testing"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// fakeSocialRepo est un faux repository pilotable pour tester le Service
// sans base de donnees, sur le meme principe que
// internal/messages/service_mock_test.go (fakeMessagesRepo).
type fakeSocialRepo struct {
	// profil rattache au compte courant
	currentProfileID uuid.UUID
	findProfileErr   error

	existingProfiles map[uuid.UUID]bool
	privateProfiles  map[uuid.UUID]bool
	blockedPairs     map[[2]uuid.UUID]bool
	following        map[[2]uuid.UUID]bool
	pendingRequests  map[[2]uuid.UUID]bool

	profileExistsErr    error
	profileIsPrivateErr error
	hasBlockErr         error
	hasFollowErr        error
	hasFollowRequestErr error
	createFollowErr     error
	createFollowReqErr  error
	createBlockErr      error
	deleteBlockErr      error
	deleteFollowErr     error
	deleteFollowReqErr  error
	acceptFollowReqErr  error
	createNotifErr      error

	deletedFollowRequestNotif bool

	followersRows  []profileRow
	followersTotal int64
	followersErr   error
	followingRows  []profileRow
	followingTotal int64
	followingErr   error

	followersCount map[uuid.UUID]int64
	followingCount map[uuid.UUID]int64
}

func newFakeSocialRepo() *fakeSocialRepo {
	return &fakeSocialRepo{
		currentProfileID: uuid.New(),
		existingProfiles: map[uuid.UUID]bool{},
		privateProfiles:  map[uuid.UUID]bool{},
		blockedPairs:     map[[2]uuid.UUID]bool{},
		following:        map[[2]uuid.UUID]bool{},
		pendingRequests:  map[[2]uuid.UUID]bool{},
		followersCount:   map[uuid.UUID]int64{},
		followingCount:   map[uuid.UUID]int64{},
	}
}

func pairKey(a, b uuid.UUID) [2]uuid.UUID { return [2]uuid.UUID{a, b} }

func (r *fakeSocialRepo) FindProfileIDByAccountID(context.Context, uuid.UUID) (uuid.UUID, error) {
	if r.findProfileErr != nil {
		return uuid.Nil, r.findProfileErr
	}
	return r.currentProfileID, nil
}

func (r *fakeSocialRepo) ProfileExists(_ context.Context, profileID uuid.UUID) (bool, error) {
	if r.profileExistsErr != nil {
		return false, r.profileExistsErr
	}
	return r.existingProfiles[profileID], nil
}

func (r *fakeSocialRepo) ProfileIsPrivate(_ context.Context, profileID uuid.UUID) (bool, error) {
	if r.profileIsPrivateErr != nil {
		return false, r.profileIsPrivateErr
	}
	return r.privateProfiles[profileID], nil
}

func (r *fakeSocialRepo) CreateFollow(_ context.Context, followerID, followedID uuid.UUID) error {
	if r.createFollowErr != nil {
		return r.createFollowErr
	}
	r.following[pairKey(followerID, followedID)] = true
	return nil
}

func (r *fakeSocialRepo) HasFollow(_ context.Context, followerID, followedID uuid.UUID) (bool, error) {
	if r.hasFollowErr != nil {
		return false, r.hasFollowErr
	}
	return r.following[pairKey(followerID, followedID)], nil
}

func (r *fakeSocialRepo) HasBlockBetween(_ context.Context, firstID, secondID uuid.UUID) (bool, error) {
	if r.hasBlockErr != nil {
		return false, r.hasBlockErr
	}
	return r.blockedPairs[pairKey(firstID, secondID)] || r.blockedPairs[pairKey(secondID, firstID)], nil
}

func (r *fakeSocialRepo) CreateBlock(_ context.Context, blockerID, blockedID uuid.UUID) error {
	if r.createBlockErr != nil {
		return r.createBlockErr
	}
	r.blockedPairs[pairKey(blockerID, blockedID)] = true
	delete(r.following, pairKey(blockerID, blockedID))
	delete(r.following, pairKey(blockedID, blockerID))
	return nil
}

func (r *fakeSocialRepo) DeleteBlock(_ context.Context, blockerID, blockedID uuid.UUID) error {
	if r.deleteBlockErr != nil {
		return r.deleteBlockErr
	}
	delete(r.blockedPairs, pairKey(blockerID, blockedID))
	return nil
}

func (r *fakeSocialRepo) CreateFollowRequest(_ context.Context, requesterID, targetID uuid.UUID) error {
	if r.createFollowReqErr != nil {
		return r.createFollowReqErr
	}
	r.pendingRequests[pairKey(requesterID, targetID)] = true
	return nil
}

func (r *fakeSocialRepo) HasFollowRequest(_ context.Context, requesterID, targetID uuid.UUID) (bool, error) {
	if r.hasFollowRequestErr != nil {
		return false, r.hasFollowRequestErr
	}
	return r.pendingRequests[pairKey(requesterID, targetID)], nil
}

func (r *fakeSocialRepo) DeleteFollowRequest(_ context.Context, requesterID, targetID uuid.UUID) error {
	if r.deleteFollowReqErr != nil {
		return r.deleteFollowReqErr
	}
	delete(r.pendingRequests, pairKey(requesterID, targetID))
	return nil
}

func (r *fakeSocialRepo) AcceptFollowRequest(_ context.Context, requesterID, targetID uuid.UUID) error {
	if r.acceptFollowReqErr != nil {
		return r.acceptFollowReqErr
	}
	if !r.pendingRequests[pairKey(requesterID, targetID)] {
		return gorm.ErrRecordNotFound
	}
	delete(r.pendingRequests, pairKey(requesterID, targetID))
	r.following[pairKey(requesterID, targetID)] = true
	return nil
}

func (r *fakeSocialRepo) CreateNotification(context.Context, *models.Notification) error {
	return r.createNotifErr
}

func (r *fakeSocialRepo) DeleteFollowRequestNotification(context.Context, uuid.UUID, uuid.UUID) error {
	r.deletedFollowRequestNotif = true
	return nil
}

func (r *fakeSocialRepo) DeleteFollow(_ context.Context, followerID, followedID uuid.UUID) error {
	if r.deleteFollowErr != nil {
		return r.deleteFollowErr
	}
	delete(r.following, pairKey(followerID, followedID))
	return nil
}

func (r *fakeSocialRepo) CountFollowers(_ context.Context, profileID uuid.UUID) (int64, error) {
	return r.followersCount[profileID], nil
}

func (r *fakeSocialRepo) CountFollowing(_ context.Context, profileID uuid.UUID) (int64, error) {
	return r.followingCount[profileID], nil
}

func (r *fakeSocialRepo) FindFollowers(context.Context, uuid.UUID, int, int) ([]profileRow, int64, error) {
	if r.followersErr != nil {
		return nil, 0, r.followersErr
	}
	return r.followersRows, r.followersTotal, nil
}

func (r *fakeSocialRepo) FindFollowing(context.Context, uuid.UUID, int, int) ([]profileRow, int64, error) {
	if r.followingErr != nil {
		return nil, 0, r.followingErr
	}
	return r.followingRows, r.followingTotal, nil
}

func (r *fakeSocialRepo) FindBlockedProfiles(context.Context, uuid.UUID, int, int) ([]profileRow, int64, error) {
	return nil, 0, nil
}

func TestSocialServiceFollowMocked(t *testing.T) {
	ctx := context.Background()

	t.Run("self follow rejected", func(t *testing.T) {
		repo := newFakeSocialRepo()
		service := &Service{repo: repo}
		if _, err := service.Follow(ctx, uuid.New(), repo.currentProfileID); !errors.Is(err, ErrCannotFollowSelf) {
			t.Fatalf("Follow(self) error = %v, want ErrCannotFollowSelf", err)
		}
	})

	t.Run("blocked relation rejected", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.blockedPairs[pairKey(repo.currentProfileID, target)] = true
		service := &Service{repo: repo}
		if _, err := service.Follow(ctx, uuid.New(), target); !errors.Is(err, ErrBlockedRelation) {
			t.Fatalf("Follow(blocked) error = %v, want ErrBlockedRelation", err)
		}
	})

	t.Run("target profile missing", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		service := &Service{repo: repo}
		if _, err := service.Follow(ctx, uuid.New(), target); !errors.Is(err, ErrProfileNotFound) {
			t.Fatalf("Follow(missing) error = %v, want ErrProfileNotFound", err)
		}
	})

	t.Run("already following returns following true", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		repo.following[pairKey(repo.currentProfileID, target)] = true
		service := &Service{repo: repo}
		resp, err := service.Follow(ctx, uuid.New(), target)
		if err != nil || !resp.Following {
			t.Fatalf("Follow(already following) = %+v, %v", resp, err)
		}
	})

	t.Run("public profile follow creates follow and notification", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		service := &Service{repo: repo}
		resp, err := service.Follow(ctx, uuid.New(), target)
		if err != nil || !resp.Following || resp.RequestPending {
			t.Fatalf("Follow(public) = %+v, %v", resp, err)
		}
		if !repo.following[pairKey(repo.currentProfileID, target)] {
			t.Fatal("Follow(public) should record the follow relation")
		}
	})

	t.Run("private profile follow creates pending request", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		repo.privateProfiles[target] = true
		service := &Service{repo: repo}
		resp, err := service.Follow(ctx, uuid.New(), target)
		if err != nil || resp.Following || !resp.RequestPending {
			t.Fatalf("Follow(private) = %+v, %v", resp, err)
		}
		if !repo.pendingRequests[pairKey(repo.currentProfileID, target)] {
			t.Fatal("Follow(private) should record a pending follow request")
		}
	})

	t.Run("private profile follow already pending", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		repo.privateProfiles[target] = true
		repo.pendingRequests[pairKey(repo.currentProfileID, target)] = true
		service := &Service{repo: repo}
		resp, err := service.Follow(ctx, uuid.New(), target)
		if err != nil || !resp.RequestPending {
			t.Fatalf("Follow(private pending) = %+v, %v", resp, err)
		}
	})

	t.Run("propagates repository errors", func(t *testing.T) {
		boom := errors.New("boom")

		t.Run("find profile error", func(t *testing.T) {
			repo := newFakeSocialRepo()
			repo.findProfileErr = boom
			service := &Service{repo: repo}
			if _, err := service.Follow(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
				t.Fatalf("Follow() error = %v, want boom", err)
			}
		})

		t.Run("has block error", func(t *testing.T) {
			repo := newFakeSocialRepo()
			repo.hasBlockErr = boom
			service := &Service{repo: repo}
			if _, err := service.Follow(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
				t.Fatalf("Follow() error = %v, want boom", err)
			}
		})

		t.Run("profile exists error", func(t *testing.T) {
			repo := newFakeSocialRepo()
			repo.profileExistsErr = boom
			service := &Service{repo: repo}
			if _, err := service.Follow(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
				t.Fatalf("Follow() error = %v, want boom", err)
			}
		})

		t.Run("has follow error", func(t *testing.T) {
			repo := newFakeSocialRepo()
			target := uuid.New()
			repo.existingProfiles[target] = true
			repo.hasFollowErr = boom
			service := &Service{repo: repo}
			if _, err := service.Follow(ctx, uuid.New(), target); !errors.Is(err, boom) {
				t.Fatalf("Follow() error = %v, want boom", err)
			}
		})

		t.Run("is private error", func(t *testing.T) {
			repo := newFakeSocialRepo()
			target := uuid.New()
			repo.existingProfiles[target] = true
			repo.profileIsPrivateErr = boom
			service := &Service{repo: repo}
			if _, err := service.Follow(ctx, uuid.New(), target); !errors.Is(err, boom) {
				t.Fatalf("Follow() error = %v, want boom", err)
			}
		})

		t.Run("has follow request error", func(t *testing.T) {
			repo := newFakeSocialRepo()
			target := uuid.New()
			repo.existingProfiles[target] = true
			repo.privateProfiles[target] = true
			repo.hasFollowRequestErr = boom
			service := &Service{repo: repo}
			if _, err := service.Follow(ctx, uuid.New(), target); !errors.Is(err, boom) {
				t.Fatalf("Follow() error = %v, want boom", err)
			}
		})

		t.Run("create follow request error", func(t *testing.T) {
			repo := newFakeSocialRepo()
			target := uuid.New()
			repo.existingProfiles[target] = true
			repo.privateProfiles[target] = true
			repo.createFollowReqErr = boom
			service := &Service{repo: repo}
			if _, err := service.Follow(ctx, uuid.New(), target); !errors.Is(err, boom) {
				t.Fatalf("Follow() error = %v, want boom", err)
			}
		})

		t.Run("create follow error", func(t *testing.T) {
			repo := newFakeSocialRepo()
			target := uuid.New()
			repo.existingProfiles[target] = true
			repo.createFollowErr = boom
			service := &Service{repo: repo}
			if _, err := service.Follow(ctx, uuid.New(), target); !errors.Is(err, boom) {
				t.Fatalf("Follow() error = %v, want boom", err)
			}
		})
	})

	t.Run("create notification failure is ignored", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		repo.createNotifErr = errors.New("notif boom")
		service := &Service{repo: repo}
		resp, err := service.Follow(ctx, uuid.New(), target)
		if err != nil || !resp.Following {
			t.Fatalf("Follow(notif failure ignored) = %+v, %v", resp, err)
		}
	})
}

func TestSocialServiceBlockUnblockMocked(t *testing.T) {
	ctx := context.Background()
	boom := errors.New("boom")

	t.Run("self block rejected", func(t *testing.T) {
		repo := newFakeSocialRepo()
		service := &Service{repo: repo}
		if _, err := service.Block(ctx, uuid.New(), repo.currentProfileID); !errors.Is(err, ErrCannotBlockSelf) {
			t.Fatalf("Block(self) error = %v, want ErrCannotBlockSelf", err)
		}
	})

	t.Run("target missing", func(t *testing.T) {
		repo := newFakeSocialRepo()
		service := &Service{repo: repo}
		if _, err := service.Block(ctx, uuid.New(), uuid.New()); !errors.Is(err, ErrProfileNotFound) {
			t.Fatalf("Block(missing target) error = %v, want ErrProfileNotFound", err)
		}
	})

	t.Run("find profile error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.findProfileErr = boom
		service := &Service{repo: repo}
		if _, err := service.Block(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
			t.Fatalf("Block() error = %v, want boom", err)
		}
	})

	t.Run("create block error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		repo.createBlockErr = boom
		service := &Service{repo: repo}
		if _, err := service.Block(ctx, uuid.New(), target); !errors.Is(err, boom) {
			t.Fatalf("Block() error = %v, want boom", err)
		}
	})

	t.Run("happy path also removes existing follow", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		repo.following[pairKey(repo.currentProfileID, target)] = true
		service := &Service{repo: repo}
		resp, err := service.Block(ctx, uuid.New(), target)
		if err != nil || !resp.Blocked {
			t.Fatalf("Block() = %+v, %v", resp, err)
		}
		if !repo.blockedPairs[pairKey(repo.currentProfileID, target)] {
			t.Fatal("Block() should record the block relation")
		}
		if repo.following[pairKey(repo.currentProfileID, target)] {
			t.Fatal("Block() should remove the existing follow relation")
		}
	})

	t.Run("reciprocal block also clears the reverse follow", func(t *testing.T) {
		repo := newFakeSocialRepo()
		other := uuid.New()
		repo.existingProfiles[other] = true
		// other suit deja le profil courant avant le blocage.
		repo.following[pairKey(other, repo.currentProfileID)] = true
		service := &Service{repo: repo}

		if _, err := service.Block(ctx, uuid.New(), other); err != nil {
			t.Fatalf("Block() error = %v", err)
		}
		if repo.following[pairKey(other, repo.currentProfileID)] {
			t.Fatal("Block() should clear the reverse follow relation too")
		}
	})

	t.Run("unblock find profile error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.findProfileErr = boom
		service := &Service{repo: repo}
		if _, err := service.Unblock(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
			t.Fatalf("Unblock() error = %v, want boom", err)
		}
	})

	t.Run("unblock delete error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.deleteBlockErr = boom
		service := &Service{repo: repo}
		if _, err := service.Unblock(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
			t.Fatalf("Unblock() error = %v, want boom", err)
		}
	})

	t.Run("unblock happy path", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.blockedPairs[pairKey(repo.currentProfileID, target)] = true
		service := &Service{repo: repo}
		resp, err := service.Unblock(ctx, uuid.New(), target)
		if err != nil || resp.Blocked {
			t.Fatalf("Unblock() = %+v, %v", resp, err)
		}
		if repo.blockedPairs[pairKey(repo.currentProfileID, target)] {
			t.Fatal("Unblock() should remove the block relation")
		}
	})
}

func TestSocialServiceUnfollowMocked(t *testing.T) {
	ctx := context.Background()
	boom := errors.New("boom")

	t.Run("self unfollow rejected", func(t *testing.T) {
		repo := newFakeSocialRepo()
		service := &Service{repo: repo}
		if _, err := service.Unfollow(ctx, uuid.New(), repo.currentProfileID); !errors.Is(err, ErrCannotFollowSelf) {
			t.Fatalf("Unfollow(self) error = %v, want ErrCannotFollowSelf", err)
		}
	})

	t.Run("find profile error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.findProfileErr = boom
		service := &Service{repo: repo}
		if _, err := service.Unfollow(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
			t.Fatalf("Unfollow() error = %v, want boom", err)
		}
	})

	t.Run("delete follow error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.deleteFollowErr = boom
		service := &Service{repo: repo}
		if _, err := service.Unfollow(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
			t.Fatalf("Unfollow() error = %v, want boom", err)
		}
	})

	t.Run("delete follow request error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.deleteFollowReqErr = boom
		service := &Service{repo: repo}
		if _, err := service.Unfollow(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
			t.Fatalf("Unfollow() error = %v, want boom", err)
		}
	})

	t.Run("happy path clears follow, request and notification", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.following[pairKey(repo.currentProfileID, target)] = true
		repo.pendingRequests[pairKey(repo.currentProfileID, target)] = true
		service := &Service{repo: repo}
		resp, err := service.Unfollow(ctx, uuid.New(), target)
		if err != nil || resp.Following {
			t.Fatalf("Unfollow() = %+v, %v", resp, err)
		}
		if repo.following[pairKey(repo.currentProfileID, target)] {
			t.Fatal("Unfollow() should remove the follow relation")
		}
		if repo.pendingRequests[pairKey(repo.currentProfileID, target)] {
			t.Fatal("Unfollow() should remove the pending follow request")
		}
		if !repo.deletedFollowRequestNotif {
			t.Fatal("Unfollow() should attempt to delete the follow request notification")
		}
	})
}

func TestSocialServiceAcceptRejectFollowRequestMocked(t *testing.T) {
	ctx := context.Background()
	boom := errors.New("boom")

	t.Run("accept find profile error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.findProfileErr = boom
		service := &Service{repo: repo}
		if _, err := service.AcceptFollowRequest(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
			t.Fatalf("AcceptFollowRequest() error = %v, want boom", err)
		}
	})

	t.Run("accept missing request", func(t *testing.T) {
		repo := newFakeSocialRepo()
		service := &Service{repo: repo}
		if _, err := service.AcceptFollowRequest(ctx, uuid.New(), uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("AcceptFollowRequest(missing) error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("accept repository error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.acceptFollowReqErr = boom
		service := &Service{repo: repo}
		if _, err := service.AcceptFollowRequest(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
			t.Fatalf("AcceptFollowRequest() error = %v, want boom", err)
		}
	})

	t.Run("accept happy path", func(t *testing.T) {
		repo := newFakeSocialRepo()
		requester := uuid.New()
		repo.pendingRequests[pairKey(requester, repo.currentProfileID)] = true
		service := &Service{repo: repo}
		resp, err := service.AcceptFollowRequest(ctx, uuid.New(), requester)
		if err != nil || !resp.Following {
			t.Fatalf("AcceptFollowRequest() = %+v, %v", resp, err)
		}
		if !repo.following[pairKey(requester, repo.currentProfileID)] {
			t.Fatal("AcceptFollowRequest() should create the follow relation")
		}
		if !repo.deletedFollowRequestNotif {
			t.Fatal("AcceptFollowRequest() should delete the follow request notification")
		}
	})

	t.Run("reject find profile error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.findProfileErr = boom
		service := &Service{repo: repo}
		if err := service.RejectFollowRequest(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
			t.Fatalf("RejectFollowRequest() error = %v, want boom", err)
		}
	})

	t.Run("reject has follow request error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.hasFollowRequestErr = boom
		service := &Service{repo: repo}
		if err := service.RejectFollowRequest(ctx, uuid.New(), uuid.New()); !errors.Is(err, boom) {
			t.Fatalf("RejectFollowRequest() error = %v, want boom", err)
		}
	})

	t.Run("reject no pending request", func(t *testing.T) {
		repo := newFakeSocialRepo()
		service := &Service{repo: repo}
		if err := service.RejectFollowRequest(ctx, uuid.New(), uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
			t.Fatalf("RejectFollowRequest(no pending) error = %v, want ErrRecordNotFound", err)
		}
	})

	t.Run("reject delete request error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		requester := uuid.New()
		repo.pendingRequests[pairKey(requester, repo.currentProfileID)] = true
		repo.deleteFollowReqErr = boom
		service := &Service{repo: repo}
		if err := service.RejectFollowRequest(ctx, uuid.New(), requester); !errors.Is(err, boom) {
			t.Fatalf("RejectFollowRequest() error = %v, want boom", err)
		}
	})

	t.Run("reject happy path", func(t *testing.T) {
		repo := newFakeSocialRepo()
		requester := uuid.New()
		repo.pendingRequests[pairKey(requester, repo.currentProfileID)] = true
		service := &Service{repo: repo}
		if err := service.RejectFollowRequest(ctx, uuid.New(), requester); err != nil {
			t.Fatalf("RejectFollowRequest() error = %v", err)
		}
		if repo.pendingRequests[pairKey(requester, repo.currentProfileID)] {
			t.Fatal("RejectFollowRequest() should remove the pending request")
		}
		if !repo.deletedFollowRequestNotif {
			t.Fatal("RejectFollowRequest() should delete the follow request notification")
		}
	})
}

func TestSocialServiceFollowersFollowingMocked(t *testing.T) {
	ctx := context.Background()
	boom := errors.New("boom")

	displayName := "Bob B"
	rows := []profileRow{
		{ID: uuid.New(), Username: "bob", DisplayName: &displayName, Email: "bob@example.com", Role: "USER"},
		{ID: uuid.New(), Username: "carol", Email: "carol@example.com", Role: ""},
	}

	t.Run("followers target missing", func(t *testing.T) {
		repo := newFakeSocialRepo()
		service := &Service{repo: repo}
		if _, err := service.Followers(ctx, uuid.New(), 1, 20); !errors.Is(err, ErrProfileNotFound) {
			t.Fatalf("Followers(missing) error = %v, want ErrProfileNotFound", err)
		}
	})

	t.Run("followers profile exists error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		repo.profileExistsErr = boom
		service := &Service{repo: repo}
		if _, err := service.Followers(ctx, uuid.New(), 1, 20); !errors.Is(err, boom) {
			t.Fatalf("Followers() error = %v, want boom", err)
		}
	})

	t.Run("followers repository error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		repo.followersErr = boom
		service := &Service{repo: repo}
		if _, err := service.Followers(ctx, target, 1, 20); !errors.Is(err, boom) {
			t.Fatalf("Followers() error = %v, want boom", err)
		}
	})

	t.Run("followers happy path maps rows to users", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		repo.followersRows = rows
		repo.followersTotal = 2
		repo.followersCount[rows[0].ID] = 5
		repo.followingCount[rows[0].ID] = 1
		service := &Service{repo: repo}

		resp, err := service.Followers(ctx, target, 0, 0)
		if err != nil {
			t.Fatalf("Followers() error = %v", err)
		}
		if resp.Total != 2 || resp.Page != 1 || resp.Limit != 20 {
			t.Fatalf("Followers() pagination = %+v", resp)
		}
		if len(resp.Users) != 2 {
			t.Fatalf("Followers() users = %d, want 2", len(resp.Users))
		}
		if resp.Users[0].DisplayName != displayName {
			t.Fatalf("Followers() displayName = %q, want %q", resp.Users[0].DisplayName, displayName)
		}
		if resp.Users[0].FollowersCount != 5 || resp.Users[0].FollowingCount != 1 {
			t.Fatalf("Followers() counts = %+v", resp.Users[0])
		}
		if resp.Users[1].DisplayName != "carol" {
			t.Fatalf("Followers() fallback displayName = %q, want carol", resp.Users[1].DisplayName)
		}
		if resp.Users[1].Role != "USER" {
			t.Fatalf("Followers() fallback role = %q, want USER", resp.Users[1].Role)
		}
	})

	t.Run("following target missing", func(t *testing.T) {
		repo := newFakeSocialRepo()
		service := &Service{repo: repo}
		if _, err := service.Following(ctx, uuid.New(), 1, 20); !errors.Is(err, ErrProfileNotFound) {
			t.Fatalf("Following(missing) error = %v, want ErrProfileNotFound", err)
		}
	})

	t.Run("following repository error", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		repo.followingErr = boom
		service := &Service{repo: repo}
		if _, err := service.Following(ctx, target, 1, 20); !errors.Is(err, boom) {
			t.Fatalf("Following() error = %v, want boom", err)
		}
	})

	t.Run("following happy path", func(t *testing.T) {
		repo := newFakeSocialRepo()
		target := uuid.New()
		repo.existingProfiles[target] = true
		repo.followingRows = rows
		repo.followingTotal = 2
		service := &Service{repo: repo}
		resp, err := service.Following(ctx, target, 1, 10)
		if err != nil || resp.Total != 2 || len(resp.Users) != 2 {
			t.Fatalf("Following() = %+v, %v", resp, err)
		}
	})
}

func TestSocialServiceEnsureProfileExistsMocked(t *testing.T) {
	ctx := context.Background()
	boom := errors.New("boom")

	repo := newFakeSocialRepo()
	repo.profileExistsErr = boom
	service := &Service{repo: repo}
	if err := service.ensureProfileExists(ctx, uuid.New()); !errors.Is(err, boom) {
		t.Fatalf("ensureProfileExists() error = %v, want boom", err)
	}

	repo2 := newFakeSocialRepo()
	target := uuid.New()
	service2 := &Service{repo: repo2}
	if err := service2.ensureProfileExists(ctx, target); !errors.Is(err, ErrProfileNotFound) {
		t.Fatalf("ensureProfileExists(missing) error = %v, want ErrProfileNotFound", err)
	}

	repo2.existingProfiles[target] = true
	if err := service2.ensureProfileExists(ctx, target); err != nil {
		t.Fatalf("ensureProfileExists(existing) error = %v", err)
	}
}
