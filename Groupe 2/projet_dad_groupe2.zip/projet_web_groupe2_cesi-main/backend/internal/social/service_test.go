package social

import (
	"context"
	"testing"

	"github.com/google/uuid"
)

func TestNormalizePagination(t *testing.T) {
	tests := []struct {
		name      string
		page      int
		limit     int
		wantPage  int
		wantLimit int
	}{
		{name: "defaults", page: 0, limit: 0, wantPage: 1, wantLimit: 20},
		{name: "keeps valid values", page: 2, limit: 10, wantPage: 2, wantLimit: 10},
		{name: "caps limit", page: 3, limit: 99, wantPage: 3, wantLimit: 50},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			page, limit := normalizePagination(tt.page, tt.limit)
			if page != tt.wantPage || limit != tt.wantLimit {
				t.Fatalf("normalizePagination() = (%d, %d), want (%d, %d)", page, limit, tt.wantPage, tt.wantLimit)
			}
		})
	}
}

func TestSocialServiceWorkflowsDryRun(t *testing.T) {
	service := NewService(NewRepository(socialDryRunDB(t)))
	ctx := context.Background()
	accountID := uuid.New()
	targetID := uuid.New()
	requesterID := uuid.New()

	_, _ = service.Follow(ctx, accountID, targetID)
	_, _ = service.Follow(ctx, accountID, uuid.Nil)
	_, _ = service.Block(ctx, accountID, targetID)
	_, _ = service.Unblock(ctx, accountID, targetID)
	_, _ = service.Unfollow(ctx, accountID, targetID)
	_, _ = service.AcceptFollowRequest(ctx, accountID, requesterID)
	_ = service.RejectFollowRequest(ctx, accountID, requesterID)
	_, _ = service.Followers(ctx, targetID, 0, 0)
	_, _ = service.Following(ctx, targetID, 0, 0)
	_ = service.ensureProfileExists(ctx, targetID)
}
