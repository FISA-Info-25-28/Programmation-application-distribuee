package users

import (
	"errors"
	"strings"
	"time"

	"breezy/backend/internal/validation"
	"github.com/google/uuid"
)

type userResponse struct {
	ID             uuid.UUID `json:"id"`
	ProfileID      uuid.UUID `json:"profileId"`
	Username       string    `json:"username"`
	DisplayName    string    `json:"displayName"`
	Email          string    `json:"email"`
	Role           string    `json:"role"`
	Bio            *string   `json:"bio"`
	AvatarURL      *string   `json:"avatarUrl"`
	FollowersCount int64     `json:"followersCount"`
	FollowingCount int64     `json:"followingCount"`
	IsFollowing    bool      `json:"isFollowing"`
	RequestPending bool      `json:"requestPending"`
	IsPrivate      bool      `json:"isPrivate"`
	PostsCount     int64     `json:"postsCount"`
	CreatedAt      time.Time `json:"createdAt"`
}

// adminUserResponse represente un compte affiche dans l'administration.
// Entrees : donnees agregees depuis auth.accounts et profiles.profiles.
// Sortie JSON : identifiants, profil public, role, statut et dates du compte.
type adminUserResponse struct {
	AccountID   uuid.UUID `json:"accountId"`
	ProfileID   uuid.UUID `json:"profileId"`
	Username    string    `json:"username"`
	DisplayName string    `json:"displayName"`
	Email       string    `json:"email"`
	Role        string    `json:"role"`
	Status      string    `json:"status"`
	IsPrivate   bool      `json:"isPrivate"`
	CreatedAt   time.Time `json:"createdAt"`
	UpdatedAt   time.Time `json:"updatedAt"`
}

// createAdminUserRequest porte les champs envoyes par un administrateur pour creer un compte.
// Entrees JSON : email, password, username, displayName et role optionnel.
// Sortie : aucune sortie directe, Validate retourne une erreur si un champ est invalide.
type createAdminUserRequest struct {
	Email       string `json:"email" binding:"required,email"`
	Password    string `json:"password" binding:"required,min=12"`
	Username    string `json:"username" binding:"required,min=3,max=30"`
	DisplayName string `json:"displayName" binding:"required,min=1,max=80"`
	Role        string `json:"role"`
}

// Validate controle la creation de compte depuis l'administration.
// Entrees : valeurs du formulaire createAdminUserRequest.
// Sortie : nil si les champs respectent les regles, sinon une erreur de validation.
func (r createAdminUserRequest) Validate() error {
	if len(strings.TrimSpace(r.Email)) > 254 {
		return errors.New("email is too long")
	}
	if err := validation.Username(r.Username); err != nil {
		return err
	}
	if _, err := validation.TrimmedRequired(r.DisplayName, 80, "displayName"); err != nil {
		return err
	}
	if len(strings.TrimSpace(r.Password)) > 256 {
		return errors.New("password is too long")
	}
	if err := validation.Password(r.Password, r.Username, r.Email, r.DisplayName); err != nil {
		return err
	}
	if strings.TrimSpace(r.Role) == "" {
		return nil
	}
	return validation.OneOf(r.Role, "USER", "MODERATOR", "ADMIN")
}

// updateUserRoleRequest porte le nouveau role choisi par un administrateur.
// Entree JSON : role attendu parmi USER, MODERATOR ou ADMIN.
// Sortie : aucune sortie directe, Validate retourne une erreur si le role est invalide.
type updateUserRoleRequest struct {
	Role string `json:"role" binding:"required"`
}

// Validate controle que le role demande est autorise.
// Entree : role du payload updateUserRoleRequest.
// Sortie : nil si le role est accepte, sinon une erreur de validation.
func (r updateUserRoleRequest) Validate() error {
	return validation.OneOf(r.Role, "USER", "MODERATOR", "ADMIN")
}
