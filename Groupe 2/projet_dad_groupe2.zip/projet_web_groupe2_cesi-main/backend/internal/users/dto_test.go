package users

import (
	"strings"
	"testing"
)

func TestCreateAdminUserRequestValidate(t *testing.T) {
	req := createAdminUserRequest{
		Email:       "admin@example.com",
		Password:    "StrongPass1!",
		Username:    "admin_user",
		DisplayName: "Admin User",
		Role:        "ADMIN",
	}
	if err := req.Validate(); err != nil {
		t.Fatalf("createAdminUserRequest.Validate() unexpected error: %v", err)
	}

	tests := []createAdminUserRequest{
		{Email: strings.Repeat("a", 255), Password: "StrongPass1!", Username: "admin_user", DisplayName: "Admin User"},
		{Email: "admin@example.com", Password: "StrongPass1!", Username: "bad-name", DisplayName: "Admin User"},
		{Email: "admin@example.com", Password: "StrongPass1!", Username: "admin_user", DisplayName: ""},
		{Email: "admin@example.com", Password: strings.Repeat("x", 257), Username: "admin_user", DisplayName: "Admin User"},
		{Email: "admin@example.com", Password: "weak", Username: "admin_user", DisplayName: "Admin User"},
		{Email: "admin@example.com", Password: "StrongPass1!", Username: "admin_user", DisplayName: "Admin User", Role: "OWNER"},
	}
	for _, req := range tests {
		if err := req.Validate(); err == nil {
			t.Fatalf("createAdminUserRequest.Validate(%+v) expected error", req)
		}
	}
}

func TestUpdateUserRoleRequestValidate(t *testing.T) {
	for _, role := range []string{"USER", "moderator", " ADMIN "} {
		if err := (updateUserRoleRequest{Role: role}).Validate(); err != nil {
			t.Fatalf("updateUserRoleRequest.Validate(%q) unexpected error: %v", role, err)
		}
	}
	if err := (updateUserRoleRequest{Role: "OWNER"}).Validate(); err == nil {
		t.Fatal("updateUserRoleRequest.Validate() expected invalid role error")
	}
}
