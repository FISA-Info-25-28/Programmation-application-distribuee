package users

import (
	"errors"
	"log"
	"net/http"
	"strconv"

	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Handler struct {
	db      *gorm.DB
	service *Service
}

func NewHandler(db *gorm.DB) *Handler {
	repo := NewRepository(db)
	return &Handler{db: db, service: NewService(repo)}
}

func (h *Handler) Suggestions(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	users, err := h.service.Suggestions(c.Request.Context(), accountID, parseSuggestionsLimit(c.Query("limit")))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "suggestions lookup failed"})
		return
	}

	c.JSON(http.StatusOK, users)
}

func (h *Handler) Search(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	accountID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	users, err := h.service.SearchForAccount(c.Request.Context(), accountID, c.Query("q"))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "users lookup failed"})
		return
	}

	c.JSON(http.StatusOK, users)
}

// ListAdminUsers retourne la liste des comptes consultables par un administrateur.
// Entrees : contexte HTTP authentifie ADMIN, query param q facultatif pour filtrer.
// Sortie HTTP : 200 avec les utilisateurs adminUserResponse ou une erreur JSON.
func (h *Handler) ListAdminUsers(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	users, err := h.service.ListAdminUsers(c.Request.Context(), c.Query("q"))
	if err != nil {
		log.Printf("[users] admin users lookup failed: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "admin users lookup failed"})
		return
	}

	c.JSON(http.StatusOK, users)
}

// CreateAdminUser cree un compte utilisateur depuis l'administration.
// Entrees : contexte HTTP ADMIN et payload JSON createAdminUserRequest.
// Sortie HTTP : 201 avec le compte cree, 400/409/500 selon l'erreur rencontree.
func (h *Handler) CreateAdminUser(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	var req createAdminUserRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid user payload"})
		return
	}

	user, err := h.service.CreateAdminUser(c.Request.Context(), req)
	if err != nil {
		switch {
		case errors.Is(err, ErrEmailAlreadyRegistered):
			c.JSON(http.StatusConflict, gin.H{"error": "email already registered"})
		case errors.Is(err, ErrUsernameAlreadyRegistered):
			c.JSON(http.StatusConflict, gin.H{"error": "username already registered"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "user creation failed"})
		}
		return
	}

	c.JSON(http.StatusCreated, user)
}

// UpdateAdminUserRole modifie le role d'un compte cible.
// Entrees : contexte HTTP ADMIN, accountId dans l'URL et payload updateUserRoleRequest.
// Sortie HTTP : 200 avec le compte mis a jour, ou une erreur JSON si l'action est refusee.
func (h *Handler) UpdateAdminUserRole(c *gin.Context) {
	if !h.databaseAvailable(c) {
		return
	}

	actorID, ok := middleware.AccountID(c)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "authenticated account missing"})
		return
	}

	accountID, err := uuid.Parse(c.Param("accountId"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid account id"})
		return
	}

	var req updateUserRoleRequest
	if err := c.ShouldBindJSON(&req); err != nil || req.Validate() != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid role payload"})
		return
	}

	user, err := h.service.UpdateAdminUserRole(c.Request.Context(), actorID, accountID, req.Role)
	if err != nil {
		switch {
		case errors.Is(err, ErrCannotChangeOwnRole):
			c.JSON(http.StatusBadRequest, gin.H{"error": "cannot change own role"})
		case errors.Is(err, gorm.ErrRecordNotFound):
			c.JSON(http.StatusNotFound, gin.H{"error": "user not found"})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "role update failed"})
		}
		return
	}

	c.JSON(http.StatusOK, user)
}

func (h *Handler) databaseAvailable(c *gin.Context) bool {
	if h.db != nil {
		return true
	}
	c.JSON(http.StatusServiceUnavailable, gin.H{"error": "database unavailable"})
	return false
}

func parseSuggestionsLimit(raw string) int {
	limit, err := strconv.Atoi(raw)
	if err != nil || limit <= 0 {
		return 4
	}
	if limit > 50 {
		return 50
	}
	return limit
}
