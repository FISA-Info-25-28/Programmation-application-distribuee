package users

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"breezy/backend/internal/middleware"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestUsersHandlerDatabaseUnavailable(t *testing.T) {
	gin.SetMode(gin.TestMode)
	handler := NewHandler(nil)

	tests := []struct {
		method string
		path   string
		setup  func(*gin.Engine)
	}{
		{method: http.MethodGet, path: "/suggestions", setup: func(r *gin.Engine) { r.GET("/suggestions", handler.Suggestions) }},
		{method: http.MethodGet, path: "/search", setup: func(r *gin.Engine) { r.GET("/search", handler.Search) }},
		{method: http.MethodGet, path: "/admin/users", setup: func(r *gin.Engine) { r.GET("/admin/users", handler.ListAdminUsers) }},
		{method: http.MethodPost, path: "/admin/users", setup: func(r *gin.Engine) { r.POST("/admin/users", handler.CreateAdminUser) }},
		{method: http.MethodPatch, path: "/admin/users/bad/role", setup: func(r *gin.Engine) { r.PATCH("/admin/users/:accountId/role", handler.UpdateAdminUserRole) }},
	}

	for _, tt := range tests {
		router := gin.New()
		tt.setup(router)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(tt.method, tt.path, nil))
		if rec.Code != http.StatusServiceUnavailable {
			t.Fatalf("%s %s status = %d, want 503", tt.method, tt.path, rec.Code)
		}
	}
}

func TestRegisterRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	RegisterRoutes(router, NewHandler(nil))

	for _, path := range []string{"/suggestions", "/search", "/admin/users"} {
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, path, nil))
		if rec.Code != http.StatusUnauthorized {
			t.Fatalf("GET %s status = %d, want 401", path, rec.Code)
		}
	}
}

// usersHandlerMockDB ouvre une connexion GORM appuyee sur sqlmock (mode reel)
// afin de scripter les requetes SQL attendues lors des tests de handler.
func usersHandlerMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

func withAccountID(accountID uuid.UUID) gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Set(middleware.ContextAccountID, accountID)
		c.Next()
	}
}

func TestHandlerSuggestionsAndSearchMissingAccount(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := usersHandlerMockDB(t)
	handler := NewHandler(db)

	tests := []struct {
		method, path string
		setup        func(*gin.Engine)
	}{
		{method: http.MethodGet, path: "/suggestions", setup: func(r *gin.Engine) { r.GET("/suggestions", handler.Suggestions) }},
		{method: http.MethodGet, path: "/search", setup: func(r *gin.Engine) { r.GET("/search", handler.Search) }},
		{method: http.MethodPatch, path: "/admin/users/" + uuid.NewString() + "/role", setup: func(r *gin.Engine) {
			r.PATCH("/admin/users/:accountId/role", handler.UpdateAdminUserRole)
		}},
	}

	for _, tt := range tests {
		router := gin.New()
		tt.setup(router)
		rec := httptest.NewRecorder()
		req := httptest.NewRequest(tt.method, tt.path, strings.NewReader(`{"role":"ADMIN"}`))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("%s %s status = %d, want 500: %s", tt.method, tt.path, rec.Code, rec.Body.String())
		}
	}
}

func TestHandlerSuggestionsSuccessAndFailure(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()

	t.Run("success", func(t *testing.T) {
		db, mock := usersHandlerMockDB(t)
		handler := NewHandler(db)
		mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{
			"id", "account_id", "username", "display_name", "email", "role", "bio", "avatar_url", "is_private", "created_at",
			"followers_count", "following_count", "is_following", "request_pending", "posts_count",
		}))

		router := gin.New()
		router.Use(withAccountID(accountID))
		router.GET("/suggestions", handler.Suggestions)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/suggestions", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Suggestions() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("query error", func(t *testing.T) {
		db, mock := usersHandlerMockDB(t)
		handler := NewHandler(db)
		mock.ExpectQuery(".*").WillReturnError(gorm.ErrInvalidData)

		router := gin.New()
		router.Use(withAccountID(accountID))
		router.GET("/suggestions", handler.Suggestions)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/suggestions", nil))
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("Suggestions() status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}

func TestHandlerSearchSuccessAndFailure(t *testing.T) {
	gin.SetMode(gin.TestMode)
	accountID := uuid.New()

	t.Run("success", func(t *testing.T) {
		db, mock := usersHandlerMockDB(t)
		handler := NewHandler(db)
		mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{
			"id", "account_id", "username", "display_name", "email", "role", "bio", "avatar_url", "is_private", "created_at",
			"followers_count", "following_count", "is_following", "request_pending", "posts_count",
		}))

		router := gin.New()
		router.Use(withAccountID(accountID))
		router.GET("/search", handler.Search)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/search?q=alice", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("Search() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("query error", func(t *testing.T) {
		db, mock := usersHandlerMockDB(t)
		handler := NewHandler(db)
		mock.ExpectQuery(".*").WillReturnError(gorm.ErrInvalidData)

		router := gin.New()
		router.Use(withAccountID(accountID))
		router.GET("/search", handler.Search)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/search?q=alice", nil))
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("Search() status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}

func TestHandlerListAdminUsersSuccessAndFailure(t *testing.T) {
	gin.SetMode(gin.TestMode)

	t.Run("success", func(t *testing.T) {
		db, mock := usersHandlerMockDB(t)
		handler := NewHandler(db)
		now := time.Now().UTC()
		rows := sqlmock.NewRows([]string{
			"account_id", "profile_id", "username", "display_name", "email", "role", "status", "is_private", "created_at", "updated_at",
		}).AddRow(uuid.New(), uuid.New(), "alice", "Alice", "alice@example.com", "USER", "ACTIVE", false, now, now)
		mock.ExpectQuery(".*").WillReturnRows(rows)

		router := gin.New()
		router.GET("/admin/users", handler.ListAdminUsers)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/admin/users", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("ListAdminUsers() status = %d, want 200: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("query error", func(t *testing.T) {
		db, mock := usersHandlerMockDB(t)
		handler := NewHandler(db)
		mock.ExpectQuery(".*").WillReturnError(gorm.ErrInvalidData)

		router := gin.New()
		router.GET("/admin/users", handler.ListAdminUsers)
		rec := httptest.NewRecorder()
		router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/admin/users", nil))
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("ListAdminUsers() status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}

func TestHandlerCreateAdminUserInvalidPayload(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := usersHandlerMockDB(t)
	handler := NewHandler(db)

	tests := []struct {
		name string
		body string
	}{
		{name: "malformed json", body: `{`},
		{name: "missing required fields", body: `{"email":"bad"}`},
		{name: "invalid role", body: `{"email":"a@example.com","password":"StrongPass123!","username":"alice","displayName":"Alice","role":"OWNER"}`},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			router.POST("/admin/users", handler.CreateAdminUser)
			rec := httptest.NewRecorder()
			req := httptest.NewRequest(http.MethodPost, "/admin/users", strings.NewReader(tt.body))
			req.Header.Set("Content-Type", "application/json")
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusBadRequest {
				t.Fatalf("CreateAdminUser(%s) status = %d, want 400: %s", tt.name, rec.Code, rec.Body.String())
			}
		})
	}
}

func TestHandlerCreateAdminUserConflicts(t *testing.T) {
	gin.SetMode(gin.TestMode)
	body := `{"email":"new.admin@example.com","password":"StrongPass123!","username":"new_admin","displayName":"New Admin","role":"MODERATOR"}`

	t.Run("email already registered", func(t *testing.T) {
		db, mock := usersHandlerMockDB(t)
		handler := NewHandler(db)
		mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"id", "email"}).AddRow(uuid.New(), "new.admin@example.com"))

		router := gin.New()
		router.POST("/admin/users", handler.CreateAdminUser)
		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/admin/users", strings.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusConflict {
			t.Fatalf("CreateAdminUser() status = %d, want 409: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("username already registered", func(t *testing.T) {
		db, mock := usersHandlerMockDB(t)
		handler := NewHandler(db)
		mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
		mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"id", "username"}).AddRow(uuid.New(), "new_admin"))

		router := gin.New()
		router.POST("/admin/users", handler.CreateAdminUser)
		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/admin/users", strings.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusConflict {
			t.Fatalf("CreateAdminUser() status = %d, want 409: %s", rec.Code, rec.Body.String())
		}
	})

	t.Run("unexpected service error", func(t *testing.T) {
		db, mock := usersHandlerMockDB(t)
		handler := NewHandler(db)
		mock.ExpectQuery(".*").WillReturnError(gorm.ErrInvalidData)

		router := gin.New()
		router.POST("/admin/users", handler.CreateAdminUser)
		rec := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodPost, "/admin/users", strings.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		router.ServeHTTP(rec, req)
		if rec.Code != http.StatusInternalServerError {
			t.Fatalf("CreateAdminUser() status = %d, want 500: %s", rec.Code, rec.Body.String())
		}
	})
}

func TestHandlerCreateAdminUserSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := usersHandlerMockDB(t)
	handler := NewHandler(db)
	accountID := uuid.New()
	profileID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
	adminRows := sqlmock.NewRows([]string{
		"account_id", "profile_id", "username", "display_name", "email", "role", "status", "is_private", "created_at", "updated_at",
	}).AddRow(accountID, profileID, "new_admin", "New Admin", "new.admin@example.com", "MODERATOR", "ACTIVE", false, now, now)
	mock.ExpectQuery(".*").WillReturnRows(adminRows)
	mock.ExpectCommit()

	router := gin.New()
	router.POST("/admin/users", handler.CreateAdminUser)
	rec := httptest.NewRecorder()
	body := `{"email":"new.admin@example.com","password":"StrongPass123!","username":"new_admin","displayName":"New Admin","role":"MODERATOR"}`
	req := httptest.NewRequest(http.MethodPost, "/admin/users", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusCreated {
		t.Fatalf("CreateAdminUser() status = %d, want 201: %s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), "new_admin") {
		t.Fatalf("CreateAdminUser() body = %s, want username in payload", rec.Body.String())
	}
}

func TestHandlerUpdateAdminUserRoleInvalidInput(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := usersHandlerMockDB(t)
	handler := NewHandler(db)
	accountID := uuid.New()

	tests := []struct {
		name string
		path string
		body string
	}{
		{name: "invalid account id", path: "/admin/users/not-a-uuid/role", body: `{"role":"ADMIN"}`},
		{name: "malformed json", path: "/admin/users/" + uuid.NewString() + "/role", body: `{`},
		{name: "invalid role", path: "/admin/users/" + uuid.NewString() + "/role", body: `{"role":"OWNER"}`},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			router := gin.New()
			router.Use(withAccountID(accountID))
			router.PATCH("/admin/users/:accountId/role", handler.UpdateAdminUserRole)
			rec := httptest.NewRecorder()
			req := httptest.NewRequest(http.MethodPatch, tt.path, strings.NewReader(tt.body))
			req.Header.Set("Content-Type", "application/json")
			router.ServeHTTP(rec, req)
			if rec.Code != http.StatusBadRequest {
				t.Fatalf("UpdateAdminUserRole(%s) status = %d, want 400: %s", tt.name, rec.Code, rec.Body.String())
			}
		})
	}
}

func TestHandlerUpdateAdminUserRoleCannotChangeOwnRole(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, _ := usersHandlerMockDB(t)
	handler := NewHandler(db)
	accountID := uuid.New()

	router := gin.New()
	router.Use(withAccountID(accountID))
	router.PATCH("/admin/users/:accountId/role", handler.UpdateAdminUserRole)
	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPatch, "/admin/users/"+accountID.String()+"/role", strings.NewReader(`{"role":"ADMIN"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("UpdateAdminUserRole(self) status = %d, want 400: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerUpdateAdminUserRoleNotFound(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := usersHandlerMockDB(t)
	handler := NewHandler(db)
	actorID := uuid.New()
	targetID := uuid.New()

	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectRollback()

	router := gin.New()
	router.Use(withAccountID(actorID))
	router.PATCH("/admin/users/:accountId/role", handler.UpdateAdminUserRole)
	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPatch, "/admin/users/"+targetID.String()+"/role", strings.NewReader(`{"role":"ADMIN"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusNotFound {
		t.Fatalf("UpdateAdminUserRole(missing) status = %d, want 404: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerUpdateAdminUserRoleUnexpectedError(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := usersHandlerMockDB(t)
	handler := NewHandler(db)
	actorID := uuid.New()
	targetID := uuid.New()

	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnError(gorm.ErrInvalidData)
	mock.ExpectRollback()

	router := gin.New()
	router.Use(withAccountID(actorID))
	router.PATCH("/admin/users/:accountId/role", handler.UpdateAdminUserRole)
	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPatch, "/admin/users/"+targetID.String()+"/role", strings.NewReader(`{"role":"ADMIN"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("UpdateAdminUserRole(unexpected) status = %d, want 500: %s", rec.Code, rec.Body.String())
	}
}

func TestHandlerUpdateAdminUserRoleSuccess(t *testing.T) {
	gin.SetMode(gin.TestMode)
	db, mock := usersHandlerMockDB(t)
	handler := NewHandler(db)
	actorID := uuid.New()
	targetID := uuid.New()
	profileID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()
	rows := sqlmock.NewRows([]string{
		"account_id", "profile_id", "username", "display_name", "email", "role", "status", "is_private", "created_at", "updated_at",
	}).AddRow(targetID, profileID, "target", "Target", "target@example.com", "ADMIN", "ACTIVE", false, now, now)
	mock.ExpectQuery(".*").WillReturnRows(rows)

	router := gin.New()
	router.Use(withAccountID(actorID))
	router.PATCH("/admin/users/:accountId/role", handler.UpdateAdminUserRole)
	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPatch, "/admin/users/"+targetID.String()+"/role", strings.NewReader(`{"role":"ADMIN"}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("UpdateAdminUserRole() status = %d, want 200: %s", rec.Code, rec.Body.String())
	}
}
