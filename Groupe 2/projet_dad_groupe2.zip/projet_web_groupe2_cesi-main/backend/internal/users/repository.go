package users

import (
	"context"
	"strings"
	"time"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository struct {
	db *gorm.DB
}

type profileRow struct {
	ID             uuid.UUID
	AccountID      uuid.UUID
	Username       string
	DisplayName    string
	Email          string
	Role           string
	Bio            *string
	AvatarURL      *string
	FollowersCount int64
	FollowingCount int64
	IsFollowing    bool
	RequestPending bool
	IsPrivate      bool
	PostsCount     int64
	CreatedAt      time.Time
}

// adminUserRow represente une ligne SQL utilisee par l'ecran d'administration.
// Entrees : colonnes selectionnees dans auth.accounts et profiles.profiles.
// Sortie : structure interne convertie ensuite en adminUserResponse.
type adminUserRow struct {
	AccountID   uuid.UUID
	ProfileID   uuid.UUID
	Username    string
	DisplayName string
	Email       string
	Role        string
	Status      string
	IsPrivate   bool
	CreatedAt   time.Time
	UpdatedAt   time.Time
}

func NewRepository(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

// WithDB cree un repository utilisant une connexion GORM donnee.
// Entree : db, souvent une transaction en cours.
// Sortie : nouveau Repository branche sur cette connexion.
func (r *Repository) WithDB(db *gorm.DB) *Repository {
	return &Repository{db: db}
}

// Transaction execute une operation atomique dans le repository users.
// Entree : fonction recevant un repository connecte a la transaction.
// Sortie : nil si le commit reussit, sinon l'erreur qui annule la transaction.
func (r *Repository) Transaction(ctx context.Context, fn func(txRepo *Repository) error) error {
	return r.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		return fn(r.WithDB(tx))
	})
}

func (r *Repository) Suggestions(ctx context.Context, currentAccountID uuid.UUID, limit int) ([]profileRow, error) {
	if limit <= 0 {
		limit = 4
	}

	var rows []profileRow
	err := r.db.WithContext(ctx).
		Raw(`
			WITH viewer AS (
				SELECT id, account_id
				FROM profiles.profiles
				WHERE account_id = ?
			)
			SELECT
				p.id,
				p.account_id,
				p.username,
				COALESCE(p.display_name, p.username) AS display_name,
				COALESCE(a.email, '') AS email,
				COALESCE(a.role::text, 'USER') AS role,
				p.bio,
				p.avatar_url,
				p.is_private,
				p.created_at,
				(SELECT COUNT(*) FROM social.follows followers WHERE followers.followed_id = p.id) AS followers_count,
				(SELECT COUNT(*) FROM social.follows following WHERE following.follower_id = p.id) AS following_count,
				FALSE AS is_following,
				FALSE AS request_pending,
				(SELECT COUNT(*) FROM posts.posts own_posts WHERE own_posts.author_id = p.id AND own_posts.parent_id IS NULL) AS posts_count
			FROM profiles.profiles p
			CROSS JOIN viewer v
			LEFT JOIN auth.accounts a ON a.id = p.account_id
			WHERE p.account_id <> v.account_id
			  AND NOT EXISTS (
				SELECT 1 FROM social.blocks b
				WHERE (b.blocker_id = p.id AND b.blocked_id = v.id)
				   OR (b.blocker_id = v.id AND b.blocked_id = p.id)
			  )
			  AND NOT EXISTS (
				SELECT 1
				FROM social.follows existing_follow
				WHERE existing_follow.follower_id = v.id AND existing_follow.followed_id = p.id
			  )
			  AND NOT EXISTS (
				SELECT 1
				FROM social.follow_requests existing_request
				WHERE existing_request.requester_id = v.id AND existing_request.target_id = p.id
			  )
			ORDER BY followers_count DESC, p.created_at DESC
			LIMIT ?
		`, currentAccountID, limit).
		Scan(&rows).
		Error

	return rows, err
}

func (r *Repository) Search(ctx context.Context, currentAccountID uuid.UUID, query string, limit int) ([]profileRow, error) {
	if limit <= 0 {
		limit = 20
	}

	q := "%" + strings.ToLower(strings.TrimSpace(query)) + "%"
	var rows []profileRow
	err := r.db.WithContext(ctx).
		Raw(`
			SELECT
				p.id,
				p.account_id,
				p.username,
				COALESCE(p.display_name, p.username) AS display_name,
				COALESCE(a.email, '') AS email,
				COALESCE(a.role::text, 'USER') AS role,
				p.bio,
				p.avatar_url,
				p.is_private,
				p.created_at,
				COUNT(DISTINCT followers.id) AS followers_count,
				COUNT(DISTINCT following.id) AS following_count,
				EXISTS (
					SELECT 1
					FROM social.follows current_follow
					JOIN profiles.profiles current_profile ON current_profile.id = current_follow.follower_id
					WHERE current_profile.account_id = ? AND current_follow.followed_id = p.id
				) AS is_following,
				EXISTS (
					SELECT 1
					FROM social.follow_requests current_request
					JOIN profiles.profiles current_profile ON current_profile.id = current_request.requester_id
					WHERE current_profile.account_id = ? AND current_request.target_id = p.id
				) AS request_pending,
				COUNT(DISTINCT own_posts.id) AS posts_count
			FROM profiles.profiles p
			LEFT JOIN auth.accounts a ON a.id = p.account_id
			LEFT JOIN social.follows followers ON followers.followed_id = p.id
			LEFT JOIN social.follows following ON following.follower_id = p.id
			LEFT JOIN posts.posts own_posts ON own_posts.author_id = p.id AND own_posts.parent_id IS NULL
			WHERE (lower(p.username) LIKE ? OR lower(COALESCE(p.display_name, p.username)) LIKE ?)
			  AND NOT EXISTS (
				SELECT 1 FROM social.blocks b
				JOIN profiles.profiles viewer ON viewer.account_id = ?
				WHERE (b.blocker_id = p.id AND b.blocked_id = viewer.id)
				   OR (b.blocker_id = viewer.id AND b.blocked_id = p.id)
			  )
			GROUP BY p.id, p.account_id, p.username, p.display_name, a.email, a.role, p.bio, p.avatar_url, p.is_private, p.created_at
			ORDER BY followers_count DESC, p.username ASC
			LIMIT ?
		`, currentAccountID, currentAccountID, q, q, currentAccountID, limit).
		Scan(&rows).
		Error

	return rows, err
}

// ListAdminUsers liste les comptes pour l'administration avec un filtre optionnel.
// Entrees : ctx, query de recherche et limite maximale de resultats.
// Sortie : lignes adminUserRow triees par role puis username, ou une erreur SQL.
func (r *Repository) ListAdminUsers(ctx context.Context, query string, limit int) ([]adminUserRow, error) {
	if limit <= 0 || limit > 100 {
		limit = 100
	}

	baseSQL := `
		SELECT
			a.id AS account_id,
			p.id AS profile_id,
			p.username,
			COALESCE(p.display_name, p.username) AS display_name,
			a.email,
			COALESCE(a.role::text, 'USER') AS role,
			COALESCE(a.status::text, 'ACTIVE') AS status,
			p.is_private,
			a.created_at,
			a.updated_at
		FROM auth.accounts a
		JOIN profiles.profiles p ON p.account_id = a.id
	`
	orderSQL := `
		ORDER BY
			CASE COALESCE(a.role::text, 'USER')
				WHEN 'ADMIN' THEN 1
				WHEN 'MODERATOR' THEN 2
				ELSE 3
			END,
			p.username ASC
		LIMIT ?
	`

	var rows []adminUserRow
	trimmed := strings.TrimSpace(query)
	if trimmed == "" {
		err := r.db.WithContext(ctx).Raw(baseSQL+orderSQL, limit).Scan(&rows).Error
		return rows, err
	}

	q := "%" + strings.ToLower(trimmed) + "%"
	err := r.db.WithContext(ctx).
		Raw(baseSQL+`
			WHERE lower(a.email) LIKE ?
				OR lower(p.username) LIKE ?
				OR lower(COALESCE(p.display_name, p.username)) LIKE ?
		`+orderSQL, q, q, q, limit).
		Scan(&rows).Error
	return rows, err
}

// FindAccountByID recupere un compte depuis le schema auth.
// Entrees : ctx et UUID du compte.
// Sortie : modele Account trouve ou erreur GORM.
func (r *Repository) FindAccountByID(ctx context.Context, accountID uuid.UUID) (models.Account, error) {
	var account models.Account
	err := r.db.WithContext(ctx).Table("auth.accounts").First(&account, "id = ?", accountID).Error
	return account, err
}

// FindAccountByEmail recherche un compte par e-mail, sans tenir compte de la casse.
// Entrees : ctx et email saisi.
// Sortie : modele Account trouve ou erreur GORM.
func (r *Repository) FindAccountByEmail(ctx context.Context, email string) (models.Account, error) {
	var account models.Account
	err := r.db.WithContext(ctx).Table("auth.accounts").Where("lower(email) = lower(?)", email).First(&account).Error
	return account, err
}

// FindProfileByUsername recherche un profil par username, sans tenir compte de la casse.
// Entrees : ctx et username saisi.
// Sortie : modele Profile trouve ou erreur GORM.
func (r *Repository) FindProfileByUsername(ctx context.Context, username string) (models.Profile, error) {
	var profile models.Profile
	err := r.db.WithContext(ctx).
		Table("profiles.profiles").
		Where("lower(username) = lower(?)", username).
		First(&profile).
		Error
	return profile, err
}

// CreateAccount insere un compte dans le schema auth.
// Entrees : ctx et modele Account a creer.
// Sortie : nil si l'insertion reussit, sinon erreur GORM.
func (r *Repository) CreateAccount(ctx context.Context, account *models.Account) error {
	return r.db.WithContext(ctx).Table("auth.accounts").Omit("SuspendedUntil").Create(account).Error
}

// CreateProfile insere le profil public associe a un compte.
// Entrees : ctx et modele Profile a creer.
// Sortie : nil si l'insertion reussit, sinon erreur GORM.
func (r *Repository) CreateProfile(ctx context.Context, profile *models.Profile) error {
	return r.db.WithContext(ctx).Table("profiles.profiles").Create(profile).Error
}

// UpdateAccountRole met a jour le role d'un compte et recharge sa vue admin.
// Entrees : ctx, UUID du compte cible et role normalise.
// Sortie : ligne adminUserRow mise a jour ou erreur GORM.
func (r *Repository) UpdateAccountRole(ctx context.Context, accountID uuid.UUID, role string) (adminUserRow, error) {
	if err := r.db.WithContext(ctx).
		Table("auth.accounts").
		Where("id = ?", accountID).
		Update("role", role).
		Error; err != nil {
		return adminUserRow{}, err
	}
	return r.FindAdminUserByAccountID(ctx, accountID)
}

// FindAdminUserByAccountID recharge un compte dans le format utilise par l'administration.
// Entrees : ctx et UUID du compte.
// Sortie : adminUserRow complete ou gorm.ErrRecordNotFound si le compte n'existe pas.
func (r *Repository) FindAdminUserByAccountID(ctx context.Context, accountID uuid.UUID) (adminUserRow, error) {
	var row adminUserRow
	err := r.db.WithContext(ctx).
		Raw(`
			SELECT
				a.id AS account_id,
				p.id AS profile_id,
				p.username,
				COALESCE(p.display_name, p.username) AS display_name,
				a.email,
				COALESCE(a.role::text, 'USER') AS role,
				COALESCE(a.status::text, 'ACTIVE') AS status,
				p.is_private,
				a.created_at,
				a.updated_at
			FROM auth.accounts a
			JOIN profiles.profiles p ON p.account_id = a.id
			WHERE a.id = ?
		`, accountID).
		Scan(&row).
		Error
	if err != nil {
		return adminUserRow{}, err
	}
	if row.AccountID == uuid.Nil {
		return adminUserRow{}, gorm.ErrRecordNotFound
	}
	return row, nil
}
