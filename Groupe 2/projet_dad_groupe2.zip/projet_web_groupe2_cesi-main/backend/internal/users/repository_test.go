package users

import (
	"context"
	"errors"
	"testing"
	"time"

	"breezy/backend/internal/models"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestRepositoryWithDB(t *testing.T) {
	repo := NewRepository(&gorm.DB{})
	nextDB := &gorm.DB{}
	next := repo.WithDB(nextDB)
	if next == repo {
		t.Fatal("WithDB() should return a new repository")
	}
	if next.db != nextDB {
		t.Fatal("WithDB() did not use provided DB")
	}
}

func TestUsersRepositoryQueriesDryRun(t *testing.T) {
	repo := NewRepository(usersDryRunDB(t))
	ctx := context.Background()
	accountID := uuid.New()

	_ = repo.Transaction(ctx, func(txRepo *Repository) error { return nil })
	_, _ = repo.Suggestions(ctx, accountID, 0)
	_, _ = repo.Search(ctx, accountID, " alice ", 0)
	_, _ = repo.ListAdminUsers(ctx, "", 0)
	_, _ = repo.ListAdminUsers(ctx, "alice", 500)
	_, _ = repo.FindAccountByID(ctx, accountID)
	_, _ = repo.FindAccountByEmail(ctx, "a@example.com")
	_, _ = repo.FindProfileByUsername(ctx, "alice")
	_ = repo.CreateAccount(ctx, &models.Account{ID: accountID, Email: "a@example.com"})
	_ = repo.CreateProfile(ctx, &models.Profile{AccountID: accountID, Username: "alice"})
	_, _ = repo.UpdateAccountRole(ctx, accountID, "MODERATOR")
	_, _ = repo.FindAdminUserByAccountID(ctx, accountID)
}

func usersDryRunDB(t *testing.T) *gorm.DB {
	t.Helper()
	sqlDB, _, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{DryRun: true})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db
}

// usersMockDB ouvre une connexion GORM appuyee sur sqlmock (mode reel, pas
// DryRun) afin de pouvoir scripter precisement les lignes et erreurs SQL
// renvoyees a chaque requete.
func usersMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

func TestRepositoryTransactionCommitAndRollback(t *testing.T) {
	db, mock := usersMockDB(t)
	repo := NewRepository(db)
	ctx := context.Background()

	mock.ExpectBegin()
	mock.ExpectCommit()
	if err := repo.Transaction(ctx, func(txRepo *Repository) error { return nil }); err != nil {
		t.Fatalf("Transaction() commit unexpected error: %v", err)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations: %v", err)
	}

	wantErr := errors.New("boom")
	mock.ExpectBegin()
	mock.ExpectRollback()
	if err := repo.Transaction(ctx, func(txRepo *Repository) error { return wantErr }); !errors.Is(err, wantErr) {
		t.Fatalf("Transaction() rollback error = %v, want %v", err, wantErr)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet expectations: %v", err)
	}
}

func TestFindAdminUserByAccountIDFound(t *testing.T) {
	db, mock := usersMockDB(t)
	repo := NewRepository(db)
	accountID := uuid.New()
	profileID := uuid.New()
	now := time.Now().UTC()

	rows := sqlmock.NewRows([]string{
		"account_id", "profile_id", "username", "display_name", "email", "role", "status", "is_private", "created_at", "updated_at",
	}).AddRow(accountID, profileID, "alice", "Alice", "alice@example.com", "ADMIN", "ACTIVE", false, now, now)
	mock.ExpectQuery(".*").WillReturnRows(rows)

	row, err := repo.FindAdminUserByAccountID(context.Background(), accountID)
	if err != nil {
		t.Fatalf("FindAdminUserByAccountID() unexpected error: %v", err)
	}
	if row.AccountID != accountID || row.ProfileID != profileID || row.Username != "alice" || row.Role != "ADMIN" {
		t.Fatalf("FindAdminUserByAccountID() = %+v, want matching row", row)
	}
}

func TestFindAdminUserByAccountIDNotFound(t *testing.T) {
	db, mock := usersMockDB(t)
	repo := NewRepository(db)

	rows := sqlmock.NewRows([]string{
		"account_id", "profile_id", "username", "display_name", "email", "role", "status", "is_private", "created_at", "updated_at",
	})
	mock.ExpectQuery(".*").WillReturnRows(rows)

	if _, err := repo.FindAdminUserByAccountID(context.Background(), uuid.New()); !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("FindAdminUserByAccountID() error = %v, want gorm.ErrRecordNotFound", err)
	}
}

func TestFindAdminUserByAccountIDQueryError(t *testing.T) {
	db, mock := usersMockDB(t)
	repo := NewRepository(db)
	wantErr := errors.New("connection lost")
	mock.ExpectQuery(".*").WillReturnError(wantErr)

	if _, err := repo.FindAdminUserByAccountID(context.Background(), uuid.New()); err == nil {
		t.Fatal("FindAdminUserByAccountID() expected error, got nil")
	}
}

func TestUpdateAccountRoleUpdateError(t *testing.T) {
	db, mock := usersMockDB(t)
	repo := NewRepository(db)
	wantErr := errors.New("update failed")

	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnError(wantErr)
	mock.ExpectRollback()

	if _, err := repo.UpdateAccountRole(context.Background(), uuid.New(), "ADMIN"); err == nil {
		t.Fatal("UpdateAccountRole() expected error, got nil")
	}
}

func TestUpdateAccountRoleSuccess(t *testing.T) {
	db, mock := usersMockDB(t)
	repo := NewRepository(db)
	accountID := uuid.New()
	profileID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()
	rows := sqlmock.NewRows([]string{
		"account_id", "profile_id", "username", "display_name", "email", "role", "status", "is_private", "created_at", "updated_at",
	}).AddRow(accountID, profileID, "alice", "Alice", "alice@example.com", "ADMIN", "ACTIVE", false, now, now)
	mock.ExpectQuery(".*").WillReturnRows(rows)

	row, err := repo.UpdateAccountRole(context.Background(), accountID, "ADMIN")
	if err != nil {
		t.Fatalf("UpdateAccountRole() unexpected error: %v", err)
	}
	if row.AccountID != accountID || row.Role != "ADMIN" {
		t.Fatalf("UpdateAccountRole() = %+v, want matching row", row)
	}
}
