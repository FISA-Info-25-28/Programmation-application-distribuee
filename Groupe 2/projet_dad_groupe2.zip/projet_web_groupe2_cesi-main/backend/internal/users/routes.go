package users

import (
	"breezy/backend/internal/middleware"
	"github.com/gin-gonic/gin"
)

func RegisterRoutes(router *gin.Engine, handler *Handler) {
	authenticated := router.Group("/")
	authenticated.Use(middleware.AuthRequired())
	authenticated.GET("/suggestions", handler.Suggestions)
	authenticated.GET("/search", handler.Search)

	// Routes d'administration des comptes.
	// Entrees : requetes HTTP authentifiees avec role ADMIN.
	// Sorties : liste, creation et mise a jour de role des comptes utilisateurs.
	admin := authenticated.Group("/admin")
	admin.Use(middleware.RequireRole(middleware.RoleAdmin))
	admin.GET("/users", handler.ListAdminUsers)
	admin.POST("/users", handler.CreateAdminUser)
	admin.PATCH("/users/:accountId/role", handler.UpdateAdminUserRole)
}
