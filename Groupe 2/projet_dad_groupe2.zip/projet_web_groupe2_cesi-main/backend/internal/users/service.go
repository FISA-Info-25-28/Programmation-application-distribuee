package users

import (
	"context"
	"errors"
	"strings"
	"time"

	"breezy/backend/internal/models"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

var (
	ErrEmailAlreadyRegistered    = errors.New("email already registered")
	ErrUsernameAlreadyRegistered = errors.New("username already registered")
	ErrCannotChangeOwnRole       = errors.New("cannot change own role")
)

type Service struct {
	repo *Repository
}

// NewService construit le service utilisateurs autour de son repository.
// Entree : repo.
// Sortie : valeur retour de type *Service.
func NewService(repo *Repository) *Service {
	return &Service{repo: repo}
}

// Suggestions recupere une liste de profils suggeres pour le compte courant.
// Entree : ctx, currentAccountID, limit.
// Sortie : valeurs retour de la fonction.
func (s *Service) Suggestions(ctx context.Context, currentAccountID uuid.UUID, limit int) ([]userResponse, error) {
	if limit <= 0 {
		limit = 4
	}
	rows, err := s.repo.Suggestions(ctx, currentAccountID, limit)
	if err != nil {
		return nil, err
	}
	return rowsToUsers(rows), nil
}

// Search recherche des utilisateurs sans contexte de compte connecte.
// Entree : ctx, query.
// Sortie : valeurs retour de la fonction.
func (s *Service) Search(ctx context.Context, query string) ([]userResponse, error) {
	return s.SearchForAccount(ctx, uuid.Nil, query)
}

// SearchForAccount recherche des utilisateurs avec les etats de relation du compte courant.
// Entree : ctx, currentAccountID, query.
// Sortie : valeurs retour de la fonction.
func (s *Service) SearchForAccount(ctx context.Context, currentAccountID uuid.UUID, query string) ([]userResponse, error) {
	rows, err := s.repo.Search(ctx, currentAccountID, query, 20)
	if err != nil {
		return nil, err
	}
	return rowsToUsers(rows), nil
}

// rowsToUsers transforme les lignes de profils enrichies en DTO utilisateur.
// Entree : rows.
// Sortie : valeur retour de type []userResponse.
func rowsToUsers(rows []profileRow) []userResponse {
	users := make([]userResponse, 0, len(rows))
	for _, row := range rows {
		users = append(users, rowToUser(row))
	}
	return users
}

func rowToUser(row profileRow) userResponse {
	return userResponse{
		ID:             row.ID,
		ProfileID:      row.ID,
		Username:       row.Username,
		DisplayName:    row.DisplayName,
		Email:          row.Email,
		Role:           row.Role,
		Bio:            row.Bio,
		AvatarURL:      row.AvatarURL,
		FollowersCount: row.FollowersCount,
		FollowingCount: row.FollowingCount,
		IsFollowing:    row.IsFollowing,
		RequestPending: row.RequestPending,
		IsPrivate:      row.IsPrivate,
		PostsCount:     row.PostsCount,
		CreatedAt:      row.CreatedAt,
	}
}

// ListAdminUsers prepare la liste des comptes pour l'ecran d'administration.
// Entrees : ctx et query de recherche facultative.
// Sortie : tableau adminUserResponse ou erreur de repository.
func (s *Service) ListAdminUsers(ctx context.Context, query string) ([]adminUserResponse, error) {
	rows, err := s.repo.ListAdminUsers(ctx, query, 100)
	if err != nil {
		return nil, err
	}
	return rowsToAdminUsers(rows), nil
}

// CreateAdminUser cree un compte et son profil depuis l'administration.
// Entrees : ctx et payload createAdminUserRequest deja valide par le handler.
// Sortie : compte cree au format adminUserResponse ou erreur metier/technique.
func (s *Service) CreateAdminUser(ctx context.Context, req createAdminUserRequest) (adminUserResponse, error) {
	email := strings.ToLower(strings.TrimSpace(req.Email))
	username := strings.TrimSpace(req.Username)
	displayName := strings.TrimSpace(req.DisplayName)
	role := strings.ToUpper(strings.TrimSpace(req.Role))
	if role == "" {
		role = "USER"
	}

	if _, err := s.repo.FindAccountByEmail(ctx, email); err == nil {
		return adminUserResponse{}, ErrEmailAlreadyRegistered
	} else if !errors.Is(err, gorm.ErrRecordNotFound) {
		return adminUserResponse{}, err
	}

	if _, err := s.repo.FindProfileByUsername(ctx, username); err == nil {
		return adminUserResponse{}, ErrUsernameAlreadyRegistered
	} else if !errors.Is(err, gorm.ErrRecordNotFound) {
		return adminUserResponse{}, err
	}

	passwordHash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		return adminUserResponse{}, err
	}

	now := time.Now().UTC()
	account := models.Account{
		Email:           email,
		PasswordHash:    string(passwordHash),
		Role:            role,
		Status:          "ACTIVE",
		EmailVerifiedAt: &now,
	}

	var row adminUserRow
	err = s.repo.Transaction(ctx, func(txRepo *Repository) error {
		if err := txRepo.CreateAccount(ctx, &account); err != nil {
			return err
		}

		profile := models.Profile{
			AccountID:   account.ID,
			Username:    username,
			DisplayName: &displayName,
		}
		if err := txRepo.CreateProfile(ctx, &profile); err != nil {
			return err
		}

		var err error
		row, err = txRepo.FindAdminUserByAccountID(ctx, account.ID)
		return err
	})
	if err != nil {
		return adminUserResponse{}, err
	}

	return rowToAdminUser(row), nil
}

// UpdateAdminUserRole modifie le role d'un compte cible.
// Entrees : ctx, compte acteur, compte cible et role demande.
// Sortie : compte mis a jour ou erreur si l'admin tente de modifier son propre role.
func (s *Service) UpdateAdminUserRole(ctx context.Context, actorAccountID, accountID uuid.UUID, role string) (adminUserResponse, error) {
	if actorAccountID == accountID {
		return adminUserResponse{}, ErrCannotChangeOwnRole
	}

	row, err := s.repo.UpdateAccountRole(ctx, accountID, strings.ToUpper(strings.TrimSpace(role)))
	if err != nil {
		return adminUserResponse{}, err
	}
	return rowToAdminUser(row), nil
}

// rowsToAdminUsers convertit plusieurs lignes SQL en reponses JSON admin.
// Entree : slice adminUserRow issue du repository.
// Sortie : slice adminUserResponse prete a etre retournee par l'API.
func rowsToAdminUsers(rows []adminUserRow) []adminUserResponse {
	users := make([]adminUserResponse, 0, len(rows))
	for _, row := range rows {
		users = append(users, rowToAdminUser(row))
	}
	return users
}

// rowToAdminUser convertit une ligne SQL en reponse JSON admin.
// Entree : adminUserRow issue d'une requete.
// Sortie : adminUserResponse exposee par l'API.
func rowToAdminUser(row adminUserRow) adminUserResponse {
	return adminUserResponse{
		AccountID:   row.AccountID,
		ProfileID:   row.ProfileID,
		Username:    row.Username,
		DisplayName: row.DisplayName,
		Email:       row.Email,
		Role:        row.Role,
		Status:      row.Status,
		IsPrivate:   row.IsPrivate,
		CreatedAt:   row.CreatedAt,
		UpdatedAt:   row.UpdatedAt,
	}
}
