package users

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestRowsToUsers(t *testing.T) {
	bio := "hello"
	avatar := "https://example.com/avatar.png"
	createdAt := time.Now().UTC()
	row := profileRow{
		ID:             uuid.New(),
		AccountID:      uuid.New(),
		Username:       "alice",
		DisplayName:    "Alice",
		Email:          "alice@example.com",
		Role:           "MODERATOR",
		Bio:            &bio,
		AvatarURL:      &avatar,
		FollowersCount: 12,
		FollowingCount: 7,
		IsFollowing:    true,
		RequestPending: true,
		IsPrivate:      true,
		PostsCount:     4,
		CreatedAt:      createdAt,
	}

	got := rowsToUsers([]profileRow{row})
	if len(got) != 1 {
		t.Fatalf("rowsToUsers() len = %d, want 1", len(got))
	}
	user := got[0]
	if user.ID != row.ID || user.ProfileID != row.ID || user.Username != "alice" || user.DisplayName != "Alice" {
		t.Fatalf("rowsToUsers() identity = %+v, want row identity", user)
	}
	if user.Email != row.Email || user.Role != row.Role || user.Bio != &bio || user.AvatarURL != &avatar {
		t.Fatalf("rowsToUsers() account/public fields = %+v, want row fields", user)
	}
	if user.FollowersCount != 12 || user.FollowingCount != 7 || !user.IsFollowing || !user.RequestPending || !user.IsPrivate || user.PostsCount != 4 {
		t.Fatalf("rowsToUsers() counters/state = %+v, want row counters/state", user)
	}
}

func TestAdminUserRowMapping(t *testing.T) {
	now := time.Now().UTC()
	row := adminUserRow{
		AccountID:   uuid.New(),
		ProfileID:   uuid.New(),
		Username:    "admin",
		DisplayName: "Admin",
		Email:       "admin@example.com",
		Role:        "ADMIN",
		Status:      "ACTIVE",
		IsPrivate:   true,
		CreatedAt:   now,
		UpdatedAt:   now.Add(time.Minute),
	}

	one := rowToAdminUser(row)
	if one.AccountID != row.AccountID || one.ProfileID != row.ProfileID || one.Role != "ADMIN" || !one.IsPrivate {
		t.Fatalf("rowToAdminUser() = %+v, want mapped row", one)
	}

	many := rowsToAdminUsers([]adminUserRow{row})
	if len(many) != 1 || many[0] != one {
		t.Fatalf("rowsToAdminUsers() = %+v, want [%+v]", many, one)
	}
}

func TestUsersServiceWorkflowsDryRun(t *testing.T) {
	service := NewService(NewRepository(usersDryRunDB(t)))
	ctx := context.Background()
	accountID := uuid.New()

	_, _ = service.Suggestions(ctx, accountID, 10)
	_, _ = service.Search(ctx, "alice")
	_, _ = service.SearchForAccount(ctx, accountID, "alice")
	_, _ = service.ListAdminUsers(ctx, "")
	_, _ = service.CreateAdminUser(ctx, createAdminUserRequest{
		Email:       "created@example.com",
		Password:    "StrongPass123!",
		Username:    "created_user",
		DisplayName: "Created User",
		Role:        "MODERATOR",
	})
	_, _ = service.UpdateAdminUserRole(ctx, uuid.New(), accountID, "ADMIN")
	_, _ = service.UpdateAdminUserRole(ctx, accountID, accountID, "USER")
}

// usersServiceMockDB ouvre une connexion GORM appuyee sur sqlmock (mode reel)
// afin de scripter precisement les requetes SQL attendues par le service.
func usersServiceMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqlDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New() unexpected error: %v", err)
	}
	t.Cleanup(func() { _ = sqlDB.Close() })
	db, err := gorm.Open(postgres.New(postgres.Config{Conn: sqlDB}), &gorm.Config{})
	if err != nil {
		t.Fatalf("gorm.Open() unexpected error: %v", err)
	}
	return db, mock
}

func validCreateAdminUserRequest() createAdminUserRequest {
	return createAdminUserRequest{
		Email:       "new.admin@example.com",
		Password:    "StrongPass123!",
		Username:    "new_admin",
		DisplayName: "New Admin",
		Role:        "MODERATOR",
	}
}

func TestServiceCreateAdminUserEmailAlreadyRegistered(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))

	rows := sqlmock.NewRows([]string{"id", "email"}).AddRow(uuid.New(), "new.admin@example.com")
	mock.ExpectQuery(".*").WillReturnRows(rows)

	_, err := service.CreateAdminUser(context.Background(), validCreateAdminUserRequest())
	if !errors.Is(err, ErrEmailAlreadyRegistered) {
		t.Fatalf("CreateAdminUser() error = %v, want ErrEmailAlreadyRegistered", err)
	}
}

func TestServiceCreateAdminUserEmailLookupError(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))
	wantErr := errors.New("boom")

	mock.ExpectQuery(".*").WillReturnError(wantErr)

	_, err := service.CreateAdminUser(context.Background(), validCreateAdminUserRequest())
	if err == nil || errors.Is(err, ErrEmailAlreadyRegistered) {
		t.Fatalf("CreateAdminUser() error = %v, want wrapped lookup error", err)
	}
}

func TestServiceCreateAdminUserUsernameAlreadyRegistered(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))

	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
	rows := sqlmock.NewRows([]string{"id", "username"}).AddRow(uuid.New(), "new_admin")
	mock.ExpectQuery(".*").WillReturnRows(rows)

	_, err := service.CreateAdminUser(context.Background(), validCreateAdminUserRequest())
	if !errors.Is(err, ErrUsernameAlreadyRegistered) {
		t.Fatalf("CreateAdminUser() error = %v, want ErrUsernameAlreadyRegistered", err)
	}
}

func TestServiceCreateAdminUserUsernameLookupError(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))
	wantErr := errors.New("boom")

	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(".*").WillReturnError(wantErr)

	_, err := service.CreateAdminUser(context.Background(), validCreateAdminUserRequest())
	if err == nil || errors.Is(err, ErrUsernameAlreadyRegistered) {
		t.Fatalf("CreateAdminUser() error = %v, want wrapped lookup error", err)
	}
}

func TestServiceCreateAdminUserTransactionRollback(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))
	wantErr := errors.New("insert failed")

	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnError(wantErr)
	mock.ExpectRollback()

	_, err := service.CreateAdminUser(context.Background(), validCreateAdminUserRequest())
	if err == nil {
		t.Fatal("CreateAdminUser() expected transaction error, got nil")
	}
}

func TestServiceCreateAdminUserSuccess(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))
	accountID := uuid.New()
	profileID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
	adminRows := sqlmock.NewRows([]string{
		"account_id", "profile_id", "username", "display_name", "email", "role", "status", "is_private", "created_at", "updated_at",
	}).AddRow(accountID, profileID, "new_admin", "New Admin", "new.admin@example.com", "MODERATOR", "ACTIVE", false, now, now)
	mock.ExpectQuery(".*").WillReturnRows(adminRows)
	mock.ExpectCommit()

	got, err := service.CreateAdminUser(context.Background(), validCreateAdminUserRequest())
	if err != nil {
		t.Fatalf("CreateAdminUser() unexpected error: %v", err)
	}
	if got.AccountID != accountID || got.ProfileID != profileID || got.Role != "MODERATOR" || got.Username != "new_admin" {
		t.Fatalf("CreateAdminUser() = %+v, want matching admin user", got)
	}
}

func TestServiceCreateAdminUserDefaultsRoleToUser(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))
	accountID := uuid.New()
	profileID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectQuery(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectBegin()
	mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(accountID))
	mock.ExpectQuery(".*").WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(profileID))
	adminRows := sqlmock.NewRows([]string{
		"account_id", "profile_id", "username", "display_name", "email", "role", "status", "is_private", "created_at", "updated_at",
	}).AddRow(accountID, profileID, "no_role_user", "No Role", "no.role@example.com", "USER", "ACTIVE", false, now, now)
	mock.ExpectQuery(".*").WillReturnRows(adminRows)
	mock.ExpectCommit()

	req := validCreateAdminUserRequest()
	req.Role = ""
	req.Username = "no_role_user"
	req.Email = "no.role@example.com"

	got, err := service.CreateAdminUser(context.Background(), req)
	if err != nil {
		t.Fatalf("CreateAdminUser() unexpected error: %v", err)
	}
	if got.Role != "USER" {
		t.Fatalf("CreateAdminUser() role = %q, want USER default", got.Role)
	}
}

func TestServiceUpdateAdminUserRoleCannotChangeOwnRole(t *testing.T) {
	service := NewService(NewRepository(nil))
	accountID := uuid.New()

	_, err := service.UpdateAdminUserRole(context.Background(), accountID, accountID, "ADMIN")
	if !errors.Is(err, ErrCannotChangeOwnRole) {
		t.Fatalf("UpdateAdminUserRole() error = %v, want ErrCannotChangeOwnRole", err)
	}
}

func TestServiceUpdateAdminUserRoleNotFound(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))

	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnError(gorm.ErrRecordNotFound)
	mock.ExpectRollback()

	_, err := service.UpdateAdminUserRole(context.Background(), uuid.New(), uuid.New(), "ADMIN")
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		t.Fatalf("UpdateAdminUserRole() error = %v, want gorm.ErrRecordNotFound", err)
	}
}

func TestServiceUpdateAdminUserRoleSuccess(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))
	actorID := uuid.New()
	targetID := uuid.New()
	profileID := uuid.New()
	now := time.Now().UTC()

	mock.ExpectBegin()
	mock.ExpectExec(".*").WillReturnResult(sqlmock.NewResult(0, 1))
	mock.ExpectCommit()
	rows := sqlmock.NewRows([]string{
		"account_id", "profile_id", "username", "display_name", "email", "role", "status", "is_private", "created_at", "updated_at",
	}).AddRow(targetID, profileID, "target", "Target", "target@example.com", "ADMIN", "ACTIVE", false, now, now)
	mock.ExpectQuery(".*").WillReturnRows(rows)

	got, err := service.UpdateAdminUserRole(context.Background(), actorID, targetID, " admin ")
	if err != nil {
		t.Fatalf("UpdateAdminUserRole() unexpected error: %v", err)
	}
	if got.AccountID != targetID || got.Role != "ADMIN" {
		t.Fatalf("UpdateAdminUserRole() = %+v, want matching admin user", got)
	}
}

func TestServiceSuggestionsAndSearchQueryError(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))
	wantErr := errors.New("query failed")

	mock.ExpectQuery(".*").WillReturnError(wantErr)
	if _, err := service.Suggestions(context.Background(), uuid.New(), 10); err == nil {
		t.Fatal("Suggestions() expected error, got nil")
	}

	mock.ExpectQuery(".*").WillReturnError(wantErr)
	if _, err := service.SearchForAccount(context.Background(), uuid.New(), "alice"); err == nil {
		t.Fatal("SearchForAccount() expected error, got nil")
	}
}

func TestServiceListAdminUsersQueryError(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))
	wantErr := errors.New("query failed")

	mock.ExpectQuery(".*").WillReturnError(wantErr)
	if _, err := service.ListAdminUsers(context.Background(), "admin"); err == nil {
		t.Fatal("ListAdminUsers() expected error, got nil")
	}
}

func TestServiceListAdminUsersSuccess(t *testing.T) {
	db, mock := usersServiceMockDB(t)
	service := NewService(NewRepository(db))
	now := time.Now().UTC()

	rows := sqlmock.NewRows([]string{
		"account_id", "profile_id", "username", "display_name", "email", "role", "status", "is_private", "created_at", "updated_at",
	}).AddRow(uuid.New(), uuid.New(), "alice", "Alice", "alice@example.com", "USER", "ACTIVE", false, now, now)
	mock.ExpectQuery(".*").WillReturnRows(rows)

	got, err := service.ListAdminUsers(context.Background(), "")
	if err != nil {
		t.Fatalf("ListAdminUsers() unexpected error: %v", err)
	}
	if len(got) != 1 || got[0].Username != "alice" {
		t.Fatalf("ListAdminUsers() = %+v, want one matching user", got)
	}
}
