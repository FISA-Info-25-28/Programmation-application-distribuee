package validation

import (
	"errors"
	"net/url"
	"regexp"
	"strings"

	"github.com/google/uuid"
)

var usernamePattern = regexp.MustCompile(`^[a-zA-Z0-9_]{3,30}$`)

func TrimmedRequired(value string, maxRunes int, field string) (string, error) {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return "", errors.New(field + " is required")
	}
	if maxRunes > 0 && len([]rune(trimmed)) > maxRunes {
		return "", errors.New(field + " is too long")
	}
	return trimmed, nil
}

func OptionalText(value *string, maxRunes int, field string) error {
	if value == nil {
		return nil
	}
	if maxRunes > 0 && len([]rune(strings.TrimSpace(*value))) > maxRunes {
		return errors.New(field + " is too long")
	}
	return nil
}

func Username(value string) error {
	if !usernamePattern.MatchString(strings.TrimSpace(value)) {
		return errors.New("invalid username")
	}
	return nil
}

func URL(value string, field string) error {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return errors.New(field + " is required")
	}
	parsed, err := url.ParseRequestURI(trimmed)
	if err != nil || parsed.Scheme == "" || parsed.Host == "" {
		return errors.New("invalid " + field)
	}
	return nil
}

func MediaURL(value string) error {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" || !strings.Contains(trimmed, "/api/media/files/") {
		return errors.New("invalid media url")
	}
	return nil
}

func OneOf(value string, allowed ...string) error {
	normalized := strings.ToUpper(strings.TrimSpace(value))
	for _, item := range allowed {
		if normalized == item {
			return nil
		}
	}
	return errors.New("invalid value")
}

func NonNilUUID(value uuid.UUID, field string) error {
	if value == uuid.Nil {
		return errors.New(field + " is required")
	}
	return nil
}

// Password valide les règles de sécurité du mot de passe à la création de compte.
// username, email et displayName sont utilisés pour détecter si le mot de passe les contient.
// Entree : password, username, email, displayName.
// Sortie : erreur eventuelle.
func Password(password, username, email, displayName string) error {
	if len(password) < 12 {
		return errors.New("password too short")
	}

	const specials = `!@#$%^&*()-_+=[]{}|;:'",.<>?/~\`
	var hasUpper, hasDigit, hasSpecial bool
	for _, c := range password {
		if c >= 'A' && c <= 'Z' {
			hasUpper = true
		}
		if c >= '0' && c <= '9' {
			hasDigit = true
		}
		if strings.ContainsRune(specials, c) {
			hasSpecial = true
		}
	}

	if !hasUpper {
		return errors.New("password missing uppercase")
	}
	if !hasDigit {
		return errors.New("password missing digit")
	}
	if !hasSpecial {
		return errors.New("password missing special char")
	}

	lower := strings.ToLower(password)
	if u := strings.ToLower(strings.TrimSpace(username)); len(u) >= 3 && strings.Contains(lower, u) {
		return errors.New("password contains username")
	}
	if at := strings.Index(email, "@"); at >= 3 {
		if local := strings.ToLower(email[:at]); strings.Contains(lower, local) {
			return errors.New("password contains email")
		}
	}

	for _, w := range splitNameWords(displayName) {
		if len([]rune(w)) >= 4 && strings.Contains(lower, strings.ToLower(w)) {
			return errors.New("password contains display name")
		}
	}

	return nil
}

func splitNameWords(s string) []string {
	return strings.FieldsFunc(s, func(r rune) bool {
		return r == ' ' || r == '-' || r == '_' || r == '.'
	})
}
