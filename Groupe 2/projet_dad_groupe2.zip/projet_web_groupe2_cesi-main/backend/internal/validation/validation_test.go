package validation

import (
	"strings"
	"testing"

	"github.com/google/uuid"
)

func TestTrimmedRequired(t *testing.T) {
	got, err := TrimmedRequired("  Breezy  ", 10, "name")
	if err != nil {
		t.Fatalf("TrimmedRequired() unexpected error: %v", err)
	}
	if got != "Breezy" {
		t.Fatalf("TrimmedRequired() = %q, want Breezy", got)
	}

	if _, err := TrimmedRequired("   ", 10, "name"); err == nil {
		t.Fatal("TrimmedRequired() expected required error")
	}

	if _, err := TrimmedRequired("abcdef", 5, "name"); err == nil {
		t.Fatal("TrimmedRequired() expected max length error")
	}
}

func TestOptionalText(t *testing.T) {
	if err := OptionalText(nil, 5, "bio"); err != nil {
		t.Fatalf("OptionalText(nil) unexpected error: %v", err)
	}

	value := "  hello  "
	if err := OptionalText(&value, 5, "bio"); err != nil {
		t.Fatalf("OptionalText(valid) unexpected error: %v", err)
	}

	tooLong := "bonjour"
	if err := OptionalText(&tooLong, 5, "bio"); err == nil {
		t.Fatal("OptionalText() expected max length error")
	}
}

func TestUsername(t *testing.T) {
	valid := []string{"abc", "user_123", "A12345678901234567890123456789"}
	for _, username := range valid {
		if err := Username(username); err != nil {
			t.Fatalf("Username(%q) unexpected error: %v", username, err)
		}
	}

	invalid := []string{"ab", "has-dash", "has space", strings.Repeat("a", 31)}
	for _, username := range invalid {
		if err := Username(username); err == nil {
			t.Fatalf("Username(%q) expected error", username)
		}
	}
}

func TestURL(t *testing.T) {
	if err := URL("https://example.com/avatar.png", "avatarUrl"); err != nil {
		t.Fatalf("URL(valid) unexpected error: %v", err)
	}

	for _, raw := range []string{"", "notaurl", "/relative/path"} {
		if err := URL(raw, "avatarUrl"); err == nil {
			t.Fatalf("URL(%q) expected error", raw)
		}
	}
}

func TestMediaURL(t *testing.T) {
	if err := MediaURL("http://localhost:8080/api/media/files/image.png"); err != nil {
		t.Fatalf("MediaURL(valid) unexpected error: %v", err)
	}
	if err := MediaURL("http://localhost:8080/uploads/image.png"); err == nil {
		t.Fatal("MediaURL() expected error for non media API url")
	}
}

func TestOneOf(t *testing.T) {
	if err := OneOf(" followers ", "PUBLIC", "FOLLOWERS", "PRIVATE"); err != nil {
		t.Fatalf("OneOf() unexpected error: %v", err)
	}
	if err := OneOf("friends", "PUBLIC", "FOLLOWERS", "PRIVATE"); err == nil {
		t.Fatal("OneOf() expected error")
	}
}

func TestNonNilUUID(t *testing.T) {
	if err := NonNilUUID(uuid.New(), "id"); err != nil {
		t.Fatalf("NonNilUUID(valid) unexpected error: %v", err)
	}
	if err := NonNilUUID(uuid.Nil, "id"); err == nil {
		t.Fatal("NonNilUUID(nil) expected error")
	}
}

func TestPassword(t *testing.T) {
	if err := Password("StrongPass1!", "alice", "alice@example.com", "Alice Doe"); err != nil {
		t.Fatalf("Password(valid) unexpected error: %v", err)
	}

	tests := []struct {
		name        string
		password    string
		username    string
		email       string
		displayName string
	}{
		{name: "too short", password: "Short1!"},
		{name: "missing uppercase", password: "lowercase123!"},
		{name: "missing digit", password: "NoDigitPass!"},
		{name: "missing special", password: "NoSpecial123"},
		{name: "contains username", password: "AliceSuper123!", username: "alice"},
		{name: "contains email local", password: "MyAliceMail123!", email: "alicemail@example.com"},
		{name: "contains display name", password: "SecureRobert123!", displayName: "Robert Martin"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := Password(tt.password, tt.username, tt.email, tt.displayName); err == nil {
				t.Fatal("Password() expected error")
			}
		})
	}
}
