-- ============================================================
-- Breezy — init.sql (PostgreSQL, multi-schéma)
-- Généré depuis schema.dbml. À monter dans /docker-entrypoint-initdb.d/
-- ============================================================

-- 1) Schémas -------------------------------------------------
CREATE SCHEMA IF NOT EXISTS auth;
CREATE SCHEMA IF NOT EXISTS profiles;
CREATE SCHEMA IF NOT EXISTS social;
CREATE SCHEMA IF NOT EXISTS posts;
CREATE SCHEMA IF NOT EXISTS messages;
CREATE SCHEMA IF NOT EXISTS moderation;

-- 2) Extension pour gen_random_uuid() (natif en PG13+, ceci sécurise) 
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 3) Types ENUM ----------------------------------------------
CREATE TYPE auth.user_role            AS ENUM ('USER','MODERATOR','ADMIN');
CREATE TYPE auth.account_status       AS ENUM ('ACTIVE','SUSPENDED','BANNED');
CREATE TYPE social.notification_type  AS ENUM ('LIKE','FOLLOW','FOLLOW_REQUEST','REPLY','MENTION','MODERATION_REPORT');
CREATE TYPE posts.media_type          AS ENUM ('IMAGE','VIDEO');
CREATE TYPE posts.post_visibility     AS ENUM ('PUBLIC','FOLLOWERS','PRIVATE');
CREATE TYPE moderation.report_status  AS ENUM ('PENDING','REVIEWED','RESOLVED','REJECTED');

-- 4) Tables --------------------------------------------------

-- auth
CREATE TABLE auth.accounts (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email             text NOT NULL UNIQUE,
  password_hash     text NOT NULL,
  role              auth.user_role NOT NULL DEFAULT 'USER',
  status            auth.account_status NOT NULL DEFAULT 'ACTIVE',
  suspended_until   timestamptz,
  email_verified_at timestamptz,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE auth.sessions (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id         uuid NOT NULL,
  refresh_token_hash text NOT NULL,
  expires_at         timestamptz NOT NULL,
  revoked_at         timestamptz,
  created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE auth.email_verification_tokens (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id  uuid NOT NULL,
  token_hash  text NOT NULL,
  expires_at  timestamptz NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- profiles
CREATE TABLE profiles.profiles (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id            uuid NOT NULL UNIQUE,
  username              text NOT NULL UNIQUE,
  display_name          text,
  bio                   text,
  avatar_url            text,
  banner_url            text,
  is_private            boolean NOT NULL DEFAULT false,
  -- Identite reelle memorisee pendant une sanction (profil anonymise en
  -- "user_<id>"). NULL = profil non anonymise.
  original_username     text,
  original_display_name text,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS profiles.preferences (
  profile_id uuid PRIMARY KEY,
  locale     text NOT NULL DEFAULT 'fr',
  theme      text NOT NULL DEFAULT 'light',
  updated_at timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT chk_preferences_theme
    CHECK (theme IN ('system', 'light', 'dark')),

  CONSTRAINT chk_preferences_locale
    CHECK (locale IN ('fr', 'en'))
);

-- social
CREATE TABLE social.follows (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid NOT NULL,
  followed_id uuid NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT follows_no_self CHECK (follower_id <> followed_id),
  CONSTRAINT follows_unique  UNIQUE (follower_id, followed_id)
);
CREATE INDEX idx_follows_followed ON social.follows (followed_id);

CREATE TABLE social.follow_requests (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid NOT NULL,
  target_id    uuid NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT follow_requests_no_self CHECK (requester_id <> target_id),
  CONSTRAINT follow_requests_unique UNIQUE (requester_id, target_id)
);
CREATE INDEX idx_follow_requests_target ON social.follow_requests (target_id);

CREATE TABLE social.notifications (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id uuid NOT NULL,
  actor_id     uuid NOT NULL,
  type         social.notification_type NOT NULL,
  post_id      uuid,
  is_read      boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_recipient ON social.notifications (recipient_id, created_at);

-- posts
CREATE TABLE posts.posts (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id  uuid NOT NULL,
  content    varchar(280) NOT NULL,
  parent_id  uuid,
  visibility posts.post_visibility NOT NULL DEFAULT 'PUBLIC',
  -- Visibilite reelle memorisee pendant une sanction (post force en PRIVATE).
  -- NULL = post non masque.
  original_visibility text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
CREATE INDEX idx_posts_author_created ON posts.posts (author_id, created_at);
CREATE INDEX idx_posts_parent         ON posts.posts (parent_id);

CREATE TABLE posts.media (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    uuid NOT NULL,
  media_type posts.media_type NOT NULL,
  url        text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE posts.likes (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    uuid NOT NULL,
  user_id    uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT likes_unique UNIQUE (post_id, user_id)
);
CREATE INDEX idx_likes_user ON posts.likes (user_id);

CREATE TABLE posts.reposts (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    uuid NOT NULL,
  user_id    uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT reposts_unique UNIQUE (post_id, user_id)
);
CREATE INDEX idx_reposts_user ON posts.reposts (user_id);

CREATE TABLE posts.tags (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE posts.post_tags (
  post_id uuid NOT NULL,
  tag_id  uuid NOT NULL,
  PRIMARY KEY (post_id, tag_id)
);

-- messages
CREATE TABLE messages.conversations (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE messages.members (
  conversation_id uuid NOT NULL,
  profile_id      uuid NOT NULL,
  last_read_at    timestamptz,
  PRIMARY KEY (conversation_id, profile_id)
);

CREATE TABLE messages.private_messages (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL,
  sender_id       uuid NOT NULL,
  content         text NOT NULL,
  media_url       text,
  media_type      text CHECK (media_type IN ('IMAGE', 'VIDEO')),
  reply_to_id     uuid,
  created_at      timestamptz NOT NULL DEFAULT now(),
  edited_at       timestamptz,
  deleted_at      timestamptz
);
CREATE INDEX idx_pm_conversation_created ON messages.private_messages (conversation_id, created_at);
CREATE INDEX idx_pm_deleted ON messages.private_messages (deleted_at);

CREATE TABLE messages.message_likes (
  message_id uuid NOT NULL,
  user_id    uuid NOT NULL,
  reaction   text NOT NULL DEFAULT 'HEART',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, user_id)
);

CREATE TABLE messages.message_preferences (
  profile_id uuid PRIMARY KEY,
  retention  text NOT NULL DEFAULT 'forever',
  updated_at timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT chk_message_preferences_retention
    CHECK (retention IN ('forever', '1h', '2h', '3h', '1d', '7d', '30d'))
);

-- moderation
CREATE TABLE moderation.reports (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id      uuid NOT NULL,
  reported_post_id uuid,
  reported_user_id uuid,
  reason           text NOT NULL,
  status           moderation.report_status NOT NULL DEFAULT 'PENDING',
  reviewed_by      uuid,
  reviewed_at      timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT reports_target_check CHECK (reported_post_id IS NOT NULL OR reported_user_id IS NOT NULL)
);

-- 5) Clés étrangères (toutes après les tables -> ordre indépendant) ----
ALTER TABLE profiles.profiles               ADD CONSTRAINT fk_profiles_account  FOREIGN KEY (account_id)       REFERENCES auth.accounts(id)        ON DELETE CASCADE;
ALTER TABLE profiles.preferences            ADD CONSTRAINT fk_preferences_profile FOREIGN KEY (profile_id) REFERENCES profiles.profiles(id) ON DELETE CASCADE;
ALTER TABLE auth.sessions                   ADD CONSTRAINT fk_sessions_account  FOREIGN KEY (account_id)       REFERENCES auth.accounts(id)        ON DELETE CASCADE;
ALTER TABLE auth.email_verification_tokens  ADD CONSTRAINT fk_evt_account       FOREIGN KEY (account_id)       REFERENCES auth.accounts(id)        ON DELETE CASCADE;
ALTER TABLE social.follows                  ADD CONSTRAINT fk_follows_follower  FOREIGN KEY (follower_id)      REFERENCES profiles.profiles(id)    ON DELETE CASCADE;
ALTER TABLE social.follows                  ADD CONSTRAINT fk_follows_followed  FOREIGN KEY (followed_id)      REFERENCES profiles.profiles(id)    ON DELETE CASCADE;
ALTER TABLE social.follow_requests          ADD CONSTRAINT fk_follow_requests_requester FOREIGN KEY (requester_id) REFERENCES profiles.profiles(id) ON DELETE CASCADE;
ALTER TABLE social.follow_requests          ADD CONSTRAINT fk_follow_requests_target FOREIGN KEY (target_id) REFERENCES profiles.profiles(id) ON DELETE CASCADE;
ALTER TABLE social.notifications            ADD CONSTRAINT fk_notif_recipient   FOREIGN KEY (recipient_id)     REFERENCES profiles.profiles(id)    ON DELETE CASCADE;
ALTER TABLE social.notifications            ADD CONSTRAINT fk_notif_actor       FOREIGN KEY (actor_id)         REFERENCES profiles.profiles(id)    ON DELETE CASCADE;
ALTER TABLE social.notifications            ADD CONSTRAINT fk_notif_post        FOREIGN KEY (post_id)          REFERENCES posts.posts(id)          ON DELETE CASCADE;
ALTER TABLE posts.posts                     ADD CONSTRAINT fk_posts_author      FOREIGN KEY (author_id)        REFERENCES profiles.profiles(id)    ON DELETE CASCADE;
ALTER TABLE posts.posts                     ADD CONSTRAINT fk_posts_parent      FOREIGN KEY (parent_id)        REFERENCES posts.posts(id)          ON DELETE CASCADE;
ALTER TABLE posts.media                     ADD CONSTRAINT fk_media_post        FOREIGN KEY (post_id)          REFERENCES posts.posts(id)          ON DELETE CASCADE;
ALTER TABLE posts.likes                     ADD CONSTRAINT fk_likes_post        FOREIGN KEY (post_id)          REFERENCES posts.posts(id)          ON DELETE CASCADE;
ALTER TABLE posts.likes                     ADD CONSTRAINT fk_likes_user        FOREIGN KEY (user_id)          REFERENCES profiles.profiles(id)    ON DELETE CASCADE;
ALTER TABLE posts.reposts                   ADD CONSTRAINT fk_reposts_post      FOREIGN KEY (post_id)          REFERENCES posts.posts(id)          ON DELETE CASCADE;
ALTER TABLE posts.reposts                   ADD CONSTRAINT fk_reposts_user      FOREIGN KEY (user_id)          REFERENCES profiles.profiles(id)    ON DELETE CASCADE;
ALTER TABLE posts.post_tags                 ADD CONSTRAINT fk_pt_post           FOREIGN KEY (post_id)          REFERENCES posts.posts(id)          ON DELETE CASCADE;
ALTER TABLE posts.post_tags                 ADD CONSTRAINT fk_pt_tag            FOREIGN KEY (tag_id)           REFERENCES posts.tags(id)           ON DELETE CASCADE;
ALTER TABLE messages.members                ADD CONSTRAINT fk_members_conv      FOREIGN KEY (conversation_id)  REFERENCES messages.conversations(id) ON DELETE CASCADE;
ALTER TABLE messages.members                ADD CONSTRAINT fk_members_profile   FOREIGN KEY (profile_id)       REFERENCES profiles.profiles(id)    ON DELETE CASCADE;
ALTER TABLE messages.private_messages       ADD CONSTRAINT fk_pm_conv           FOREIGN KEY (conversation_id)  REFERENCES messages.conversations(id) ON DELETE CASCADE;
ALTER TABLE messages.private_messages       ADD CONSTRAINT fk_pm_sender         FOREIGN KEY (sender_id)        REFERENCES profiles.profiles(id)    ON DELETE CASCADE;
ALTER TABLE messages.private_messages       ADD CONSTRAINT fk_pm_reply_to       FOREIGN KEY (reply_to_id)      REFERENCES messages.private_messages(id) ON DELETE SET NULL;
ALTER TABLE messages.message_likes          ADD CONSTRAINT fk_message_likes_message FOREIGN KEY (message_id) REFERENCES messages.private_messages(id) ON DELETE CASCADE;
ALTER TABLE messages.message_likes          ADD CONSTRAINT fk_message_likes_user FOREIGN KEY (user_id) REFERENCES profiles.profiles(id) ON DELETE CASCADE;
ALTER TABLE messages.message_preferences    ADD CONSTRAINT fk_message_preferences_profile FOREIGN KEY (profile_id) REFERENCES profiles.profiles(id) ON DELETE CASCADE;
ALTER TABLE moderation.reports              ADD CONSTRAINT fk_reports_reporter  FOREIGN KEY (reporter_id)      REFERENCES profiles.profiles(id)    ON DELETE CASCADE;
ALTER TABLE moderation.reports              ADD CONSTRAINT fk_reports_post      FOREIGN KEY (reported_post_id) REFERENCES posts.posts(id)          ON DELETE SET NULL;
ALTER TABLE moderation.reports              ADD CONSTRAINT fk_reports_user      FOREIGN KEY (reported_user_id) REFERENCES profiles.profiles(id)    ON DELETE SET NULL;
ALTER TABLE moderation.reports              ADD CONSTRAINT fk_reports_reviewer  FOREIGN KEY (reviewed_by)      REFERENCES profiles.profiles(id)    ON DELETE SET NULL;

-- 6) Trigger : maintenir updated_at automatiquement ----------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_accounts_updated             BEFORE UPDATE ON auth.accounts                FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_profiles_updated             BEFORE UPDATE ON profiles.profiles            FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_preferences_updated          BEFORE UPDATE ON profiles.preferences         FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_posts_updated                BEFORE UPDATE ON posts.posts                  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_conversations_updated        BEFORE UPDATE ON messages.conversations       FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_message_preferences_updated  BEFORE UPDATE ON messages.message_preferences FOR EACH ROW EXECUTE FUNCTION set_updated_at();
