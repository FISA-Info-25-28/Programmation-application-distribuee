-- ============================================================
-- 002_add_reposts.sql — rattrape la table posts.reposts sur les volumes
-- pgdata créés avant l'ajout de cette table à 001_init.sql.
-- Idempotent : sans effet si la table/contraintes existent déjà.
-- ============================================================

CREATE TABLE IF NOT EXISTS posts.reposts (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    uuid NOT NULL,
  user_id    uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT reposts_unique UNIQUE (post_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_reposts_user ON posts.reposts (user_id);

-- Clés étrangères (ajoutées seulement si absentes)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_reposts_post') THEN
    ALTER TABLE posts.reposts ADD CONSTRAINT fk_reposts_post
      FOREIGN KEY (post_id) REFERENCES posts.posts(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_reposts_user') THEN
    ALTER TABLE posts.reposts ADD CONSTRAINT fk_reposts_user
      FOREIGN KEY (user_id) REFERENCES profiles.profiles(id) ON DELETE CASCADE;
  END IF;
END$$;
