ALTER TABLE profiles.profiles
  ADD COLUMN IF NOT EXISTS banner_url text;
