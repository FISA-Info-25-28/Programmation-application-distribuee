-- ============================================================
-- 003_add_sanction_columns.sql — rattrape les colonnes utilisees pour
-- l'anonymisation/masquage lors d'une sanction (ban/suspension) sur les
-- volumes pgdata crees avant l'ajout de ces colonnes a 001_init.sql.
-- Idempotent : sans effet si les colonnes existent deja.
-- ============================================================

-- Identite reelle memorisee pendant qu'un profil est anonymise ("user_<id>").
ALTER TABLE profiles.profiles
  ADD COLUMN IF NOT EXISTS original_username     text,
  ADD COLUMN IF NOT EXISTS original_display_name text;

-- Visibilite reelle memorisee pendant qu'un post est force en PRIVATE.
ALTER TABLE posts.posts
  ADD COLUMN IF NOT EXISTS original_visibility text;
