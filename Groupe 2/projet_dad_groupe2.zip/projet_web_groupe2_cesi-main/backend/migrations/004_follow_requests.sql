ALTER TYPE social.notification_type
  ADD VALUE IF NOT EXISTS 'FOLLOW_REQUEST';

CREATE TABLE IF NOT EXISTS social.follow_requests (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid NOT NULL,
  target_id    uuid NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT follow_requests_no_self CHECK (requester_id <> target_id),
  CONSTRAINT follow_requests_unique UNIQUE (requester_id, target_id),
  CONSTRAINT fk_follow_requests_requester
    FOREIGN KEY (requester_id) REFERENCES profiles.profiles(id) ON DELETE CASCADE,
  CONSTRAINT fk_follow_requests_target
    FOREIGN KEY (target_id) REFERENCES profiles.profiles(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_follow_requests_target
  ON social.follow_requests (target_id);
