ALTER TABLE messages.private_messages
  ADD COLUMN IF NOT EXISTS reply_to_id uuid;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'fk_pm_reply_to'
  ) THEN
    ALTER TABLE messages.private_messages
      ADD CONSTRAINT fk_pm_reply_to
      FOREIGN KEY (reply_to_id)
      REFERENCES messages.private_messages(id)
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS messages.message_likes (
  message_id uuid NOT NULL,
  user_id    uuid NOT NULL,
  reaction   text NOT NULL DEFAULT 'HEART',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, user_id)
);

ALTER TABLE messages.message_likes
  ADD COLUMN IF NOT EXISTS reaction text NOT NULL DEFAULT 'HEART';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'fk_message_likes_message'
  ) THEN
    ALTER TABLE messages.message_likes
      ADD CONSTRAINT fk_message_likes_message
      FOREIGN KEY (message_id)
      REFERENCES messages.private_messages(id)
      ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'fk_message_likes_user'
  ) THEN
    ALTER TABLE messages.message_likes
      ADD CONSTRAINT fk_message_likes_user
      FOREIGN KEY (user_id)
      REFERENCES profiles.profiles(id)
      ON DELETE CASCADE;
  END IF;
END $$;
