ALTER TABLE profiles.profiles
  ADD COLUMN IF NOT EXISTS public_key text;
