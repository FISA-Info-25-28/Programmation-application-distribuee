package main

import (
	"bytes"
	"fmt"
	"html/template"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type service struct {
	Name  string
	Test  []string
	Cover []string
}

type report struct {
	Name    string
	Percent string
	Profile string
	Func    string
	HTML    string
}

var percentPattern = regexp.MustCompile(`([0-9]+(?:\.[0-9]+)?)%`)

func main() {
	openReport := len(os.Args) > 1 && os.Args[1] == "-open"
	coverageDir := strings.TrimSpace(os.Getenv("COVERAGE_DIR"))
	if coverageDir == "" {
		coverageDir = "coverage"
	}
	if err := os.RemoveAll(coverageDir); err != nil {
		exit(err)
	}
	if err := os.MkdirAll(coverageDir, 0o755); err != nil {
		exit(err)
	}

	var reports []report
	for _, svc := range services() {
		fmt.Printf("\n==> Coverage: %s\n", svc.Name)
		result, err := runCoverage(coverageDir, svc)
		if err != nil {
			exit(err)
		}
		reports = append(reports, result)
	}

	if err := writeIndex(coverageDir, reports); err != nil {
		exit(err)
	}

	sort.Slice(reports, func(i, j int) bool { return reports[i].Name < reports[j].Name })
	fmt.Println("\nCoverage summary")
	for _, report := range reports {
		fmt.Printf("%-20s %6s%%  %s\n", report.Name, report.Percent, report.HTML)
	}
	fmt.Println("\nOpen coverage/index.html to browse all reports.")

	if openReport {
		if err := open(filepath.Join(coverageDir, "index.html")); err != nil {
			exit(err)
		}
	}
}

func runCoverage(coverageDir string, svc service) (report, error) {
	profile := filepath.Join(coverageDir, svc.Name+".out")
	funcFile := filepath.Join(coverageDir, svc.Name+".txt")
	htmlFile := filepath.Join(coverageDir, svc.Name+".html")
	profilePath, err := filepath.Abs(profile)
	if err != nil {
		return report{}, err
	}
	htmlPath, err := filepath.Abs(htmlFile)
	if err != nil {
		return report{}, err
	}

	args := append([]string{}, svc.Test...)
	args = append(args, "-coverpkg="+strings.Join(svc.Cover, ","), "-covermode=count", "-coverprofile="+profilePath)
	if err := run("go", append([]string{"test"}, args...)...); err != nil {
		return report{}, err
	}
	if err := normalizeCoverageProfile(profilePath); err != nil {
		return report{}, err
	}

	funcOutput, err := output("go", "tool", "cover", "-func="+profilePath)
	if err != nil {
		return report{}, err
	}
	if err := os.WriteFile(funcFile, funcOutput, 0o644); err != nil {
		return report{}, err
	}
	if err := run("go", "tool", "cover", "-html="+profilePath, "-o", htmlPath); err != nil {
		return report{}, err
	}

	percent := "0.0"
	lines := bytes.Split(bytes.TrimSpace(funcOutput), []byte("\n"))
	if len(lines) > 0 {
		matches := percentPattern.FindSubmatch(lines[len(lines)-1])
		if len(matches) == 2 {
			percent = string(matches[1])
		}
	}

	return report{
		Name:    svc.Name,
		Percent: percent,
		Profile: filepath.ToSlash(profile),
		Func:    filepath.ToSlash(funcFile),
		HTML:    filepath.ToSlash(htmlFile),
	}, nil
}

func normalizeCoverageProfile(path string) error {
	body, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	lines := strings.Split(strings.TrimSpace(string(body)), "\n")
	if len(lines) == 0 || !strings.HasPrefix(lines[0], "mode: ") {
		return fmt.Errorf("invalid coverage profile %s", path)
	}

	counts := make(map[string]int)
	for _, line := range lines[1:] {
		fields := strings.Fields(line)
		if len(fields) != 3 {
			return fmt.Errorf("invalid coverage line %q", line)
		}
		count, err := strconv.Atoi(fields[2])
		if err != nil {
			return fmt.Errorf("invalid coverage count in %q: %w", line, err)
		}
		key := fields[0] + " " + fields[1]
		counts[key] += count
	}

	keys := make([]string, 0, len(counts))
	for key := range counts {
		keys = append(keys, key)
	}
	sort.Strings(keys)

	var normalized strings.Builder
	normalized.WriteString(lines[0])
	normalized.WriteByte('\n')
	for _, key := range keys {
		fmt.Fprintf(&normalized, "%s %d\n", key, counts[key])
	}
	return os.WriteFile(path, []byte(normalized.String()), 0o644)
}

func run(name string, args ...string) error {
	cmd := exec.Command(name, args...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func output(name string, args ...string) ([]byte, error) {
	cmd := exec.Command(name, args...)
	cmd.Stderr = os.Stderr
	return cmd.Output()
}

func writeIndex(coverageDir string, reports []report) error {
	indexPath := filepath.Join(coverageDir, "index.html")
	file, err := os.Create(indexPath)
	if err != nil {
		return err
	}
	defer file.Close()

	page := struct {
		GeneratedAt string
		Reports     []report
	}{
		GeneratedAt: time.Now().Format("2006-01-02 15:04:05"),
		Reports:     reports,
	}

	return indexTemplate.Execute(file, page)
}

func open(path string) error {
	switch {
	case os.Getenv("OS") == "Windows_NT":
		return exec.Command("rundll32", "url.dll,FileProtocolHandler", path).Start()
	case commandExists("xdg-open"):
		return exec.Command("xdg-open", path).Start()
	default:
		return exec.Command("open", path).Start()
	}
}

func commandExists(name string) bool {
	_, err := exec.LookPath(name)
	return err == nil
}

func exit(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}

func services() []service {
	return []service{
		{Name: "all", Test: []string{"./cmd/...", "./internal/...", "./internal/integration"}, Cover: []string{"./internal/..."}},
		{Name: "api-gateway", Test: withIntegration("./cmd/api-gateway", "./internal/config", "./internal/middleware", "./internal/security", "./internal/server"), Cover: []string{"./internal/config", "./internal/middleware", "./internal/security", "./internal/server"}},
		{Name: "auth-service", Test: withIntegration("./cmd/auth-service", "./internal/auth", "./internal/config", "./internal/db", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"), Cover: []string{"./internal/auth", "./internal/config", "./internal/db", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"}},
		{Name: "user-service", Test: withIntegration("./cmd/user-service", "./internal/users", "./internal/notifications", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"), Cover: []string{"./internal/users", "./internal/notifications", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"}},
		{Name: "profile-service", Test: withIntegration("./cmd/profile-service", "./internal/profile", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"), Cover: []string{"./internal/profile", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"}},
		{Name: "post-service", Test: withIntegration("./cmd/post-service", "./internal/post", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"), Cover: []string{"./internal/post", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"}},
		{Name: "media-service", Test: withIntegration("./cmd/media-service", "./internal/media", "./internal/config", "./internal/middleware", "./internal/security", "./internal/server"), Cover: []string{"./internal/media", "./internal/config", "./internal/middleware", "./internal/security", "./internal/server"}},
		{Name: "moderation-service", Test: withIntegration("./cmd/moderation-service", "./internal/moderation", "./internal/sanction", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"), Cover: []string{"./internal/moderation", "./internal/sanction", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"}},
		{Name: "messages-service", Test: withIntegration("./cmd/messages-service", "./internal/messages", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"), Cover: []string{"./internal/messages", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"}},
		{Name: "social-service", Test: withIntegration("./cmd/social-service", "./internal/social", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"), Cover: []string{"./internal/social", "./internal/config", "./internal/db", "./internal/middleware", "./internal/models", "./internal/security", "./internal/server", "./internal/validation"}},
	}
}

func withIntegration(paths ...string) []string {
	return append(paths, "./internal/integration")
}

var indexTemplate = template.Must(template.New("index").Funcs(template.FuncMap{
	"base": func(path string) string { return filepath.Base(path) },
}).Parse(`<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Breezy backend coverage</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 32px; color: #17202a; background: #f7f9fb; }
    main { max-width: 1100px; margin: 0 auto; }
    h1 { margin-bottom: 4px; }
    p { color: #52616f; }
    table { width: 100%; border-collapse: collapse; background: white; border: 1px solid #d8e0e8; }
    th, td { text-align: left; padding: 12px 14px; border-bottom: 1px solid #e6edf3; }
    th { background: #eef4f8; }
    tr.global td { background: #e9f7fb; }
    code { font-size: 13px; }
    a { color: #087ea4; text-decoration: none; font-weight: 600; }
    a:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <main>
    <h1>Breezy backend coverage</h1>
    <p>Genere le {{.GeneratedAt}}. Le rapport <strong>all</strong> couvre tout le backend, les autres lignes isolent chaque service.</p>
    <table>
      <thead>
        <tr>
          <th>Service</th>
          <th>Coverage</th>
          <th>Rapport visuel</th>
          <th>Detail fonctions</th>
          <th>Profil brut</th>
        </tr>
      </thead>
      <tbody>
        {{range .Reports}}
        <tr {{if eq .Name "all"}}class="global"{{end}}>
          <td>{{.Name}}</td>
          <td><strong>{{.Percent}}%</strong></td>
          <td><a href="{{base .HTML}}">HTML</a></td>
          <td><a href="{{base .Func}}">Fonctions</a></td>
          <td><code>{{.Profile}}</code></td>
        </tr>
        {{end}}
      </tbody>
    </table>
  </main>
</body>
</html>
`))
