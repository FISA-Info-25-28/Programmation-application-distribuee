package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestServicesIncludesAllBackendReports(t *testing.T) {
	names := map[string]bool{}
	for _, svc := range services() {
		names[svc.Name] = true
		if len(svc.Test) == 0 || len(svc.Cover) == 0 {
			t.Fatalf("service %q should define test and cover packages", svc.Name)
		}
	}

	for _, name := range []string{
		"all",
		"api-gateway",
		"auth-service",
		"user-service",
		"profile-service",
		"post-service",
		"media-service",
		"moderation-service",
		"messages-service",
		"social-service",
	} {
		if !names[name] {
			t.Fatalf("services() missing %q", name)
		}
	}
}

func TestWriteIndex(t *testing.T) {
	dir := t.TempDir()
	reports := []report{{
		Name:    "all",
		Percent: "42.5",
		Profile: "coverage/all.out",
		Func:    "coverage/all.txt",
		HTML:    "coverage/all.html",
	}}

	if err := writeIndex(dir, reports); err != nil {
		t.Fatalf("writeIndex() unexpected error: %v", err)
	}

	body, err := os.ReadFile(filepath.Join(dir, "index.html"))
	if err != nil {
		t.Fatalf("ReadFile(index.html) unexpected error: %v", err)
	}
	content := string(body)
	if !strings.Contains(content, "Breezy backend coverage") || !strings.Contains(content, "42.5%") || !strings.Contains(content, "all.html") {
		t.Fatalf("index content missing expected coverage data: %s", content)
	}
}

func TestCommandExists(t *testing.T) {
	if !commandExists("go") {
		t.Fatal("commandExists(go) = false, want true")
	}
	if commandExists("definitely-not-a-real-breezy-command") {
		t.Fatal("commandExists(fake) = true, want false")
	}
}

func TestNormalizeCoverageProfileMergesDuplicateBlocks(t *testing.T) {
	path := filepath.Join(t.TempDir(), "coverage.out")
	profile := strings.Join([]string{
		"mode: count",
		"example/file.go:1.1,2.2 3 0",
		"example/file.go:1.1,2.2 3 2",
		"example/file.go:4.1,4.5 1 1",
		"",
	}, "\n")
	if err := os.WriteFile(path, []byte(profile), 0o644); err != nil {
		t.Fatalf("WriteFile() unexpected error: %v", err)
	}
	if err := normalizeCoverageProfile(path); err != nil {
		t.Fatalf("normalizeCoverageProfile() unexpected error: %v", err)
	}
	body, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("ReadFile() unexpected error: %v", err)
	}
	content := string(body)
	if strings.Count(content, "example/file.go:1.1,2.2") != 1 || !strings.Contains(content, "example/file.go:1.1,2.2 3 2") {
		t.Fatalf("normalized profile did not merge duplicate blocks: %s", content)
	}
}

func TestCoverageDirectoryCanBeConfigured(t *testing.T) {
	t.Setenv("COVERAGE_DIR", filepath.Join(t.TempDir(), "custom-coverage"))
	if got := strings.TrimSpace(os.Getenv("COVERAGE_DIR")); got == "" {
		t.Fatal("COVERAGE_DIR should be available to the coverage command")
	}
}

func TestNormalizeCoverageProfileMissingFile(t *testing.T) {
	path := filepath.Join(t.TempDir(), "missing.out")
	if err := normalizeCoverageProfile(path); err == nil {
		t.Fatal("normalizeCoverageProfile() expected error for missing file")
	}
}

func TestNormalizeCoverageProfileMissingModeHeader(t *testing.T) {
	path := filepath.Join(t.TempDir(), "coverage.out")
	if err := os.WriteFile(path, []byte("example/file.go:1.1,2.2 3 0\n"), 0o644); err != nil {
		t.Fatalf("WriteFile() unexpected error: %v", err)
	}
	if err := normalizeCoverageProfile(path); err == nil {
		t.Fatal("normalizeCoverageProfile() expected error for missing mode header")
	}
}

func TestNormalizeCoverageProfileInvalidLine(t *testing.T) {
	path := filepath.Join(t.TempDir(), "coverage.out")
	profile := strings.Join([]string{
		"mode: count",
		"example/file.go:1.1,2.2 3",
		"",
	}, "\n")
	if err := os.WriteFile(path, []byte(profile), 0o644); err != nil {
		t.Fatalf("WriteFile() unexpected error: %v", err)
	}
	if err := normalizeCoverageProfile(path); err == nil {
		t.Fatal("normalizeCoverageProfile() expected error for malformed line")
	}
}

func TestNormalizeCoverageProfileInvalidCount(t *testing.T) {
	path := filepath.Join(t.TempDir(), "coverage.out")
	profile := strings.Join([]string{
		"mode: count",
		"example/file.go:1.1,2.2 3 not-a-number",
		"",
	}, "\n")
	if err := os.WriteFile(path, []byte(profile), 0o644); err != nil {
		t.Fatalf("WriteFile() unexpected error: %v", err)
	}
	if err := normalizeCoverageProfile(path); err == nil {
		t.Fatal("normalizeCoverageProfile() expected error for invalid count")
	}
}

func TestWriteIndexFailsForInvalidDirectory(t *testing.T) {
	// Repertoire inexistant : os.Create echouera lors de la creation de
	// index.html, ce qui exerce la branche d'erreur de writeIndex().
	invalidDir := filepath.Join(t.TempDir(), "does", "not", "exist")
	if err := writeIndex(invalidDir, nil); err == nil {
		t.Fatal("writeIndex() expected error for nonexistent directory")
	}
}
