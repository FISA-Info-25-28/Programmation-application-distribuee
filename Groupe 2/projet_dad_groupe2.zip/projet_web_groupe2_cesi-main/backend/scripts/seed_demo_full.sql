-- Seed complet demo Breezy: comptes, profils, posts, follows, likes, replies et notifications.
-- Exemple:
--   docker exec -i breezy-postgres psql -U breezy_user -d breezy < backend/scripts/seed_demo_full.sql

BEGIN;

WITH demo_accounts(email, role, username, display_name, bio) AS (
  VALUES
    ('admin@breezy.demo', 'ADMIN'::auth.user_role, 'demo_admin_breezy', 'Admin Breezy', 'Compte admin pour la demo.'),
    ('moderator@breezy.demo', 'MODERATOR'::auth.user_role, 'demo_mod_breezy', 'Moderateur Breezy', 'Moderation, qualite et veille.'),
    ('user@breezy.demo', 'USER'::auth.user_role, 'demo_user_breezy', 'User Breezy', 'Compte principal pour tester le flux social.'),
    ('maeva@breezy.demo', 'USER'::auth.user_role, 'maeva_dev', 'Maeva Dev', 'Frontend Angular et UI propre.'),
    ('thais@breezy.demo', 'USER'::auth.user_role, 'thais_design', 'Thais Design', 'Design system et micro-interactions.'),
    ('lisa@breezy.demo', 'USER'::auth.user_role, 'lisa_code', 'Lisa Code', 'Back, front et un peu de cafe.'),
    ('allan@breezy.demo', 'USER'::auth.user_role, 'allan_fullstack', 'Allan Fullstack', 'API, Docker et debug.'),
    ('nina@breezy.demo', 'USER'::auth.user_role, 'nina_product', 'Nina Product', 'Produit et priorisation.'),
    ('samir@breezy.demo', 'USER'::auth.user_role, 'samir_api', 'Samir API', 'Services Go et PostgreSQL.'),
    ('jade@breezy.demo', 'USER'::auth.user_role, 'jade_ui', 'Jade UI', 'Accessibilite et composants.'),
    ('enzo@breezy.demo', 'USER'::auth.user_role, 'enzo_ops', 'Enzo Ops', 'Infra locale et observabilite.'),
    ('romane@breezy.demo', 'USER'::auth.user_role, 'romane_data', 'Romane Data', 'Stats, tags et moderation.'),
    ('yanis@breezy.demo', 'USER'::auth.user_role, 'yanis_mobile', 'Yanis Mobile', 'Responsive et mobile first.'),
    ('clara@breezy.demo', 'USER'::auth.user_role, 'clara_ux', 'Clara UX', 'Parcours utilisateur et tests.'),
    ('noah@breezy.demo', 'USER'::auth.user_role, 'noah_security', 'Noah Security', 'Securite, roles et JWT.')
),
upserted_accounts AS (
  INSERT INTO auth.accounts (email, password_hash, role, status)
  SELECT email, crypt('Demo1234!', gen_salt('bf')), role, 'ACTIVE'::auth.account_status
  FROM demo_accounts
  ON CONFLICT (email) DO UPDATE
  SET role = EXCLUDED.role,
      status = 'ACTIVE'::auth.account_status
  RETURNING id, email
)
INSERT INTO profiles.profiles (account_id, username, display_name, bio)
SELECT upserted_accounts.id, demo_accounts.username, demo_accounts.display_name, demo_accounts.bio
FROM upserted_accounts
JOIN demo_accounts ON demo_accounts.email = upserted_accounts.email
ON CONFLICT (account_id) DO UPDATE
SET username = EXCLUDED.username,
    display_name = EXCLUDED.display_name,
    bio = EXCLUDED.bio,
    updated_at = now();

WITH post_seed(username, content, created_at) AS (
  VALUES
    ('demo_user_breezy', 'Je teste le nouveau flux social Breezy avec notifications, abonnements et posts. #demo', now() - interval '6 days'),
    ('maeva_dev', 'Le front profil commence a respirer: edition, posts et listes sociales. #angular', now() - interval '5 days 8 hours'),
    ('thais_design', 'Petit rappel UI: un bouton clair vaut mieux que trois explications. #design', now() - interval '5 days'),
    ('lisa_code', 'Brancher un microservice social se passe bien quand les routes sont propres. #backend', now() - interval '4 days 6 hours'),
    ('allan_fullstack', 'Docker compose avec un service de plus, et tout le monde reste calme. #devops', now() - interval '4 days'),
    ('nina_product', 'Objectif demo: assez de donnees pour cliquer partout sans tomber sur du vide. #product', now() - interval '3 days 7 hours'),
    ('samir_api', 'Les notifications LIKE FOLLOW REPLY MENTION sont pretes a etre testees. @demo_user_breezy #api', now() - interval '3 days'),
    ('jade_ui', 'J ai ajoute quelques mots a flouter dans mes parametres pour tester la censure locale.', now() - interval '2 days 9 hours'),
    ('enzo_ops', 'Le feed abonnements devient vraiment interessant quand les follows sont seeds. #social', now() - interval '2 days'),
    ('romane_data', 'Les tags de demo devraient aider a verifier la recherche. #demo #data', now() - interval '1 day 8 hours'),
    ('yanis_mobile', 'Sur mobile, la page profil doit rester lisible meme avec une banniere custom. #mobile', now() - interval '1 day'),
    ('clara_ux', 'Le bon test: login user@breezy.demo puis suivre, liker, repondre, regarder les notifications.', now() - interval '12 hours'),
    ('noah_security', 'JWT partout ou il faut, et pas de follow sans compte connecte. #security', now() - interval '8 hours')
)
INSERT INTO posts.posts (author_id, content, visibility, created_at, updated_at)
SELECT profiles.id, post_seed.content, 'PUBLIC'::posts.post_visibility, post_seed.created_at, post_seed.created_at
FROM post_seed
JOIN profiles.profiles profiles ON profiles.username = post_seed.username
WHERE NOT EXISTS (
  SELECT 1 FROM posts.posts existing
  WHERE existing.author_id = profiles.id AND existing.content = post_seed.content
);

WITH parent_post AS (
  SELECT p.id
  FROM posts.posts p
  JOIN profiles.profiles author ON author.id = p.author_id
  WHERE author.username = 'demo_user_breezy'
  ORDER BY p.created_at ASC
  LIMIT 1
),
reply_seed(username, content, created_at) AS (
  VALUES
    ('maeva_dev', 'Reponse seed: je confirme, le flux social marche bien. @demo_user_breezy', now() - interval '6 hours'),
    ('thais_design', 'Reponse seed: le profil est beaucoup plus vivant comme ca.', now() - interval '5 hours'),
    ('samir_api', 'Reponse seed: je verifie les notifications de reponse.', now() - interval '4 hours')
)
INSERT INTO posts.posts (author_id, content, parent_id, visibility, created_at, updated_at)
SELECT profiles.id, reply_seed.content, parent_post.id, 'PUBLIC'::posts.post_visibility, reply_seed.created_at, reply_seed.created_at
FROM reply_seed
JOIN parent_post ON true
JOIN profiles.profiles profiles ON profiles.username = reply_seed.username
WHERE NOT EXISTS (
  SELECT 1 FROM posts.posts existing
  WHERE existing.author_id = profiles.id AND existing.content = reply_seed.content
);

WITH follow_seed(follower_username, followed_username) AS (
  VALUES
    ('demo_user_breezy', 'maeva_dev'), ('demo_user_breezy', 'thais_design'), ('demo_user_breezy', 'lisa_code'),
    ('demo_user_breezy', 'allan_fullstack'), ('demo_user_breezy', 'samir_api'), ('demo_user_breezy', 'jade_ui'),
    ('maeva_dev', 'demo_user_breezy'), ('thais_design', 'demo_user_breezy'), ('lisa_code', 'demo_user_breezy'),
    ('allan_fullstack', 'demo_user_breezy'), ('nina_product', 'demo_user_breezy'), ('samir_api', 'demo_user_breezy'),
    ('jade_ui', 'demo_user_breezy'), ('enzo_ops', 'demo_user_breezy'), ('romane_data', 'demo_user_breezy'),
    ('yanis_mobile', 'demo_user_breezy'), ('clara_ux', 'demo_user_breezy'), ('noah_security', 'demo_user_breezy'),
    ('maeva_dev', 'thais_design'), ('thais_design', 'maeva_dev'), ('samir_api', 'allan_fullstack'),
    ('allan_fullstack', 'samir_api'), ('jade_ui', 'clara_ux'), ('clara_ux', 'jade_ui')
)
INSERT INTO social.follows (follower_id, followed_id)
SELECT follower.id, followed.id
FROM follow_seed
JOIN profiles.profiles follower ON follower.username = follow_seed.follower_username
JOIN profiles.profiles followed ON followed.username = follow_seed.followed_username
ON CONFLICT (follower_id, followed_id) DO NOTHING;

WITH like_seed(liker_username, author_username) AS (
  VALUES
    ('maeva_dev', 'demo_user_breezy'), ('thais_design', 'demo_user_breezy'), ('lisa_code', 'demo_user_breezy'),
    ('allan_fullstack', 'demo_user_breezy'), ('samir_api', 'demo_user_breezy'), ('jade_ui', 'demo_user_breezy'),
    ('demo_user_breezy', 'maeva_dev'), ('demo_user_breezy', 'thais_design'), ('demo_user_breezy', 'lisa_code'),
    ('demo_user_breezy', 'samir_api'), ('demo_user_breezy', 'clara_ux')
),
target_posts AS (
  SELECT DISTINCT ON (author.username) p.id, author.username
  FROM posts.posts p
  JOIN profiles.profiles author ON author.id = p.author_id
  WHERE p.parent_id IS NULL
  ORDER BY author.username, p.created_at DESC
)
INSERT INTO posts.likes (post_id, user_id)
SELECT target_posts.id, liker.id
FROM like_seed
JOIN target_posts ON target_posts.username = like_seed.author_username
JOIN profiles.profiles liker ON liker.username = like_seed.liker_username
ON CONFLICT (post_id, user_id) DO NOTHING;

WITH notif_seed(recipient_username, actor_username, type_name, post_author_username, created_at) AS (
  VALUES
    ('demo_user_breezy', 'maeva_dev', 'FOLLOW', NULL, now() - interval '4 hours'),
    ('demo_user_breezy', 'thais_design', 'FOLLOW', NULL, now() - interval '3 hours 50 minutes'),
    ('demo_user_breezy', 'samir_api', 'LIKE', 'demo_user_breezy', now() - interval '3 hours'),
    ('demo_user_breezy', 'maeva_dev', 'REPLY', 'demo_user_breezy', now() - interval '2 hours'),
    ('demo_user_breezy', 'samir_api', 'MENTION', 'samir_api', now() - interval '1 hour'),
    ('maeva_dev', 'demo_user_breezy', 'LIKE', 'maeva_dev', now() - interval '55 minutes'),
    ('thais_design', 'demo_user_breezy', 'LIKE', 'thais_design', now() - interval '45 minutes'),
    ('samir_api', 'demo_user_breezy', 'FOLLOW', NULL, now() - interval '40 minutes'),
    ('samir_api', 'demo_user_breezy', 'LIKE', 'samir_api', now() - interval '30 minutes'),
    ('samir_api', 'allan_fullstack', 'LIKE', 'samir_api', now() - interval '20 minutes'),
    ('samir_api', 'maeva_dev', 'REPLY', 'samir_api', now() - interval '10 minutes'),
    ('allan_fullstack', 'samir_api', 'FOLLOW', NULL, now() - interval '38 minutes'),
    ('allan_fullstack', 'demo_user_breezy', 'LIKE', 'allan_fullstack', now() - interval '25 minutes'),
    ('allan_fullstack', 'samir_api', 'REPLY', 'allan_fullstack', now() - interval '15 minutes')
),
notif_posts AS (
  SELECT DISTINCT ON (author.username) author.username, p.id
  FROM posts.posts p
  JOIN profiles.profiles author ON author.id = p.author_id
  WHERE p.parent_id IS NULL
  ORDER BY author.username, p.created_at DESC
)
INSERT INTO social.notifications (recipient_id, actor_id, type, post_id, is_read, created_at)
SELECT recipient.id, actor.id, notif_seed.type_name::social.notification_type, notif_posts.id, false, notif_seed.created_at
FROM notif_seed
JOIN profiles.profiles recipient ON recipient.username = notif_seed.recipient_username
JOIN profiles.profiles actor ON actor.username = notif_seed.actor_username
LEFT JOIN notif_posts ON notif_posts.username = notif_seed.post_author_username
WHERE NOT EXISTS (
  SELECT 1 FROM social.notifications existing
  WHERE existing.recipient_id = recipient.id
    AND existing.actor_id = actor.id
    AND existing.type::text = notif_seed.type_name
    AND existing.created_at = notif_seed.created_at
);

WITH tag_values(name) AS (
  VALUES ('demo'), ('angular'), ('backend'), ('design'), ('api'), ('social'), ('mobile'), ('security'), ('data'), ('product'), ('devops')
)
INSERT INTO posts.tags (name)
SELECT name FROM tag_values
ON CONFLICT (name) DO NOTHING;

WITH extracted_post_tags AS (
  SELECT DISTINCT
    p.id AS post_id,
    LOWER(match[1]) AS tag_name
  FROM posts.posts p
  CROSS JOIN LATERAL regexp_matches(p.content, '#([[:alnum:]_]+)', 'gi') AS match
  WHERE p.deleted_at IS NULL
),
resolved_tags AS (
  SELECT
    extracted_post_tags.post_id,
    t.id AS tag_id
  FROM extracted_post_tags
  JOIN posts.tags t ON t.name = extracted_post_tags.tag_name
  WHERE extracted_post_tags.tag_name <> ''
)
INSERT INTO posts.post_tags (post_id, tag_id)
SELECT post_id, tag_id
FROM resolved_tags
ON CONFLICT (post_id, tag_id) DO NOTHING;

COMMIT;
