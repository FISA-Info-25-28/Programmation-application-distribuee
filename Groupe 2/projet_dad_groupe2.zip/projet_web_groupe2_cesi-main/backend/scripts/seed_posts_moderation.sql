-- Seed de posts/reponses/reports pour tester le back sans mocks.
--
-- Prerequis:
-- - Postgres lance avec la migration 001_init.sql
--
-- Exemple Docker depuis la racine du repo:
--   docker exec -i breezy-postgres psql -U cesi_user -d cesi_app < backend/scripts/seed_posts_moderation.sql
--
-- Si tes identifiants DB sont differents, remplace cesi_user/cesi_app par les valeurs de backend/.env.

BEGIN;

WITH demo_accounts(email, role, username, display_name) AS (
  VALUES
    ('admin@breezy.demo', 'ADMIN'::auth.user_role, 'demo_admin_breezy', 'Admin Breezy'),
    ('moderator@breezy.demo', 'MODERATOR'::auth.user_role, 'demo_mod_breezy', 'Moderateur Breezy'),
    ('user@breezy.demo', 'USER'::auth.user_role, 'demo_user_breezy', 'User Breezy')
),
inserted_accounts AS (
  INSERT INTO auth.accounts (email, password_hash, role, status)
  SELECT
    email,
    crypt('Demo1234!', gen_salt('bf')),
    role,
    'ACTIVE'::auth.account_status
  FROM demo_accounts
  ON CONFLICT (email) DO UPDATE
  SET role = EXCLUDED.role,
      status = 'ACTIVE'::auth.account_status
  RETURNING id, email
)
UPDATE profiles.profiles
SET username = demo_accounts.username,
    display_name = demo_accounts.display_name,
    updated_at = now()
FROM inserted_accounts
JOIN demo_accounts ON demo_accounts.email = inserted_accounts.email
WHERE profiles.profiles.account_id = inserted_accounts.id;

WITH demo_accounts(email, role, username, display_name) AS (
  VALUES
    ('admin@breezy.demo', 'ADMIN'::auth.user_role, 'demo_admin_breezy', 'Admin Breezy'),
    ('moderator@breezy.demo', 'MODERATOR'::auth.user_role, 'demo_mod_breezy', 'Moderateur Breezy'),
    ('user@breezy.demo', 'USER'::auth.user_role, 'demo_user_breezy', 'User Breezy')
),
demo_account_ids AS (
  SELECT accounts.id, demo_accounts.username, demo_accounts.display_name
  FROM auth.accounts
  JOIN demo_accounts ON demo_accounts.email = accounts.email
)
INSERT INTO profiles.profiles (account_id, username, display_name)
SELECT id, username, display_name
FROM demo_account_ids
WHERE NOT EXISTS (
  SELECT 1
  FROM profiles.profiles
  WHERE profiles.profiles.account_id = demo_account_ids.id
);

WITH demo_profiles AS (
  SELECT id, username
  FROM profiles.profiles
  WHERE username IN ('demo_user_breezy', 'demo_mod_breezy', 'demo_admin_breezy')
),
seed_posts(id, username, content, created_at) AS (
  VALUES
    (
      '10000000-0000-0000-0000-000000000001'::uuid,
      'demo_user_breezy',
      'Post seed public pour verifier GET /api/posts/feed avec le vrai backend.',
      now() - interval '5 days'
    ),
    (
      '10000000-0000-0000-0000-000000000002'::uuid,
      'demo_mod_breezy',
      'Post moderateur seed: utile pour verifier que plusieurs auteurs remontent dans le feed.',
      now() - interval '4 days'
    ),
    (
      '10000000-0000-0000-0000-000000000003'::uuid,
      'demo_user_breezy',
      'Post volontairement a signaler pour tester la creation et la revue des reports.',
      now() - interval '3 days'
    ),
    (
      '10000000-0000-0000-0000-000000000004'::uuid,
      'demo_admin_breezy',
      'Post admin seed pour tester la moderation avec un contenu deja signale.',
      now() - interval '2 days'
    ),
    (
      '10000000-0000-0000-0000-000000000005'::uuid,
      'demo_user_breezy',
      'Post parent seed pour tester GET /api/posts/:id/replies.',
      now() - interval '1 day'
    )
)
INSERT INTO posts.posts (id, author_id, content, parent_id, visibility, created_at, updated_at, deleted_at)
SELECT
  seed_posts.id,
  demo_profiles.id,
  seed_posts.content,
  NULL,
  'PUBLIC'::posts.post_visibility,
  seed_posts.created_at,
  seed_posts.created_at,
  NULL
FROM seed_posts
JOIN demo_profiles ON demo_profiles.username = seed_posts.username
ON CONFLICT (id) DO UPDATE
SET author_id = EXCLUDED.author_id,
    content = EXCLUDED.content,
    parent_id = EXCLUDED.parent_id,
    visibility = EXCLUDED.visibility,
    updated_at = now(),
    deleted_at = NULL;

WITH demo_profiles AS (
  SELECT id, username
  FROM profiles.profiles
  WHERE username IN ('demo_mod_breezy', 'demo_admin_breezy')
),
seed_replies(id, username, parent_id, content, created_at) AS (
  VALUES
    (
      '10000000-0000-0000-0000-000000000006'::uuid,
      'demo_mod_breezy',
      '10000000-0000-0000-0000-000000000005'::uuid,
      'Reponse seed moderateur pour tester les commentaires en base.',
      now() - interval '20 hours'
    ),
    (
      '10000000-0000-0000-0000-000000000007'::uuid,
      'demo_admin_breezy',
      '10000000-0000-0000-0000-000000000005'::uuid,
      'Reponse seed admin pour verifier le comptage des commentaires.',
      now() - interval '18 hours'
    )
)
INSERT INTO posts.posts (id, author_id, content, parent_id, visibility, created_at, updated_at, deleted_at)
SELECT
  seed_replies.id,
  demo_profiles.id,
  seed_replies.content,
  seed_replies.parent_id,
  'PUBLIC'::posts.post_visibility,
  seed_replies.created_at,
  seed_replies.created_at,
  NULL
FROM seed_replies
JOIN demo_profiles ON demo_profiles.username = seed_replies.username
ON CONFLICT (id) DO UPDATE
SET author_id = EXCLUDED.author_id,
    content = EXCLUDED.content,
    parent_id = EXCLUDED.parent_id,
    visibility = EXCLUDED.visibility,
    updated_at = now(),
    deleted_at = NULL;

WITH demo_profiles AS (
  SELECT id, username
  FROM profiles.profiles
  WHERE username IN ('demo_user_breezy', 'demo_mod_breezy', 'demo_admin_breezy')
),
seed_likes(post_id, username) AS (
  VALUES
    ('10000000-0000-0000-0000-000000000001'::uuid, 'demo_mod_breezy'),
    ('10000000-0000-0000-0000-000000000001'::uuid, 'demo_admin_breezy'),
    ('10000000-0000-0000-0000-000000000003'::uuid, 'demo_mod_breezy'),
    ('10000000-0000-0000-0000-000000000005'::uuid, 'demo_admin_breezy')
)
INSERT INTO posts.likes (post_id, user_id)
SELECT seed_likes.post_id, demo_profiles.id
FROM seed_likes
JOIN demo_profiles ON demo_profiles.username = seed_likes.username
ON CONFLICT (post_id, user_id) DO NOTHING;

WITH tag_values(name) AS (
  VALUES ('backend'), ('moderation'), ('demo'), ('seed')
)
INSERT INTO posts.tags (name)
SELECT name
FROM tag_values
ON CONFLICT (name) DO NOTHING;

WITH seeded_tags AS (
  SELECT id, name
  FROM posts.tags
  WHERE name IN ('backend', 'moderation', 'demo', 'seed')
),
post_tag_values(post_id, tag_name) AS (
  VALUES
    ('10000000-0000-0000-0000-000000000001'::uuid, 'backend'),
    ('10000000-0000-0000-0000-000000000001'::uuid, 'demo'),
    ('10000000-0000-0000-0000-000000000003'::uuid, 'moderation'),
    ('10000000-0000-0000-0000-000000000003'::uuid, 'seed'),
    ('10000000-0000-0000-0000-000000000005'::uuid, 'backend')
)
INSERT INTO posts.post_tags (post_id, tag_id)
SELECT post_tag_values.post_id, seeded_tags.id
FROM post_tag_values
JOIN seeded_tags ON seeded_tags.name = post_tag_values.tag_name
ON CONFLICT (post_id, tag_id) DO NOTHING;

WITH reporter AS (
  SELECT id
  FROM profiles.profiles
  WHERE username = 'demo_user_breezy'
),
reviewer AS (
  SELECT id
  FROM profiles.profiles
  WHERE username = 'demo_mod_breezy'
)
INSERT INTO moderation.reports (
  id,
  reporter_id,
  reported_post_id,
  reported_user_id,
  reason,
  status,
  reviewed_by,
  reviewed_at,
  created_at
)
VALUES
  (
    '20000000-0000-0000-0000-000000000001'::uuid,
    (SELECT id FROM reporter),
    '10000000-0000-0000-0000-000000000003'::uuid,
    NULL,
    'Signalement seed en attente pour tester la liste moderation.',
    'PENDING'::moderation.report_status,
    NULL,
    NULL,
    now() - interval '12 hours'
  ),
  (
    '20000000-0000-0000-0000-000000000002'::uuid,
    (SELECT id FROM reporter),
    '10000000-0000-0000-0000-000000000004'::uuid,
    NULL,
    'Signalement seed deja relu pour tester les statuts.',
    'REVIEWED'::moderation.report_status,
    (SELECT id FROM reviewer),
    now() - interval '2 hours',
    now() - interval '10 hours'
  )
ON CONFLICT (id) DO UPDATE
SET reporter_id = EXCLUDED.reporter_id,
    reported_post_id = EXCLUDED.reported_post_id,
    reported_user_id = EXCLUDED.reported_user_id,
    reason = EXCLUDED.reason,
    status = EXCLUDED.status,
    reviewed_by = EXCLUDED.reviewed_by,
    reviewed_at = EXCLUDED.reviewed_at;

COMMIT;
