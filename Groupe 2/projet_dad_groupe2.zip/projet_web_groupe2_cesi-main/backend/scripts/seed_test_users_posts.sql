-- Seed test Breezy: 10 utilisateurs, 10 posts, follows, likes, tags et quelques reponses.
--
-- Usage depuis la racine du repo:
--   docker exec -i breezy-postgres psql -U breezy_user -d breezy < backend/scripts/seed_test_users_posts.sql
--
-- Si tes variables sont differentes, remplace breezy_user/breezy
-- par les valeurs de ton .env.

BEGIN;

WITH seed_accounts(email, role, username, display_name, bio, avatar_url) AS (
  VALUES
    ('alice.test@breezy.demo', 'USER'::auth.user_role, 'alice_test', 'Alice Test', 'Aime tester les parcours complets.', 'https://i.pravatar.cc/150?img=1'),
    ('bruno.test@breezy.demo', 'USER'::auth.user_role, 'bruno_test', 'Bruno Test', 'Debug, API et patience.', 'https://i.pravatar.cc/150?img=2'),
    ('carla.test@breezy.demo', 'USER'::auth.user_role, 'carla_test', 'Carla Test', 'UI, recherche et details propres.', 'https://i.pravatar.cc/150?img=3'),
    ('diego.test@breezy.demo', 'USER'::auth.user_role, 'diego_test', 'Diego Test', 'Compose, Docker et scripts utiles.', 'https://i.pravatar.cc/150?img=4'),
    ('emma.test@breezy.demo', 'USER'::auth.user_role, 'emma_test', 'Emma Test', 'Experience utilisateur et details visuels.', 'https://i.pravatar.cc/150?img=5'),
    ('farid.test@breezy.demo', 'USER'::auth.user_role, 'farid_test', 'Farid Test', 'Services Go et SQL lisible.', 'https://i.pravatar.cc/150?img=6'),
    ('giulia.test@breezy.demo', 'USER'::auth.user_role, 'giulia_test', 'Giulia Test', 'Likes, follows et notifs.', 'https://i.pravatar.cc/150?img=7'),
    ('hugo.test@breezy.demo', 'USER'::auth.user_role, 'hugo_test', 'Hugo Test', 'Responsive et feed vivant.', 'https://i.pravatar.cc/150?img=8'),
    ('ines.test@breezy.demo', 'USER'::auth.user_role, 'ines_test', 'Ines Test', 'Tags, recherche et data de demo.', 'https://i.pravatar.cc/150?img=9'),
    ('jade.test@breezy.demo', 'USER'::auth.user_role, 'jade_test', 'Jade Test', 'Moderation et verification fonctionnelle.', 'https://i.pravatar.cc/150?img=10')
),
upserted_accounts AS (
  INSERT INTO auth.accounts (email, password_hash, role, status, email_verified_at)
  SELECT
    email,
    crypt('Test1234!', gen_salt('bf')),
    role,
    'ACTIVE'::auth.account_status,
    now()
  FROM seed_accounts
  ON CONFLICT (email) DO UPDATE
  SET role = EXCLUDED.role,
      status = 'ACTIVE'::auth.account_status,
      email_verified_at = now()
  RETURNING id, email
)
INSERT INTO profiles.profiles (account_id, username, display_name, bio, avatar_url)
SELECT
  upserted_accounts.id,
  seed_accounts.username,
  seed_accounts.display_name,
  seed_accounts.bio,
  seed_accounts.avatar_url
FROM upserted_accounts
JOIN seed_accounts ON seed_accounts.email = upserted_accounts.email
ON CONFLICT (account_id) DO UPDATE
SET username = EXCLUDED.username,
    display_name = EXCLUDED.display_name,
    bio = EXCLUDED.bio,
    avatar_url = EXCLUDED.avatar_url,
    updated_at = now();

WITH preference_seed(username, locale, theme) AS (
  VALUES
    ('alice_test', 'fr', 'light'),
    ('bruno_test', 'fr', 'system'),
    ('carla_test', 'en', 'light'),
    ('diego_test', 'fr', 'dark'),
    ('emma_test', 'fr', 'light'),
    ('farid_test', 'en', 'system'),
    ('giulia_test', 'fr', 'light'),
    ('hugo_test', 'fr', 'dark'),
    ('ines_test', 'en', 'light'),
    ('jade_test', 'fr', 'system')
)
INSERT INTO profiles.preferences (profile_id, locale, theme)
SELECT p.id, preference_seed.locale, preference_seed.theme
FROM preference_seed
JOIN profiles.profiles p ON p.username = preference_seed.username
ON CONFLICT (profile_id) DO UPDATE
SET locale = EXCLUDED.locale,
    theme = EXCLUDED.theme,
    updated_at = now();

WITH follow_seed(follower_username, followed_username) AS (
  VALUES
    ('alice_test', 'bruno_test'),
    ('alice_test', 'carla_test'),
    ('alice_test', 'diego_test'),
    ('bruno_test', 'alice_test'),
    ('bruno_test', 'farid_test'),
    ('carla_test', 'alice_test'),
    ('carla_test', 'emma_test'),
    ('diego_test', 'farid_test'),
    ('emma_test', 'alice_test'),
    ('farid_test', 'ines_test'),
    ('giulia_test', 'alice_test'),
    ('giulia_test', 'hugo_test'),
    ('hugo_test', 'carla_test'),
    ('ines_test', 'jade_test'),
    ('jade_test', 'alice_test')
)
INSERT INTO social.follows (follower_id, followed_id)
SELECT follower.id, followed.id
FROM follow_seed
JOIN profiles.profiles follower ON follower.username = follow_seed.follower_username
JOIN profiles.profiles followed ON followed.username = follow_seed.followed_username
ON CONFLICT (follower_id, followed_id) DO NOTHING;

WITH post_seed(id, username, content, visibility, created_at) AS (
  VALUES
    ('30000000-0000-0000-0000-000000000001'::uuid, 'alice_test', 'Premier post de test pour verifier que le feed charge bien les donnees depuis la base. #demo #feed', 'PUBLIC'::posts.post_visibility, now() - interval '5 days'),
    ('30000000-0000-0000-0000-000000000002'::uuid, 'bruno_test', 'Je valide le parcours API -> gateway -> frontend avec de vraies donnees. #backend #api', 'PUBLIC'::posts.post_visibility, now() - interval '4 days 20 hours'),
    ('30000000-0000-0000-0000-000000000003'::uuid, 'carla_test', 'La page recherche devrait retrouver ce post via son tag principal. #search #ui', 'PUBLIC'::posts.post_visibility, now() - interval '4 days'),
    ('30000000-0000-0000-0000-000000000004'::uuid, 'diego_test', 'Petit test Docker Compose avec un jeu de donnees stable et reexecutable. #docker #devops', 'PUBLIC'::posts.post_visibility, now() - interval '3 days 18 hours'),
    ('30000000-0000-0000-0000-000000000005'::uuid, 'emma_test', 'Je verifie le rendu des cartes, avatars, dates et interactions utilisateur. #frontend #ux', 'PUBLIC'::posts.post_visibility, now() - interval '3 days'),
    ('30000000-0000-0000-0000-000000000006'::uuid, 'farid_test', 'Les microservices restent simples quand les contrats JSON sont clairs. #go #microservices', 'PUBLIC'::posts.post_visibility, now() - interval '2 days 12 hours'),
    ('30000000-0000-0000-0000-000000000007'::uuid, 'giulia_test', 'Quelques likes et follows seeds rendent le produit tout de suite plus vivant. #social #likes', 'PUBLIC'::posts.post_visibility, now() - interval '2 days'),
    ('30000000-0000-0000-0000-000000000008'::uuid, 'hugo_test', 'Le feed mobile doit rester lisible meme quand le contenu devient plus dense. #mobile #responsive', 'PUBLIC'::posts.post_visibility, now() - interval '1 day 18 hours'),
    ('30000000-0000-0000-0000-000000000009'::uuid, 'ines_test', 'Ce post sert aussi a tester les tags populaires et la recherche par mot-cle. #data #tags', 'PUBLIC'::posts.post_visibility, now() - interval '1 day'),
    ('30000000-0000-0000-0000-000000000010'::uuid, 'jade_test', 'Je laisse un post de moderation soft pour verifier que tout remonte sans erreur 500. #moderation #test', 'PUBLIC'::posts.post_visibility, now() - interval '12 hours')
)
INSERT INTO posts.posts (id, author_id, content, parent_id, visibility, created_at, updated_at, deleted_at)
SELECT
  post_seed.id,
  p.id,
  post_seed.content,
  NULL,
  post_seed.visibility,
  post_seed.created_at,
  post_seed.created_at,
  NULL
FROM post_seed
JOIN profiles.profiles p ON p.username = post_seed.username
ON CONFLICT (id) DO UPDATE
SET author_id = EXCLUDED.author_id,
    content = EXCLUDED.content,
    parent_id = EXCLUDED.parent_id,
    visibility = EXCLUDED.visibility,
    updated_at = now(),
    deleted_at = NULL;

WITH reply_seed(id, username, parent_id, content, created_at) AS (
  VALUES
    ('30000000-0000-0000-0000-000000000011'::uuid, 'bruno_test', '30000000-0000-0000-0000-000000000001'::uuid, 'Je confirme, ce post est utile pour valider le feed principal.', now() - interval '10 hours'),
    ('30000000-0000-0000-0000-000000000012'::uuid, 'carla_test', '30000000-0000-0000-0000-000000000001'::uuid, 'Je vois bien la reponse en base, pratique pour tester le detail du post.', now() - interval '9 hours'),
    ('30000000-0000-0000-0000-000000000013'::uuid, 'jade_test', '30000000-0000-0000-0000-000000000010'::uuid, 'Reponse de test pour le comptage des commentaires.', now() - interval '6 hours')
)
INSERT INTO posts.posts (id, author_id, content, parent_id, visibility, created_at, updated_at, deleted_at)
SELECT
  reply_seed.id,
  p.id,
  reply_seed.content,
  reply_seed.parent_id,
  'PUBLIC'::posts.post_visibility,
  reply_seed.created_at,
  reply_seed.created_at,
  NULL
FROM reply_seed
JOIN profiles.profiles p ON p.username = reply_seed.username
ON CONFLICT (id) DO UPDATE
SET author_id = EXCLUDED.author_id,
    content = EXCLUDED.content,
    parent_id = EXCLUDED.parent_id,
    visibility = EXCLUDED.visibility,
    updated_at = now(),
    deleted_at = NULL;

WITH like_seed(post_id, liker_username) AS (
  VALUES
    ('30000000-0000-0000-0000-000000000001'::uuid, 'bruno_test'),
    ('30000000-0000-0000-0000-000000000001'::uuid, 'carla_test'),
    ('30000000-0000-0000-0000-000000000002'::uuid, 'alice_test'),
    ('30000000-0000-0000-0000-000000000003'::uuid, 'emma_test'),
    ('30000000-0000-0000-0000-000000000004'::uuid, 'farid_test'),
    ('30000000-0000-0000-0000-000000000005'::uuid, 'giulia_test'),
    ('30000000-0000-0000-0000-000000000006'::uuid, 'hugo_test'),
    ('30000000-0000-0000-0000-000000000007'::uuid, 'ines_test'),
    ('30000000-0000-0000-0000-000000000008'::uuid, 'jade_test'),
    ('30000000-0000-0000-0000-000000000010'::uuid, 'alice_test')
)
INSERT INTO posts.likes (post_id, user_id)
SELECT like_seed.post_id, p.id
FROM like_seed
JOIN profiles.profiles p ON p.username = like_seed.liker_username
ON CONFLICT (post_id, user_id) DO NOTHING;

WITH tag_values(name) AS (
  VALUES
    ('demo'), ('feed'), ('backend'), ('api'), ('search'),
    ('ui'), ('docker'), ('devops'), ('frontend'), ('ux'),
    ('go'), ('microservices'), ('social'), ('likes'), ('mobile'),
    ('responsive'), ('data'), ('tags'), ('moderation'), ('test')
)
INSERT INTO posts.tags (name)
SELECT name
FROM tag_values
ON CONFLICT (name) DO NOTHING;

WITH post_tag_values(post_id, tag_name) AS (
  VALUES
    ('30000000-0000-0000-0000-000000000001'::uuid, 'demo'),
    ('30000000-0000-0000-0000-000000000001'::uuid, 'feed'),
    ('30000000-0000-0000-0000-000000000002'::uuid, 'backend'),
    ('30000000-0000-0000-0000-000000000002'::uuid, 'api'),
    ('30000000-0000-0000-0000-000000000003'::uuid, 'search'),
    ('30000000-0000-0000-0000-000000000003'::uuid, 'ui'),
    ('30000000-0000-0000-0000-000000000004'::uuid, 'docker'),
    ('30000000-0000-0000-0000-000000000004'::uuid, 'devops'),
    ('30000000-0000-0000-0000-000000000005'::uuid, 'frontend'),
    ('30000000-0000-0000-0000-000000000005'::uuid, 'ux'),
    ('30000000-0000-0000-0000-000000000006'::uuid, 'go'),
    ('30000000-0000-0000-0000-000000000006'::uuid, 'microservices'),
    ('30000000-0000-0000-0000-000000000007'::uuid, 'social'),
    ('30000000-0000-0000-0000-000000000007'::uuid, 'likes'),
    ('30000000-0000-0000-0000-000000000008'::uuid, 'mobile'),
    ('30000000-0000-0000-0000-000000000008'::uuid, 'responsive'),
    ('30000000-0000-0000-0000-000000000009'::uuid, 'data'),
    ('30000000-0000-0000-0000-000000000009'::uuid, 'tags'),
    ('30000000-0000-0000-0000-000000000010'::uuid, 'moderation'),
    ('30000000-0000-0000-0000-000000000010'::uuid, 'test')
),
seeded_tags AS (
  SELECT id, name
  FROM posts.tags
)
INSERT INTO posts.post_tags (post_id, tag_id)
SELECT post_tag_values.post_id, seeded_tags.id
FROM post_tag_values
JOIN seeded_tags ON seeded_tags.name = post_tag_values.tag_name
ON CONFLICT (post_id, tag_id) DO NOTHING;

COMMIT;
