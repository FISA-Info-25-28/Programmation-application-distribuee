#!/usr/bin/env bash
# Genere un certificat TLS auto-signe (EC P-256) pour l'api-gateway en
# developpement local. Ce certificat n'est pas reconnu par les navigateurs
# (avertissement "non securise" attendu) : il sert uniquement a chiffrer le
# trafic vers https://localhost:8080 en dev. En production, le TLS reel
# (Let's Encrypt) est deja termine au niveau de frontend/nginx.conf.
#
# Usage : ./certs/generate-dev-cert.sh
set -euo pipefail

# Evite que Git Bash (MSYS) ne convertisse "/CN=localhost" en chemin Windows.
export MSYS_NO_PATHCONV=1

cd "$(dirname "$0")"

openssl req -x509 \
  -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 \
  -nodes -days 365 \
  -keyout gateway.key \
  -out gateway.crt \
  -subj "/CN=localhost" \
  -addext "subjectAltName=DNS:localhost,IP:127.0.0.1"

echo "Certificat genere : certs/gateway.crt + certs/gateway.key"
