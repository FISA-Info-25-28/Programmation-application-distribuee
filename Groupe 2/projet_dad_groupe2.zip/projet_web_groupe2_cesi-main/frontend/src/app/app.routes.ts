import type { Routes } from '@angular/router';
import { Auth } from './pages/auth/auth';
import { authGuard } from './core/guards/auth.guard';
import { guestGuard } from './core/guards/guest.guard';
import { roleGuard } from './core/guards/role.guard';
import { guestProtectedGuard } from './core/guards/guest-protected.guard';

// Ce fichier définit les routes de l'application Angular, 
// en utilisant des guards pour protéger certaines routes en fonction de l'authentification et des rôles des utilisateurs. 
// Les composants sont chargés de manière paresseuse (lazy loading) pour optimiser les performances.
export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },

  {
    path: 'auth',
    component: Auth,
    canActivate: [guestGuard],
  },

  {
    path: 'home',
    loadComponent: () => import('./pages/home/home').then((m) => m.Home),
    canActivate: [authGuard],
    children: [
      { path: '', redirectTo: 'feed', pathMatch: 'full' },
      {
        path: 'feed',
        loadComponent: () => import('./pages/feed/feed').then((m) => m.Feed),
      },
      {
        path: 'post/:id',
        loadComponent: () => import('./pages/post/post').then((m) => m.PostDetail),
      },
      {
        path: 'search/tags/:tags',
        canActivate: [guestProtectedGuard],
        loadComponent: () => import('./pages/search/search').then((m) => m.Search),
      },
      {
        path: 'search/tag/:tag',
        canActivate: [guestProtectedGuard],
        loadComponent: () => import('./pages/search/search').then((m) => m.Search),
      },
      {
        path: 'search',
        canActivate: [guestProtectedGuard],
        loadComponent: () => import('./pages/search/search').then((m) => m.Search),
      },
      {
        path: 'notifications',
        canActivate: [guestProtectedGuard],
        loadComponent: () => import('./pages/notifications/notifications').then((m) => m.Notifications),
      },
      {
        path: 'messages',
        canActivate: [guestProtectedGuard],
        loadComponent: () => import('./pages/messages/messages').then((m) => m.Messages),
      },
      {
        path: 'messages/:id',
        canActivate: [guestProtectedGuard],
        loadComponent: () => import('./pages/messages/messages').then((m) => m.Messages),
      },
      {
        path: 'profile/edit',
        canActivate: [guestProtectedGuard],
        loadComponent: () => import('./pages/profile/profile-edit/profile-edit').then((m) => m.ProfileEdit),
      },
      {
        path: 'profile/:username',
        canActivate: [guestProtectedGuard],
        loadComponent: () => import('./pages/profile/profile').then((m) => m.Profile),
      },
      {
        path: 'bookmarks',
        canActivate: [guestProtectedGuard],
        loadComponent: () => import('./pages/bookmarks/bookmarks').then((m) => m.Bookmarks),
      },
      {
        path: 'settings',
        loadComponent: () => import('./pages/settings/settings').then((m) => m.Settings),
      },
      {
        path: 'moderation',
        canActivate: [roleGuard(['MODERATOR', 'ADMIN'])],
        loadComponent: () => import('./pages/moderation/moderation').then((m) => m.Moderation),
      },
      {
        path: 'administration',
        canActivate: [roleGuard(['ADMIN'])],
        loadComponent: () => import('./pages/administration/administration').then((m) => m.Administration),
      },
    ],
  },

  { path: '**', redirectTo: 'home' },
];
