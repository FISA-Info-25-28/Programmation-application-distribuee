import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FlashMessages } from './shared/flash/flash-messages';
import { ReplyModal } from './shared/reply-modal/reply-modal';
import { ThemeService } from './core/services/theme.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FlashMessages, ReplyModal],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  private readonly theme = inject(ThemeService);
}
