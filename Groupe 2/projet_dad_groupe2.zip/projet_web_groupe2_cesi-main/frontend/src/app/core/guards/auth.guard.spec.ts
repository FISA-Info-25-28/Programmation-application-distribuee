import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import type { UrlTree } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { GuestService } from '../services/guest.service';
import { authGuard } from './auth.guard';
import { vi } from 'vitest';
import { signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';

describe('authGuard', () => {
  const urlTree = {} as UrlTree;
  const router = { createUrlTree: vi.fn() };
  const auth = { isLoggedIn: vi.fn(), authReady: signal(true).asReadonly() };
  const guest = { isGuest: vi.fn() };

  beforeEach(() => {
    router.createUrlTree.mockReturnValue(urlTree);
    auth.isLoggedIn.mockReset();
    guest.isGuest.mockReset();
    TestBed.configureTestingModule({
      providers: [
        { provide: Router, useValue: router },
        { provide: AuthService, useValue: auth },
        { provide: GuestService, useValue: guest },
      ],
    });
  });

  it('allows logged in users and guests', async () => {
    auth.isLoggedIn.mockReturnValue(true);
    guest.isGuest.mockReturnValue(false);

    await expect(
      TestBed.runInInjectionContext(() => firstValueFrom(authGuard({} as never, {} as never) as never)),
    ).resolves.toBe(true);

    auth.isLoggedIn.mockReturnValue(false);
    guest.isGuest.mockReturnValue(true);
    await expect(
      TestBed.runInInjectionContext(() => firstValueFrom(authGuard({} as never, {} as never) as never)),
    ).resolves.toBe(true);
  });

  it('redirects anonymous non-guest users to auth', async () => {
    auth.isLoggedIn.mockReturnValue(false);
    guest.isGuest.mockReturnValue(false);

    await expect(
      TestBed.runInInjectionContext(() => firstValueFrom(authGuard({} as never, {} as never) as never)),
    ).resolves.toBe(urlTree);
    expect(router.createUrlTree).toHaveBeenCalledWith(['/auth']);
  });
});
