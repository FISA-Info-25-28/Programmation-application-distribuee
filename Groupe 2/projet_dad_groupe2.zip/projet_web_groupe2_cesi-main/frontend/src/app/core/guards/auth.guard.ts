import { inject } from '@angular/core';
import { toObservable } from '@angular/core/rxjs-interop';
import type { CanActivateFn } from '@angular/router';
import { Router } from '@angular/router';
import { filter, map, take } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { GuestService } from '../services/guest.service';

// Attend la fin de la verification /auth/me initiale avant de decider : sinon,
// au refresh de page, le guard tranche avant que la session (cookie) soit resolue
// et renvoie a tort vers /auth.
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const guest = inject(GuestService);
  const router = inject(Router);
  return toObservable(auth.authReady).pipe(
    filter((ready) => ready),
    take(1),
    map(() => (auth.isLoggedIn() || guest.isGuest() ? true : router.createUrlTree(['/auth']))),
  );
};
