import { inject } from '@angular/core';
import type { CanActivateFn } from '@angular/router';
import { GuestService } from '../services/guest.service';

export const guestProtectedGuard: CanActivateFn = () => {
  const guest = inject(GuestService);
  if (guest.isGuest()) {
    guest.showModal();
    return false;
  }
  return true;
};
