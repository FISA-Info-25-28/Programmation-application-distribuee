import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import type { UrlTree } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { guestGuard } from './guest.guard';
import { vi } from 'vitest';
import { signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';

describe('guestGuard', () => {
  const urlTree = {} as UrlTree;
  const router = { createUrlTree: vi.fn() };
  const auth = { isLoggedIn: vi.fn(), authReady: signal(true).asReadonly() };

  beforeEach(() => {
    router.createUrlTree.mockReturnValue(urlTree);
    auth.isLoggedIn.mockReset();
    TestBed.configureTestingModule({
      providers: [
        { provide: Router, useValue: router },
        { provide: AuthService, useValue: auth },
      ],
    });
  });

  it('allows anonymous users', async () => {
    auth.isLoggedIn.mockReturnValue(false);

    await expect(
      TestBed.runInInjectionContext(() => firstValueFrom(guestGuard({} as never, {} as never) as never)),
    ).resolves.toBe(true);
  });

  it('redirects authenticated users to home', async () => {
    auth.isLoggedIn.mockReturnValue(true);

    await expect(
      TestBed.runInInjectionContext(() => firstValueFrom(guestGuard({} as never, {} as never) as never)),
    ).resolves.toBe(urlTree);
    expect(router.createUrlTree).toHaveBeenCalledWith(['/home']);
  });
});
