import {
  HttpBackend,
  HttpClient,
  HttpErrorResponse,
  HttpInterceptorFn,
} from '@angular/common/http';
import { inject } from '@angular/core';
import { Observable, catchError, finalize, shareReplay, switchMap, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { TokenService } from '../services/token.service';

let refreshRequest$: Observable<unknown> | null = null;

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const backend = inject(HttpBackend);
  const token = inject(TokenService);
  const request = req.clone({ withCredentials: true });

  return next(request).pipe(
    catchError((err: HttpErrorResponse) => {
      if (err.status !== 401 || shouldSkipRefresh(req.url)) {
        return throwError(() => err);
      }

      refreshRequest$ ??= new HttpClient(backend)
        .post(`${environment.apiBaseUrl}/auth/refresh`, {}, { withCredentials: true })
        .pipe(
          shareReplay({ bufferSize: 1, refCount: false }),
          finalize(() => {
            refreshRequest$ = null;
          }),
        );

      return refreshRequest$.pipe(
        switchMap(() => next(request)),
        catchError((refreshErr) => {
          token.clear();
          return throwError(() => refreshErr);
        }),
      );
    }),
  );
};

function shouldSkipRefresh(url: string): boolean {
  return (
    url.includes('/auth/login') ||
    url.includes('/auth/register') ||
    url.includes('/auth/refresh') ||
    url.includes('/auth/logout')
  );
}
