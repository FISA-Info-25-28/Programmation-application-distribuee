import type { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { FlashService } from '../../shared/flash/flash.service';
import { TokenService } from '../services/token.service';
import { GuestService } from '../services/guest.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);
  const flash = inject(FlashService);
  const token = inject(TokenService);
  const guest = inject(GuestService);

  return next(req).pipe(
    catchError((err: HttpErrorResponse) => {
      if (err.status === 401 && !guest.isGuest()) {
        token.clear();
        void router.navigateByUrl('/auth');
      } else if (err.status >= 500 && !isSilentRequest(req.url)) {
        flash.show('Erreur serveur, reessaie dans un moment.', 'error');
      } else if (err.status === 403 && !isSilentRequest(req.url)) {
        flash.show('Acces refuse.', 'error');
      }
      return throwError(() => err);
    }),
  );
};

function isSilentRequest(url: string): boolean {
  return (
    url.includes('/notifications') ||
    url.endsWith('/messages/settings') ||
    url.endsWith('/conversations') ||
    url.includes('/users/suggestions') ||
    url.includes('/tags/trending') ||
    url.includes('/auth/')
  );
}
