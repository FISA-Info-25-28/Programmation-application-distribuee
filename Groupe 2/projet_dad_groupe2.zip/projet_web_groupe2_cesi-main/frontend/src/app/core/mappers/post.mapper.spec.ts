import { ApiPost } from '../models/api-post.model';
import { Post } from '../models/post.model';
import { User } from '../models/user.model';
import { extractApiPosts, extractTags, mapApiPost, mapApiPosts, resolveAuthorSummary } from './post.mapper';

const currentUser: User = {
  id: 'account-1',
  profileId: 'profile-1',
  username: 'ada',
  displayName: 'Ada Lovelace',
  email: 'ada@example.test',
  role: 'USER',
  bio: null,
  avatarUrl: '/ada.png',
  followersCount: 0,
  followingCount: 0,
  postsCount: 0,
  createdAt: '2026-01-01T00:00:00Z',
};

describe('post mapper', () => {
  it('extracts posts from array and wrapped responses', () => {
    const posts = [{ id: '1' } as ApiPost];

    expect(extractApiPosts(posts)).toBe(posts);
    expect(extractApiPosts({ posts })).toBe(posts);
    expect(extractApiPosts({ posts: null })).toEqual([]);
  });

  it('maps api counters, tags and current-user author fallback', () => {
    const post = mapApiPost(
      {
        id: 'post-1',
        authorId: 'profile-1',
        content: 'Hello #Angular',
        parentId: null,
        visibility: 'PUBLIC',
        createdAt: '2026-01-01T00:00:00Z',
        updatedAt: '2026-01-01T00:00:00Z',
        likesCount: 2,
        commentsCount: 3,
      },
      currentUser,
    );

    expect(post).toEqual(
      expect.objectContaining({
        id: 'post-1',
        likeCount: 2,
        replyCount: 3,
        tags: ['Angular'],
        author: expect.objectContaining({ username: 'ada' }),
      }),
    );
  });

  it('normalizes already mapped posts without losing optional defaults', () => {
    const existing: Post = {
      id: 'post-1',
      author: { id: 'u1', username: 'bob', displayName: 'Bob', avatarUrl: null },
      content: 'No tag',
      lang: '',
      visibility: 'PUBLIC',
      tags: [],
      likeCount: 1,
      replyCount: 2,
      repostCount: 3,
      isLiked: true,
      isReposted: false,
      isBookmarked: true,
      parentId: null,
      createdAt: '2026-01-01T00:00:00Z',
      media: [],
    };

    expect(mapApiPost(existing)).toEqual({
      ...existing,
      repostedBy: null,
      poll: null,
    });
  });

  it('maps collections and resolves anonymous author summaries', () => {
    const apiPost = {
      id: 'post-1',
      authorId: 'unknown-author',
      content: 'Hi',
      parentId: null,
      visibility: 'PUBLIC',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    } satisfies ApiPost;

    expect(mapApiPosts([apiPost])[0].author.displayName).toBe('Utilisateur unknown-');
    expect(resolveAuthorSummary('', null).username).toBe('user_inconnu');
    expect(extractTags('#one text #two')).toEqual(['one', 'two']);
  });
});
