import { ApiPost, ApiPostCollectionResponse } from '../models/api-post.model';
import { Post } from '../models/post.model';
import { User } from '../models/user.model';

type AuthorSummary = Post['author'];

type PostLike = ApiPost | Post;

function isPost(value: PostLike): value is Post {
	return 'likeCount' in value || 'replyCount' in value;
}

export function extractApiPosts(response: ApiPostCollectionResponse): PostLike[] {
	if (Array.isArray(response)) return response;
	if (Array.isArray(response?.posts)) return response.posts;
	return [];
}

export function mapApiPosts(
	response: ApiPostCollectionResponse,
	currentUser: User | null = null,
): Post[] {
	return extractApiPosts(response).map((post) => mapApiPost(post, currentUser));
}

export function mapApiPost(api: PostLike, currentUser: User | null = null): Post {
	if (isPost(api)) {
		return {
			id: api.id,
			author: api.author,
			content: api.content,
			lang: api.lang ?? '',
			visibility: api.visibility ?? 'PUBLIC',
			tags: Array.isArray(api.tags) ? api.tags : extractTags(api.content),
			likeCount: api.likeCount ?? 0,
			replyCount: api.replyCount ?? 0,
			repostCount: api.repostCount ?? 0,
			isLiked: api.isLiked ?? false,
			isReposted: api.isReposted ?? false,
			isBookmarked: api.isBookmarked ?? false,
			parentId: api.parentId ?? null,
			createdAt: api.createdAt,
			media: api.media ?? [],
			repostedBy: api.repostedBy ?? null,
			poll: api.poll ?? null,
		};
	}

	const author = api.author ?? resolveAuthorSummary(api.authorId, currentUser);

	return {
		id: api.id,
		author,
    content: api.content,
    lang: (api as any).lang ?? '',
    visibility: api.visibility ?? 'PUBLIC',
    tags: extractTags(api.content),
    likeCount: api.likesCount ?? 0,
    replyCount: api.commentsCount ?? 0,
    repostCount: api.repostCount ?? 0,
    isLiked: api.isLiked ?? false,
    isReposted: api.isReposted ?? false,
    isBookmarked: api.isBookmarked ?? false,
    parentId: api.parentId ?? null,
    createdAt: api.createdAt,
    media: api.media ?? [],
    repostedBy: api.repostedBy ?? null,
    poll: (api as any).poll ?? null,
  };
}

export function resolveAuthorSummary(
  authorId: string,
  currentUser: User | null = null,
): AuthorSummary {
  if (currentUser && (currentUser.profileId === authorId || currentUser.id === authorId)) {
    return {
      id: authorId,
      username: currentUser.username,
      displayName: currentUser.displayName,
      avatarUrl: currentUser.avatarUrl,
    };
  }

  const shortId = authorId.slice(0, 8) || 'inconnu';
  return {
    id: authorId,
    username: `user_${shortId}`,
    displayName: `Utilisateur ${shortId}`,
    avatarUrl: null,
  };
}

export function extractTags(content: string): string[] {
  return (content.match(/#(\w+)/g) ?? []).map((tag) => tag.slice(1));
}
