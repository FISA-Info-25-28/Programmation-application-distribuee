import { mapApiProfile } from './profile.mapper';

describe('mapApiProfile', () => {
  it('maps api profile fields and completes missing user data from fallback', () => {
    const user = mapApiProfile(
      {
        id: 'profile-1',
        accountId: 'account-1',
        username: 'ada',
        displayName: 'Ada',
        bio: 'Maths',
        avatarUrl: '/ada.png',
        createdAt: '2026-01-01T00:00:00Z',
      },
      {
        email: 'ada@example.test',
        role: 'ADMIN',
        followersCount: 3,
        followingCount: 4,
        postsCount: 5,
      },
    );

    expect(user).toEqual(
      expect.objectContaining({
        id: 'account-1',
        profileId: 'profile-1',
        username: 'ada',
        email: 'ada@example.test',
        role: 'ADMIN',
        followersCount: 3,
        followingCount: 4,
        postsCount: 5,
      }),
    );
  });

  it('uses safe defaults when no fallback is available', () => {
    const user = mapApiProfile({
      id: 'profile-1',
      accountId: 'account-1',
      username: 'ada',
      displayName: 'Ada',
      bio: null,
      avatarUrl: null,
      createdAt: '2026-01-01T00:00:00Z',
    });

    expect(user.email).toBe('');
    expect(user.role).toBe('USER');
    expect(user.followersCount).toBe(0);
  });
});
