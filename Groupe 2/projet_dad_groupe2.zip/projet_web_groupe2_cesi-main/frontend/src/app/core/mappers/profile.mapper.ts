import { ApiProfile } from '../models/api-profile.model';
import { User } from '../models/user.model';

// Le profile-service ne connaît ni l'email/le rôle (auth-service) ni les
// compteurs d'abonnés/abonnements/posts (user-service et post-service,
// pas encore implémentés) : on les complète depuis `fallback` si dispo.
export function mapApiProfile(api: ApiProfile, fallback?: Partial<User> | null): User {
  return {
    id: api.accountId,
    profileId: api.id,
    username: api.username,
    displayName: api.displayName,
    email: fallback?.email ?? '',
    role: fallback?.role ?? 'USER',
    bio: api.bio,
    avatarUrl: api.avatarUrl,
    followersCount: fallback?.followersCount ?? 0,
    followingCount: fallback?.followingCount ?? 0,
    postsCount: fallback?.postsCount ?? 0,
    createdAt: api.createdAt,
  };
}
