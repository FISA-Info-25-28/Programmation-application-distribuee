export interface ApiPost {
  id: string;
  authorId: string;
  author?: {
    id: string;
    username: string;
    displayName: string;
    avatarUrl: string | null;
  };
  content: string;
  parentId: string | null;
  visibility: string;
  createdAt: string;
  updatedAt: string;
  likesCount?: number;
  commentsCount?: number;
  repostCount?: number;
  isLiked?: boolean;
  isReposted?: boolean;
  isBookmarked?: boolean;
  hasMedia?: boolean;
  media?: Array<{ id: string; type: 'IMAGE' | 'VIDEO'; url: string }>;
  repostedBy?: { id: string; username: string; displayName: string; avatarUrl: string | null } | null;
}

export type ApiPostCollectionResponse =
  | ApiPost[]
  | {
      posts?: ApiPost[] | unknown;
    };
