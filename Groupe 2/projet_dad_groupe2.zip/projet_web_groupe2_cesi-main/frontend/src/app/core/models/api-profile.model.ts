// Forme renvoyée par le profile-service (GET/PATCH /api/profiles/me, GET /api/profiles/:username).
export interface ApiProfile {
  id: string;
  accountId: string;
  username: string;
  displayName: string;
  bio: string | null;
  avatarUrl: string | null;
  createdAt: string;
}
