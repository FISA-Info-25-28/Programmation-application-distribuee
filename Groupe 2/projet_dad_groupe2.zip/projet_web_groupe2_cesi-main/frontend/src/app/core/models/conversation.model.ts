import { User } from './user.model';

export interface Conversation {
  id: string;
  currentProfileId?: string;
  participant: Pick<User, 'id' | 'username' | 'displayName' | 'avatarUrl'> & { publicKey?: string | null };
  lastMessage: string;
  /** Nonce du dernier message chiffré (NaCl box). Vide = texte en clair (legacy ou aperçu non textuel). */
  lastMessageNonce?: string;
  lastMessageSenderId?: string | null;
  lastMessageAt: string;
  unreadCount: number;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  content: string;
  /** Nonce NaCl box du contenu chiffré. Vide = message envoyé avant le chiffrement (affiché en clair tel quel). */
  nonce?: string;
  kind?: 'TEXT' | 'SHARED_POST';
  mediaUrl?: string | null;
  mediaType?: 'IMAGE' | 'VIDEO' | null;
  replyToId?: string | null;
  replyTo?: MessageReply | null;
  likeCount: number;
  likedByMe: boolean;
  reactions: MessageReaction[];
  isFirstUnread: boolean;
  status: 'SENDING' | 'DELIVERED' | 'READ';
  createdAt: string;
  editedAt?: string | null;
  deletedAt?: string | null;
}

export type MessageReactionType = 'HEART' | 'THUMBS_UP' | 'THUMBS_DOWN';

export interface MessageReaction {
  type: MessageReactionType;
  count: number;
  reactedByMe: boolean;
}

export interface MessageReply {
  id: string;
  senderId: string;
  content: string;
  nonce?: string;
  mediaType?: 'IMAGE' | 'VIDEO' | null;
  deletedAt?: string | null;
}
