export type MediaType = 'IMAGE' | 'VIDEO';

export interface MediaAttachment {
  id?: string;
  type: MediaType;
  url: string;
}

export interface MediaUploadResponse {
  url: string;
  filename: string;
  mediaType: MediaType;
  mimeType: string;
}
