export type NotificationType =
  | 'LIKE'
  | 'FOLLOW'
  | 'FOLLOW_REQUEST'
  | 'REPLY'
  | 'MENTION'
  | 'MODERATION_REPORT'
  | 'TEST';

export interface Notification {
  id: string;
  type: NotificationType;
  actorProfileId: string;
  actorDisplayName: string;
  actorUsername: string;
  postId: string | null;
  postExcerpt: string | null;
  requestPending: boolean;
  isRead: boolean;
  createdAt: string;
}
