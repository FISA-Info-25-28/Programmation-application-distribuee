import { User } from './user.model';
import { MediaAttachment } from './media.model';

export interface PollOption {
  id: string;
  text: string;
  voteCount: number;
  position: number;
}

export interface Poll {
  id: string;
  options: PollOption[];
  totalVotes: number;
  endsAt: string | null;
  closedAt: string | null;
  isClosed: boolean;
  hasVoted: boolean;
  votedOptionId: string | null;
}

export interface Post {
  id: string;
  author: Pick<User, 'id' | 'username' | 'displayName' | 'avatarUrl'>;
  content: string;
  lang: string;
  visibility: string;
  tags: string[];
  likeCount: number;
  replyCount: number;
  repostCount: number;
  isLiked: boolean;
  isReposted: boolean;
  isBookmarked: boolean;
  parentId: string | null;
  createdAt: string;
  media: MediaAttachment[];
  repostedBy?: { id: string; username: string; displayName: string; avatarUrl: string | null } | null;
  poll?: Poll | null;
  isPinned?: boolean;
}
