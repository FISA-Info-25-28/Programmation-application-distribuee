export type ReportTargetType = 'POST' | 'USER';
export type ReportStatus = 'PENDING' | 'REVIEWED' | 'RESOLVED' | 'REJECTED';

export interface Report {
  id: string;
  reporterId: string;
  reporterDisplayName?: string;
  targetType: ReportTargetType;
  targetId: string;
  targetExcerpt?: string;
  reason: string;
  status: ReportStatus;
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt: string;
}

export interface ApiReport {
  id: string;
  reporterId: string;
  reporterUsername?: string;
  reporterDisplayName?: string;
  reportedPostId?: string;
  reportedPostContent?: string;
  reportedUserId?: string;
  reason: string;
  status: ReportStatus;
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt: string;
}
