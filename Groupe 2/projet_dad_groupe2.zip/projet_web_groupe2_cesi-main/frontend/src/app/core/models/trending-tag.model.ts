export interface TrendingTag {
  name: string;
  postCount: number;
  likeCount: number;
  repostCount: number;
}
