export type UserRole = 'USER' | 'MODERATOR' | 'ADMIN';

export interface User {
  id: string;
  profileId?: string | null;
  username: string;
  displayName: string;
  email: string;
  role: UserRole;
  bio: string | null;
  avatarUrl: string | null;
  bannerUrl?: string | null;
  isPrivate?: boolean;
  followersCount: number;
  followingCount: number;
  isFollowing?: boolean;
  requestPending?: boolean;
  postsCount: number;
  createdAt: string;
  lastLoginAt?: string | null;
}
