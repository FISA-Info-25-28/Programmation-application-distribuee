import { PLATFORM_ID } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { LangService } from '../services/lang.service';
import { TPipe } from './t.pipe';

describe('TPipe', () => {
  let lang: LangService;
  let pipe: TPipe;

  beforeEach(() => {
    localStorage.removeItem('breezy.lang');
    TestBed.configureTestingModule({
      providers: [{ provide: PLATFORM_ID, useValue: 'browser' }],
    });
    lang = TestBed.inject(LangService);
    pipe = TestBed.runInInjectionContext(() => new TPipe());
  });

  afterEach(() => {
    localStorage.removeItem('breezy.lang');
  });

  it('resolves dotted translation keys from the current language', () => {
    expect(pipe.transform('nav.home')).toBe('Accueil');

    lang.setLang('en');
    expect(pipe.transform('nav.home')).toBe('Home');
  });

  it('returns the key when the path does not resolve to a string', () => {
    expect(pipe.transform('nav.unknown')).toBe('nav.unknown');
    expect(pipe.transform('nav')).toBe('nav');
  });
});
