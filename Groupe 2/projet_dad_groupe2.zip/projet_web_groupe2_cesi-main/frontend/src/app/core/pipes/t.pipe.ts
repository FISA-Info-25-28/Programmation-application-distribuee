import { inject, Pipe, PipeTransform } from '@angular/core';

import { LangService } from '../services/lang.service';
import type { Translations } from '../i18n/types';

/**
 * Pipe de traduction par chemin pointé.
 * Usage : {{ 'post.translate' | t }}
 * pure: false → se réévalue quand le signal lang change.
 */
@Pipe({ name: 't', pure: false, standalone: true })
export class TPipe implements PipeTransform {
  private readonly langService = inject(LangService);

  transform(key: string): string {
    const parts = key.split('.');
    let current: unknown = this.langService.tr();
    for (const part of parts) {
      if (current == null || typeof current !== 'object') return key;
      current = (current as Record<string, unknown>)[part];
    }
    return typeof current === 'string' ? current : key;
  }
}

/** Raccourci pour injecter les traductions dans les composants .ts */
export type TR = Translations;
