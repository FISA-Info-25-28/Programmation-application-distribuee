import { computed, inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, forkJoin, map, of, tap } from 'rxjs';
import { User } from '../models/user.model';
import { TokenService } from './token.service';
import { environment } from '../../../environments/environment';

interface ApiAccount {
  id: string;
  profileId?: string | null;
  username?: string;
  displayName?: string;
  email: string;
  role: User['role'];
  status: string;
  lastLoginAt?: string | null;
}

interface ApiProfile {
  id: string;
  accountId: string;
  username: string;
  displayName: string;
  bio: string | null;
  avatarUrl: string | null;
  bannerUrl: string | null;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  isPrivate: boolean;
  createdAt: string;
}

interface AuthResponse {
  accessToken?: string;
  refreshToken?: string;
  tokenType?: string;
  expiresIn: number;
  user: ApiAccount;
}

interface RegisterResponse {
  message: string;
  requiresEmailVerification: boolean;
  verificationEmailSent: boolean;
  user: ApiAccount;
}

interface MessageResponse {
  message: string;
}

interface UserProfileInput {
  username?: string;
  displayName?: string;
}

export type AccountStatus = 'ACTIVE' | 'SUSPENDED' | 'BANNED';

interface UsernameAvailabilityResponse {
  available: boolean;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly token = inject(TokenService);

  private readonly _currentUser = signal<User | null>(this.resolveInitialUser());
  private readonly _authReady = signal(false);

  readonly currentUser = this._currentUser.asReadonly();
  readonly isLoggedIn = computed(() => this._currentUser() !== null);
  // Devient true une fois la verification /auth/me initiale resolue (succes ou echec).
  // Les guards de route doivent attendre ce signal avant de decider d'une redirection,
  // sinon ils tranchent avant la fin de l'appel asynchrone et renvoient vers /auth a tort.
  readonly authReady = this._authReady.asReadonly();
  readonly unreadNotifCount = signal(0);
  readonly unreadMessageCount = signal(0);

  // Resynchronise toujours via /auth/me au demarrage : la session vit dans des
  // cookies httpOnly, le localStorage n'est qu'un cache qui peut etre absent.
  constructor() {
    this.syncCurrentUser();
  }

  // Connecte l'utilisateur et persiste la session renvoyee par l'API.
  login(email: string, password: string): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(`${environment.apiBaseUrl}/auth/login`, { email, password })
      .pipe(tap((response) => this.saveAuthResponse(response)));
  }

  // Cree un compte avec ses informations de profil initiales.
  register(
    email: string,
    password: string,
    profile?: UserProfileInput,
  ): Observable<RegisterResponse> {
    return this.http.post<RegisterResponse>(`${environment.apiBaseUrl}/auth/register`, {
      email,
      password,
      username: profile?.username,
      displayName: profile?.displayName,
    });
  }

  // Confirme l'adresse e-mail a partir du token de verification.
  verifyEmail(token: string): Observable<MessageResponse> {
    return this.http.get<MessageResponse>(`${environment.apiBaseUrl}/auth/verify-email`, {
      params: { token },
    });
  }

  // Demande l'envoi d'un e-mail de reinitialisation de mot de passe.
  forgotPassword(email: string): Observable<MessageResponse> {
    return this.http.post<MessageResponse>(`${environment.apiBaseUrl}/auth/forgot-password`, { email });
  }

  // Remplace le mot de passe via un token de reinitialisation valide.
  resetPassword(token: string, newPassword: string): Observable<MessageResponse> {
    return this.http.post<MessageResponse>(`${environment.apiBaseUrl}/auth/reset-password`, { token, newPassword });
  }

  // Met a jour le statut d'un compte depuis les outils d'administration.
  updateAccountStatus(accountId: string, status: AccountStatus): Observable<ApiAccount> {
    return this.http.patch<ApiAccount>(
      `${environment.apiBaseUrl}/auth/accounts/${accountId}/status`,
      { status },
    );
  }

  // Verifie la disponibilite d'un nom d'utilisateur.
  checkUsername(username: string): Observable<UsernameAvailabilityResponse> {
    return this.http.get<UsernameAvailabilityResponse>(
      `${environment.apiBaseUrl}/auth/check-username`,
      {
        params: { username },
      },
    );
  }

  // Verifie la disponibilite d'une adresse e-mail.
  checkEmail(email: string): Observable<UsernameAvailabilityResponse> {
    return this.http.get<UsernameAvailabilityResponse>(
      `${environment.apiBaseUrl}/auth/check-email`,
      {
        params: { email },
      },
    );
  }

  // Recharge le nombre de messages non lus et conserve la derniere valeur en cas d'erreur.
  refreshUnreadMessages(): Observable<number> {
    return this.http
      .get<{ count: number }>(`${environment.apiBaseUrl}/conversations/unread-count`)
      .pipe(
        map((res) => res.count),
        tap((count) => this.unreadMessageCount.set(count)),
        catchError(() => of(this.unreadMessageCount())),
      );
  }

  // Recharge le nombre de notifications non lues et conserve la derniere valeur en cas d'erreur.
  refreshUnreadNotifications(): Observable<number> {
    return this.http
      .get<{ count: number }>(`${environment.apiBaseUrl}/notifications/unread-count`)
      .pipe(
        map((res) => res.count),
        tap((count) => this.unreadNotifCount.set(count)),
        catchError(() => of(this.unreadNotifCount())),
      );
  }

  // Remplace l'utilisateur courant et sauvegarde la session locale.
  setUser(user: User): void {
    this._currentUser.set(user);
    this.token.save({
      email: user.email,
      loggedAt: new Date().toISOString(),
      user,
    });
  }

  // Répercute un utilisateur à jour dans la session : signal courant + token persistant.
  // Utilisé par ProfileService après une mise à jour de profil (PATCH /profiles/me),
  // pour que le reste de l'app voie immédiatement les nouveaux displayName/bio/avatar.
  persistUser(user: User): void {
    this._currentUser.set(user);
    const session = this.token.getSession();
    if (session) {
      this.token.save({ ...session, user });
    }
  }

  // Deconnecte l'utilisateur cote API puis nettoie l'etat local.
  logout(): void {
    this.http
      .post(`${environment.apiBaseUrl}/auth/logout`, {})
      .subscribe({ error: () => undefined });
    this._currentUser.set(null);
    this.token.clear();
  }

  // Appele apres le callback Google OAuth : lit /auth/me (cookie deja pose par le backend)
  // et hydrate localStorage + signal courant.
  syncFromGoogle(): Observable<ApiAccount> {
    return this.http.get<ApiAccount>(`${environment.apiBaseUrl}/auth/me`).pipe(
      tap((account) => {
        const user = this.accountToUser(account);
        this.token.save({
          email: account.email,
          loggedAt: new Date().toISOString(),
          user,
        });
        this._currentUser.set(user);
      }),
    );
  }

  // Recharge le compte et le profil courants depuis l'API.
  private syncCurrentUser(): void {
    forkJoin({
      account: this.http.get<ApiAccount>(`${environment.apiBaseUrl}/auth/me`),
      profile: this.http
        .get<ApiProfile>(`${environment.apiBaseUrl}/profiles/me`)
        .pipe(catchError(() => of(null))),
    }).subscribe({
      next: ({ account, profile }) => {
        const current = this._currentUser();
        const baseUser = this.accountToUser(
          account,
          {
            username: profile?.username ?? current?.username,
            displayName: profile?.displayName ?? current?.displayName,
          },
          current,
        );
        const user: User = profile
          ? {
              ...baseUser,
              profileId: profile.id,
              username: profile.username,
              displayName: profile.displayName,
              bio: profile.bio,
              avatarUrl: profile.avatarUrl,
              bannerUrl: profile.bannerUrl,
              followersCount: profile.followersCount,
              followingCount: profile.followingCount,
              postsCount: profile.postsCount,
              isPrivate: profile.isPrivate,
              createdAt: profile.createdAt,
            }
          : baseUser;
        this.token.save({
          email: account.email,
          loggedAt: new Date().toISOString(),
          user,
        });
        this._currentUser.set(user);
        this._authReady.set(true);
      },
      error: () => {
        this._currentUser.set(null);
        this.token.clear();
        this._authReady.set(true);
      },
    });
  }

  // Reconstruit l'utilisateur initial a partir de la session locale.
  private resolveInitialUser(): User | null {
    const session = this.token.getSession();
    if (!session) return null;
    if (session.user) return session.user;
    return this.accountToUser({
      id: session.email,
      email: session.email,
      role: 'USER',
      status: 'ACTIVE',
    });
  }

  // Sauvegarde une reponse d'authentification et declenche une resynchronisation.
  private saveAuthResponse(response: AuthResponse, profile?: UserProfileInput): void {
    const user = this.accountToUser(response.user, profile);
    this.token.save({
      email: response.user.email,
      loggedAt: new Date().toISOString(),
      user,
    });
    this._currentUser.set(user);
    this.syncCurrentUser();
  }

  // Convertit le compte API en modele utilisateur utilise par le front.
  private accountToUser(
    account: ApiAccount,
    profile?: UserProfileInput,
    current?: User | null,
  ): User {
    const emailUsername = account.email.split('@')[0] || 'user';
    const username = account.username?.trim() || profile?.username?.trim() || emailUsername;
    const displayName = account.displayName?.trim() || profile?.displayName?.trim() || username;
    return {
      id: account.id,
      profileId: account.profileId ?? current?.profileId ?? null,
      username,
      displayName,
      email: account.email,
      role: account.role,
      bio: current?.bio ?? null,
      avatarUrl: current?.avatarUrl ?? null,
      bannerUrl: current?.bannerUrl ?? null,
      followersCount: current?.followersCount ?? 0,
      followingCount: current?.followingCount ?? 0,
      postsCount: current?.postsCount ?? 0,
      createdAt: current?.createdAt ?? new Date().toISOString(),
      lastLoginAt: account.lastLoginAt ?? current?.lastLoginAt ?? null,
    };
  }
}
