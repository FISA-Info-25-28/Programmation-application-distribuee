import { TestBed } from '@angular/core/testing';
import { CensorService } from './censor.service';

describe('CensorService', () => {
  let service: CensorService;

  beforeEach(() => {
    localStorage.removeItem('breezy.censor.words');
    TestBed.configureTestingModule({});
    service = TestBed.inject(CensorService);
  });

  afterEach(() => {
    localStorage.removeItem('breezy.censor.words');
  });

  it('normalizes, deduplicates and persists custom words', () => {
    service.setCustomWords(['  Test  ', 'test', 'cafe', 'cafe!']);

    expect(service.customWords()).toEqual(['test', 'cafe']);
    expect(JSON.parse(localStorage.getItem('breezy.censor.words') ?? '[]')).toEqual(['test', 'cafe']);
  });

  it('marks default words, custom words, tags and mentions as censored parts', () => {
    service.setCustomWords(['spoiler']);

    const parts = service.parse('ok #spoiler @merde clean');

    expect(parts.find((part) => part.text === '#spoiler')).toEqual(
      expect.objectContaining({ isTag: true, censored: true }),
    );
    expect(parts.find((part) => part.text === '@merde')).toEqual(
      expect.objectContaining({ isMention: true, censored: true }),
    );
    expect(parts.find((part) => part.text === 'clean')?.censored).toBe(false);
  });
});
