import { Injectable, signal } from '@angular/core';

export interface CensoredPart {
  text: string;
  isTag: boolean;
  isMention: boolean;
  censored: boolean;
}

@Injectable({ providedIn: 'root' })
export class CensorService {
  private readonly storageKey = 'breezy.censor.words';
  private readonly defaultWords = ['pute', 'merde', 'connard', 'connasse', 'salope', 'encule', 'batard'];

  readonly customWords = signal<string[]>(this.loadWords());

  // Enregistre la liste normalisee des mots personnalises a censurer.
  setCustomWords(words: string[]): void {
    const cleaned = this.normalizeWords(words);
    this.customWords.set(cleaned);
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(this.storageKey, JSON.stringify(cleaned));
    }
  }

  // Decoupe un contenu en morceaux et indique ceux qui doivent etre censures.
  parse(content: string): CensoredPart[] {
    const blocked = new Set([...this.defaultWords, ...this.customWords()].map((word) => this.normalize(word)));
    return content.split(/(\s+)/).map((text) => {
      const normalized = this.normalize(text.replace(/^#|^@/, ''));
      return {
        text,
        isTag: text.startsWith('#'),
        isMention: text.startsWith('@'),
        censored: normalized.length > 0 && blocked.has(normalized),
      };
    });
  }

  // Recharge les mots personnalises depuis le stockage local.
  private loadWords(): string[] {
    if (typeof localStorage === 'undefined') return [];

    try {
      const raw = localStorage.getItem(this.storageKey);
      return raw ? this.normalizeWords(JSON.parse(raw) as string[]) : [];
    } catch {
      localStorage.removeItem(this.storageKey);
      return [];
    }
  }

  // Nettoie, deduplique et normalise une liste de mots.
  private normalizeWords(words: string[]): string[] {
    return [...new Set(words.map((word) => this.normalize(word)).filter(Boolean))];
  }

  // Normalise une valeur pour permettre une comparaison de censure fiable.
  private normalize(value: string): string {
    return value
      .toLowerCase()
      .normalize('NFD')
      .replace(/\p{Diacritic}/gu, '')
      .replace(/[^\p{L}\p{N}_-]/gu, '')
      .trim();
  }
}
