import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import nacl from 'tweetnacl';
import { encodeBase64, decodeBase64, decodeUTF8, encodeUTF8 } from 'tweetnacl-util';

import { AuthService } from './auth.service';
import { environment } from '../../../environments/environment';

interface StoredKeyPair {
  accountId: string;
  publicKey: string;
  secretKey: string;
}

const DB_NAME = 'breezy-crypto';
const STORE_NAME = 'keypairs';
const DB_VERSION = 1;

/**
 * Chiffrement de bout en bout des messages privés (NaCl box,
 * Curve25519-XSalsa20-Poly1305). La clé privée ne quitte jamais le
 * navigateur : elle est générée et stockée en IndexedDB, jamais transmise
 * au serveur. Seule la clé publique est envoyée via PATCH /me.
 */
@Injectable({ providedIn: 'root' })
export class CryptoService {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);

  private keyPair: nacl.BoxKeyPair | null = null;
  private ensurePromise: Promise<void> | null = null;

  /**
   * Génère (si besoin) la paire de clés de l'utilisateur courant et envoie
   * la clé publique au serveur si elle n'y est pas déjà. Idempotent.
   */
  ensureKeyPair(): Promise<void> {
    if (!this.ensurePromise) {
      this.ensurePromise = this.ensureKeyPairInternal();
    }
    return this.ensurePromise;
  }

  /** Chiffre un texte en clair pour un destinataire donné. */
  encrypt(plaintext: string, recipientPublicKeyB64: string): { ciphertext: string; nonce: string } {
    if (!this.keyPair) throw new Error('crypto: key pair not initialized');
    const recipientPublicKey = decodeBase64(recipientPublicKeyB64);
    const nonce = nacl.randomBytes(nacl.box.nonceLength);
    const message = decodeUTF8(plaintext);
    const box = nacl.box(message, nonce, recipientPublicKey, this.keyPair.secretKey);
    return { ciphertext: encodeBase64(box), nonce: encodeBase64(nonce) };
  }

  /**
   * Déchiffre un message. Retourne `null` si l'ouverture échoue (clé
   * absente, corrompue, ou rotation de clé côté destinataire).
   */
  decrypt(ciphertextB64: string, nonceB64: string, otherPublicKeyB64: string): string | null {
    if (!this.keyPair || !ciphertextB64 || !nonceB64 || !otherPublicKeyB64) return null;
    try {
      const otherPublicKey = decodeBase64(otherPublicKeyB64);
      const nonce = decodeBase64(nonceB64);
      const ciphertext = decodeBase64(ciphertextB64);
      const opened = nacl.box.open(ciphertext, nonce, otherPublicKey, this.keyPair.secretKey);
      if (!opened) return null;
      return encodeUTF8(opened);
    } catch {
      return null;
    }
  }

  private async ensureKeyPairInternal(): Promise<void> {
    if (typeof indexedDB === 'undefined') return; // SSR : pas de cle cote serveur

    const accountId = this.auth.currentUser()?.id;
    if (!accountId) return;

    const stored = await this.loadKeyPair(accountId);
    if (stored) {
      this.keyPair = {
        publicKey: decodeBase64(stored.publicKey),
        secretKey: decodeBase64(stored.secretKey),
      };
      return;
    }

    const generated = nacl.box.keyPair();
    this.keyPair = generated;
    await this.saveKeyPair({
      accountId,
      publicKey: encodeBase64(generated.publicKey),
      secretKey: encodeBase64(generated.secretKey),
    });

    this.http
      .patch(`${environment.apiBaseUrl}/profiles/me`, { publicKey: encodeBase64(generated.publicKey) })
      .subscribe({ error: () => undefined });
  }

  private openDb(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'accountId' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  private async loadKeyPair(accountId: string): Promise<StoredKeyPair | null> {
    if (typeof indexedDB === 'undefined') return null;
    const db = await this.openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const request = tx.objectStore(STORE_NAME).get(accountId);
      request.onsuccess = () => resolve((request.result as StoredKeyPair) ?? null);
      request.onerror = () => reject(request.error);
    });
  }

  private async saveKeyPair(entry: StoredKeyPair): Promise<void> {
    if (typeof indexedDB === 'undefined') return;
    const db = await this.openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(entry);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}
