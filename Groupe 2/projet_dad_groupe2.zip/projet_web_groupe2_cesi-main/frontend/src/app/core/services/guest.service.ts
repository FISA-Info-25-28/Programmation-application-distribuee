import { inject, Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class GuestService {
  private readonly router = inject(Router);

  readonly isGuest = signal(false);
  readonly modalVisible = signal(false);

  activate(): void {
    this.isGuest.set(true);
    void this.router.navigate(['/home/feed']);
  }

  deactivate(): void {
    this.isGuest.set(false);
    this.modalVisible.set(false);
  }

  showModal(): void {
    this.modalVisible.set(true);
  }

  hideModal(): void {
    this.modalVisible.set(false);
  }

  requireAuth(): boolean {
    if (this.isGuest()) {
      this.showModal();
      return false;
    }
    return true;
  }
}
