import { PLATFORM_ID } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { LangService } from './lang.service';

describe('LangService', () => {
  afterEach(() => {
    localStorage.removeItem('breezy.lang');
    TestBed.resetTestingModule();
  });

  it('loads French by default and persists selected languages', () => {
    TestBed.configureTestingModule({
      providers: [{ provide: PLATFORM_ID, useValue: 'browser' }],
    });
    const service = TestBed.inject(LangService);

    expect(service.lang()).toBe('fr');

    service.setLang('en');

    expect(service.lang()).toBe('en');
    expect(service.tr().nav.home).toBe('Home');
    expect(localStorage.getItem('breezy.lang')).toBe('en');
  });

  it('falls back to French for unsupported stored values and on the server', () => {
    localStorage.setItem('breezy.lang', 'xx');
    TestBed.configureTestingModule({
      providers: [{ provide: PLATFORM_ID, useValue: 'browser' }],
    });

    expect(TestBed.inject(LangService).lang()).toBe('fr');

    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [{ provide: PLATFORM_ID, useValue: 'server' }],
    });

    expect(TestBed.inject(LangService).lang()).toBe('fr');
  });
});
