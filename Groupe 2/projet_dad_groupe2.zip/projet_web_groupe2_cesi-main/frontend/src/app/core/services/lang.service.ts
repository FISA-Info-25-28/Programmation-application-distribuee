import { computed, inject, Injectable, PLATFORM_ID, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

import { FR } from '../i18n/fr';
import { EN } from '../i18n/en';
import { ES } from '../i18n/es';
import { IT } from '../i18n/it';
import { DE } from '../i18n/de';
import { PT } from '../i18n/pt';
import type { Translations } from '../i18n/types';

export type Lang = 'fr' | 'en' | 'es' | 'it' | 'de' | 'pt';

const TRANSLATIONS: Record<Lang, Translations> = {
  fr: FR,
  en: EN,
  es: ES,
  it: IT,
  de: DE,
  pt: PT,
};

const LANGS: readonly Lang[] = ['fr', 'en', 'es', 'it', 'de', 'pt'];

@Injectable({ providedIn: 'root' })
export class LangService {
  private readonly platformId = inject(PLATFORM_ID);

  readonly lang = signal<Lang>(this.loadLang());

  /** Objet de traductions réactif — change quand lang() change */
  readonly tr = computed<Translations>(() => TRANSLATIONS[this.lang()]);

  // Change la langue courante et la persiste dans le navigateur.
  setLang(l: Lang): void {
    this.lang.set(l);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('breezy.lang', l);
    }
  }

  // Recharge la langue sauvegardee ou utilise le francais par defaut.
  private loadLang(): Lang {
    if (!isPlatformBrowser(this.platformId)) return 'fr';
    const stored = localStorage.getItem('breezy.lang');
    return LANGS.includes(stored as Lang) ? (stored as Lang) : 'fr';
  }
}
