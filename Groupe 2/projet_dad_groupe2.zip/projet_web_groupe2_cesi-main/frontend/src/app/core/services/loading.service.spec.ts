import { TestBed } from '@angular/core/testing';
import { LoadingService } from './loading.service';

describe('LoadingService', () => {
  let service: LoadingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoadingService);
  });

  it('is loading while at least one operation is active', () => {
    expect(service.isLoading()).toBe(false);

    service.increment();
    service.increment();
    expect(service.isLoading()).toBe(true);

    service.decrement();
    expect(service.isLoading()).toBe(true);

    service.decrement();
    service.decrement();
    expect(service.isLoading()).toBe(false);
  });
});
