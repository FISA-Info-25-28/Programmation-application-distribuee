import { Injectable, signal, computed } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class LoadingService {
  private readonly count = signal(0);
  readonly isLoading = computed(() => this.count() > 0);

  // Incremente le compteur de chargements actifs.
  increment(): void {
    this.count.update((n) => n + 1);
  }

  // Decremente le compteur de chargements sans passer sous zero.
  decrement(): void {
    this.count.update((n) => Math.max(0, n - 1));
  }
}
