import { provideHttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { MediaService } from './media.service';

describe('MediaService', () => {
  let service: MediaService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient()],
    });
    service = TestBed.inject(MediaService);
  });

  it('accepts supported image and video formats under the size limit', () => {
    expect(service.validate(new File(['x'], 'image.png', { type: 'image/png' }))).toBeNull();
    expect(service.validate(new File(['x'], 'video.mp4', { type: 'video/mp4' }))).toBeNull();
  });

  it('rejects unsupported formats and files above 100 MB', () => {
    const tooLarge = new File([new ArrayBuffer(100 * 1024 * 1024 + 1)], 'image.png', {
      type: 'image/png',
    });

    expect(service.validate(new File(['x'], 'file.txt', { type: 'text/plain' }))).toContain('Format');
    expect(service.validate(tooLarge)).toContain('100');
  });
});
