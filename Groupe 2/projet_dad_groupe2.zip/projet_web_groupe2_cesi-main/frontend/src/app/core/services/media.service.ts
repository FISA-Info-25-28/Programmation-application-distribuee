import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';

import { MediaUploadResponse } from '../models/media.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class MediaService {
  private readonly http = inject(HttpClient);

  // Envoie un fichier au media-service et retourne ses informations publiques.
  upload(file: File): Observable<MediaUploadResponse> {
    const body = new FormData();
    body.append('file', file);
    return this.http.post<MediaUploadResponse>(`${environment.apiBaseUrl}/media/upload`, body).pipe(
      catchError((error: HttpErrorResponse) =>
        throwError(() => new Error(this.errorMessage(error))),
      ),
    );
  }

  // Verifie le type et la taille d'un fichier avant envoi.
  validate(file: File): string | null {
    const allowed = [
      'image/jpeg',
      'image/png',
      'image/webp',
      'image/gif',
      'video/mp4',
      'video/webm',
      'video/quicktime',
    ];
    if (!allowed.includes(file.type)) {
      return 'Format non pris en charge. Utilise JPEG, PNG, WebP, GIF, MP4, WebM ou MOV.';
    }
    if (file.size > 100 * 1024 * 1024) {
      return 'Le fichier dépasse la limite de 100 Mo.';
    }
    return null;
  }

  // Convertit une erreur HTTP d'upload en message lisible par l'interface.
  private errorMessage(error: HttpErrorResponse): string {
    if (error.status === 0) {
      return 'Le service média est inaccessible. Vérifie que le media-service et l’API sont démarrés.';
    }
    const apiMessage = typeof error.error?.error === 'string' ? error.error.error : null;
    return apiMessage ?? `Échec de l’envoi du média (${error.status}).`;
  }
}
