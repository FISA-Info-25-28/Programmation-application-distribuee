import { isPlatformBrowser } from '@angular/common';
import { effect, inject, Injectable, PLATFORM_ID, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { TokenService } from './token.service';
import { AuthService } from './auth.service';

export type MessageRetention = '1h' | '7d' | '30d' | 'forever';

const RETENTION_MS: Record<Exclude<MessageRetention, 'forever'>, number> = {
  '1h': 60 * 60_000,
  '7d': 7 * 24 * 60 * 60_000,
  '30d': 30 * 24 * 60 * 60_000,
};

@Injectable({ providedIn: 'root' })
export class MessageSettingsService {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly token = inject(TokenService);
  private readonly auth = inject(AuthService);
  private readonly isBrowser = isPlatformBrowser(this.platformId);
  private readonly legacyStorageKey = 'breezy.messageRetention';

  readonly retention = signal<MessageRetention>(this.loadRetention());

  // Recharge la retention quand l'utilisateur connecte change (login initial,
  // resync au demarrage, logout), pour eviter qu'une valeur par defaut reste
  // affichee tant qu'aucun appel manuel n'a ete fait.
  constructor() {
    effect(() => {
      this.auth.currentUser();
      this.retention.set(this.loadRetention());
    });
  }

  // Recharge la retention associee a l'utilisateur courant depuis le stockage local.
  refreshForCurrentUser(): void {
    this.retention.set(this.loadRetention());
  }

  // Recupere la retention depuis l'API et la synchronise localement.
  loadFromApi(): Observable<{ retention: MessageRetention }> {
    return this.http.get<{ retention: MessageRetention }>(`${environment.apiBaseUrl}/messages/settings`).pipe(
      tap(({ retention }) => this.storeRetention(retention)),
    );
  }

  // Met a jour la retention localement sans appel API.
  setRetention(value: MessageRetention): void {
    this.storeRetention(value);
  }

  // Sauvegarde la retention cote API puis aligne la valeur locale.
  saveRetention(value: MessageRetention): Observable<{ retention: MessageRetention }> {
    this.storeRetention(value);
    return this.http.patch<{ retention: MessageRetention }>(`${environment.apiBaseUrl}/messages/settings`, {
      retention: value,
    }).pipe(tap(({ retention }) => this.storeRetention(retention)));
  }

  // Stocke la retention dans le signal et le localStorage utilisateur.
  private storeRetention(value: MessageRetention): void {
    this.retention.set(value);
    if (this.isBrowser) {
      const key = this.storageKey();
      if (key) {
        localStorage.setItem(key, value);
        localStorage.removeItem(this.legacyStorageKey);
      }
    }
  }

  // Filtre les messages affichables selon la retention courante.
  filterVisibleMessages<T extends { createdAt: string }>(messages: T[]): T[] {
    const retention = this.retention();
    if (retention === 'forever') return messages;

    const minTime = Date.now() - RETENTION_MS[retention];
    return messages.filter((message) => new Date(message.createdAt).getTime() >= minTime);
  }

  // Charge la retention sauvegardee pour l'utilisateur courant.
  private loadRetention(): MessageRetention {
    if (!this.isBrowser) return 'forever';

    const key = this.storageKey();
    if (!key) return 'forever';

    const value = localStorage.getItem(key);
    return this.isRetention(value) ? value : 'forever';
  }

  // Construit la cle de stockage propre a l'utilisateur connecte.
  private storageKey(): string | null {
    const userKey = this.auth.currentUser()?.id ?? this.token.getSession()?.email;
    return userKey ? `breezy.users.${userKey}.messageRetention` : null;
  }

  // Verifie qu'une valeur correspond a une retention supportee.
  private isRetention(value: string | null): value is MessageRetention {
    return value === '1h' || value === '7d' || value === '30d' || value === 'forever';
  }
}
