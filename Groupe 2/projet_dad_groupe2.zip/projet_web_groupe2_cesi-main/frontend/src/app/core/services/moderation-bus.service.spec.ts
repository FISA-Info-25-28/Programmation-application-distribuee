import { TestBed } from '@angular/core/testing';
import { ModerationBusService } from './moderation-bus.service';

describe('ModerationBusService', () => {
  let service: ModerationBusService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ModerationBusService);
  });

  it('increments sanction counters independently', () => {
    service.announceSanction();
    service.announceSanction();
    service.announceLift();

    expect(service.sanctionApplied()).toBe(2);
    expect(service.sanctionLifted()).toBe(1);
  });
});
