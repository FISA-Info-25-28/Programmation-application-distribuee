import { Injectable, signal } from '@angular/core';

// Bus de modération : sert à prévenir le reste de l'app qu'une sanction
// (bannissement / suspension) vient d'être appliquée avec succès.
//
// Pourquoi : les actions de modération sont déclenchées depuis le composant
// <app-moderation-actions> (rendu dans un post, une réponse ou un profil), mais
// le backend masque/anonymise alors le contenu de l'utilisateur visé. Il faut
// donc rafraîchir la page courante + la colonne de suggestions pour que
// l'affichage reflète immédiatement la sanction. Le shell `home` écoute ce
// signal (cf. home.ts) ; on évite ainsi de dupliquer la logique dans chaque page.
//
// Alternative écartée : faire remonter un (output) jusqu'à chaque page parente —
// impossible ici car le composant est profondément imbriqué et réutilisé partout.
@Injectable({ providedIn: 'root' })
export class ModerationBusService {
  // Compteur incrémenté à chaque sanction (ban / suspension). Les vues abonnées
  // comparent la valeur pour ne réagir qu'aux nouvelles sanctions (cf. home.ts).
  // → le shell `home` recharge la page courante ET les suggestions.
  readonly sanctionApplied = signal(0);

  // Compteur incrémenté à chaque levée de sanction (le compte redevient ACTIVE).
  // → le shell `home` recharge uniquement les suggestions : le compte de nouveau
  //   actif peut réapparaître dans les suggestions. Pas besoin de recharger la
  //   page courante (la page de modération met déjà à jour sa liste localement).
  readonly sanctionLifted = signal(0);

  // Signale qu'une sanction vient d'etre appliquee.
  announceSanction(): void {
    this.sanctionApplied.update((n) => n + 1);
  }

  // Signale qu'une sanction vient d'etre levee.
  announceLift(): void {
    this.sanctionLifted.update((n) => n + 1);
  }
}
