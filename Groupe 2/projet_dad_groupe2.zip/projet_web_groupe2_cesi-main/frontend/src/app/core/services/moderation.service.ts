import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';

// Reponse du moderation-service apres un ban ou une suspension.
export interface ModerationActionResult {
  profileId: string;
  accountId: string;
  status: 'BANNED' | 'SUSPENDED' | 'ACTIVE';
  suspendedUntil?: string;
}

// Compte actuellement sous sanction (banni ou suspendu non expire), expose a
// l'espace de gestion de la page de moderation.
export interface ModeratedUser {
  profileId: string;
  accountId: string;
  username: string;
  displayName: string;
  role: 'USER' | 'MODERATOR' | 'ADMIN';
  status: 'BANNED' | 'SUSPENDED';
  suspendedUntil?: string;
  updatedAt: string;
}

// Service de moderation : controle d'acces cote front + appels HTTP. Les actions
// (suspendre / bannir) sont declenchees inline depuis le composant
// <app-moderation-actions> rendu dans les menus "..." (post, reponse, profil).
// On manipule toujours un profileId (identifiant d'auteur partage par posts,
// reponses et page profil) ; le compte auth.accounts est resolu cote backend.
@Injectable({ providedIn: 'root' })
export class ModerationService {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);

  // Le moderateur peut-il agir sur ce profil ? Vrai si l'utilisateur courant est
  // MODERATOR/ADMIN et que la cible n'est pas lui-meme. Le controle de role fin
  // (un MODERATOR ne peut viser un ADMIN) est applique cote backend.
  canModerate(targetProfileId?: string | null): boolean {
    const user = this.auth.currentUser();
    if (!user) return false;
    if (user.role !== 'MODERATOR' && user.role !== 'ADMIN') return false;
    return !!targetProfileId && targetProfileId !== user.profileId;
  }

  // Bannit definitivement un profil via le service de moderation.
  ban(profileId: string, reason?: string): Observable<ModerationActionResult> {
    return this.http.post<ModerationActionResult>(
      `${environment.apiBaseUrl}/moderation/users/${profileId}/ban`,
      { reason: reason ?? '' },
    );
  }

  // Suspend temporairement un profil pour une duree exprimee en heures.
  suspend(profileId: string, durationHours: number, reason?: string): Observable<ModerationActionResult> {
    return this.http.post<ModerationActionResult>(
      `${environment.apiBaseUrl}/moderation/users/${profileId}/suspend`,
      { durationHours, reason: reason ?? '' },
    );
  }

  // Liste les comptes actuellement sous sanction (bannis ou suspendus non expires).
  listSanctions(): Observable<ModeratedUser[]> {
    return this.http.get<ModeratedUser[]>(`${environment.apiBaseUrl}/moderation/sanctions`);
  }

  // Leve la sanction (suspension ou bannissement) : remet le compte en ACTIVE.
  lift(profileId: string): Observable<ModerationActionResult> {
    return this.http.post<ModerationActionResult>(
      `${environment.apiBaseUrl}/moderation/users/${profileId}/lift`,
      {},
    );
  }
}
