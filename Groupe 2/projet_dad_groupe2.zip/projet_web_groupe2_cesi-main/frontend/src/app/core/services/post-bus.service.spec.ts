import { TestBed } from '@angular/core/testing';
import { Post } from '../models/post.model';
import { PostBusService } from './post-bus.service';
import { vi } from 'vitest';

const post: Post = {
  id: 'post-1',
  author: { id: 'u1', username: 'ada', displayName: 'Ada', avatarUrl: null },
  content: 'Hello',
  lang: '',
  visibility: 'PUBLIC',
  tags: [],
  likeCount: 0,
  replyCount: 0,
  repostCount: 0,
  isLiked: false,
  isReposted: false,
  isBookmarked: false,
  parentId: null,
  createdAt: '2026-01-01T00:00:00Z',
  media: [],
};

describe('PostBusService', () => {
  let service: PostBusService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PostBusService);
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('announces a post briefly then clears it', () => {
    vi.useFakeTimers();

    service.announce(post);
    expect(service.newPost()).toBe(post);

    vi.advanceTimersByTime(50);
    expect(service.newPost()).toBeNull();
  });
});
