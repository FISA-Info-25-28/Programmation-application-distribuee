import { Injectable, signal } from '@angular/core';
import { Post } from '../models/post.model';

@Injectable({ providedIn: 'root' })
export class PostBusService {
  private readonly _newPost = signal<Post | null>(null);
  readonly newPost = this._newPost.asReadonly();

  // Diffuse la creation d'un nouveau post puis remet le signal a vide.
  announce(post: Post): void {
    this._newPost.set(post);
    setTimeout(() => this._newPost.set(null), 50);
  }
}
