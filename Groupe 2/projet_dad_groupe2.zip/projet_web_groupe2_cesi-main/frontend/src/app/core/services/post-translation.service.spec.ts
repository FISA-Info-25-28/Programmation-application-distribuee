import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';

import { PostTranslationService, SAME_LANGUAGE } from './post-translation.service';
import { LangService } from './lang.service';

describe('PostTranslationService', () => {
  let fetchMock: ReturnType<typeof vi.fn>;
  let currentLang: ReturnType<typeof signal<'fr' | 'pt'>>;

  beforeEach(() => {
    fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    currentLang = signal<'fr' | 'pt'>('fr');

    TestBed.configureTestingModule({
      providers: [
        {
          provide: LangService,
          useValue: { lang: currentLang.asReadonly() },
        },
      ],
    });
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    TestBed.resetTestingModule();
  });

  it('excludes hashtags from the translated text and keeps them unchanged in the result', async () => {
    fetchMock.mockResolvedValue({
      ok: true,
      json: () => Promise.resolve([[['Bonjour le monde', 'Hello world!']], null, 'en']),
    });

    const service = TestBed.inject(PostTranslationService);
    const result = await firstValueFrom(service.translate('post-1', 'Hello #Angular world #Demo!'));

    const calledUrl = fetchMock.mock.calls[0][0] as string;

    expect(new URL(calledUrl).searchParams.get('q')).toBe('Hello world!');
    expect(result).toBe('Bonjour le monde #Angular #Demo');
  });

  it('does not request a translation when a post only contains hashtags', async () => {
    const service = TestBed.inject(PostTranslationService);
    const result = await firstValueFrom(service.translate('post-1', '#Angular #Demo'));

    expect(fetchMock).not.toHaveBeenCalled();
    expect(result).toBe(SAME_LANGUAGE);
  });

  it('tries Brazilian Portuguese first and falls back to generic Portuguese', async () => {
    currentLang.set('pt');
    fetchMock
      .mockResolvedValueOnce({
        ok: false,
        json: () => Promise.resolve(null),
      })
      .mockResolvedValueOnce({
        ok: true,
        json: () => Promise.resolve([[['Ola mundo', 'Hello world']], null, 'en']),
      });

    const service = TestBed.inject(PostTranslationService);
    const result = await firstValueFrom(service.translate('post-pt', 'Hello world'));

    const firstUrl = new URL(fetchMock.mock.calls[0][0] as string);
    const secondUrl = new URL(fetchMock.mock.calls[1][0] as string);

    expect(firstUrl.searchParams.get('tl')).toBe('pt-BR');
    expect(secondUrl.searchParams.get('tl')).toBe('pt');
    expect(result).toBe('Ola mundo');
  });
});
