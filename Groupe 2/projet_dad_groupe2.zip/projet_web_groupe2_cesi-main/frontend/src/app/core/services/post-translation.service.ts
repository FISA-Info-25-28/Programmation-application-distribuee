import { inject, Injectable } from '@angular/core';
import { from, Observable, of } from 'rxjs';

import { LangService } from './lang.service';

export const SAME_LANGUAGE = 'SAME_LANGUAGE' as const;
export type TranslateResult = string | null | typeof SAME_LANGUAGE;

const hashtagPattern = /(^|[^\p{L}\p{N}_])#([\p{L}\p{N}_]+)/gu;
const googleTargetLangs: Record<string, readonly string[]> = {
  pt: ['pt-BR', 'pt'],
};

@Injectable({ providedIn: 'root' })
export class PostTranslationService {
  private readonly lang = inject(LangService);
  private readonly cache = new Map<string, TranslateResult>();

  // Traduit le texte d'un post vers la langue courante et met le resultat en cache.
  translate(postId: string, text: string): Observable<TranslateResult> {
    const appLang = this.lang.lang();
    const cacheKey = `${postId}:${appLang}`;
    const targetLangs = googleTargetLangs[appLang] ?? [appLang];
    const { text: translatableText, tags } = this.extractTranslationText(text);

    const cached = this.cache.get(cacheKey);
    if (cached !== undefined) return of(cached);
    if (!translatableText) {
      this.cache.set(cacheKey, SAME_LANGUAGE);
      return of(SAME_LANGUAGE);
    }

    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), 5000);

    return from(
      this.translateWithFallbacks(translatableText, targetLangs, controller.signal)
        .then((translated): TranslateResult => {
          clearTimeout(tid);

          if (translated === SAME_LANGUAGE) {
            this.cache.set(cacheKey, SAME_LANGUAGE);
            return SAME_LANGUAGE;
          }

          if (!translated) return null;

          const translatedWithTags = this.appendUntranslatedTags(translated, tags);
          this.cache.set(cacheKey, translatedWithTags);
          return translatedWithTags;
        })
        .catch((): TranslateResult => {
          clearTimeout(tid);
          return null;
        }),
    );
  }

  private async translateWithFallbacks(
    text: string,
    targetLangs: readonly string[],
    signal: AbortSignal,
  ): Promise<TranslateResult> {
    for (const targetLang of targetLangs) {
      const translated = await this.requestGoogleTranslation(text, targetLang, signal);
      if (translated) return translated;
    }

    return null;
  }

  private async requestGoogleTranslation(
    text: string,
    targetLang: string,
    signal: AbortSignal,
  ): Promise<TranslateResult> {
    const url =
      `https://translate.googleapis.com/translate_a/single` +
      `?client=gtx&sl=auto&tl=${targetLang}&dt=t` +
      `&q=${encodeURIComponent(text)}`;

    const response = await fetch(url, { signal });
    if (!response.ok) return null;

    const res = (await response.json()) as unknown[];

    // Response: [ [[translated_segment, original_segment, ...], ...], null, "detected_lang", ... ]
    const detectedLang = res?.[2] as string | undefined;
    if (this.sameLanguage(detectedLang, targetLang)) return SAME_LANGUAGE;

    const segments = res?.[0] as [string, ...unknown[]][] | undefined;
    return (
      segments
        ?.map((s) => s[0] as string)
        .filter(Boolean)
        .join('')
        .trim() || null
    );
  }

  private sameLanguage(detectedLang: string | undefined, targetLang: string): boolean {
    if (!detectedLang) return false;
    return detectedLang.toLowerCase().split('-')[0] === targetLang.toLowerCase().split('-')[0];
  }

  private extractTranslationText(text: string): { text: string; tags: string[] } {
    const tags = Array.from(text.matchAll(hashtagPattern), (match) => `#${match[2]}`);
    const cleanedText = text
      .replace(hashtagPattern, '$1')
      .replace(/\s+([.,!?;:])/g, '$1')
      .replace(/\s{2,}/g, ' ')
      .trim();

    return { text: cleanedText, tags };
  }

  private appendUntranslatedTags(translated: string, tags: string[]): string {
    if (tags.length === 0) return translated;
    return `${translated} ${tags.join(' ')}`.trim();
  }
}
