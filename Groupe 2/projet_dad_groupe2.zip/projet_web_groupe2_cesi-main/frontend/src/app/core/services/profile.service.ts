import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable, tap } from 'rxjs';

import { environment } from '../../../environments/environment';
import { ApiProfile } from '../models/api-profile.model';
import { User } from '../models/user.model';
import { mapApiProfile } from '../mappers/profile.mapper';
import { AuthService } from './auth.service';

// Champs modifiables du profil. Le username n'est pas modifiable (identifiant
// stable) et l'email/le rôle relèvent de l'auth-service, pas du profile-service.
export interface ProfileUpdateInput {
  displayName: string;
  bio: string | null;
}

// Point d'entrée unique vers le profile-service backend (schéma `profiles`).
// Renvoie toujours des `User` du domaine front (via mapApiProfile), et assure la
// liaison avec l'authentification : enrichissement des champs que le
// profile-service ne connaît pas (email, rôle) et synchronisation de la session
// quand l'utilisateur courant modifie son propre profil.
@Injectable({ providedIn: 'root' })
export class ProfileService {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);

  private readonly baseUrl = `${environment.apiBaseUrl}/profiles`;

  // Profil de l'utilisateur connecté (GET /profiles/me). On passe l'utilisateur
  // courant en fallback pour conserver email/rôle/compteurs absents du profile-service.
  getMyProfile(): Observable<User> {
    return this.http
      .get<ApiProfile>(`${this.baseUrl}/me`)
      .pipe(map((api) => mapApiProfile(api, this.auth.currentUser())));
  }

  // Profil public d'un autre utilisateur (GET /profiles/:username).
  getProfileByUsername(username: string): Observable<User> {
    return this.http
      .get<ApiProfile>(`${this.baseUrl}/${username}`)
      .pipe(map((api) => mapApiProfile(api)));
  }

  // Résout le bon endpoint selon le username demandé : /me pour son propre profil
  // (enrichi via la session), /:username sinon. Évite de dupliquer ce choix dans les pages.
  getProfileForUsername(username: string): Observable<User> {
    return this.isOwnUsername(username)
      ? this.getMyProfile()
      : this.getProfileByUsername(username);
  }

  // Met à jour le profil courant (PATCH /profiles/me) puis répercute le résultat
  // dans la session d'authentification. Le profile-service ne renvoie ni email/rôle
  // (auth-service) ni username (non modifiable) : on les conserve via le fallback,
  // et persistUser pousse l'utilisateur à jour dans le signal + le token.
  updateMyProfile(data: ProfileUpdateInput): Observable<User> {
    return this.http.patch<ApiProfile>(`${this.baseUrl}/me`, data).pipe(
      map((api) => mapApiProfile(api, this.auth.currentUser())),
      tap((user) => this.auth.persistUser(user)),
    );
  }

  // Le username demandé correspond-il à l'utilisateur connecté ?
  isOwnUsername(username: string): boolean {
    return this.auth.currentUser()?.username === username;
  }
}
