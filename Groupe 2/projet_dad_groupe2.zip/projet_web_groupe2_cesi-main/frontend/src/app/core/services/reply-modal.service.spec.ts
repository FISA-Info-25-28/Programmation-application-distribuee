import { TestBed } from '@angular/core/testing';
import { Post } from '../models/post.model';
import { ReplyModalService } from './reply-modal.service';
import { vi } from 'vitest';

const post: Post = {
  id: 'post-1',
  author: { id: 'u1', username: 'ada', displayName: 'Ada', avatarUrl: null },
  content: 'Hello',
  lang: '',
  visibility: 'PUBLIC',
  tags: [],
  likeCount: 0,
  replyCount: 0,
  repostCount: 0,
  isLiked: false,
  isReposted: false,
  isBookmarked: false,
  parentId: null,
  createdAt: '2026-01-01T00:00:00Z',
  media: [],
};

describe('ReplyModalService', () => {
  let service: ReplyModalService;

  beforeEach(() => {
    document.body.classList.remove('overflow-hidden');
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReplyModalService);
  });

  afterEach(() => {
    document.body.classList.remove('overflow-hidden');
  });

  it('stores reply context and toggles body overflow class', () => {
    const onSuccess = vi.fn();

    service.open(post, onSuccess);

    expect(service.context()).toEqual({ post, onSuccess });
    expect(document.body.classList.contains('overflow-hidden')).toBe(true);

    service.close();
    expect(service.context()).toBeNull();
    expect(document.body.classList.contains('overflow-hidden')).toBe(false);
  });
});
