import { Injectable, signal } from '@angular/core';
import { Post } from '../models/post.model';

export interface ReplyContext {
  post: Post;
  onSuccess: (updatedParent: Post, createdReply: Post) => void;
}

@Injectable({ providedIn: 'root' })
export class ReplyModalService {
  readonly context = signal<ReplyContext | null>(null);

  // Ouvre la modale de reponse pour un post et bloque le scroll de la page.
  open(post: Post, onSuccess: (updatedParent: Post, createdReply: Post) => void): void {
    this.context.set({ post, onSuccess });
    if (typeof document !== 'undefined') document.body.classList.add('overflow-hidden');
  }

  // Ferme la modale de reponse et restaure le scroll de la page.
  close(): void {
    this.context.set(null);
    if (typeof document !== 'undefined') document.body.classList.remove('overflow-hidden');
  }
}
