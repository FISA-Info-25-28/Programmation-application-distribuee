import { TestBed } from '@angular/core/testing';
import { ScrollLockService } from './scroll-lock.service';

describe('ScrollLockService', () => {
  let service: ScrollLockService;

  beforeEach(() => {
    document.body.style.overflow = '';
    TestBed.configureTestingModule({});
    service = TestBed.inject(ScrollLockService);
  });

  afterEach(() => {
    document.body.style.overflow = '';
  });

  it('keeps the page locked until every lock is released', () => {
    service.lock();
    service.lock();
    expect(document.body.style.overflow).toBe('hidden');

    service.unlock();
    expect(document.body.style.overflow).toBe('hidden');

    service.unlock();
    expect(document.body.style.overflow).toBe('');
  });

  it('does not underflow when unlocked too many times', () => {
    service.unlock();

    expect(document.body.style.overflow).toBe('');
  });
});
