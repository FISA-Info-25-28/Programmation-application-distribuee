import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ScrollLockService {
  private count = 0;

  // Bloque le scroll de la page tant qu'au moins un appel est actif.
  lock(): void {
    this.count++;
    if (typeof document !== 'undefined' && this.count === 1) {
      document.body.style.overflow = 'hidden';
    }
  }

  // Libere un verrou de scroll et restaure la page quand il n'en reste aucun.
  unlock(): void {
    this.count = Math.max(0, this.count - 1);
    if (typeof document !== 'undefined' && this.count === 0) {
      document.body.style.overflow = '';
    }
  }
}
