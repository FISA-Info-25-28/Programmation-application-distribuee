import { TestBed } from '@angular/core/testing';
import { ScrollStateService } from './scroll-state.service';

describe('ScrollStateService', () => {
  let service: ScrollStateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ScrollStateService);
  });

  it('hides the header when scrolling down past the threshold', () => {
    service.update(20);
    expect(service.headerHidden()).toBe(false);

    service.update(100);
    expect(service.headerHidden()).toBe(true);
  });

  it('shows the header when scrolling up enough', () => {
    service.update(100);
    service.update(94);

    expect(service.headerHidden()).toBe(false);
  });
});
