import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ScrollStateService {
  readonly headerHidden = signal(false);
  private _lastY = 0;

  // Met a jour l'etat du header selon le sens et la position du scroll.
  update(y: number): void {
    if (y > this._lastY && y > 80) {
      this.headerHidden.set(true);
    } else if (y < this._lastY - 4) {
      this.headerHidden.set(false);
    }
    this._lastY = y;
  }
}
