import { TestBed } from '@angular/core/testing';
import { ShareMessageService } from './share-message.service';

describe('ShareMessageService', () => {
  let service: ShareMessageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ShareMessageService);
  });

  it('opens and closes a share payload', () => {
    service.open('post-1', 'hello', 'Ada', 'ada');

    expect(service.payload()).toEqual({
      postId: 'post-1',
      excerpt: 'hello',
      authorDisplayName: 'Ada',
      authorUsername: 'ada',
    });
    expect(service.postExcerpt()).toBe('hello');

    service.close();
    expect(service.payload()).toBeNull();
    expect(service.postExcerpt()).toBeNull();
  });
});
