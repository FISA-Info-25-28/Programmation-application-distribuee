import { Injectable, signal } from '@angular/core';

export interface SharePayload {
  postId: string;
  excerpt: string;
  authorDisplayName: string;
  authorUsername: string;
}

@Injectable({ providedIn: 'root' })
export class ShareMessageService {
  private readonly _payload = signal<SharePayload | null>(null);
  readonly payload = this._payload.asReadonly();

  readonly postExcerpt = () => this._payload()?.excerpt ?? null;

  // Ouvre le partage en message prive avec les informations du post.
  open(postId: string, excerpt: string, authorDisplayName: string, authorUsername: string): void {
    this._payload.set({ postId, excerpt, authorDisplayName, authorUsername });
  }

  // Ferme le partage en message prive et vide le payload courant.
  close(): void {
    this._payload.set(null);
  }
}
