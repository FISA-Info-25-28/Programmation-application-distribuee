import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { effect, inject, Injectable, PLATFORM_ID, signal } from '@angular/core';
import { TokenService } from './token.service';
import { AuthService } from './auth.service';

export type Theme = 'light' | 'dark' | 'system';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly document = inject(DOCUMENT);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly token = inject(TokenService);
  private readonly auth = inject(AuthService);
  private readonly isBrowser = isPlatformBrowser(this.platformId);
  private readonly legacyStorageKey = 'breezy.theme';

  readonly theme = signal<Theme>(this.loadTheme());

  // Applique automatiquement le theme courant quand le signal change.
  // Recharge aussi le theme quand l'identite de l'utilisateur connecte change
  // (login initial, resync /auth/me au demarrage, logout), pour eviter qu'un
  // theme par defaut reste affiche tant qu'aucun appel manuel n'a ete fait.
  constructor() {
    effect(() => {
      this.applyTheme(this.theme());
    });
    effect(() => {
      this.auth.currentUser();
      this.theme.set(this.loadTheme());
    });
  }

  // Change le theme courant et le persiste pour l'utilisateur connecte.
  setTheme(theme: Theme): void {
    this.theme.set(theme);
    if (this.isBrowser) {
      const key = this.storageKey();
      if (key) {
        localStorage.setItem(key, theme);
        localStorage.removeItem(this.legacyStorageKey);
      }
    }
  }

  // Recharge le theme associe a l'utilisateur courant depuis le stockage local.
  refreshForCurrentUser(): void {
    this.theme.set(this.loadTheme());
  }

  // Charge le theme sauvegarde ou retourne le theme clair par defaut.
  private loadTheme(): Theme {
    if (!this.isBrowser) return 'light';

    const key = this.storageKey();
    if (!key) return 'light';

    const value = localStorage.getItem(key);
    return this.isTheme(value) ? value : 'light';
  }

  // Applique la classe CSS correspondant au theme choisi.
  private applyTheme(theme: Theme): void {
    if (!this.isBrowser) return;

    const root = this.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      return;
    }
    if (theme === 'light') {
      root.classList.remove('dark');
      return;
    }

    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    root.classList.toggle('dark', prefersDark);
  }

  // Construit la cle de stockage propre a l'utilisateur connecte.
  private storageKey(): string | null {
    const userKey = this.auth.currentUser()?.id ?? this.token.getSession()?.email;
    return userKey ? `breezy.users.${userKey}.theme` : null;
  }

  // Verifie qu'une valeur correspond a un theme supporte.
  private isTheme(value: string | null): value is Theme {
    return value === 'light' || value === 'dark' || value === 'system';
  }
}
