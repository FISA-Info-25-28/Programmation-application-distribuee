import { PLATFORM_ID } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { TokenService } from './token.service';

describe('TokenService', () => {
  const storageKey = 'breezy.session';

  afterEach(() => {
    localStorage.removeItem(storageKey);
    TestBed.resetTestingModule();
  });

  it('saves, reads and clears a browser session', () => {
    TestBed.configureTestingModule({
      providers: [{ provide: PLATFORM_ID, useValue: 'browser' }],
    });
    const service = TestBed.inject(TokenService);

    service.save({ email: 'ada@example.test', loggedAt: 'now' });

    expect(service.getSession()).toEqual({ email: 'ada@example.test', loggedAt: 'now', user: undefined });
    expect(service.isLoggedIn()).toBe(true);
    expect(service.getToken()).toBeNull();

    service.clear();
    expect(service.getSession()).toBeNull();
  });

  it('ignores invalid JSON and server platform storage', () => {
    localStorage.setItem(storageKey, '{bad json');
    TestBed.configureTestingModule({
      providers: [{ provide: PLATFORM_ID, useValue: 'browser' }],
    });

    expect(TestBed.inject(TokenService).getSession()).toBeNull();

    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [{ provide: PLATFORM_ID, useValue: 'server' }],
    });

    expect(TestBed.inject(TokenService).getSession()).toBeNull();
  });
});
