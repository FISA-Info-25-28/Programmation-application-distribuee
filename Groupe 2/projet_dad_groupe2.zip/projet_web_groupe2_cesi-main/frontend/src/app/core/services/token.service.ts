import { inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { User } from '../models/user.model';

export interface BreezySession {
  email: string;
  loggedAt: string;
  user?: User;
}

@Injectable({ providedIn: 'root' })
export class TokenService {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly sessionKey = 'breezy.session';

  // Lit la session locale et nettoie les anciens champs de tokens si besoin.
  getSession(): BreezySession | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    const raw = localStorage.getItem(this.sessionKey);
    if (!raw) return null;
    try {
      const session = JSON.parse(raw) as BreezySession & {
        token?: string;
        refreshToken?: string;
      };
      if (session.token || session.refreshToken) {
        this.save(session);
      }
      return {
        email: session.email,
        loggedAt: session.loggedAt,
        user: session.user,
      };
    } catch {
      return null;
    }
  }

  // Retourne toujours null car les tokens d'auth sont portes par les cookies HTTP-only.
  getToken(): string | null {
    return null;
  }

  // Enregistre les informations de session utiles au front dans le localStorage.
  save(session: BreezySession): void {
    if (!isPlatformBrowser(this.platformId)) return;
    localStorage.setItem(
      this.sessionKey,
      JSON.stringify({
        email: session.email,
        loggedAt: session.loggedAt,
        user: session.user,
      } satisfies BreezySession),
    );
  }

  // Indique si une session locale existe pour l'utilisateur courant.
  isLoggedIn(): boolean {
    return this.getSession() !== null;
  }

  // Supprime la session locale stockee dans le navigateur.
  clear(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    localStorage.removeItem(this.sessionKey);
  }
}
