import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, finalize, map, Observable, of, shareReplay, tap } from 'rxjs';

import { environment } from '../../../environments/environment';
import { User } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class UserSuggestionsService {
  private readonly http = inject(HttpClient);

  private cachedUsers: User[] | null = null;
  private inFlightRequest: Observable<User[]> | null = null;

  load(limit = 20): Observable<User[]> {
    if (this.cachedUsers) {
      return of(this.cachedUsers.slice(0, limit));
    }

    if (!this.inFlightRequest) {
      this.inFlightRequest = this.http
        .get<User[]>(`${environment.apiBaseUrl}/users/suggestions`, {
          params: { limit: Math.max(limit, 20) },
        })
        .pipe(
          map((users) => users.filter((user) => !user.isFollowing && !user.requestPending)),
          tap((users) => {
            this.cachedUsers = users;
          }),
          catchError(() => of([] as User[])),
          finalize(() => {
            this.inFlightRequest = null;
          }),
          shareReplay({ bufferSize: 1, refCount: false }),
        );
    }

    return this.inFlightRequest.pipe(map((users) => users.slice(0, limit)));
  }

  hide(userId: string): void {
    if (!this.cachedUsers) return;
    this.cachedUsers = this.cachedUsers.filter((user) => user.id !== userId);
  }
}
