import { avatarClass, initials, refreshImageUrl, timeAgo, versionedImageUrl } from './avatar';
import { vi } from 'vitest';

describe('avatar utils', () => {
  it('derives a stable avatar class from a user id', () => {
    expect(avatarClass('user-7')).toBe('av-3');
    expect(avatarClass('abc')).toBe('av-2');
  });

  it('builds initials from the first two words', () => {
    expect(initials('Ada Lovelace')).toBe('AL');
    expect(initials('Prince')).toBe('P');
  });

  it('versions refreshed image urls without losing existing query params', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-01-01T00:00:00Z'));

    refreshImageUrl('/avatar.png');
    refreshImageUrl('/avatar.png?size=64');

    expect(versionedImageUrl('/avatar.png')).toBe('/avatar.png?v=1767225600000');
    expect(versionedImageUrl('/avatar.png?size=64')).toBe('/avatar.png?size=64&v=1767225600000');
    expect(versionedImageUrl(null)).toBeNull();

    vi.useRealTimers();
  });

  it('formats recent dates and ignores invalid or future dates', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-01-01T12:00:00Z'));

    expect(timeAgo('2026-01-01T11:59:30Z')).toBe('30s');
    expect(timeAgo('2026-01-01T11:00:00Z')).toBe('1h');
    expect(timeAgo('not-a-date')).toBe('');
    expect(timeAgo('2026-01-01T13:00:00Z')).toBe('');

    vi.useRealTimers();
  });
});
