export function avatarClass(userId: string): string {
  const n = parseInt(userId.replace(/\D/g, '') || '1', 10);
  return `av-${(n % 5) + 1}`;
}

const imageVersions = new Map<string, number>();

export function refreshImageUrl(url: string | null | undefined): void {
  if (!url) return;
  imageVersions.set(url, Date.now());
}

export function versionedImageUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  const version = imageVersions.get(url);
  if (!version) return url;
  const separator = url.includes('?') ? '&' : '?';
  return `${url}${separator}v=${version}`;
}

export function initials(displayName: string): string {
  return displayName
    .split(' ')
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('');
}

export function timeAgo(
  iso: string | null | undefined,
  lang: 'fr' | 'en' | 'es' | 'it' | 'de' | 'pt' = 'fr',
): string {
  if (!iso) return '';
  const date = new Date(iso);
  if (isNaN(date.getTime())) return '';
  const diff = (Date.now() - date.getTime()) / 1000;
  // dates futures ou antérieures à 10 ans (ex : Go zero time 0001-01-01)
  if (diff < 0 || diff > 315_576_000) return '';
  const dayUnit = lang === 'fr' ? 'j' : lang === 'it' ? 'g' : lang === 'de' ? 'T' : 'd';
  if (diff < 60) return `${Math.round(diff)}s`;
  if (diff < 3600) return `${Math.round(diff / 60)}min`;
  if (diff < 86400) return `${Math.round(diff / 3600)}h`;
  return `${Math.round(diff / 86400)}${dayUnit}`;
}
