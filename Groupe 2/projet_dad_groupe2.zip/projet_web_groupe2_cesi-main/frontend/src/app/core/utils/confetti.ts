const CONFETTI_COLORS = ['#00a9c0', '#3cc8d7', '#ff8a5b', '#ff5e6c', '#2bc4a0', '#f4a63c'];
const CONFETTI_COUNT = 56;
const CONFETTI_DURATION_MS = 3000;
const CESI_KEYWORD_RE = /\bCESI\b/i;
const TEST_KEYWORD_RE = /\bTEST\b/i;

export function shouldCelebratePost(content: string): boolean {
  return CESI_KEYWORD_RE.test(content) && !TEST_KEYWORD_RE.test(content);
}

export function launchConfetti(): void {
  if (typeof document === 'undefined') return;

  const layer = document.createElement('div');
  layer.className = 'breezy-confetti-layer';

  for (let i = 0; i < CONFETTI_COUNT; i += 1) {
    const piece = document.createElement('span');
    piece.className = 'breezy-confetti-piece';
    piece.style.left = `${Math.random() * 100}%`;
    piece.style.background = CONFETTI_COLORS[i % CONFETTI_COLORS.length];
    piece.style.animationDelay = `${Math.random() * 0.35}s`;
    piece.style.animationDuration = `${2.1 + Math.random() * 0.9}s`;
    piece.style.transform = `translateY(-24vh) rotate(${Math.random() * 360}deg)`;
    piece.style.setProperty('--confetti-x', `${(Math.random() - 0.5) * 24}vw`);
    piece.style.setProperty('--confetti-spin', `${180 + Math.random() * 540}deg`);
    layer.appendChild(piece);
  }

  document.body.appendChild(layer);
  window.setTimeout(() => layer.remove(), CONFETTI_DURATION_MS);
}
