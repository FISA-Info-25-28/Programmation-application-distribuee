import { activeMentionQuery, insertMention, parseSocialText } from './social-text';

describe('social-text utils', () => {
  it('detects an active mention only at the end of the text', () => {
    expect(activeMentionQuery('hello @tha')).toBe('tha');
    expect(activeMentionQuery('@')).toBe('');
    expect(activeMentionQuery('hello @tha world')).toBeNull();
  });

  it('replaces the active mention query with the selected username', () => {
    expect(insertMention('hello @th', 'thais')).toBe('hello @thais ');
    expect(insertMention('@th', 'thais')).toBe('@thais ');
  });

  it('splits text, hashtags and mentions into typed parts', () => {
    expect(parseSocialText('Hi @ada about #Angular')).toEqual([
      { text: 'Hi ', type: 'text' },
      { text: '@ada', type: 'mention', value: 'ada' },
      { text: ' about ', type: 'text' },
      { text: '#Angular', type: 'tag', value: 'Angular' },
    ]);
  });
});
