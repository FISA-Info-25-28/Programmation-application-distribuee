export type SocialTextPart = {
  text: string;
  type: 'text' | 'tag' | 'mention';
  value?: string;
};

export function activeMentionQuery(text: string): string | null {
  const match = text.match(/(?:^|\s)@([a-z0-9_]*)$/i);
  return match ? match[1] : null;
}

export function insertMention(text: string, username: string): string {
  const mention = `@${username} `;
  return text.replace(/(^|\s)@[a-z0-9_]*$/i, (_, prefix: string) => `${prefix}${mention}`);
}

export function parseSocialText(text: string): SocialTextPart[] {
  return text
    .split(/([#@][a-z0-9_]{1,30})/gi)
    .filter(Boolean)
    .map((part) => {
      if (part.startsWith('#')) {
        return { text: part, type: 'tag', value: part.slice(1) };
      }
      if (part.startsWith('@')) {
        return { text: part, type: 'mention', value: part.slice(1) };
      }
      return { text: part, type: 'text' };
    });
}
