import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { signal } from '@angular/core';
import { of, throwError } from 'rxjs';

import { Administration } from './administration';
import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../../shared/flash/flash.service';
import { LangService } from '../../core/services/lang.service';

const section = new Proxy({}, { get: (_target, prop) => String(prop) });
const lang = { tr: () => new Proxy({}, { get: () => section }) };

describe('Administration', () => {
  let fixture: ComponentFixture<Administration>;
  let component: Administration;
  let http: { get: ReturnType<typeof vi.fn>; post: ReturnType<typeof vi.fn>; patch: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };

  const adminUser = {
    accountId: 'a1',
    profileId: 'p1',
    username: 'ada',
    displayName: 'Ada',
    email: 'ada@example.com',
    role: 'USER',
    status: 'ACTIVE',
    isPrivate: false,
    createdAt: '2026-06-24T10:00:00Z',
    updatedAt: '2026-06-24T10:00:00Z',
  };

  beforeEach(async () => {
    vi.useFakeTimers();
    http = {
      get: vi.fn(() => of([adminUser])),
      post: vi.fn(() => of({ ...adminUser, accountId: 'a2' })),
      patch: vi.fn(() => of({ ...adminUser, role: 'MODERATOR' })),
    };
    flash = { show: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [Administration],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: AuthService, useValue: { currentUser: signal({ id: 'current' }).asReadonly() } },
        { provide: FlashService, useValue: flash },
        { provide: LangService, useValue: lang },
      ],
    })
      .overrideComponent(Administration, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Administration);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('creates and loads users', () => {
    expect(component).toBeTruthy();
    expect((component as any).users()).toEqual([adminUser]);
    expect((component as any).counts().total).toBe(1);
  });

  it('validates password rules from form data', () => {
    (component as any).updateForm('email', 'ada@example.com');
    (component as any).updateForm('username', 'ada');
    (component as any).updateForm('displayName', 'Ada Lovelace');

    const checklist = (component as any).passwordChecklist('Complex1234!');

    expect(checklist.every((item: { valid: boolean }) => item.valid)).toBe(true);
  });

  it('creates a user when the form is valid', () => {
    (component as any).form.set({
      email: 'new@example.com',
      password: 'Complex1234!',
      username: 'newuser',
      displayName: 'New User',
      role: 'USER',
    });
    (component as any).emailAvailable.set(true);
    (component as any).usernameAvailable.set(true);

    (component as any).createUser();

    expect(http.post).toHaveBeenCalled();
    expect((component as any).users()[0].accountId).toBe('a2');
  });

  it('maps duplicate email creation errors to the form', () => {
    http.post.mockReturnValueOnce(
      throwError(() => new HttpErrorResponse({ status: 409, error: { error: 'email already registered' } })),
    );
    (component as any).form.set({
      email: 'taken@example.com',
      password: 'Complex1234!',
      username: 'takenuser',
      displayName: 'Taken User',
      role: 'USER',
    });
    (component as any).emailAvailable.set(true);
    (component as any).usernameAvailable.set(true);

    (component as any).createUser();

    expect((component as any).serverFieldErrors().email).toBe('emailConflict');
  });
});
