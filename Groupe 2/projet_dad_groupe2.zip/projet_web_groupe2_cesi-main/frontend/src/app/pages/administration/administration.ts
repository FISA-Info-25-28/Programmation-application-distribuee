import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../../shared/flash/flash.service';
import { LangService } from '../../core/services/lang.service';
import { TPipe } from '../../core/pipes/t.pipe';
import { UserRole } from '../../core/models/user.model';
import { environment } from '../../../environments/environment';

type AdminTab = 'create' | 'roles';

/**
 * Utilisateur affiche dans l'administration.
 * Entree : reponse de l'API /users/admin/users.
 * Sortie : modele local utilise pour les cards et actions de role.
 */
interface AdminUser {
  accountId: string;
  profileId: string;
  username: string;
  displayName: string;
  email: string;
  role: UserRole;
  status: string;
  isPrivate: boolean;
  createdAt: string;
  updatedAt: string;
  suspendedUntil?: string | null;
}

/**
 * Etat du formulaire de creation de compte.
 * Entree : valeurs saisies par l'admin.
 * Sortie : payload nettoye avant envoi a l'API de creation.
 */
interface CreateUserForm {
  email: string;
  password: string;
  username: string;
  displayName: string;
  role: UserRole;
}

/**
 * Reponse des endpoints de disponibilite email/username.
 * Entree : GET /auth/check-email ou /auth/check-username.
 * Sortie : available indique si la valeur peut etre utilisee.
 */
interface AvailabilityResponse {
  available: boolean;
}

@Component({
  selector: 'app-administration',
  templateUrl: './administration.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, TPipe],
})
export class Administration {
  private readonly http = inject(HttpClient);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);
  protected readonly auth = inject(AuthService);
  protected readonly lang = inject(LangService);

  protected readonly roles: UserRole[] = ['USER', 'MODERATOR', 'ADMIN'];
  protected readonly activeTab = signal<AdminTab>('create');
  protected readonly users = signal<AdminUser[]>([]);
  protected readonly query = signal('');
  protected readonly isLoading = signal(false);
  protected readonly busyAccountId = signal<string | null>(null);
  protected readonly creating = signal(false);
  protected readonly submitted = signal(false);
  protected readonly serverFieldErrors = signal<Partial<Record<keyof CreateUserForm, string>>>({});
  protected readonly emailAvailable = signal<boolean | null>(null);
  protected readonly usernameAvailable = signal<boolean | null>(null);
  protected readonly checkingEmail = signal(false);
  protected readonly checkingUsername = signal(false);
  protected readonly showPassword = signal(false);
  protected readonly form = signal<CreateUserForm>({
    email: '',
    password: '',
    username: '',
    displayName: '',
    role: 'USER',
  });

  protected readonly counts = computed(() => ({
    total: this.users().length,
    admins: this.users().filter((user) => user.role === 'ADMIN').length,
    moderators: this.users().filter((user) => user.role === 'MODERATOR').length,
  }));

  protected readonly formErrors = computed<Partial<Record<keyof CreateUserForm, string>>>(() => {
    const form = this.form();
    const submitted = this.submitted();
    const errors: Partial<Record<keyof CreateUserForm, string>> = { ...this.serverFieldErrors() };

    if ((submitted || form.email.length > 0) && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      errors.email = this.lang.tr().admin.emailInvalid;
    } else if (this.emailAvailable() === false) {
      errors.email = this.lang.tr().admin.emailConflict;
    }
    if ((submitted || form.username.length > 0) && !/^[A-Za-z0-9_]{3,30}$/.test(form.username.trim())) {
      errors.username = this.lang.tr().admin.usernameInvalid;
    } else if (this.usernameAvailable() === false) {
      errors.username = this.lang.tr().admin.usernameConflict;
    }
    if ((submitted || form.displayName.length > 0) && form.displayName.trim().length === 0) {
      errors.displayName = this.lang.tr().admin.displayNameRequired;
    }
    if (form.displayName.trim().length > 80) {
      errors.displayName = this.lang.tr().admin.displayNameTooLong;
    }
    if ((submitted || form.password.length > 0) && !this.passwordValid(form.password)) {
      errors.password = this.lang.tr().admin.passwordInvalid;
    }

    return errors;
  });

  protected readonly formValid = computed(() => {
    const form = this.form();
    return (
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim()) &&
      /^[A-Za-z0-9_]{3,30}$/.test(form.username.trim()) &&
      form.displayName.trim().length > 0 &&
      form.displayName.trim().length <= 80 &&
      this.passwordValid(form.password) &&
      this.emailAvailable() !== false &&
      this.usernameAvailable() !== false &&
      !this.checkingEmail() &&
      !this.checkingUsername()
    );
  });

  private emailCheckTimer: ReturnType<typeof setTimeout> | null = null;
  private usernameCheckTimer: ReturnType<typeof setTimeout> | null = null;

  /**
   * Initialise la page en chargeant les comptes administrables.
   * Entree : aucune, Angular instancie le composant.
   * Sortie : signaux users/isLoading hydrates via loadUsers.
   */
  constructor() {
    this.loadUsers();
  }

  /**
   * Charge la liste des comptes pour l'onglet roles et les statistiques.
   * Entree : query() comme filtre facultatif.
   * Sortie : met a jour users() ou affiche une erreur de chargement.
   */
  protected loadUsers(): void {
    this.isLoading.set(true);
    this.http
      .get<AdminUser[]>(`${environment.apiBaseUrl}/users/admin/users`, {
        params: this.query().trim() ? { q: this.query().trim() } : {},
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (users) => {
          this.users.set(users);
          this.isLoading.set(false);
        },
        error: () => {
          this.isLoading.set(false);
          this.flash.show(this.lang.tr().admin.loadError, 'error');
        },
      });
  }

  /**
   * Met a jour un champ du formulaire et relance les controles associes.
   * Entrees : cle du champ et nouvelle valeur saisie.
   * Sortie : form() mis a jour, erreurs serveur nettoyees, checks email/username planifies si besoin.
   */
  protected updateForm<K extends keyof CreateUserForm>(key: K, value: CreateUserForm[K]): void {
    this.form.update((form) => ({ ...form, [key]: value }));
    this.serverFieldErrors.update((errors) => {
      const next = { ...errors };
      delete next[key];
      return next;
    });
    if (key === 'email') {
      this.scheduleEmailCheck(String(value));
    }
    if (key === 'username') {
      this.scheduleUsernameCheck(String(value));
    }
  }

  /**
   * Cree un compte depuis l'onglet creation.
   * Entree : form() courant apres validation locale et disponibilite email/username.
   * Sortie : ajoute le compte a users() ou place les erreurs sous les champs concernes.
   */
  protected createUser(): void {
    this.submitted.set(true);
    const form = this.form();
    if (!this.formValid()) {
      return;
    }

    this.creating.set(true);
    this.http
      .post<AdminUser>(`${environment.apiBaseUrl}/users/admin/users`, {
        email: form.email.trim(),
        password: form.password,
        username: form.username.trim(),
        displayName: form.displayName.trim(),
        role: form.role,
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (user) => {
          this.creating.set(false);
          this.users.update((users) => [user, ...users]);
          this.submitted.set(false);
          this.serverFieldErrors.set({});
          this.emailAvailable.set(null);
          this.usernameAvailable.set(null);
          this.form.set({ email: '', password: '', username: '', displayName: '', role: 'USER' });
          this.flash.show(this.lang.tr().admin.createSuccess, 'success');
        },
        error: (error: HttpErrorResponse) => {
          this.creating.set(false);
          this.applyCreationError(error);
        },
      });
  }

  /**
   * Change le role d'un utilisateur depuis l'onglet roles.
   * Entrees : utilisateur cible et role demande.
   * Sortie : remplace l'utilisateur dans users() par la reponse serveur ou affiche une erreur.
   */
  protected setRole(user: AdminUser, role: UserRole): void {
    if (user.role === role || this.busyAccountId()) return;

    this.busyAccountId.set(user.accountId);
    this.http
      .patch<AdminUser>(`${environment.apiBaseUrl}/users/admin/users/${user.accountId}/role`, { role })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (updated) => {
          this.busyAccountId.set(null);
          this.users.update((users) => users.map((item) => (item.accountId === updated.accountId ? updated : item)));
          this.flash.show(this.lang.tr().admin.roleUpdated, 'success');
        },
        error: (error: HttpErrorResponse) => {
          this.busyAccountId.set(null);
          this.flash.show(
            error.error?.error === 'cannot change own role'
              ? this.lang.tr().admin.selfRoleError
              : this.lang.tr().admin.roleUpdateError,
            'error',
          );
        },
      });
  }

  /**
   * Retourne le libelle traduit d'un role.
   * Entree : role technique USER, MODERATOR ou ADMIN.
   * Sortie : chaine traduite pour l'interface.
   */
  protected roleLabel(role: UserRole): string {
    switch (role) {
      case 'ADMIN':
        return this.lang.tr().admin.roleAdmin;
      case 'MODERATOR':
        return this.lang.tr().admin.roleModerator;
      default:
        return this.lang.tr().admin.roleUser;
    }
  }

  /**
   * Retourne le libelle traduit d'un statut de compte.
   * Entree : statut technique ACTIVE, SUSPENDED ou BANNED.
   * Sortie : chaine traduite pour l'interface.
   */
  protected statusLabel(status: string): string {
    switch (status) {
      case 'BANNED':
        return this.lang.tr().admin.statusBanned;
      case 'SUSPENDED':
        return this.lang.tr().admin.statusSuspended;
      default:
        return this.lang.tr().admin.statusActive;
    }
  }

  /**
   * Indique si l'admin courant peut modifier le role de la cible.
   * Entree : utilisateur affiche dans la liste.
   * Sortie : false pour son propre compte afin d'eviter l'auto-revocation.
   */
  protected canEditRole(user: AdminUser): boolean {
    return user.accountId !== this.auth.currentUser()?.id;
  }

  /**
   * Change l'onglet actif de la page d'administration.
   * Entree : identifiant d'onglet create ou roles.
   * Sortie : activeTab() mis a jour.
   */
  protected setTab(tab: AdminTab): void {
    this.activeTab.set(tab);
  }

  /**
   * Construit la checklist du mot de passe.
   * Entree : mot de passe saisi.
   * Sortie : liste de regles avec libelle traduit et etat valide/invalide.
   */
  protected passwordChecklist(password: string): { label: string; valid: boolean }[] {
    const form = this.form();
    const lower = password.toLowerCase();
    const emailLocal = form.email.split('@')[0]?.toLowerCase() ?? '';
    const username = form.username.trim().toLowerCase();
    const displayWords = form.displayName.toLowerCase().split(/[\s._-]+/).filter((word) => word.length >= 4);

    return [
      { label: this.lang.tr().admin.passwordRuleLength, valid: password.length >= 12 },
      { label: this.lang.tr().admin.passwordRuleUpper, valid: /[A-Z]/.test(password) },
      { label: this.lang.tr().admin.passwordRuleDigit, valid: /\d/.test(password) },
      { label: this.lang.tr().admin.passwordRuleSpecial, valid: /[^A-Za-z0-9]/.test(password) },
      {
        label: this.lang.tr().admin.passwordRuleNoUserInfo,
        valid:
          (!username || username.length < 3 || !lower.includes(username)) &&
          (!emailLocal || emailLocal.length < 3 || !lower.includes(emailLocal)) &&
          !displayWords.some((word) => lower.includes(word)),
      },
    ];
  }

  /**
   * Verifie que toutes les regles du mot de passe sont valides.
   * Entree : mot de passe saisi.
   * Sortie : true si toutes les regles de passwordChecklist sont valides.
   */
  private passwordValid(password: string): boolean {
    return this.passwordChecklist(password).every((item) => item.valid);
  }

  /**
   * Programme la verification de disponibilite d'un e-mail.
   * Entree : valeur courante du champ email.
   * Sortie : emailAvailable/checkingEmail mis a jour apres debounce et appel API.
   */
  private scheduleEmailCheck(value: string): void {
    if (this.emailCheckTimer) {
      clearTimeout(this.emailCheckTimer);
    }
    this.emailAvailable.set(null);
    const email = value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      this.checkingEmail.set(false);
      return;
    }

    this.checkingEmail.set(true);
    this.emailCheckTimer = setTimeout(() => {
      this.http
        .get<AvailabilityResponse>(`${environment.apiBaseUrl}/auth/check-email`, { params: { email } })
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: (response) => {
            if (this.form().email.trim() === email) {
              this.emailAvailable.set(response.available);
            }
            this.checkingEmail.set(false);
          },
          error: () => {
            this.checkingEmail.set(false);
          },
        });
    }, 350);
  }

  /**
   * Programme la verification de disponibilite d'un username.
   * Entree : valeur courante du champ username.
   * Sortie : usernameAvailable/checkingUsername mis a jour apres debounce et appel API.
   */
  private scheduleUsernameCheck(value: string): void {
    if (this.usernameCheckTimer) {
      clearTimeout(this.usernameCheckTimer);
    }
    this.usernameAvailable.set(null);
    const username = value.trim();
    if (!/^[A-Za-z0-9_]{3,30}$/.test(username)) {
      this.checkingUsername.set(false);
      return;
    }

    this.checkingUsername.set(true);
    this.usernameCheckTimer = setTimeout(() => {
      this.http
        .get<AvailabilityResponse>(`${environment.apiBaseUrl}/auth/check-username`, { params: { username } })
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: (response) => {
            if (this.form().username.trim() === username) {
              this.usernameAvailable.set(response.available);
            }
            this.checkingUsername.set(false);
          },
          error: () => {
            this.checkingUsername.set(false);
          },
        });
    }, 350);
  }

  /**
   * Transforme une erreur serveur de creation en erreur de champ.
   * Entree : HttpErrorResponse retournee par l'API.
   * Sortie : serverFieldErrors() renseigne pour afficher l'erreur au bon endroit.
   */
  private applyCreationError(error: HttpErrorResponse): void {
    switch (error.error?.error) {
      case 'email already registered':
        this.serverFieldErrors.set({ email: this.lang.tr().admin.emailConflict });
        return;
      case 'username already registered':
        this.serverFieldErrors.set({ username: this.lang.tr().admin.usernameConflict });
        return;
      case 'invalid user payload':
        this.serverFieldErrors.set({ password: this.lang.tr().admin.invalidPayload });
        return;
      default:
        this.serverFieldErrors.set({ email: this.lang.tr().admin.createError });
    }
  }
}
