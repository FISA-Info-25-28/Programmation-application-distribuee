import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PLATFORM_ID } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { of, throwError } from 'rxjs';

import { Auth } from './auth';
import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../../shared/flash/flash.service';
import { GuestService } from '../../core/services/guest.service';
import { LangService } from '../../core/services/lang.service';
import { ThemeService } from '../../core/services/theme.service';

const authSection = new Proxy({}, { get: (_target, prop) => String(prop) });
const lang = { tr: () => ({ auth: authSection }) };

describe('Auth', () => {
  let fixture: ComponentFixture<Auth>;
  let component: Auth;
  let auth: any;
  let router: { navigate: ReturnType<typeof vi.fn>; navigateByUrl: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    vi.useFakeTimers();
    auth = {
      login: vi.fn(() => of({})),
      register: vi.fn(() => of({})),
      forgotPassword: vi.fn(() => of({})),
      resetPassword: vi.fn(() => of({})),
      checkUsername: vi.fn(() => of({ available: true })),
      checkEmail: vi.fn(() => of({ available: true })),
      syncFromGoogle: vi.fn(() => of({})),
      verifyEmail: vi.fn(() => of({})),
    };
    router = { navigate: vi.fn(), navigateByUrl: vi.fn() };
    flash = { show: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [Auth],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { snapshot: { queryParamMap: { get: vi.fn(() => null) } } },
        },
        { provide: Router, useValue: router },
        { provide: AuthService, useValue: auth },
        { provide: ThemeService, useValue: { refreshForCurrentUser: vi.fn() } },
        { provide: FlashService, useValue: flash },
        { provide: LangService, useValue: lang },
        { provide: GuestService, useValue: { activate: vi.fn() } },
        { provide: PLATFORM_ID, useValue: 'browser' },
      ],
    })
      .overrideComponent(Auth, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Auth);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('creates', () => {
    expect(component).toBeTruthy();
  });

  it('switches between auth modes', () => {
    (component as any).showRegister();
    expect((component as any).mode()).toBe('register');

    (component as any).showForgot();
    expect((component as any).mode()).toBe('forgot');
  });

  it('checks username availability after debounce', () => {
    (component as any).updateRegisterUsername('available_user');
    vi.advanceTimersByTime(350);

    expect(auth.checkUsername).toHaveBeenCalledWith('available_user');
    expect((component as any).usernameAvailability()).toBe('available');
  });

  it('logs in and navigates home', () => {
    (component as any).loginEmail.set('ada@example.com');
    (component as any).loginPassword.set('secret');

    (component as any).onSubmit(new SubmitEvent('submit'));

    expect(auth.login).toHaveBeenCalledWith('ada@example.com', 'secret');
    expect(router.navigateByUrl).toHaveBeenCalledWith('/home');
  });

  it('shows invalid login feedback on 401', () => {
    auth.login.mockReturnValueOnce(throwError(() => new HttpErrorResponse({ status: 401 })));
    (component as any).loginEmail.set('ada@example.com');
    (component as any).loginPassword.set('bad');

    (component as any).onSubmit(new SubmitEvent('submit'));

    expect(flash.show).toHaveBeenCalledWith('loginInvalid', 'error');
  });
});
