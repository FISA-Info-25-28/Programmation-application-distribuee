import { HttpErrorResponse } from '@angular/common/http';
import { isPlatformBrowser } from '@angular/common';
import { Component, computed, Inject, OnDestroy, OnInit, PLATFORM_ID, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';
import { ThemeService } from '../../core/services/theme.service';
import { FlashService } from '../../shared/flash/flash.service';
import { LegalDialog } from '../../shared/legal-dialog/legal-dialog';
import { LangService } from '../../core/services/lang.service';
import { GuestService } from '../../core/services/guest.service';
import { TPipe } from '../../core/pipes/t.pipe';

type RegisterField = 'name' | 'username' | 'email' | 'password' | 'passwordConfirm' | 'terms';
type RegisterErrors = Partial<Record<RegisterField, string>>;
type UsernameAvailability = 'idle' | 'checking' | 'available' | 'taken';
type EmailAvailability = 'idle' | 'checking' | 'available' | 'taken';

@Component({
  selector: 'app-auth',
  imports: [FormsModule, LegalDialog, TPipe],
  templateUrl: './auth.html',
  styleUrl: './auth.css',
})
export class Auth implements OnInit, OnDestroy {
  private readonly rememberKey = 'breezy.remember';
  private usernameCheckTimer: ReturnType<typeof setTimeout> | null = null;
  private usernameCheckSubscription?: Subscription;
  private emailCheckTimer: ReturnType<typeof setTimeout> | null = null;
  private emailCheckSubscription?: Subscription;

  protected readonly mode = signal<'login' | 'register' | 'forgot' | 'reset'>('login');
  protected readonly showLoginPassword = signal(false);
  protected readonly showRegisterPassword = signal(false);
  protected readonly isSubmitting = signal(false);
  protected readonly loginEmail = signal('');
  protected readonly loginPassword = signal('');
  protected readonly rememberMe = signal(false);
  protected readonly registerName = signal('');
  protected readonly registerUsername = signal('');
  protected readonly registerEmail = signal('');
  protected readonly registerPassword = signal('');
  protected readonly registerPasswordConfirm = signal('');
  protected readonly registerTermsAccepted = signal(false);
  protected readonly registerTermsAcknowledged = signal(false);
  protected readonly registerErrors = signal<RegisterErrors>({});
  protected readonly usernameAvailability = signal<UsernameAvailability>('idle');
  protected readonly emailAvailability = signal<EmailAvailability>('idle');
  protected readonly forgotEmail = signal('');
  protected readonly forgotSent = signal(false);
  protected readonly resetToken = signal('');
  protected readonly resetNewPassword = signal('');
  protected readonly resetConfirm = signal('');
  protected readonly showResetPassword = signal(false);
  protected readonly showLegalDialog = signal(false);

  private static readonly SPECIAL_RE = /[!@#$%^&*()\-_+=[\]{}|;:'",.<>?/~\\]/;

  protected readonly passwordRules = computed(() => {
    const pwd = this.registerPassword();
    const lower = pwd.toLowerCase();
    const username = this.registerUsername().trim().toLowerCase();
    const emailLocal = this.registerEmail().trim().split('@')[0].toLowerCase();
    const nameWords = this.registerName().trim().toLowerCase()
      .split(/[\s\-_.]+/)
      .filter(w => w.length >= 4);
    const noUserInfo =
      (username.length < 3 || !lower.includes(username)) &&
      (emailLocal.length < 3 || !lower.includes(emailLocal)) &&
      nameWords.every(w => !lower.includes(w));
    return {
      length: pwd.length >= 12,
      uppercase: /[A-Z]/.test(pwd),
      digit: /[0-9]/.test(pwd),
      special: Auth.SPECIAL_RE.test(pwd),
      noUserInfo,
    };
  });

  protected readonly passwordValid = computed(() => {
    const r = this.passwordRules();
    return r.length && r.uppercase && r.digit && r.special && r.noUserInfo;
  });

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly auth: AuthService,
    private readonly theme: ThemeService,
    private readonly flash: FlashService,
    private readonly lang: LangService,
    private readonly guest: GuestService,
    @Inject(PLATFORM_ID) private readonly platformId: object,
  ) {}

  ngOnInit(): void {
    this.handleGoogleCallback();
    this.handleEmailVerification();
    this.handleResetToken();

    if (!this.isBrowser()) {
      return;
    }

    const tab = this.route.snapshot.queryParamMap.get('tab');
    if (tab === 'register') this.mode.set('register');

    const remembered = localStorage.getItem(this.rememberKey);
    if (!remembered) {
      return;
    }

    try {
      const value = JSON.parse(remembered) as { email?: string; remember?: boolean };
      this.loginEmail.set(value.email ?? '');
      this.rememberMe.set(Boolean(value.remember));
    } catch {
      localStorage.removeItem(this.rememberKey);
    }
  }

  protected showLogin(): void {
    this.mode.set('login');
  }

  protected showRegister(): void {
    this.mode.set('register');
  }

  protected showForgot(): void {
    this.forgotSent.set(false);
    this.mode.set('forgot');
  }

  protected enterGuestMode(): void {
    this.guest.activate();
  }

  ngOnDestroy(): void {
    this.cancelUsernameCheck();
    this.cancelEmailCheck();
  }

  protected updateRegisterName(value: string): void {
    this.registerName.set(value);
    this.clearRegisterError('name');
  }

  protected updateRegisterUsername(value: string): void {
    this.registerUsername.set(value);
    this.clearRegisterError('username');
    this.queueUsernameCheck(value);
  }

  protected updateRegisterEmail(value: string): void {
    this.registerEmail.set(value);
    this.clearRegisterError('email');
    this.queueEmailCheck(value);
  }

  protected updateRegisterPassword(value: string): void {
    this.registerPassword.set(value);
    this.clearRegisterError('password');
    this.clearRegisterError('passwordConfirm');
  }

  protected updateRegisterPasswordConfirm(value: string): void {
    this.registerPasswordConfirm.set(value);
    this.clearRegisterError('passwordConfirm');
  }

  protected updateRegisterTermsAccepted(value: boolean): void {
    if (value && !this.registerTermsAcknowledged()) {
      this.registerTermsAccepted.set(false);
      this.setRegisterError('terms', this.lang.tr().auth.termsRequired);
      this.showLegalDialog.set(true);
      return;
    }
    this.registerTermsAccepted.set(value);
    this.clearRegisterError('terms');
  }

  protected registerError(field: RegisterField): string | null {
    if (
      field === 'passwordConfirm' &&
      !this.registerErrors()[field] &&
      this.registerPasswordConfirm().length > 0 &&
      this.registerPassword() !== this.registerPasswordConfirm()
    ) {
      return this.lang.tr().auth.pwMismatch;
    }

    return this.registerErrors()[field] ?? null;
  }

  protected registerValid(field: RegisterField): boolean {
    if (this.registerError(field)) return false;

    switch (field) {
      case 'name': {
        const value = this.registerName().trim();
        return value.length > 0 && value.length <= 80;
      }
      case 'username':
        return (
          /^[A-Za-z0-9_]{3,30}$/.test(this.registerUsername().trim()) &&
          this.usernameAvailability() === 'available'
        );
      case 'email':
        return (
          /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.registerEmail().trim()) &&
          this.emailAvailability() === 'available'
        );
      case 'password':
        return this.passwordValid();
      case 'passwordConfirm': {
        const value = this.registerPasswordConfirm();
        return value.length > 0 && value === this.registerPassword() && this.registerValid('password');
      }
      case 'terms':
        return this.registerTermsAccepted();
    }
  }

  protected toggleLoginPassword(): void {
    this.showLoginPassword.update((value) => !value);
  }

  protected toggleRegisterPassword(): void {
    this.showRegisterPassword.update((value) => !value);
  }

  protected openLegalDialog(): void {
    this.showLegalDialog.set(true);
  }

  protected closeLegalDialog(): void {
    this.showLegalDialog.set(false);
  }

  protected acceptLegalDialog(): void {
    this.registerTermsAcknowledged.set(true);
    this.registerTermsAccepted.set(true);
    this.clearRegisterError('terms');
  }

  protected forgotPassword(event: Event): void {
    event.preventDefault();
    this.showForgot();
  }

  protected submitForgot(event: Event): void {
    event.preventDefault();
    if (this.isSubmitting()) return;
    const email = this.forgotEmail().trim();
    if (!email) {
      this.flash.show(this.lang.tr().auth.forgotEmailEmpty, 'error');
      return;
    }
    this.isSubmitting.set(true);
    this.auth.forgotPassword(email).subscribe({
      next: () => {
        this.isSubmitting.set(false);
        this.forgotSent.set(true);
      },
      error: () => {
        this.isSubmitting.set(false);
        this.forgotSent.set(true);
      },
    });
  }

  protected submitReset(event: Event): void {
    event.preventDefault();
    if (this.isSubmitting()) return;
    const newPassword = this.resetNewPassword();
    const confirm = this.resetConfirm();
    if (newPassword.length < 8 || !/[A-Z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
      this.flash.show(this.lang.tr().auth.resetPasswordWeak, 'error');
      return;
    }
    if (newPassword !== confirm) {
      this.flash.show(this.lang.tr().auth.pwMismatch, 'error');
      return;
    }
    this.isSubmitting.set(true);
    this.auth.resetPassword(this.resetToken(), newPassword).subscribe({
      next: () => {
        this.isSubmitting.set(false);
        this.resetNewPassword.set('');
        this.resetConfirm.set('');
        this.resetToken.set('');
        this.mode.set('login');
        void this.router.navigate([], {
          relativeTo: this.route,
          queryParams: { resetToken: null },
          queryParamsHandling: 'merge',
          replaceUrl: true,
        });
        this.flash.show(this.lang.tr().auth.resetPasswordSuccess, 'success');
      },
      error: (err: HttpErrorResponse) => {
        this.isSubmitting.set(false);
        const apiError = this.apiErrorMessage(err);
        if (apiError === 'expired reset token') {
          this.flash.show(this.lang.tr().auth.resetLinkExpired, 'error');
        } else {
          this.flash.show(this.lang.tr().auth.resetLinkInvalid, 'error');
        }
      },
    });
  }

  protected toggleResetPassword(): void {
    this.showResetPassword.update((v) => !v);
  }

  protected onSubmit(event: SubmitEvent): void {
    event.preventDefault();
    if (this.isSubmitting()) return;

    if (this.mode() === 'login') {
      this.login();
      return;
    }

    this.register();
  }

  private login(): void {
    const email = this.loginEmail().trim();
    const password = this.loginPassword();

    if (!email || !password) {
      this.flash.show(this.lang.tr().auth.loginEmpty, 'error');
      return;
    }

    this.isSubmitting.set(true);
    this.auth.login(email, password).subscribe({
      next: () => {
        this.theme.refreshForCurrentUser();
        this.persistRememberedEmail(email);
        this.flash.show(this.lang.tr().auth.loginSuccess, 'success');
        void this.router.navigateByUrl('/home');
      },
      error: (err: HttpErrorResponse) => {
        this.isSubmitting.set(false);
        if (err.status === 401) {
          this.flash.show(this.lang.tr().auth.loginInvalid, 'error');
          return;
        }
        if (err.status === 403) {
          const apiError = this.apiErrorMessage(err);
          if (apiError === 'email not verified') {
            this.flash.show(this.lang.tr().auth.emailNotVerified, 'error');
            return;
          }
          if (apiError === 'account suspended') {
            const rawUntil = (err.error as Record<string, unknown>)?.['suspendedUntil'];
            const untilStr = typeof rawUntil === 'string' ? this.formatSuspensionDate(rawUntil) : null;
            const t = this.lang.tr().auth;
            const msg = untilStr
              ? `${t.accountSuspendedUntil} ${untilStr}. ${t.checkEmailsInfo}`
              : t.accountSuspended;
            this.flash.show(msg, 'error');
            return;
          }
          if (apiError === 'account banned') {
            this.flash.show(this.lang.tr().auth.accountBanned, 'error');
            return;
          }
        }
        this.flash.show(this.lang.tr().auth.loginError, 'error');
      },
      complete: () => this.isSubmitting.set(false),
    });
  }

  private register(): void {
    this.registerErrors.set({});

    const displayName = this.registerName().trim();
    const username = this.registerUsername().trim();
    const email = this.registerEmail().trim();
    const password = this.registerPassword();
    const passwordConfirm = this.registerPasswordConfirm();
    const termsAccepted = this.registerTermsAccepted();

    const errors = this.validateRegisterForm(displayName, username, email, password, passwordConfirm, termsAccepted);
    if (Object.keys(errors).length > 0) {
      this.registerErrors.set(errors);
      return;
    }

    this.isSubmitting.set(true);
    this.auth.register(email, password, {
      username,
      displayName,
    }).subscribe({
      next: () => {
        this.persistRememberedEmail(email);
        this.mode.set('login');
        this.loginEmail.set(email);
        this.loginPassword.set('');
        this.registerName.set('');
        this.registerUsername.set('');
        this.registerEmail.set('');
        this.registerPassword.set('');
        this.registerPasswordConfirm.set('');
        this.registerTermsAccepted.set(false);
        this.usernameAvailability.set('idle');
        this.emailAvailability.set('idle');
        this.flash.show(this.lang.tr().auth.registerSuccess, 'success');
      },
      error: (err: HttpErrorResponse) => {
        this.isSubmitting.set(false);
        if (err.status === 409) {
          const apiError = this.apiErrorMessage(err);
          if (apiError === 'username already registered') {
            this.setRegisterError('username', this.lang.tr().auth.registerUsernameTaken);
            return;
          }

          this.setRegisterError('email', this.lang.tr().auth.registerConflict);
          return;
        }
        if (err.status === 400) {
          const apiError = this.apiErrorMessage(err);
          if (apiError === 'invalid username') {
            this.setRegisterError('username', this.lang.tr().auth.registerInvalidUsername);
            return;
          }

          this.flash.show(this.lang.tr().auth.registerBadRequest, 'error');
          return;
        }
        this.flash.show(this.lang.tr().auth.registerError, 'error');
      },
      complete: () => this.isSubmitting.set(false),
    });
  }

  private validateRegisterForm(
    displayName: string,
    username: string,
    email: string,
    password: string,
    passwordConfirm: string,
    termsAccepted: boolean,
  ): RegisterErrors {
    const errors: RegisterErrors = {};

    const a = this.lang.tr().auth;

    if (!displayName) {
      errors.name = a.nameRequired;
    } else if (displayName.length > 80) {
      errors.name = a.nameTooLong;
    }

    if (!username) {
      errors.username = a.usernameRequired;
    } else if (!/^[A-Za-z0-9_]{3,30}$/.test(username)) {
      errors.username = a.usernameFormat;
    } else if (this.usernameAvailability() === 'taken') {
      errors.username = a.usernameTakenError;
    }

    if (!email) {
      errors.email = a.emailRequired;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      errors.email = a.emailInvalid;
    } else if (this.emailAvailability() === 'taken') {
      errors.email = a.emailTakenError;
    }

    if (!password) {
      errors.password = a.passwordRequired;
    } else if (!this.passwordValid()) {
      errors.password = a.passwordWeakError;
    }

    if (!passwordConfirm) {
      errors.passwordConfirm = a.passwordConfirmRequired;
    } else if (password !== passwordConfirm) {
      errors.passwordConfirm = a.pwMismatch;
    }

    if (!termsAccepted) {
      errors.terms = this.lang.tr().auth.termsRequired;
    }

    return errors;
  }

  private setRegisterError(field: RegisterField, message: string): void {
    this.registerErrors.update((errors) => ({ ...errors, [field]: message }));
  }

  private queueUsernameCheck(value: string): void {
    this.cancelUsernameCheck();

    const username = value.trim();
    if (!/^[A-Za-z0-9_]{3,30}$/.test(username)) {
      this.usernameAvailability.set('idle');
      return;
    }

    this.usernameAvailability.set('checking');
    this.usernameCheckTimer = setTimeout(() => {
      this.usernameCheckSubscription = this.auth.checkUsername(username).subscribe({
        next: ({ available }) => {
          if (this.registerUsername().trim() !== username) return;
          this.usernameAvailability.set(available ? 'available' : 'taken');
          if (!available) {
            this.setRegisterError('username', this.lang.tr().auth.usernameTakenError);
          }
        },
        error: () => {
          if (this.registerUsername().trim() === username) {
            this.usernameAvailability.set('idle');
          }
        },
      });
    }, 350);
  }

  private cancelUsernameCheck(): void {
    if (this.usernameCheckTimer) {
      clearTimeout(this.usernameCheckTimer);
      this.usernameCheckTimer = null;
    }
    this.usernameCheckSubscription?.unsubscribe();
    this.usernameCheckSubscription = undefined;
  }

  private queueEmailCheck(value: string): void {
    this.cancelEmailCheck();

    const email = value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      this.emailAvailability.set('idle');
      return;
    }

    this.emailAvailability.set('checking');
    this.emailCheckTimer = setTimeout(() => {
      this.emailCheckSubscription = this.auth.checkEmail(email).subscribe({
        next: ({ available }) => {
          if (this.registerEmail().trim() !== email) return;
          this.emailAvailability.set(available ? 'available' : 'taken');
          if (!available) {
            this.setRegisterError('email', this.lang.tr().auth.emailTakenError);
          }
        },
        error: () => {
          if (this.registerEmail().trim() === email) {
            this.emailAvailability.set('idle');
          }
        },
      });
    }, 350);
  }

  private cancelEmailCheck(): void {
    if (this.emailCheckTimer) {
      clearTimeout(this.emailCheckTimer);
      this.emailCheckTimer = null;
    }
    this.emailCheckSubscription?.unsubscribe();
    this.emailCheckSubscription = undefined;
  }

  private clearRegisterError(field: RegisterField): void {
    this.registerErrors.update((errors) => {
      if (!errors[field]) return errors;
      const next = { ...errors };
      delete next[field];
      return next;
    });
  }

  private apiErrorMessage(err: HttpErrorResponse): string | null {
    if (err.error && typeof err.error === 'object' && 'error' in err.error) {
      return String(err.error.error);
    }
    return null;
  }

  private formatSuspensionDate(iso: string): string | null {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return null;
    return d.toLocaleString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  private persistRememberedEmail(email: string): void {
    if (!this.isBrowser()) {
      return;
    }

    if (this.rememberMe()) {
      localStorage.setItem(
        this.rememberKey,
        JSON.stringify({
          email,
          remember: true,
        }),
      );
      return;
    }

    localStorage.removeItem(this.rememberKey);
  }

  private isBrowser(): boolean {
    return isPlatformBrowser(this.platformId);
  }

  protected loginWithGoogle(): void {
    if (!this.isBrowser()) return;
    window.location.href = '/api/auth/google';
  }

  protected loginWithGitHub(): void {
    if (!this.isBrowser()) return;
    window.location.href = '/api/auth/github';
  }

  private handleGoogleCallback(): void {
    if (!this.isBrowser()) return;

    const google = this.route.snapshot.queryParamMap.get('google');
    const github = this.route.snapshot.queryParamMap.get('github');
    const hasError =
      !!this.route.snapshot.queryParamMap.get('googleError') ||
      !!this.route.snapshot.queryParamMap.get('githubError');
    const isSuccess = google === '1' || github === '1';

    if (!isSuccess && !hasError) return;

    const clearParams = () => {
      void this.router.navigate([], {
        relativeTo: this.route,
        queryParams: { google: null, googleError: null, github: null, githubError: null },
        queryParamsHandling: 'merge',
        replaceUrl: true,
      });
    };

    if (hasError) {
      clearParams();
      this.flash.show(this.lang.tr().auth.oauthCancelled, 'error');
      return;
    }

    this.isSubmitting.set(true);
    this.auth.syncFromGoogle().subscribe({
      next: () => {
        clearParams();
        this.isSubmitting.set(false);
        this.flash.show(this.lang.tr().auth.loginSuccess, 'success');
        void this.router.navigateByUrl('/home');
      },
      error: () => {
        clearParams();
        this.isSubmitting.set(false);
        this.flash.show(this.lang.tr().auth.oauthError, 'error');
      },
    });
  }

  private handleEmailVerification(): void {
    const token = this.route.snapshot.queryParamMap.get('verifyEmailToken')?.trim();
    if (!token) {
      return;
    }

    this.auth.verifyEmail(token).subscribe({
      next: () => {
        this.mode.set('login');
        this.flash.show(this.lang.tr().auth.emailVerifiedSuccess, 'success');
        void this.router.navigate([], {
          relativeTo: this.route,
          queryParams: { verifyEmailToken: null },
          queryParamsHandling: 'merge',
          replaceUrl: true,
        });
      },
      error: (err: HttpErrorResponse) => {
        const apiError = this.apiErrorMessage(err);
        if (apiError === 'expired verification token') {
          this.flash.show(this.lang.tr().auth.verificationLinkExpired, 'error');
        } else {
          this.flash.show(this.lang.tr().auth.verificationLinkInvalid, 'error');
        }

        void this.router.navigate([], {
          relativeTo: this.route,
          queryParams: { verifyEmailToken: null },
          queryParamsHandling: 'merge',
          replaceUrl: true,
        });
      },
    });
  }

  private handleResetToken(): void {
    const token = this.route.snapshot.queryParamMap.get('resetToken')?.trim();
    if (!token) return;
    this.resetToken.set(token);
    this.mode.set('reset');
  }
}
