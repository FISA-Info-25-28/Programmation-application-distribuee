import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { Bookmarks } from './bookmarks';
import { AuthService } from '../../core/services/auth.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { User } from '../../core/models/user.model';
import { Post } from '../../core/models/post.model';

const user: User = {
  id: 'user-1',
  profileId: 'profile-1',
  username: 'ada',
  displayName: 'Ada',
  email: 'ada@example.test',
  role: 'USER',
  bio: null,
  avatarUrl: null,
  followersCount: 0,
  followingCount: 0,
  postsCount: 0,
  createdAt: '2026-01-01T00:00:00Z',
};

describe('Bookmarks', () => {
  let fixture: ComponentFixture<Bookmarks>;
  let component: Bookmarks;
  let http: { get: ReturnType<typeof vi.fn> };

  async function createComponent(response = of({ posts: [] as unknown[] })): Promise<void> {
    http = { get: vi.fn().mockReturnValue(response) };
    await TestBed.configureTestingModule({
      imports: [Bookmarks],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: AuthService, useValue: { currentUser: vi.fn(() => user) } },
        { provide: ScrollStateService, useValue: { headerHidden: vi.fn(() => false) } },
      ],
    })
      .overrideComponent(Bookmarks, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Bookmarks);
    component = fixture.componentInstance;
  }

  afterEach(() => {
    TestBed.resetTestingModule();
  });

  it('loads bookmarked posts and maps api data', async () => {
    await createComponent(
      of({
        posts: [
          {
            id: 'post-1',
            authorId: 'profile-1',
            content: 'Saved #Angular',
            parentId: null,
            visibility: 'PUBLIC',
            createdAt: '2026-01-01T00:00:00Z',
            updatedAt: '2026-01-01T00:00:00Z',
          },
        ],
      }),
    );

    expect(http.get).toHaveBeenCalledWith(expect.stringContaining('/posts/bookmarks'));
    expect((component as any).loading()).toBe(false);
    expect((component as any).error()).toBe(false);
    expect((component as any).posts()[0]).toEqual(
      expect.objectContaining({ id: 'post-1', tags: ['Angular'] }),
    );
  });

  it('sets an error state when loading fails', async () => {
    await createComponent(throwError(() => new Error('network')));

    expect((component as any).loading()).toBe(false);
    expect((component as any).error()).toBe(true);
    expect((component as any).posts()).toEqual([]);
  });

  it('updates or removes posts from the local list', async () => {
    await createComponent();
    const post = {
      id: 'post-1',
      author: { id: 'user-1', username: 'ada', displayName: 'Ada', avatarUrl: null },
      content: 'Saved',
      lang: '',
      visibility: 'PUBLIC',
      tags: [],
      likeCount: 0,
      replyCount: 0,
      repostCount: 0,
      isLiked: false,
      isReposted: false,
      isBookmarked: true,
      parentId: null,
      createdAt: '2026-01-01T00:00:00Z',
      media: [],
    } satisfies Post;
    (component as any).posts.set([post]);

    (component as any).updatePost({ ...post, content: 'Updated' });
    expect((component as any).posts()[0].content).toBe('Updated');

    (component as any).updatePost({ ...post, isBookmarked: false });
    expect((component as any).posts()).toEqual([]);

    (component as any).posts.set([post]);
    (component as any).removePost('post-1');
    expect((component as any).posts()).toEqual([]);
  });
});
