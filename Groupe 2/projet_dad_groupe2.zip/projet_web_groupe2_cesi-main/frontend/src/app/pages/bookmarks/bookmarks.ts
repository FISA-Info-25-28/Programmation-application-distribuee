import { ChangeDetectionStrategy, Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';

import { Post } from '../../core/models/post.model';
import { mapApiPosts } from '../../core/mappers/post.mapper';
import { AuthService } from '../../core/services/auth.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { PostCard } from '../../shared/post-card/post-card';
import { TPipe } from '../../core/pipes/t.pipe';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-bookmarks',
  templateUrl: './bookmarks.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [PostCard, TPipe],
  styles: [`
    @media (max-width: 1023px) {
      .bookmarks-sticky { transition: transform 300ms ease-in-out; }
      .bookmarks-sticky.header-is-hidden { transform: translateY(-57px); }
    }
  `],
})
export class Bookmarks {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly destroyRef = inject(DestroyRef);
  readonly scrollState = inject(ScrollStateService);

  protected readonly posts = signal<Post[]>([]);
  protected readonly loading = signal(true);
  protected readonly error = signal(false);

  constructor() {
    this.http
      .get<{ posts: unknown[] }>(`${environment.apiBaseUrl}/posts/bookmarks`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (res) => {
          this.posts.set(mapApiPosts(res, this.auth.currentUser()));
          this.loading.set(false);
        },
        error: () => {
          this.error.set(true);
          this.loading.set(false);
        },
      });
  }

  protected updatePost(updated: Post): void {
    this.posts.update((list) => {
      const next = list.map((p) => (p.id === updated.id ? updated : p));
      return updated.isBookmarked ? next : next.filter((p) => p.id !== updated.id);
    });
  }

  protected removePost(id: string): void {
    this.posts.update((list) => list.filter((p) => p.id !== id));
  }
}
