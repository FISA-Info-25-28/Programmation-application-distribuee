import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { signal } from '@angular/core';
import { of } from 'rxjs';

import { Feed } from './feed';
import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../../shared/flash/flash.service';
import { GuestService } from '../../core/services/guest.service';
import { LangService } from '../../core/services/lang.service';
import { MediaService } from '../../core/services/media.service';
import { PostBusService } from '../../core/services/post-bus.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { Post } from '../../core/models/post.model';

const lang = { tr: () => ({ composer: { publishSuccess: 'ok', publishError: 'ko', mediaLimitReached: 'limit' } }) };
const user = { id: 'u1', profileId: 'p1', username: 'ada', displayName: 'Ada', avatarUrl: null, isPrivate: false };
const apiPost = {
  id: 'post-1',
  author: { id: 'p1', username: 'ada', displayName: 'Ada', avatarUrl: null },
  authorId: 'p1',
  authorUsername: 'ada',
  authorDisplayName: 'Ada',
  authorAvatarUrl: null,
  content: 'Hello',
  visibility: 'PUBLIC',
  tags: [],
  lang: 'fr',
  likeCount: 0,
  replyCount: 0,
  repostCount: 0,
  likedByMe: false,
  repostedByMe: false,
  bookmarkedByMe: false,
  parentId: null,
  createdAt: '2026-06-24T10:00:00Z',
  media: [],
};

describe('Feed', () => {
  let fixture: ComponentFixture<Feed>;
  let component: Feed;
  let http: { get: ReturnType<typeof vi.fn>; post: ReturnType<typeof vi.fn> };
  let postBus: { newPost: ReturnType<typeof signal<Post | null>>; announce: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    http = { get: vi.fn(() => of({ posts: [apiPost] })), post: vi.fn(() => of(apiPost)) };
    postBus = { newPost: signal<Post | null>(null), announce: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [Feed],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: FlashService, useValue: { show: vi.fn() } },
        { provide: LangService, useValue: lang },
        { provide: PostBusService, useValue: postBus },
        { provide: MediaService, useValue: { validate: vi.fn(() => null), upload: vi.fn(() => of({ mediaType: 'IMAGE', url: '/a.png' })) } },
        { provide: ScrollStateService, useValue: { headerHidden: signal(false), update: vi.fn() } },
        { provide: AuthService, useValue: { currentUser: signal(user).asReadonly() } },
        { provide: GuestService, useValue: { requireAuth: vi.fn(() => true) } },
      ],
    })
      .overrideComponent(Feed, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Feed);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('creates and loads posts', () => {
    expect(component).toBeTruthy();
    expect((component as any).posts().length).toBe(1);
    expect((component as any).isLoadingPosts()).toBe(false);
  });

  it('switches to following and loads that feed once', () => {
    (component as any).switchTab('following');

    expect((component as any).activeTab()).toBe('following');
    expect((component as any).followingLoaded()).toBe(true);
  });

  it('submits a post and resets the composer', () => {
    (component as any).composerText.set('Hello world');

    (component as any).submitPost();

    expect(http.post).toHaveBeenCalled();
    expect((component as any).composerText()).toBe('');
    expect((component as any).isSubmitting()).toBe(false);
  });
});
