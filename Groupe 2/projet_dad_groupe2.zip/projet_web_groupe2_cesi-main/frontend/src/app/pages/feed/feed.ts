import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  effect,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { forkJoin } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { GuestService } from '../../core/services/guest.service';
import { FlashService } from '../../shared/flash/flash.service';
import { LangService } from '../../core/services/lang.service';
import { TPipe } from '../../core/pipes/t.pipe';
import { PostBusService } from '../../core/services/post-bus.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { mapApiPost, mapApiPosts } from '../../core/mappers/post.mapper';
import { ApiPost, ApiPostCollectionResponse } from '../../core/models/api-post.model';
import { Post } from '../../core/models/post.model';
import { environment } from '../../../environments/environment';
import { MediaAttachment } from '../../core/models/media.model';
import { MediaService } from '../../core/services/media.service';
import { EmojiPicker } from '../../shared/emoji-picker/emoji-picker';
import { MediaPickerButton } from '../../shared/media-picker-button/media-picker-button';
import { MediaPreview } from '../../shared/media-preview/media-preview';
import { MentionSuggestions } from '../../shared/mention-suggestions/mention-suggestions';
import { insertMention } from '../../core/utils/social-text';
import { PollCreator, PollDraft } from '../../shared/poll-creator/poll-creator';
import { UserAvatar } from '../../shared/user-avatar/user-avatar';
import { launchConfetti, shouldCelebratePost } from '../../core/utils/confetti';
import { ForYouFeed } from './for-you-feed/for-you-feed';
import { FollowingFeed } from './following-feed/following-feed';

type FeedTab = 'for-you' | 'following';
type FeedResponse = Post[] | ApiPostCollectionResponse;

@Component({
  selector: 'app-feed',
  templateUrl: './feed.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    FormsModule,
    TPipe,
    EmojiPicker,
    MediaPickerButton,
    MediaPreview,
    MentionSuggestions,
    PollCreator,
    UserAvatar,
    ForYouFeed,
    FollowingFeed,
  ],
})
export class Feed {
  private readonly http = inject(HttpClient);
  private readonly flash = inject(FlashService);
  protected readonly lang = inject(LangService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly postBus = inject(PostBusService);
  private readonly mediaService = inject(MediaService);
  protected readonly scrollState = inject(ScrollStateService);
  protected readonly auth = inject(AuthService);
  protected readonly guest = inject(GuestService);

  protected readonly posts = signal<Post[]>([]);
  protected readonly isLoadingPosts = signal(true);

  protected readonly activeTab = signal<FeedTab>('for-you');
  protected readonly followingPosts = signal<Post[]>([]);
  protected readonly isLoadingFollowing = signal(false);
  protected readonly followingLoaded = signal(false);

  protected readonly composerText = signal('');
  protected readonly composerFocused = signal(false);
  protected readonly isSubmitting = signal(false);
  protected readonly isUploading = signal(false);
  protected readonly selectedMedia = signal<MediaAttachment[]>([]);
  protected readonly composerVisibility = signal<'PUBLIC' | 'FOLLOWERS' | 'PRIVATE'>('PUBLIC');
  protected readonly emojiPickerOpen = signal(false);
  protected readonly pollOpen = signal(false);
  protected readonly pollDraft = signal<PollDraft | null>(null);

  constructor() {
    this.http
      .get<FeedResponse>(`${environment.apiBaseUrl}/posts/feed`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (data) => {
          this.posts.set(this.normalizePosts(data));
          this.isLoadingPosts.set(false);
        },
        error: () => this.isLoadingPosts.set(false),
      });

    effect(() => {
      const p = this.postBus.newPost();
      if (p) this.posts.update((list) => [p, ...list.filter((x) => x.id !== p.id)]);
    });

    effect(() => {
      if (this.auth.currentUser()?.isPrivate === true && this.composerVisibility() === 'PUBLIC') {
        this.composerVisibility.set('FOLLOWERS');
      }
    });

    effect(() => {
      const user = this.auth.currentUser();
      if (!user?.profileId) return;
      this.posts.update((list) => this.applyCurrentUserAuthor(list));
      this.followingPosts.update((list) => this.applyCurrentUserAuthor(list));
    });
  }

  protected get charsLeft(): number {
    return 280 - this.composerText().length;
  }

  protected get canSubmit(): boolean {
    const t = this.composerText().trim();
    const hasPoll = this.pollDraft() !== null;
    return (
      (t.length > 0 || this.selectedMedia().length > 0 || hasPoll) &&
      t.length <= 280 &&
      !this.isSubmitting() &&
      !this.isUploading()
    );
  }

  protected isPrivateProfile(): boolean {
    return this.auth.currentUser()?.isPrivate === true;
  }

  protected defaultComposerVisibility(): 'PUBLIC' | 'FOLLOWERS' {
    return this.isPrivateProfile() ? 'FOLLOWERS' : 'PUBLIC';
  }

  protected setComposerVisibility(visibility: 'PUBLIC' | 'FOLLOWERS' | 'PRIVATE'): void {
    if (visibility === 'PUBLIC' && this.isPrivateProfile()) {
      this.composerVisibility.set('FOLLOWERS');
      return;
    }
    this.composerVisibility.set(visibility);
  }

  protected switchTab(tab: FeedTab): void {
    if (tab === 'following' && !this.guest.requireAuth()) return;
    this.activeTab.set(tab);
    if (tab === 'following' && !this.followingLoaded()) {
      this.isLoadingFollowing.set(true);
      this.http
        .get<FeedResponse>(`${environment.apiBaseUrl}/posts/following`)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: (data) => {
            this.followingPosts.set(this.normalizePosts(data));
            this.followingLoaded.set(true);
            this.isLoadingFollowing.set(false);
          },
          error: () => this.isLoadingFollowing.set(false),
        });
    }
  }

  /** Mise à jour d'un post émis par PostCard (like toggle, etc.) */
  protected updatePost(updated: Post): void {
    this.posts.update((list) => list.map((p) => (p.id === updated.id ? updated : p)));
    this.followingPosts.update((list) => list.map((p) => (p.id === updated.id ? updated : p)));
  }

  protected removePost(postId: string): void {
    this.posts.update((list) => list.filter((p) => p.id !== postId));
    this.followingPosts.update((list) => list.filter((p) => p.id !== postId));
  }

  private normalizePosts(data: any): Post[] {
    // cas HTTP response wrapper
    const raw = data?.body ?? data;

    if (!raw) return [];

    if (Array.isArray(raw)) {
      return mapApiPosts(raw, this.auth.currentUser());
    }

    if (Array.isArray(raw.posts)) {
      return mapApiPosts(raw.posts, this.auth.currentUser());
    }

    return [];
  }

  private applyCurrentUserAuthor(posts: Post[]): Post[] {
    const user = this.auth.currentUser();
    if (!user) return posts;

    return posts.map((post) => {
      if (
        post.author.id !== user.profileId &&
        post.author.id !== user.id &&
        post.author.username !== user.username
      ) {
        return post;
      }

      return {
        ...post,
        author: {
          id: post.author.id,
          username: user.username,
          displayName: user.displayName,
          avatarUrl: user.avatarUrl,
        },
      };
    });
  }

  protected autoResize(event: Event): void {
    const ta = event.target as HTMLTextAreaElement;
    ta.style.height = 'auto';
    ta.style.height = `${ta.scrollHeight}px`;
  }

  protected addEmoji(emoji: string): void {
    this.composerText.update((value) => `${value}${emoji}`);
  }

  protected addMention(username: string): void {
    this.composerText.update((value) => insertMention(value, username));
  }

  protected selectMedia(files: File[]): void {
    if (!files.length) return;

    if (this.selectedMedia().length >= 4) {
      this.flash.show(this.lang.tr().composer.mediaLimitReached, 'info');
      return;
    }

    const remainingSlots = 4 - this.selectedMedia().length;
    if (files.length > remainingSlots) {
      this.flash.show(this.lang.tr().composer.mediaLimitReached, 'info');
    }

    const available = files.slice(0, remainingSlots);
    const validFiles: File[] = [];
    for (const file of available) {
      const error = this.mediaService.validate(file);
      if (error) {
        this.flash.show(error, 'error');
        continue;
      }
      validFiles.push(file);
    }
    if (!validFiles.length) return;

    this.isUploading.set(true);
    forkJoin(validFiles.map((file) => this.mediaService.upload(file)))
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (uploads) => {
          this.selectedMedia.update((items) => [
            ...items,
            ...uploads.map((uploaded) => ({ type: uploaded.mediaType, url: uploaded.url })),
          ]);
          this.isUploading.set(false);
        },
        error: (error: Error) => {
          this.isUploading.set(false);
          this.flash.show(error.message, 'error');
        },
      });
  }

  protected removeMedia(index: number): void {
    this.selectedMedia.update((items) => items.filter((_, itemIndex) => itemIndex !== index));
  }

  protected togglePoll(): void {
    if (this.pollOpen()) {
      this.pollOpen.set(false);
      this.pollDraft.set(null);
    } else {
      this.pollOpen.set(true);
    }
  }

  protected onPollDraftChange(draft: PollDraft | null): void {
    this.pollDraft.set(draft);
  }

  protected submitPost(): void {
    if (!this.guest.requireAuth()) return;
    const content = this.composerText().trim();
    const media = this.selectedMedia();
    const poll = this.pollDraft();
    if ((!content && media.length === 0 && !poll) || content.length > 280) return;
    const currentUser = this.auth.currentUser();
    if (!currentUser) return;
    if (this.isPrivateProfile() && this.composerVisibility() === 'PUBLIC') {
      this.composerVisibility.set('FOLLOWERS');
    }

    this.isSubmitting.set(true);

    // Pas d'optimiste pour les posts avec sondage (le poll.id n'est pas connu côté client)
    const optimistic: Post | null = poll
      ? null
      : {
          id: `opt-${Date.now()}`,
          author: {
            id: currentUser.id,
            username: currentUser.username,
            displayName: currentUser.displayName,
            avatarUrl: currentUser.avatarUrl,
          },
          content,
          visibility: this.composerVisibility(),
          tags: (content.match(/#(\w+)/g) ?? []).map((t) => t.slice(1)),
          lang: '',
          likeCount: 0,
          replyCount: 0,
          repostCount: 0,
          isLiked: false,
          isReposted: false,
          isBookmarked: false,
          parentId: null,
          createdAt: new Date().toISOString(),
          media,
        };
    if (optimistic) {
      this.posts.update((list) => [optimistic, ...list]);
    }

    const body: Record<string, unknown> = {
      content,
      media,
      visibility: this.composerVisibility(),
    };
    if (poll) {
      body['poll'] = { options: poll.options, durationHours: poll.durationHours };
    }

    this.http
      .post<Post | ApiPost>(`${environment.apiBaseUrl}/posts`, body)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (serverPost) => {
          const mappedPost = mapApiPost(serverPost, currentUser);
          if (optimistic) {
            this.posts.update((list) => list.map((p) => (p.id === optimistic.id ? mappedPost : p)));
          } else {
            this.posts.update((list) => [mappedPost, ...list]);
          }
          if (shouldCelebratePost(content)) {
            launchConfetti();
          }
          this.composerText.set('');
          this.selectedMedia.set([]);
          this.composerVisibility.set(this.defaultComposerVisibility());
          this.pollOpen.set(false);
          this.pollDraft.set(null);
          this.emojiPickerOpen.set(false);
          this.composerFocused.set(false);
          this.isSubmitting.set(false);
          this.flash.show(this.lang.tr().composer.publishSuccess, 'success');
        },
        error: () => {
          if (optimistic) {
            this.posts.update((list) => list.filter((p) => p.id !== optimistic.id));
          }
          this.isSubmitting.set(false);
          this.flash.show(this.lang.tr().composer.publishError, 'error');
        },
      });
  }
}
