import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { RouterLink } from '@angular/router';

import { Post } from '../../../core/models/post.model';
import { TPipe } from '../../../core/pipes/t.pipe';
import { PostCard } from '../../../shared/post-card/post-card';

@Component({
  selector: 'app-following-feed',
  templateUrl: './following-feed.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, TPipe, PostCard],
})
export class FollowingFeed {
  readonly posts = input.required<Post[]>();
  readonly isLoading = input.required<boolean>();

  readonly postChange = output<Post>();
  readonly postDeleted = output<string>();
}
