import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForYouFeed } from './for-you-feed';
import { Post } from '../../../core/models/post.model';

const post = {
  id: 'post-1',
  author: { id: 'user-1', username: 'ada', displayName: 'Ada', avatarUrl: null },
  content: 'Hello',
  lang: '',
  visibility: 'PUBLIC',
  tags: [],
  likeCount: 0,
  replyCount: 0,
  repostCount: 0,
  isLiked: false,
  isReposted: false,
  isBookmarked: false,
  parentId: null,
  createdAt: '2026-01-01T00:00:00Z',
  media: [],
} satisfies Post;

describe('ForYouFeed', () => {
  let fixture: ComponentFixture<ForYouFeed>;
  let component: ForYouFeed;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ForYouFeed],
    })
      .overrideComponent(ForYouFeed, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(ForYouFeed);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('posts', [post]);
    fixture.componentRef.setInput('isLoading', false);
    fixture.detectChanges();
  });

  it('receives posts and emits changes/deletions', () => {
    const changes: Post[] = [];
    const deleted: string[] = [];
    component.postChange.subscribe((value) => changes.push(value));
    component.postDeleted.subscribe((id) => deleted.push(id));

    component.postChange.emit(post);
    component.postDeleted.emit('post-1');

    expect(component.posts()).toEqual([post]);
    expect(component.isLoading()).toBe(false);
    expect(changes).toEqual([post]);
    expect(deleted).toEqual(['post-1']);
  });
});
