import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { NavigationEnd, Router } from '@angular/router';
import { signal } from '@angular/core';
import { of, Subject } from 'rxjs';

import { Home } from './home';
import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../../shared/flash/flash.service';
import { GuestService } from '../../core/services/guest.service';
import { LangService } from '../../core/services/lang.service';
import { LoadingService } from '../../core/services/loading.service';
import { MediaService } from '../../core/services/media.service';
import { ModerationBusService } from '../../core/services/moderation-bus.service';
import { PostBusService } from '../../core/services/post-bus.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { ShareMessageService } from '../../core/services/share-message.service';
import { UserSuggestionsService } from '../../core/services/user-suggestions.service';

const user = { id: 'u1', profileId: 'p1', username: 'ada', displayName: 'Ada', avatarUrl: null, isPrivate: false };

describe('Home', () => {
  let fixture: ComponentFixture<Home>;
  let component: Home;
  let auth: any;
  let guest: any;
  let router: any;

  beforeEach(async () => {
    vi.useFakeTimers();
    const events = new Subject<NavigationEnd>();
    auth = {
      currentUser: signal(user).asReadonly(),
      unreadNotifCount: signal(0),
      unreadMessageCount: signal(0),
      refreshUnreadNotifications: vi.fn(() => of(0)),
      refreshUnreadMessages: vi.fn(() => of(0)),
      logout: vi.fn(),
    };
    guest = { isGuest: signal(false).asReadonly(), requireAuth: vi.fn(() => true), deactivate: vi.fn(), showModal: vi.fn() };
    router = {
      url: '/home/feed',
      events,
      navigateByUrl: vi.fn(() => Promise.resolve(true)),
      navigate: vi.fn(),
      routeReuseStrategy: { shouldReuseRoute: vi.fn(() => true) },
    };

    await TestBed.configureTestingModule({
      imports: [Home],
      providers: [
        { provide: Router, useValue: router },
        { provide: HttpClient, useValue: { get: vi.fn(() => of([])), post: vi.fn(() => of({})) } },
        { provide: AuthService, useValue: auth },
        { provide: GuestService, useValue: guest },
        { provide: LoadingService, useValue: { isLoading: signal(false).asReadonly() } },
        { provide: FlashService, useValue: { show: vi.fn() } },
        { provide: LangService, useValue: { tr: () => ({ composer: { publishSuccess: 'ok' }, settings: { logoutSuccess: 'bye' } }) } },
        { provide: PostBusService, useValue: { newPost: signal(null).asReadonly(), announce: vi.fn() } },
        { provide: ModerationBusService, useValue: { sanctionApplied: signal(0).asReadonly(), sanctionLifted: signal(0).asReadonly() } },
        { provide: MediaService, useValue: { validate: vi.fn(() => null), upload: vi.fn(() => of({ mediaType: 'IMAGE', url: '/a.png' })) } },
        { provide: ScrollStateService, useValue: { headerHidden: signal(false), update: vi.fn() } },
        { provide: ShareMessageService, useValue: { isOpen: signal(false).asReadonly() } },
        { provide: UserSuggestionsService, useValue: { load: vi.fn(() => of([])) } },
      ],
    })
      .overrideComponent(Home, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Home);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('creates and refreshes shell data', () => {
    expect(component).toBeTruthy();
    expect(auth.refreshUnreadNotifications).toHaveBeenCalled();
    expect(auth.refreshUnreadMessages).toHaveBeenCalled();
  });

  it('opens the composer only when auth is allowed', () => {
    (component as any).openComposer();

    expect(guest.requireAuth).toHaveBeenCalled();
    expect((component as any).composerOpen()).toBe(true);
  });

  it('builds the current user profile link', () => {
    expect((component as any).profileLink()).toBe('/home/profile/ada');
  });

  it('logs out and navigates to auth', () => {
    (component as any).confirmLogout();

    expect(auth.logout).toHaveBeenCalled();
    expect(router.navigateByUrl).toHaveBeenCalledWith('/auth');
  });
});
