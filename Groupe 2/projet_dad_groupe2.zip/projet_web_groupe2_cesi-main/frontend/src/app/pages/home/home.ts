import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  HostListener,
  inject,
  signal,
} from '@angular/core';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { filter, forkJoin, interval, map, startWith, switchMap } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { GuestService } from '../../core/services/guest.service';
import { LoadingService } from '../../core/services/loading.service';
import { FlashService } from '../../shared/flash/flash.service';
import { LangService } from '../../core/services/lang.service';
import { TPipe } from '../../core/pipes/t.pipe';
import { PostBusService } from '../../core/services/post-bus.service';
import { ModerationBusService } from '../../core/services/moderation-bus.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { SuggestionsSidebar } from '../../shared/suggestions-sidebar/suggestions-sidebar';
import { TrendingSidebar } from '../../shared/trending-sidebar/trending-sidebar';
import { mapApiPost } from '../../core/mappers/post.mapper';
import { ApiPost } from '../../core/models/api-post.model';
import { ShareViaMessage } from '../../shared/share-via-message/share-via-message';
import { ShareMessageService } from '../../core/services/share-message.service';
import { User } from '../../core/models/user.model';
import { UserSuggestionsService } from '../../core/services/user-suggestions.service';
import { Post } from '../../core/models/post.model';
import { environment } from '../../../environments/environment';
import { MediaAttachment } from '../../core/models/media.model';
import { MediaService } from '../../core/services/media.service';
import { EmojiPicker } from '../../shared/emoji-picker/emoji-picker';
import { MediaPickerButton } from '../../shared/media-picker-button/media-picker-button';
import { MediaPreview } from '../../shared/media-preview/media-preview';
import { TrendingTag } from '../../core/models/trending-tag.model';
import { MentionSuggestions } from '../../shared/mention-suggestions/mention-suggestions';
import { insertMention } from '../../core/utils/social-text';
import { PollCreator, PollDraft } from '../../shared/poll-creator/poll-creator';
import { ConfirmationDialog } from '../../shared/confirmation-dialog/confirmation-dialog';
import { UserAvatar } from '../../shared/user-avatar/user-avatar';
import { launchConfetti, shouldCelebratePost } from '../../core/utils/confetti';
import { GuestModal } from '../../shared/guest-modal/guest-modal';
import { MobileTopbar } from '../../shared/mobile-topbar/mobile-topbar';
import { MobileBottomNav } from '../../shared/mobile-bottom-nav/mobile-bottom-nav';
import { LegalDialog } from '../../shared/legal-dialog/legal-dialog';

@Component({
  selector: 'app-home',
  templateUrl: './home.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    RouterLink,
    RouterLinkActive,
    RouterOutlet,
    FormsModule,
    TrendingSidebar,
    SuggestionsSidebar,
    TPipe,
    ShareViaMessage,
    EmojiPicker,
    MediaPickerButton,
    MediaPreview,
    MentionSuggestions,
    PollCreator,
    ConfirmationDialog,
    UserAvatar,
    GuestModal,
    MobileTopbar,
    MobileBottomNav,
    LegalDialog,
  ],
})
export class Home {
  private readonly router = inject(Router);
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  protected readonly auth = inject(AuthService);
  protected readonly guest = inject(GuestService);
  protected readonly loading = inject(LoadingService);
  protected readonly showLegalDialog = signal(false);

  protected openLegalDialog(): void {
    this.showLegalDialog.set(true);
  }

  protected closeLegalDialog(): void {
    this.showLegalDialog.set(false);
  }
  private readonly flash = inject(FlashService);
  protected readonly lang = inject(LangService);
  private readonly postBus = inject(PostBusService);
  private readonly moderationBus = inject(ModerationBusService);
  private readonly mediaService = inject(MediaService);
  protected readonly shareMsg = inject(ShareMessageService);
  private readonly userSuggestions = inject(UserSuggestionsService);

  protected readonly currentUser = this.auth.currentUser;
  protected readonly unreadNotif = this.auth.unreadNotifCount;
  protected readonly unreadMsg = this.auth.unreadMessageCount;

  protected readonly composerOpen = signal(false);
  protected readonly composerText = signal('');
  protected readonly isSubmitting = signal(false);
  protected readonly isUploading = signal(false);
  protected readonly selectedMedia = signal<MediaAttachment[]>([]);
  protected readonly composerVisibility = signal<'PUBLIC' | 'FOLLOWERS' | 'PRIVATE'>('PUBLIC');
  protected readonly emojiPickerOpen = signal(false);
  protected readonly showLogoutModal = signal(false);
  protected readonly pollOpen = signal(false);
  protected readonly pollDraft = signal<PollDraft | null>(null);

  // ── Scroll-hide (topbar mobile + tab bar feed via service partagé) ────
  protected readonly scrollState = inject(ScrollStateService);

  @HostListener('window:scroll')
  protected onScroll(): void {
    this.scrollState.update(window.scrollY);
  }

  private readonly currentUrl = toSignal(
    this.router.events.pipe(
      filter((e): e is NavigationEnd => e instanceof NavigationEnd),
      map((e) => e.urlAfterRedirects),
    ),
    { initialValue: this.router.url },
  );

  protected readonly isMessagesRoute = computed(() => this.currentUrl().includes('/home/messages'));

  protected readonly isSearchRoute = computed(() => this.currentUrl().includes('/home/search'));

  protected readonly hideSidebar = computed(() =>
    this.currentUrl().includes('/home/messages') || this.isSearchRoute(),
  );

  // Suggestions rechargeables : on s'en sert à l'init ET après une sanction de
  // modération (le compte banni/suspendu doit disparaître des suggestions).
  protected readonly suggestedUsers = signal<User[]>([]);

  protected readonly trendingTags = signal<TrendingTag[]>([]);

  protected readonly profileLink = computed(() => {
    const user = this.currentUser();
    if (!user || this.guest.isGuest()) return null;
    return `/home/profile/${user.username}`;
  });

  protected clickProfile(event: Event): void {
    if (this.guest.isGuest()) {
      event.preventDefault();
      this.guest.showModal();
    }
  }

  // Compteurs déjà traités : évitent de relancer un rafraîchissement au premier
  // passage des effects (valeur initiale 0).
  private lastSanctionCount = 0;
  private lastLiftCount = 0;

  constructor() {
    this.loadSuggestions();

    effect(() => {
      if (this.currentUser()?.isPrivate === true && this.composerVisibility() === 'PUBLIC') {
        this.composerVisibility.set('FOLLOWERS');
      }
    });

    effect(() => {
      const post = this.postBus.newPost();
      if (post?.tags.length) {
        this.loadTrendingTags();
      }
    });

    // Après un bannissement / une suspension, le backend masque et anonymise le
    // contenu de l'utilisateur visé : on recharge la page courante + les
    // suggestions pour que l'affichage soit immédiatement à jour.
    effect(() => {
      const count = this.moderationBus.sanctionApplied();
      if (count === this.lastSanctionCount) return;
      this.lastSanctionCount = count;
      this.loadSuggestions();
      this.reloadCurrentPage();
    });

    // À l'inverse, après une levée de sanction le compte redevient actif : on
    // recharge uniquement les suggestions (il peut y réapparaître).
    effect(() => {
      const count = this.moderationBus.sanctionLifted();
      if (count === this.lastLiftCount) return;
      this.lastLiftCount = count;
      this.loadSuggestions();
    });

    interval(5000)
      .pipe(startWith(0), takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.loadTrendingTags());

    interval(5000)
      .pipe(
        startWith(0),
        switchMap(() => this.auth.refreshUnreadNotifications()),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({ error: () => undefined });

    interval(30000)
      .pipe(
        startWith(0),
        switchMap(() => this.auth.refreshUnreadMessages()),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({ error: () => undefined });
  }

  protected get charsLeft(): number {
    return 280 - this.composerText().length;
  }

  protected get canSubmit(): boolean {
    const t = this.composerText().trim();
    const hasPoll = this.pollDraft() !== null;
    return (
      (t.length > 0 || this.selectedMedia().length > 0 || hasPoll) &&
      t.length <= 280 &&
      !this.isSubmitting() &&
      !this.isUploading() &&
      (!hasPoll || this.pollDraft() !== null)
    );
  }

  protected isPrivateProfile(): boolean {
    return this.currentUser()?.isPrivate === true;
  }

  protected defaultComposerVisibility(): 'PUBLIC' | 'FOLLOWERS' {
    return this.isPrivateProfile() ? 'FOLLOWERS' : 'PUBLIC';
  }

  protected setComposerVisibility(visibility: 'PUBLIC' | 'FOLLOWERS' | 'PRIVATE'): void {
    if (visibility === 'PUBLIC' && this.isPrivateProfile()) {
      this.composerVisibility.set('FOLLOWERS');
      return;
    }
    this.composerVisibility.set(visibility);
  }

  protected openComposer(): void {
    if (!this.guest.requireAuth()) return;
    if (this.isPrivateProfile() && this.composerVisibility() === 'PUBLIC') {
      this.composerVisibility.set('FOLLOWERS');
    }
    this.composerOpen.set(true);
  }

  protected goToAuth(): void {
    this.guest.deactivate();
    void this.router.navigateByUrl('/auth');
  }

  protected addEmoji(emoji: string): void {
    this.composerText.update((value) => `${value}${emoji}`);
  }

  protected addMention(username: string): void {
    this.composerText.update((value) => insertMention(value, username));
  }

  protected selectMedia(files: File[]): void {
    if (!files.length) return;

    if (this.selectedMedia().length >= 4) {
      this.flash.show(this.lang.tr().composer.mediaLimitReached, 'info');
      return;
    }

    const remainingSlots = 4 - this.selectedMedia().length;
    if (files.length > remainingSlots) {
      this.flash.show(this.lang.tr().composer.mediaLimitReached, 'info');
    }

    const validFiles: File[] = [];
    for (const file of files.slice(0, remainingSlots)) {
      const error = this.mediaService.validate(file);
      if (error) {
        this.flash.show(error, 'error');
        continue;
      }
      validFiles.push(file);
    }
    if (!validFiles.length) return;

    this.isUploading.set(true);
    forkJoin(validFiles.map((file) => this.mediaService.upload(file)))
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (uploads) => {
          this.selectedMedia.update((items) => [
            ...items,
            ...uploads.map((uploaded) => ({ type: uploaded.mediaType, url: uploaded.url })),
          ]);
          this.isUploading.set(false);
        },
        error: (error: Error) => {
          this.isUploading.set(false);
          this.flash.show(error.message, 'error');
        },
      });
  }

  protected removeMedia(index: number): void {
    this.selectedMedia.update((items) => items.filter((_, itemIndex) => itemIndex !== index));
  }

  protected submitPost(): void {
    const content = this.composerText().trim();
    const media = this.selectedMedia();
    const poll = this.pollDraft();
    if ((!content && media.length === 0 && !poll) || content.length > 280) return;
    const currentUser = this.auth.currentUser();
    if (!currentUser) return;
    if (this.isPrivateProfile() && this.composerVisibility() === 'PUBLIC') {
      this.composerVisibility.set('FOLLOWERS');
    }

    this.isSubmitting.set(true);

    const body: Record<string, unknown> = {
      content,
      media,
      visibility: this.composerVisibility(),
    };
    if (poll) {
      body['poll'] = { options: poll.options, durationHours: poll.durationHours };
    }

    this.http.post<Post | ApiPost>(`${environment.apiBaseUrl}/posts`, body).subscribe({
      next: (serverPost) => {
        const mappedPost = mapApiPost(serverPost, currentUser);
        this.postBus.announce(mappedPost);
        if (shouldCelebratePost(content)) {
          launchConfetti();
        }
        this.composerText.set('');
        this.selectedMedia.set([]);
        this.composerVisibility.set(this.defaultComposerVisibility());
        this.pollOpen.set(false);
        this.pollDraft.set(null);
        this.emojiPickerOpen.set(false);
        this.composerOpen.set(false);
        this.isSubmitting.set(false);
        this.flash.show(this.lang.tr().composer.publishSuccess, 'success');
      },
      error: (err: unknown) => {
        this.isSubmitting.set(false);
        if (err instanceof HttpErrorResponse && err.status === 403) {
          this.flash.show(this.lang.tr().composer.suspendedError, 'error');
        } else {
          this.flash.show(this.lang.tr().composer.publishError, 'error');
        }
      },
    });
  }

  protected togglePoll(): void {
    if (this.pollOpen()) {
      this.pollOpen.set(false);
      this.pollDraft.set(null);
    } else {
      this.pollOpen.set(true);
    }
  }

  protected onPollDraftChange(draft: PollDraft | null): void {
    this.pollDraft.set(draft);
  }

  protected openLogoutModal(): void {
    this.showLogoutModal.set(true);
  }

  protected closeLogoutModal(): void {
    this.showLogoutModal.set(false);
  }

  protected confirmLogout(): void {
    this.showLogoutModal.set(false);
    this.auth.logout();
    this.flash.show(this.lang.tr().settings.logoutSuccess, 'info');
    void this.router.navigateByUrl('/auth');
  }

  private loadSuggestions(): void {
    this.userSuggestions
      .load(4)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((users) => this.suggestedUsers.set(users));
  }

  // Recharge la page enfant courante (le contenu du <router-outlet>) sans
  // remonter le shell `home`. On force Angular à recréer le composant de la
  // route enfant tout en réutilisant la coquille `home` (suggestions, topbar…).
  private reloadCurrentPage(): void {
    const url = this.router.url;
    const reuseStrategy = this.router.routeReuseStrategy;
    const originalShouldReuse = reuseStrategy.shouldReuseRoute;
    // On réutilise la racine et la route `home`, mais on recrée la page enfant.
    reuseStrategy.shouldReuseRoute = (future) => {
      const path = future.routeConfig?.path;
      return path === undefined || path === '' || path === 'home';
    };
    void this.router.navigateByUrl(url, { onSameUrlNavigation: 'reload' }).finally(() => {
      reuseStrategy.shouldReuseRoute = originalShouldReuse;
    });
  }

  private loadTrendingTags(): void {
    this.http
      .get<TrendingTag[]>(`${environment.apiBaseUrl}/tags/trending`, {
        params: { limit: 3 },
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (tags) => this.trendingTags.set(tags),
        error: () => undefined,
      });
  }
}
