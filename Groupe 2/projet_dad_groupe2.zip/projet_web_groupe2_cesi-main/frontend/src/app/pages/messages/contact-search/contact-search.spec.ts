import { ComponentFixture, TestBed } from '@angular/core/testing';
import { vi } from 'vitest';

import { ContactSearch } from './contact-search';
import { User } from '../../../core/models/user.model';

const contacts: User[] = [
  {
    id: 'user-1',
    username: 'ada',
    displayName: 'Ada Lovelace',
    email: 'ada@example.test',
    role: 'USER',
    bio: null,
    avatarUrl: null,
    followersCount: 0,
    followingCount: 0,
    postsCount: 0,
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'user-2',
    username: 'bob',
    displayName: 'Bob',
    email: 'bob@example.test',
    role: 'USER',
    bio: null,
    avatarUrl: null,
    followersCount: 0,
    followingCount: 0,
    postsCount: 0,
    createdAt: '2026-01-01T00:00:00Z',
  },
];

describe('ContactSearch', () => {
  let fixture: ComponentFixture<ContactSearch>;
  let component: ContactSearch;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ContactSearch],
    })
      .overrideComponent(ContactSearch, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(ContactSearch);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('contacts', contacts);
    fixture.componentRef.setInput('existingUsernames', ['bob']);
    fixture.detectChanges();
  });

  it('filters existing contacts and submits typed usernames', () => {
    const selected: string[] = [];
    component.contactSelected.subscribe((username) => selected.push(username));
    (component as any).query.set('@ad');

    expect((component as any).results()).toEqual([contacts[0]]);

    (component as any).submit();

    expect(selected).toEqual(['ad']);
    expect((component as any).query()).toBe('');
    expect((component as any).open()).toBe(false);
  });

  it('selects a contact and stops propagation', () => {
    const selected: string[] = [];
    const event = { stopPropagation: vi.fn() };
    component.contactSelected.subscribe((username) => selected.push(username));

    (component as any).stop(event);
    (component as any).select(contacts[0]);

    expect(event.stopPropagation).toHaveBeenCalled();
    expect(selected).toEqual(['ada']);
  });
});
