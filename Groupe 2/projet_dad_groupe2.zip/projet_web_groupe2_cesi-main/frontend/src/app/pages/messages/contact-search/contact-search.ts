import { ChangeDetectionStrategy, Component, computed, HostListener, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { User } from '../../../core/models/user.model';

@Component({
  selector: 'app-contact-search',
  templateUrl: './contact-search.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  host: { class: 'block' },
})
export class ContactSearch {
  readonly contacts = input<User[]>([]);
  readonly existingUsernames = input<string[]>([]);
  readonly creating = input(false);
  readonly contactSelected = output<string>();

  protected readonly query = signal('');
  protected readonly open = signal(false);

  protected readonly results = computed(() => {
    const query = this.query().trim().replace(/^@/, '').toLowerCase();
    const existing = new Set(this.existingUsernames().map((username) => username.toLowerCase()));
    return this.contacts()
      .filter((user) => !existing.has(user.username.toLowerCase()))
      .filter((user) => !query ||
        user.username.toLowerCase().includes(query) ||
        user.displayName.toLowerCase().includes(query))
      .slice(0, 8);
  });

  @HostListener('document:click')
  protected close(): void {
    this.open.set(false);
  }

  protected stop(event: Event): void {
    event.stopPropagation();
  }

  protected submit(): void {
    const username = this.query().trim().replace(/^@/, '');
    if (!username || this.creating()) return;
    this.contactSelected.emit(username);
    this.query.set('');
    this.open.set(false);
  }

  protected select(user: User): void {
    this.contactSelected.emit(user.username);
    this.query.set('');
    this.open.set(false);
  }
}
