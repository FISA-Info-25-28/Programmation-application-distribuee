import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MessageComposer } from './message-composer';

describe('MessageComposer', () => {
  let fixture: ComponentFixture<MessageComposer>;
  let component: MessageComposer;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MessageComposer],
    })
      .overrideComponent(MessageComposer, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(MessageComposer);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('creates', () => {
    expect(component).toBeTruthy();
  });

  it('emits trimmed text and clears the composer', () => {
    const sent: string[] = [];
    component.messageSent.subscribe((value) => sent.push(value));

    (component as any).text.set('  hello  ');
    (component as any).send();

    expect(sent).toEqual(['hello']);
    expect((component as any).text()).toBe('');
  });

  it('can send media without text', () => {
    const sent: string[] = [];
    fixture.componentRef.setInput('media', { type: 'IMAGE', url: '/image.png' });
    component.messageSent.subscribe((value) => sent.push(value));

    (component as any).send();

    expect(sent).toEqual(['']);
  });

  it('adds emoji and mentions to the draft', () => {
    (component as any).text.set('Hi @a');

    (component as any).addMention('ada');
    (component as any).addEmoji('!');

    expect((component as any).text()).toContain('Hi @ada !');
    expect((component as any).text()).toContain('@ada');
  });
});
