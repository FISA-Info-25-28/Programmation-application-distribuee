import { ChangeDetectionStrategy, Component, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { MediaAttachment } from '../../../core/models/media.model';
import { EmojiPicker } from '../../../shared/emoji-picker/emoji-picker';
import { MediaPickerButton } from '../../../shared/media-picker-button/media-picker-button';
import { MediaPreview } from '../../../shared/media-preview/media-preview';
import { MentionSuggestions } from '../../../shared/mention-suggestions/mention-suggestions';
import { insertMention } from '../../../core/utils/social-text';

@Component({
  selector: 'app-message-composer',
  templateUrl: './message-composer.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, EmojiPicker, MediaPickerButton, MediaPreview, MentionSuggestions],
})
export class MessageComposer {
  readonly media = input<MediaAttachment | null>(null);
  readonly uploading = input(false);
  readonly sending = input(false);
  readonly messageSent = output<string>();
  readonly mediaSelected = output<File[]>();
  readonly mediaRemoved = output<void>();

  protected readonly text = signal('');
  protected readonly emojiOpen = signal(false);

  protected send(): void {
    const content = this.text().trim();
    if ((!content && !this.media()) || this.uploading() || this.sending()) return;
    this.messageSent.emit(content);
    this.text.set('');
    this.emojiOpen.set(false);
  }

  protected addEmoji(emoji: string): void {
    this.text.update((value) => `${value}${emoji}`);
  }

  protected addMention(username: string): void {
    this.text.update((value) => insertMention(value, username));
  }
}
