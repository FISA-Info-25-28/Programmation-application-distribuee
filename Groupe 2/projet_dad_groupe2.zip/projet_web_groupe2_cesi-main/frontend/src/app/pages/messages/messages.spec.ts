import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { signal } from '@angular/core';
import { of } from 'rxjs';

import { Messages } from './messages';
import { AuthService } from '../../core/services/auth.service';
import { CryptoService } from '../../core/services/crypto.service';
import { FlashService } from '../../shared/flash/flash.service';
import { LangService } from '../../core/services/lang.service';
import { MediaService } from '../../core/services/media.service';

const user = { id: 'u1', profileId: 'p1', username: 'ada', displayName: 'Ada', avatarUrl: null };
const conversation = {
  id: 'c1',
  participant: { id: 'p2', username: 'bob', displayName: 'Bob', avatarUrl: null, publicKey: 'pk' },
  currentProfileId: 'p1',
  lastMessage: 'Hi',
  lastMessageAt: '2026-06-24T10:00:00Z',
  lastMessageSenderId: 'p2',
  unreadCount: 1,
};
const message = {
  id: 'm1',
  conversationId: 'c1',
  senderId: 'p2',
  content: 'Hi',
  nonce: '',
  likeCount: 0,
  likedByMe: false,
  reactions: [],
  createdAt: '2026-06-24T10:00:00Z',
};

describe('Messages', () => {
  let fixture: ComponentFixture<Messages>;
  let component: Messages;
  let http: any;
  let router: { navigate: ReturnType<typeof vi.fn> };
  let crypto: any;

  beforeEach(async () => {
    vi.useFakeTimers();
    http = {
      get: vi.fn((url: string) => {
        if (url.includes('/messages')) return of([message]);
        if (url.includes('/following')) return of({ users: [] });
        return of([conversation]);
      }),
      post: vi.fn(() => of({ ...message, id: 'm2', senderId: 'p1' })),
      patch: vi.fn(() => of(message)),
      delete: vi.fn(() => of({ ...message, deletedAt: '2026-06-24T11:00:00Z', content: '' })),
    };
    router = { navigate: vi.fn() };
    crypto = {
      ensureKeyPair: vi.fn(() => Promise.resolve()),
      encrypt: vi.fn((content: string) => ({ ciphertext: content, nonce: 'nonce' })),
      decrypt: vi.fn((content: string) => content),
    };

    await TestBed.configureTestingModule({
      imports: [Messages],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: Router, useValue: router },
        { provide: ActivatedRoute, useValue: { snapshot: { paramMap: { get: vi.fn(() => 'c1') } } } },
        {
          provide: AuthService,
          useValue: { currentUser: signal(user).asReadonly(), unreadMessageCount: signal(0) },
        },
        { provide: FlashService, useValue: { show: vi.fn() } },
        { provide: MediaService, useValue: { validate: vi.fn(() => null), upload: vi.fn(() => of({ mediaType: 'IMAGE', url: '/a.png' })) } },
        { provide: CryptoService, useValue: crypto },
        { provide: LangService, useValue: { tr: () => ({ messages: {} }) } },
      ],
    })
      .overrideComponent(Messages, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Messages);
    component = fixture.componentInstance;
    fixture.detectChanges();
    await Promise.resolve();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('creates and loads conversations', () => {
    expect(component).toBeTruthy();
    expect(crypto.ensureKeyPair).toHaveBeenCalled();
    expect((component as any).conversations()[0].id).toBe('c1');
  });

  it('opens a conversation and loads messages', () => {
    (component as any).openConversation('c1');

    expect(router.navigate).toHaveBeenCalledWith(['/home/messages', 'c1'], { replaceUrl: true });
    expect((component as any).messages()[0].id).toBe('m1');
  });

  it('sends a message optimistically then merges server response', () => {
    (component as any).conversations.set([conversation]);
    (component as any).activeConvId.set('c1');

    (component as any).sendMessage(' Hello ');

    expect(http.post).toHaveBeenCalled();
    expect((component as any).messages().some((item: any) => item.id === 'm2')).toBe(true);
  });
});
