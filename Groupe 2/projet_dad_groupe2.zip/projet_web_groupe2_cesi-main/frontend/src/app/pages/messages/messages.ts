import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  ElementRef,
  inject,
  signal,
  ViewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { interval } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { LangService } from '../../core/services/lang.service';
import { CryptoService } from '../../core/services/crypto.service';
import { FlashService } from '../../shared/flash/flash.service';
import { Conversation, Message, MessageReactionType } from '../../core/models/conversation.model';
import { User } from '../../core/models/user.model';
import { environment } from '../../../environments/environment';
import { timeAgo } from '../../core/utils/avatar';
import { MediaAttachment } from '../../core/models/media.model';
import { MediaService } from '../../core/services/media.service';
import { ContactSearch } from './contact-search/contact-search';
import { MessageComposer } from './message-composer/message-composer';
import { MediaGallery } from '../../shared/media-gallery/media-gallery';
import { parseSocialText } from '../../core/utils/social-text';
import { MentionLink } from '../../shared/mention-link/mention-link';
import { UserAvatar } from '../../shared/user-avatar/user-avatar';

interface SocialUsersResponse {
  users: User[];
  page: number;
  limit: number;
  total: number;
}

@Component({
  selector: 'app-messages',
  templateUrl: './messages.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, RouterLink, ContactSearch, MessageComposer, MediaGallery, MentionLink, UserAvatar],
})
export class Messages {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly mediaService = inject(MediaService);
  private readonly crypto = inject(CryptoService);
  protected readonly lang = inject(LangService);
  protected readonly auth = inject(AuthService);

  private static readonly UNREADABLE_PLACEHOLDER = 'Message chiffré illisible';

  @ViewChild('messagesEnd') private messagesEnd?: ElementRef<HTMLElement>;

  protected readonly conversations = signal<Conversation[]>([]);
  protected readonly messages = signal<Message[]>([]);
  protected readonly activeConvId = signal<string | null>(
    this.route.snapshot.paramMap.get('id'),
  );
  protected readonly followedContacts = signal<User[]>([]);
  protected readonly isCreatingConversation = signal(false);
  protected readonly isSending = signal(false);
  protected readonly isUploading = signal(false);
  protected readonly selectedMedia = signal<MediaAttachment | null>(null);
  protected readonly editingMessageId = signal<string | null>(null);
  protected readonly editingText = signal('');
  protected readonly replyingTo = signal<Message | null>(null);
  protected readonly openReactionMenuId = signal<string | null>(null);
  private hasShownConversationsLoadError = false;
  private hasShownMessagesLoadError = false;

  protected readonly timeAgo = timeAgo;
  protected readonly parseSocialText = parseSocialText;

  protected readonly activeConv = computed(() =>
    this.conversations().find((c) => c.id === this.activeConvId()) ?? null,
  );

  protected readonly showThread = computed(
    () => this.activeConvId() !== null,
  );

  protected readonly currentProfileId = computed(
    () =>
      this.activeConv()?.currentProfileId ??
      this.conversations().find((c) => c.currentProfileId)?.currentProfileId ??
      this.auth.currentUser()?.id ??
      null,
  );

  constructor() {
    void this.crypto.ensureKeyPair().then(() => {
      this.loadConversations();
      const id = this.route.snapshot.paramMap.get('id');
      if (id) this.openConversation(id);
    });
    this.loadFollowedContacts();

    interval(5000)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.loadConversations();
        const activeId = this.activeConvId();
        if (activeId) this.loadMessages(activeId, false);
      });
  }

  private loadConversations(): void {
    this.http
      .get<Conversation[]>(`${environment.apiBaseUrl}/conversations`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (data) => {
          this.hasShownConversationsLoadError = false;
          const activeId = this.activeConvId();
          const normalized = data.map((conversation) => {
            const decrypted = { ...conversation, lastMessage: this.decryptText(
              conversation.lastMessage,
              conversation.lastMessageNonce,
              conversation.participant.publicKey,
            ) };
            return decrypted.id === activeId ? { ...decrypted, unreadCount: 0 } : decrypted;
          });
          this.conversations.set(this.sortConversations(normalized));
          const total = normalized.reduce((sum, conversation) => sum + conversation.unreadCount, 0);
          this.auth.unreadMessageCount.set(total);
        },
        error: () => {
          if (this.hasShownConversationsLoadError) return;
          this.hasShownConversationsLoadError = true;
          this.flash.show(this.lang.tr().messages.loadConversationsError, 'error');
        },
      });
  }

  private loadFollowedContacts(): void {
    const current = this.auth.currentUser();
    const profileId = current?.profileId ?? current?.id;
    if (!profileId) return;

    this.http
      .get<SocialUsersResponse>(`${environment.apiBaseUrl}/users/${profileId}/following`, {
        params: { page: 1, limit: 50 },
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (response) => this.followedContacts.set(response.users ?? []),
        error: () => this.followedContacts.set([]),
      });
  }

  protected openConversation(id: string): void {
    this.activeConvId.set(id);
    void this.router.navigate(['/home/messages', id], { replaceUrl: true });
    this.loadMessages(id, true);
  }

  private loadMessages(id: string, scroll: boolean): void {
    this.http
      .get<Message[]>(`${environment.apiBaseUrl}/conversations/${id}/messages`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (msgs) => {
          this.hasShownMessagesLoadError = false;
          this.messages.set(msgs.map((msg) => this.normalizeMessage(msg)));
          // Mark as read
          this.conversations.update((list) =>
            list.map((c) => (c.id === id ? { ...c, unreadCount: 0 } : c)),
          );
          const total = this.conversations().reduce((s, c) => s + c.unreadCount, 0);
          this.auth.unreadMessageCount.set(total);
          if (scroll) setTimeout(() => this.scrollToBottom(), 50);
        },
        error: () => {
          if (this.hasShownMessagesLoadError) return;
          this.hasShownMessagesLoadError = true;
          this.flash.show(this.lang.tr().messages.loadConversationMessagesError, 'error');
        },
      });
  }

  protected closeThread(): void {
    this.activeConvId.set(null);
    this.messages.set([]);
    this.replyingTo.set(null);
    void this.router.navigate(['/home/messages'], { replaceUrl: true });
  }

  protected createConversation(username: string): void {
    username = username.trim().replace(/^@/, '');
    if (!username || this.isCreatingConversation()) return;

    this.isCreatingConversation.set(true);
    this.http
      .post<Conversation>(`${environment.apiBaseUrl}/conversations`, { username })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (conversation) => {
          this.conversations.update((list) => [
            conversation,
            ...list.filter((c) => c.id !== conversation.id),
          ]);
          this.isCreatingConversation.set(false);
          this.openConversation(conversation.id);
        },
        error: (err) => {
          this.isCreatingConversation.set(false);
          if (err.status === 404) {
            this.flash.show(this.lang.tr().messages.profileNotFound, 'error');
            return;
          }
          if (err.status === 400) {
            this.flash.show(this.lang.tr().messages.conversationCreateProfileError, 'error');
            return;
          }
          this.flash.show(this.lang.tr().messages.conversationCreateError, 'error');
        },
      });
  }

  protected sendMessage(content: string): void {
    content = content.trim();
    const convId = this.activeConvId();
    const currentUser = this.auth.currentUser();
    const media = this.selectedMedia();
    if ((!content && !media) || !convId || !currentUser || this.isSending() || this.isUploading()) return;

    this.isSending.set(true);
    const replyTo = this.replyingTo();

    const optimistic: Message = {
      id: `opt-${Date.now()}`,
      conversationId: convId,
      senderId: this.currentProfileId() ?? currentUser.id,
      content,
      mediaUrl: media?.url,
      mediaType: media?.type,
      replyToId: replyTo?.id ?? null,
      replyTo: replyTo
        ? {
            id: replyTo.id,
            senderId: replyTo.senderId,
            content: replyTo.deletedAt ? '' : replyTo.content,
            mediaType: replyTo.mediaType,
            deletedAt: replyTo.deletedAt,
          }
        : null,
      likeCount: 0,
      likedByMe: false,
      reactions: [],
      isFirstUnread: false,
      status: 'SENDING',
      createdAt: new Date().toISOString(),
    };
    this.messages.update((list) => [...list, optimistic]);
    this.conversations.update((list) =>
      this.sortConversations(list.map((c) =>
        c.id === convId
          ? {
              ...c,
              lastMessage: content || (media?.type === 'VIDEO' ? 'Vidéo' : 'Image ou GIF'),
              lastMessageSenderId: optimistic.senderId,
              lastMessageAt: optimistic.createdAt,
            }
          : c,
      )),
    );
    this.selectedMedia.set(null);
    this.replyingTo.set(null);
    this.scrollToBottom();

    const recipientPublicKey = this.activeConv()?.participant.publicKey;
    const encrypted = content && recipientPublicKey ? this.crypto.encrypt(content, recipientPublicKey) : null;

    this.http
      .post<Message>(`${environment.apiBaseUrl}/conversations/${convId}/messages`, {
        content: encrypted ? encrypted.ciphertext : content,
        nonce: encrypted?.nonce ?? '',
        mediaUrl: media?.url,
        mediaType: media?.type,
        replyToId: replyTo?.id ?? null,
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (serverMsg) => {
          this.messages.update((list) =>
            list.map((m) => (m.id === optimistic.id ? this.normalizeMessage(serverMsg) : m)),
          );
          this.isSending.set(false);
        },
        error: () => {
          this.messages.update((list) => list.filter((m) => m.id !== optimistic.id));
          this.isSending.set(false);
          this.replyingTo.set(replyTo);
          this.flash.show(this.lang.tr().messages.sendError, 'error');
        },
      });
  }

  protected selectMessageMedia(files: File[]): void {
    const file = files[0];
    if (!file) return;
    const error = this.mediaService.validate(file);
    if (error) {
      this.flash.show(error, 'error');
      return;
    }

    this.isUploading.set(true);
    this.mediaService.upload(file).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (uploaded) => {
        this.selectedMedia.set({ type: uploaded.mediaType, url: uploaded.url });
        this.isUploading.set(false);
      },
      error: (error: Error) => {
        this.isUploading.set(false);
        this.flash.show(error.message, 'error');
      },
    });
  }

  protected startEdit(msg: Message): void {
    if (msg.deletedAt || this.isSharedPostMessage(msg)) return;
    this.openReactionMenuId.set(null);
    this.editingMessageId.set(msg.id);
    this.editingText.set(msg.content ?? '');
  }

  protected cancelEdit(): void {
    this.editingMessageId.set(null);
    this.editingText.set('');
  }

  protected saveEdit(msg: Message): void {
    const content = this.editingText().trim();
    if (!content) {
      this.flash.show(this.lang.tr().messages.emptyMessage, 'error');
      return;
    }

    if (msg.deletedAt || this.isSharedPostMessage(msg)) return;

    const previous = msg;
    this.messages.update((list) =>
      list.map((m) =>
        m.id === msg.id ? { ...m, content, editedAt: new Date().toISOString() } : m,
      ),
    );
    this.updateConversationPreview(msg.id, content);
    this.cancelEdit();

    const recipientPublicKey = this.activeConv()?.participant.publicKey;
    const encrypted = recipientPublicKey ? this.crypto.encrypt(content, recipientPublicKey) : null;

    this.http
      .patch<Message>(`${environment.apiBaseUrl}/messages/${msg.id}`, {
        content: encrypted ? encrypted.ciphertext : content,
        nonce: encrypted?.nonce ?? '',
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (updated) => {
          const normalized = this.normalizeMessage(updated);
          this.messages.update((list) => list.map((m) => (m.id === msg.id ? normalized : m)));
          this.updateConversationPreview(msg.id, normalized.deletedAt ? 'Message supprime' : normalized.content);
          this.flash.show(this.lang.tr().messages.editSuccess, 'success');
        },
        error: () => {
          this.messages.update((list) => list.map((m) => (m.id === msg.id ? previous : m)));
          this.updateConversationPreview(msg.id, previous.deletedAt ? 'Message supprime' : previous.content);
          this.flash.show(this.lang.tr().messages.editError, 'error');
        },
      });
  }

  protected deleteMessage(msg: Message): void {
    if (msg.deletedAt) return;

    const previous = this.messages();
    const deletedAt = new Date().toISOString();
    this.messages.update((list) =>
      list.map((m) => (m.id === msg.id ? { ...m, content: '', deletedAt } : m)),
    );
    this.updateConversationPreview(msg.id, 'Message supprime');

    this.http
      .delete<Message>(`${environment.apiBaseUrl}/messages/${msg.id}`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (deleted) => {
          this.messages.update((list) => list.map((m) => (m.id === msg.id ? this.normalizeMessage(deleted) : m)));
          this.updateConversationPreview(msg.id, 'Message supprime');
          this.flash.show(this.lang.tr().messages.deleteSuccess, 'success');
        },
        error: () => {
          this.messages.set(previous);
          this.updateConversationPreviewFromMessages();
          this.flash.show(this.lang.tr().messages.deleteError, 'error');
        },
      });
  }

  protected startReply(msg: Message): void {
    if (msg.deletedAt || msg.id.startsWith('opt-')) return;
    this.cancelEdit();
    this.openReactionMenuId.set(null);
    this.replyingTo.set(msg);
  }

  protected cancelReply(): void {
    this.replyingTo.set(null);
  }

  protected toggleReaction(msg: Message, reaction: MessageReactionType): void {
    if (msg.deletedAt || msg.id.startsWith('opt-') || this.isMine(msg)) return;
    this.openReactionMenuId.set(null);

    const current = msg.reactions.find((item) => item.reactedByMe)?.type ?? null;
    const removing = current === reaction;
    const updated = this.applyReactionState(msg, removing ? null : reaction);
    this.messages.update((list) =>
      list.map((m) => (m.id === msg.id ? updated : m)),
    );

    const request = removing
      ? this.http.delete<Message>(`${environment.apiBaseUrl}/messages/${msg.id}/reaction`)
      : this.http.post<Message>(`${environment.apiBaseUrl}/messages/${msg.id}/reaction`, { reaction });

    request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (updated) => this.mergeMessage(updated),
      error: () => {
        this.messages.update((list) =>
          list.map((m) =>
            m.id === msg.id
              ? { ...m, likedByMe: msg.likedByMe, likeCount: msg.likeCount, reactions: msg.reactions }
              : m,
          ),
        );
        this.flash.show(this.lang.tr().messages.reactionUpdateError, 'error');
      },
    });
  }

  protected reactionIcon(type: MessageReactionType): string {
    switch (type) {
      case 'HEART':
        return '♥';
      case 'THUMBS_UP':
        return '👍';
      case 'THUMBS_DOWN':
        return '👎';
    }
  }

  protected reactionLabel(type: MessageReactionType): string {
    const t = this.lang.tr().messages;
    switch (type) {
      case 'HEART':
        return t.reactionHeart;
      case 'THUMBS_UP':
        return t.reactionThumbsUp;
      case 'THUMBS_DOWN':
        return t.reactionThumbsDown;
    }
  }

  /**
   * Retourne le caractere affiche dans les boutons et chips de reaction.
   * Entree : type de reaction stocke par l'API.
   * Sortie : glyphe unicode stable pour le rendu frontend.
   */
  protected reactionGlyph(type: MessageReactionType): string {
    switch (type) {
      case 'HEART':
        return '\u2665';
      case 'THUMBS_UP':
        return '\u{1F44D}';
      case 'THUMBS_DOWN':
        return '\u{1F44E}';
    }
  }

  protected hasReacted(msg: Message, reaction: MessageReactionType): boolean {
    return msg.reactions.some((item) => item.type === reaction && item.reactedByMe);
  }

  protected toggleReactionMenu(msg: Message): void {
    if (msg.deletedAt || msg.id.startsWith('opt-') || this.isMine(msg)) return;
    this.openReactionMenuId.update((id) => (id === msg.id ? null : msg.id));
  }

  private applyReactionState(msg: Message, reaction: MessageReactionType | null): Message {
    const currentReactions = msg.reactions ?? [];
    const previous = currentReactions.find((item) => item.reactedByMe)?.type ?? null;
    const reactions = [...currentReactions];

    if (previous) {
      const index = reactions.findIndex((item) => item.type === previous);
      if (index >= 0) {
        const count = Math.max(0, reactions[index].count - 1);
        if (count === 0) {
          reactions.splice(index, 1);
        } else {
          reactions[index] = { ...reactions[index], count, reactedByMe: false };
        }
      }
    }

    if (reaction) {
      const index = reactions.findIndex((item) => item.type === reaction);
      if (index >= 0) {
        reactions[index] = {
          ...reactions[index],
          count: reactions[index].count + 1,
          reactedByMe: true,
        };
      } else {
        reactions.push({ type: reaction, count: 1, reactedByMe: true });
      }
    }

    const heart = reactions.find((item) => item.type === 'HEART');
    return {
      ...msg,
      reactions,
      likeCount: heart?.count ?? 0,
      likedByMe: heart?.reactedByMe ?? false,
    };
  }

  protected isMine(msg: Message): boolean {
    return msg.senderId === this.currentProfileId();
  }

  protected messageStatus(msg: Message): string {
    if (msg.status === 'SENDING') return 'Envoi…';
    if (msg.status === 'READ') return 'Lu';
    return 'Distribué';
  }

  protected messageBubbleClass(msg: Message): string {
    if (msg.deletedAt) {
      return 'border border-dashed border-[#c8d8db] bg-white/70 text-[#5e7a80] italic dark:border-[#2a4255] dark:bg-[#101f30]/65 dark:text-[#7ea6b5]';
    }

    if (this.isMine(msg)) {
      return 'rounded-br-[6px] bg-gradient-to-br from-[#00a9c0] to-[#3cc8d7] text-white shadow-[0_8px_18px_-10px_rgba(0,169,192,.65)]';
    }

    const participantId = this.activeConv()?.participant.id ?? msg.senderId;
    const index = (parseInt(participantId.replace(/\D/g, '') || '1', 10) % 5) + 1;
    const colors: Record<number, string> = {
      1: 'rounded-bl-[6px] bg-[#16283a] text-[#d8ecf2]',
      2: 'rounded-bl-[6px] bg-[#243148] text-[#f2e8ff]',
      3: 'rounded-bl-[6px] bg-[#173529] text-[#d9f5e6]',
      4: 'rounded-bl-[6px] bg-[#38283b] text-[#ffe3f5]',
      5: 'rounded-bl-[6px] bg-[#3a2d20] text-[#fff0d9]',
    };
    return colors[index];
  }

  protected messageMedia(msg: Message): MediaAttachment[] {
    if (!msg.mediaUrl || !msg.mediaType) return [];
    return [{ type: msg.mediaType, url: msg.mediaUrl }];
  }

  protected replyPreviewText(msg: Pick<Message, 'content' | 'mediaType' | 'deletedAt'>): string {
    const t = this.lang.tr().messages;
    if (msg.deletedAt) return t.deletedMessage;
    if (msg.content) return msg.content;
    if (msg.mediaType === 'VIDEO') return t.video;
    if (msg.mediaType === 'IMAGE') return t.imageOrGif;
    return t.message;
  }

  protected parseSharedPost(content: string): { postId: string; authorDisplayName: string; authorUsername: string; excerpt: string } | null {
    const withAuthor = content.match(/^breezy:post:([a-f0-9-]{36})\n([^\n]*)\n@([^\n]*)\n([\s\S]*)$/);
    if (withAuthor) return { postId: withAuthor[1], authorDisplayName: withAuthor[2].trim(), authorUsername: withAuthor[3].trim(), excerpt: withAuthor[4].trim() };

    const noAuthor = content.match(/^breezy:post:([a-f0-9-]{36})\n?([\s\S]*)$/);
    if (noAuthor) return { postId: noAuthor[1], authorDisplayName: '', authorUsername: '', excerpt: noAuthor[2].trim() };

    const urlMatch = content.match(/\/home\/post\/([a-f0-9-]{36})/);
    const excerptMatch = content.match(/«\s*([\s\S]*?)\s*»/);
    if (urlMatch) return { postId: urlMatch[1], authorDisplayName: '', authorUsername: '', excerpt: excerptMatch?.[1] ?? '' };

    return null;
  }

  protected isSharedPostMessage(message: Message): boolean {
    return this.parseSharedPost(message.content) !== null;
  }

  private scrollToBottom(): void {
    this.messagesEnd?.nativeElement?.scrollIntoView({ behavior: 'smooth' });
  }

  private updateConversationPreview(messageId: string, lastMessage: string): void {
    const convId = this.activeConvId();
    const latest = this.messages().at(-1);
    if (!convId || latest?.id !== messageId) return;

    this.conversations.update((list) =>
      list.map((c) => (c.id === convId ? { ...c, lastMessage } : c)),
    );
  }

  private updateConversationPreviewFromMessages(): void {
    const convId = this.activeConvId();
    const latest = this.messages().at(-1);
    if (!convId || !latest) return;

    this.conversations.update((list) =>
      list.map((c) =>
        c.id === convId
          ? { ...c, lastMessage: latest.deletedAt ? 'Message supprime' : latest.content }
          : c,
      ),
    );
  }

  private mergeMessage(updated: Message): void {
    const normalized = this.normalizeMessage(updated);
    this.messages.update((list) => list.map((m) => (m.id === normalized.id ? normalized : m)));
  }

  private normalizeMessage(message: Message): Message {
    const reactions = message.reactions ?? [];
    const heart = reactions.find((reaction) => reaction.type === 'HEART');
    const otherPublicKey = this.activeConv()?.participant.publicKey;
    const content = this.decryptText(message.content, message.nonce, otherPublicKey);
    const replyTo = message.replyTo
      ? { ...message.replyTo, content: this.decryptText(message.replyTo.content, message.replyTo.nonce, otherPublicKey) }
      : message.replyTo;
    return {
      ...message,
      content,
      replyTo,
      reactions,
      likeCount: heart?.count ?? message.likeCount ?? 0,
      likedByMe: heart?.reactedByMe ?? message.likedByMe ?? false,
      isFirstUnread: message.isFirstUnread ?? false,
    };
  }

  /**
   * Dechiffre un texte recu du serveur (NaCl box). `nonce` vide signifie
   * texte en clair (message anterieur au chiffrement, ou destinataire sans
   * cle publique) : affiche tel quel sans tentative de dechiffrement.
   */
  private decryptText(content: string, nonce: string | undefined, otherPublicKey: string | null | undefined): string {
    if (!content || !nonce) return content;
    if (!otherPublicKey) return Messages.UNREADABLE_PLACEHOLDER;
    return this.crypto.decrypt(content, nonce, otherPublicKey) ?? Messages.UNREADABLE_PLACEHOLDER;
  }

  protected existingConversationUsernames(): string[] {
    return this.conversations().map((conversation) => conversation.participant.username);
  }

  private sortConversations(conversations: Conversation[]): Conversation[] {
    return [...conversations].sort(
      (a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime(),
    );
  }
}
