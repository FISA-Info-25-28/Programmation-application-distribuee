import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { signal } from '@angular/core';
import { of, throwError } from 'rxjs';

import { Moderation } from './moderation';
import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../../shared/flash/flash.service';
import { LangService } from '../../core/services/lang.service';
import { ModerationService, ModeratedUser } from '../../core/services/moderation.service';
import { ModerationBusService } from '../../core/services/moderation-bus.service';

describe('Moderation', () => {
  let fixture: ComponentFixture<Moderation>;
  let component: Moderation;
  let http: { get: ReturnType<typeof vi.fn>; patch: ReturnType<typeof vi.fn> };
  let mod: {
    listSanctions: ReturnType<typeof vi.fn>;
    lift: ReturnType<typeof vi.fn>;
    suspend: ReturnType<typeof vi.fn>;
  };
  let flash: { show: ReturnType<typeof vi.fn> };
  let bus: { announceLift: ReturnType<typeof vi.fn> };

  const sanctioned: ModeratedUser = {
    accountId: 'a1',
    profileId: 'p1',
    username: 'ada',
    displayName: 'Ada',
    role: 'USER',
    status: 'SUSPENDED',
    suspendedUntil: '2026-06-24T10:00:00Z',
    updatedAt: '2026-06-24T10:00:00Z',
  };

  beforeEach(async () => {
    http = { get: vi.fn(() => of([])), patch: vi.fn(() => of({})) };
    mod = {
      listSanctions: vi.fn(() => of([sanctioned])),
      lift: vi.fn(() => of({})),
      suspend: vi.fn(() => of({ suspendedUntil: '2026-06-25T10:00:00Z' })),
    };
    flash = { show: vi.fn() };
    bus = { announceLift: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [Moderation],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: ModerationService, useValue: mod },
        { provide: ModerationBusService, useValue: bus },
        { provide: FlashService, useValue: flash },
        { provide: AuthService, useValue: { currentUser: signal(null).asReadonly() } },
        { provide: LangService, useValue: { tr: () => ({}) } },
      ],
    })
      .overrideComponent(Moderation, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Moderation);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('creates and loads moderation data', () => {
    expect(component).toBeTruthy();
    expect(http.get).toHaveBeenCalled();
    expect((component as any).sanctions()).toEqual([sanctioned]);
  });

  it('filters open reports', () => {
    (component as any).reports.set([
      { id: 'r1', status: 'PENDING' },
      { id: 'r2', status: 'REVIEWED' },
      { id: 'r3', status: 'RESOLVED' },
    ]);

    expect((component as any).filteredReports().map((report: any) => report.id)).toEqual(['r1', 'r2']);
    expect((component as any).reportCount('OPEN')).toBe(2);
  });

  it('lifts a sanction', () => {
    (component as any).lift(sanctioned);

    expect(mod.lift).toHaveBeenCalledWith('p1');
    expect(bus.announceLift).toHaveBeenCalled();
    expect((component as any).sanctions()).toEqual([]);
  });

  it('restores a report when resolving fails', () => {
    const report = { id: 'r1', status: 'PENDING', targetType: 'POST' };
    http.patch.mockReturnValueOnce(throwError(() => new Error('network')));
    (component as any).reports.set([report]);

    (component as any).resolve(report, 'RESOLVED');

    expect((component as any).reports()).toEqual([report]);
    expect(flash.show).toHaveBeenCalledWith('Erreur reseau.', 'error');
  });
});
