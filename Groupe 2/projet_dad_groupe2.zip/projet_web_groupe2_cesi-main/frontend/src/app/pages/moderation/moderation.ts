import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';

import { AuthService } from '../../core/services/auth.service';
import { LangService } from '../../core/services/lang.service';
import { FlashService } from '../../shared/flash/flash.service';
import { ApiReport, Report, ReportStatus } from '../../core/models/report.model';
import { ModeratedUser, ModerationService } from '../../core/services/moderation.service';
import { ModerationBusService } from '../../core/services/moderation-bus.service';
import { environment } from '../../../environments/environment';
import { ModerationReportCard } from '../../shared/moderation-report-card/moderation-report-card';
import { TPipe } from '../../core/pipes/t.pipe';

type ModerationTab = 'reports' | 'bans' | 'suspensions';
type ModerationFilter = 'OPEN' | ReportStatus;

interface SuspensionStep {
  hours: number;
  label: string;
}

@Component({
  selector: 'app-moderation',
  templateUrl: './moderation.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ModerationReportCard, TPipe],
})
export class Moderation {
  private readonly http = inject(HttpClient);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly mod = inject(ModerationService);
  private readonly bus = inject(ModerationBusService);
  protected readonly lang = inject(LangService);
  protected readonly auth = inject(AuthService);

  protected readonly activeTab = signal<ModerationTab>('reports');

  protected readonly reports = signal<Report[]>([]);
  protected readonly filter = signal<ModerationFilter>('OPEN');
  protected readonly filters: ModerationFilter[] = ['OPEN', 'PENDING', 'REVIEWED', 'RESOLVED', 'REJECTED'];

  protected readonly sanctions = signal<ModeratedUser[]>([]);
  protected readonly bannedUsers = computed(() => this.sanctions().filter((u) => u.status === 'BANNED'));
  protected readonly suspendedUsers = computed(() => this.sanctions().filter((u) => u.status === 'SUSPENDED'));
  protected readonly busy = signal<string | null>(null);
  protected readonly pendingHours = signal<Record<string, number>>({});

  // Durees alignees sur la liste blanche du backend (allowedSuspensionHours).
  protected readonly steps: SuspensionStep[] = [
    { hours: 1, label: '1h' },
    { hours: 24, label: '1j' },
    { hours: 72, label: '3j' },
    { hours: 168, label: '7j' },
    { hours: 336, label: '14j' },
    { hours: 720, label: '30j' },
  ];

  protected setTab(tab: ModerationTab): void {
    this.activeTab.set(tab);
  }

  protected setFilter(filter: ModerationFilter): void {
    this.filter.set(filter);
  }


  protected readonly filterLabels: Record<ModerationFilter, string> = {
    OPEN: 'Actifs',
    PENDING: 'En attente',
    REVIEWED: 'Vus',
    RESOLVED: 'Resolus',
    REJECTED: 'Rejetes',
  };

  constructor() {
    this.http
      .get<ApiReport[]>(`${environment.apiBaseUrl}/moderation/reports`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((data) => this.reports.set(data.map((report) => toReport(report))));

    this.loadSanctions();
  }

  private loadSanctions(): void {
    this.mod
      .listSanctions()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((data) => this.sanctions.set(data));
  }

  // Duree actuellement selectionnee pour une suspension (defaut : 1j).
  protected selectedHours(profileId: string): number {
    return this.pendingHours()[profileId] ?? 24;
  }

  protected selectDuration(profileId: string, hours: number): void {
    this.pendingHours.update((map) => ({ ...map, [profileId]: hours }));
  }

  // Leve la sanction (suspension ou bannissement) : le compte redevient ACTIVE.
  protected lift(user: ModeratedUser): void {
    if (this.busy()) return;
    this.busy.set(user.profileId);
    const verb = user.status === 'BANNED' ? 'banni' : 'suspendu';
    this.mod
      .lift(user.profileId)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.busy.set(null);
          this.sanctions.update((list) => list.filter((s) => s.profileId !== user.profileId));
          // Le compte redevient actif : prévenir le shell pour rafraîchir les suggestions.
          this.bus.announceLift();
          this.flash.show(`${user.displayName} n'est plus ${verb}.`, 'success');
        },
        error: () => {
          this.busy.set(null);
          this.flash.show('Erreur lors de la levee de la sanction.', 'error');
        },
      });
  }

  // Change la duree d'une suspension en cours (re-suspend avec la nouvelle duree).
  protected changeDuration(user: ModeratedUser): void {
    if (this.busy()) return;
    const hours = this.selectedHours(user.profileId);
    const label = this.steps.find((s) => s.hours === hours)?.label ?? `${hours}h`;
    this.busy.set(user.profileId);
    this.mod
      .suspend(user.profileId, hours)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (result) => {
          this.busy.set(null);
          this.sanctions.update((list) =>
            list.map((s) =>
              s.profileId === user.profileId
                ? { ...s, status: 'SUSPENDED', suspendedUntil: result.suspendedUntil }
                : s,
            ),
          );
          this.flash.show(`Suspension de ${user.displayName} mise a jour (${label}).`, 'success');
        },
        error: () => {
          this.busy.set(null);
          this.flash.show('Erreur lors du changement de duree.', 'error');
        },
      });
  }

  // Formate la date de fin d'une suspension (ex : "18 juin 2026 a 14:30").
  protected formatUntil(iso?: string): string {
    if (!iso) return '';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    return d.toLocaleString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  protected filteredReports(): Report[] {
    const filter = this.filter();
    if (filter === 'OPEN') {
      return this.reports().filter((report) => report.status === 'PENDING' || report.status === 'REVIEWED');
    }

    return this.reports().filter((report) => report.status === filter);
  }

  protected reportCount(filter: ModerationFilter): number {
    if (filter === 'OPEN') {
      return this.reports().filter((report) => report.status === 'PENDING' || report.status === 'REVIEWED').length;
    }

    return this.reports().filter((report) => report.status === filter).length;
  }

  protected resolve(report: Report, status: ReportStatus): void {
    if (report.status === status) return;

    this.reports.update((list) =>
      list.map((r) => (r.id === report.id ? { ...r, status } : r)),
    );

    this.http
      .patch<ApiReport>(`${environment.apiBaseUrl}/moderation/reports/${report.id}`, { status })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (updated) => {
          this.reports.update((list) =>
            list.map((r) => (r.id === report.id ? toReport(updated, report) : r)),
          );
          if (status === 'REJECTED' && report.targetType === 'POST') {
            this.flash.show('Signalement rejete, post retire.', 'success');
            return;
          }

          this.flash.show(`Signalement ${status === 'RESOLVED' ? 'resolu, post conserve' : 'rejete'}.`, 'success');
        },
        error: () => {
          this.reports.update((list) =>
            list.map((r) => (r.id === report.id ? report : r)),
          );
          this.flash.show('Erreur reseau.', 'error');
        },
      });
  }
}

function toReport(report: ApiReport, fallback?: Report): Report {
  const targetType = report.reportedPostId ? 'POST' : 'USER';
  const targetId = report.reportedPostId ?? report.reportedUserId ?? '';

  return {
    id: report.id,
    reporterId: report.reporterId,
    reporterDisplayName: report.reporterDisplayName ?? report.reporterUsername ?? fallback?.reporterDisplayName ?? report.reporterId,
    targetType,
    targetId,
    targetExcerpt: report.reportedPostContent ?? fallback?.targetExcerpt ?? targetId,
    reason: report.reason,
    status: report.status,
    reviewedBy: report.reviewedBy,
    reviewedAt: report.reviewedAt,
    createdAt: report.createdAt,
  };
}
