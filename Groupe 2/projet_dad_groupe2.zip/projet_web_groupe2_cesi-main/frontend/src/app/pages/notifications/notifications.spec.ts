import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { signal } from '@angular/core';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { Notifications } from './notifications';
import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../../shared/flash/flash.service';
import { LangService } from '../../core/services/lang.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { Notification } from '../../core/models/notification.model';

const notification: Notification = {
  id: 'notif-1',
  type: 'LIKE',
  actorProfileId: 'profile-2',
  actorDisplayName: 'Bob',
  actorUsername: 'bob',
  postId: 'post-1',
  postExcerpt: 'Hello',
  requestPending: false,
  isRead: false,
  createdAt: '2026-01-01T00:00:00Z',
};

describe('Notifications', () => {
  let fixture: ComponentFixture<Notifications>;
  let component: Notifications;
  let http: {
    get: ReturnType<typeof vi.fn>;
    post: ReturnType<typeof vi.fn>;
    delete: ReturnType<typeof vi.fn>;
    patch: ReturnType<typeof vi.fn>;
  };
  let router: { navigate: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };
  let unreadNotifCount = signal(0);

  beforeEach(async () => {
    localStorage.removeItem('breezy.users.user-1.notifications');
    unreadNotifCount = signal(0);
    http = {
      get: vi.fn().mockReturnValue(of([notification])),
      post: vi.fn().mockReturnValue(of({})),
      delete: vi.fn().mockReturnValue(of({})),
      patch: vi.fn().mockReturnValue(of({})),
    };
    router = { navigate: vi.fn().mockResolvedValue(true) };
    flash = { show: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [Notifications],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: Router, useValue: router },
        { provide: FlashService, useValue: flash },
        {
          provide: AuthService,
          useValue: {
            currentUser: signal({ id: 'user-1' }).asReadonly(),
            unreadNotifCount,
          },
        },
        { provide: ScrollStateService, useValue: { headerHidden: signal(false) } },
        {
          provide: LangService,
          useValue: {
            tr: () => ({
              notificationsPage: {
                likedPost: 'a aime',
                followed: 'suit',
                followRequest: 'demande',
                repliedPost: 'a repondu',
                mentioned: 'a mentionne',
                reportedPost: 'a signale',
                deletedSingular: 'Notification supprimee',
                deletedPlural: 'Notifications supprimees',
                accepted: 'Accepte',
                refused: 'Refuse',
                requestError: 'Demande impossible',
                networkError: 'Erreur reseau',
              },
            }),
          },
        },
      ],
    })
      .overrideComponent(Notifications, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Notifications);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    localStorage.removeItem('breezy.users.user-1.notifications');
  });

  it('loads notifications, labels them and marks all read', () => {
    expect((component as any).notifications()).toEqual([notification]);
    expect(unreadNotifCount()).toBe(1);
    expect((component as any).label(notification)).toBe('Bob a aime');
    expect((component as any).iconClass('LIKE')).toContain('#FF8A5B');

    (component as any).markAllRead();

    expect(unreadNotifCount()).toBe(0);
    expect((component as any).notifications()[0].isRead).toBe(true);
    expect(http.post).toHaveBeenCalledWith(expect.stringContaining('/notifications/read-all'), {});
  });

  it('selects, deletes selected notifications and navigates read notifications', () => {
    (component as any).toggleSelection('notif-1');
    expect((component as any).selectedIds().has('notif-1')).toBe(true);

    (component as any).deleteSelected();
    expect((component as any).notifications()).toEqual([]);
    expect(flash.show).toHaveBeenCalledWith('Notification supprimee', 'success');

    (component as any).notifications.set([notification]);
    (component as any).navigate(notification);
    expect(http.patch).toHaveBeenCalledWith(expect.stringContaining('/notifications/notif-1/read'), {});
    expect(router.navigate).toHaveBeenCalledWith(['/home/post', 'post-1']);
  });

  it('rolls back delete-all on network errors and applies local preferences', () => {
    localStorage.setItem('breezy.users.user-1.notifications', JSON.stringify({ likes: false }));
    expect((component as any).applyLocalPreferences([notification])).toEqual([]);

    localStorage.removeItem('breezy.users.user-1.notifications');
    http.delete.mockReturnValue(throwError(() => new Error('network')));
    (component as any).notifications.set([notification]);
    (component as any).deleteAll();

    expect((component as any).notifications()).toEqual([notification]);
    expect(flash.show).toHaveBeenCalledWith('Erreur reseau', 'error');
  });
});
