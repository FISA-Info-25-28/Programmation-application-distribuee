import { ChangeDetectionStrategy, Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../../shared/flash/flash.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { Notification, NotificationType } from '../../core/models/notification.model';
import { environment } from '../../../environments/environment';
import { timeAgo } from '../../core/utils/avatar';
import { TPipe } from '../../core/pipes/t.pipe';
import { LangService } from '../../core/services/lang.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [TPipe],
})
export class Notifications {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly lang = inject(LangService);
  protected readonly auth = inject(AuthService);
  protected readonly scrollState = inject(ScrollStateService);

  protected readonly notifications = signal<Notification[]>([]);
  protected readonly selectedIds = signal<Set<string>>(new Set());
  protected readonly timeAgo = timeAgo;

  constructor() {
    this.http
      .get<Notification[]>(`${environment.apiBaseUrl}/notifications`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((data) => {
        const filtered = this.applyLocalPreferences(data);
        this.notifications.set(filtered);
        this.selectedIds.set(
          new Set([...this.selectedIds()].filter((id) => filtered.some((n) => n.id === id))),
        );
        this.auth.unreadNotifCount.set(filtered.filter((n) => !n.isRead).length);
      });
  }

  protected markAllRead(): void {
    this.notifications.update((list) => list.map((n) => ({ ...n, isRead: true })));
    this.auth.unreadNotifCount.set(0);

    this.http
      .post(`${environment.apiBaseUrl}/notifications/read-all`, {})
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({ error: () => this.flash.show(this.lang.tr().notificationsPage.networkError, 'error') });
  }

  protected deleteAll(): void {
    if (this.notifications().length === 0) return;

    const previous = this.notifications();
    const previousSelection = this.selectedIds();
    this.notifications.set([]);
    this.selectedIds.set(new Set());
    this.auth.unreadNotifCount.set(0);

    this.http
      .delete(`${environment.apiBaseUrl}/notifications`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => this.flash.show(this.lang.tr().notificationsPage.deletedPlural, 'success'),
        error: () => {
          this.notifications.set(previous);
          this.selectedIds.set(previousSelection);
          this.auth.unreadNotifCount.set(previous.filter((n) => !n.isRead).length);
          this.flash.show(this.lang.tr().notificationsPage.networkError, 'error');
        },
      });
  }

  protected deleteSelected(): void {
    const ids = [...this.selectedIds()];
    if (ids.length === 0) return;

    const previous = this.notifications();
    const previousSelection = this.selectedIds();
    const next = previous.filter((n) => !previousSelection.has(n.id));

    this.notifications.set(next);
    this.selectedIds.set(new Set());
    this.auth.unreadNotifCount.set(next.filter((n) => !n.isRead).length);

    this.http
      .delete(`${environment.apiBaseUrl}/notifications/selected`, { body: { ids } })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () =>
          this.flash.show(
            ids.length === 1
              ? this.lang.tr().notificationsPage.deletedSingular
              : this.lang.tr().notificationsPage.deletedPlural,
            'success',
          ),
        error: () => {
          this.notifications.set(previous);
          this.selectedIds.set(previousSelection);
          this.auth.unreadNotifCount.set(previous.filter((n) => !n.isRead).length);
          this.flash.show(this.lang.tr().notificationsPage.networkError, 'error');
        },
      });
  }

  protected toggleSelection(notificationID: string): void {
    this.selectedIds.update((current) => {
      const next = new Set(current);
      if (next.has(notificationID)) {
        next.delete(notificationID);
      } else {
        next.add(notificationID);
      }
      return next;
    });
  }

  protected navigate(n: Notification): void {
    if (!n.isRead) {
      this.notifications.update((list) =>
        list.map((notification) =>
          notification.id === n.id ? { ...notification, isRead: true } : notification,
        ),
      );
      this.auth.unreadNotifCount.set(Math.max(0, this.auth.unreadNotifCount() - 1));

      this.http
        .patch(`${environment.apiBaseUrl}/notifications/${n.id}/read`, {})
        .subscribe({ error: () => undefined });
    }

    if (n.postId) {
      void this.router.navigate(['/home/post', n.postId]);
    } else if (n.actorUsername) {
      void this.router.navigate(['/home/profile', n.actorUsername]);
    } else {
      void this.router.navigate(['/home/feed']);
    }
  }

  protected respondToFollowRequest(
    event: Event,
    notification: Notification,
    accept: boolean,
  ): void {
    event.stopPropagation();
    const request$ = accept
      ? this.http.post(
          `${environment.apiBaseUrl}/users/follow-requests/${notification.actorProfileId}/accept`,
          {},
        )
      : this.http.delete(
          `${environment.apiBaseUrl}/users/follow-requests/${notification.actorProfileId}`,
        );

    request$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => {
        this.removeNotificationLocally(notification);
        this.flash.show(
          accept ? this.lang.tr().notificationsPage.accepted : this.lang.tr().notificationsPage.refused,
          'success',
        );
      },
      error: () => this.flash.show(this.lang.tr().notificationsPage.requestError, 'error'),
    });
  }

  protected iconClass(type: NotificationType): string {
    switch (type) {
      case 'LIKE':
        return 'bg-gradient-to-br from-[#FF8A5B] to-[#FF5E6C]';
      case 'FOLLOW':
      case 'FOLLOW_REQUEST':
        return 'bg-gradient-to-br from-[#00A9C0] to-[#3CC8D7]';
      case 'REPLY':
        return 'bg-gradient-to-br from-[#6C7CF0] to-[#9D7BF4]';
      case 'MENTION':
        return 'bg-gradient-to-br from-[#2BC4A0] to-[#3CC8D7]';
      case 'MODERATION_REPORT':
        return 'bg-gradient-to-br from-[#F4A63C] to-[#FF5E6C]';
      case 'TEST':
        return 'bg-gradient-to-br from-[#2BC4A0] to-[#F4A63C]';
    }
  }

  protected iconPath(type: NotificationType): string {
    switch (type) {
      case 'LIKE':
        return 'M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z';
      case 'FOLLOW':
      case 'FOLLOW_REQUEST':
        return 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM19 8v6M22 11h-6';
      case 'REPLY':
        return 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z';
      case 'MENTION':
        return 'M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34M21 2l-9 9M15 3h6v6';
      case 'MODERATION_REPORT':
        return 'M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7';
      case 'TEST':
        return 'M9 12l2 2 4-4M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z';
    }
  }

  protected label(n: Notification): string {
    switch (n.type) {
      case 'LIKE':
        return `${n.actorDisplayName} ${this.lang.tr().notificationsPage.likedPost}`;
      case 'FOLLOW':
        return `${n.actorDisplayName} ${this.lang.tr().notificationsPage.followed}`;
      case 'FOLLOW_REQUEST':
        return `${n.actorDisplayName} ${this.lang.tr().notificationsPage.followRequest}`;
      case 'REPLY':
        return `${n.actorDisplayName} ${this.lang.tr().notificationsPage.repliedPost}`;
      case 'MENTION':
        return `${n.actorDisplayName} ${this.lang.tr().notificationsPage.mentioned}`;
      case 'MODERATION_REPORT':
        return `${n.actorDisplayName} ${this.lang.tr().notificationsPage.reportedPost}`;
      case 'TEST':
        return 'Test Cédric';
    }
  }

  private applyLocalPreferences(notifications: Notification[]): Notification[] {
    const user = this.auth.currentUser();
    if (typeof localStorage === 'undefined' || !user) return notifications;

    const raw = localStorage.getItem(`breezy.users.${user.id}.notifications`);
    if (!raw) return notifications;

    try {
      const preferences = JSON.parse(raw) as Partial<
        Record<'likes' | 'follows' | 'replies' | 'mentions', boolean>
      >;
      return notifications.filter((notification) => {
        if (notification.type === 'LIKE') return preferences.likes ?? true;
        if (notification.type === 'FOLLOW' || notification.type === 'FOLLOW_REQUEST') {
          return preferences.follows ?? true;
        }
        if (notification.type === 'REPLY') return preferences.replies ?? true;
        if (notification.type === 'MENTION') return preferences.mentions ?? true;
        return true;
      });
    } catch {
      return notifications;
    }
  }

  private removeNotificationLocally(notification: Notification): void {
    this.notifications.update((list) => list.filter((item) => item.id !== notification.id));
    this.selectedIds.update((current) => {
      const next = new Set(current);
      next.delete(notification.id);
      return next;
    });
    if (!notification.isRead) {
      this.auth.unreadNotifCount.set(Math.max(0, this.auth.unreadNotifCount() - 1));
    }
  }
}
