import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { signal } from '@angular/core';
import { of } from 'rxjs';

import { PostDetail } from './post';
import { AuthService } from '../../core/services/auth.service';
import { CensorService } from '../../core/services/censor.service';
import { FlashService } from '../../shared/flash/flash.service';
import { GuestService } from '../../core/services/guest.service';
import { LangService } from '../../core/services/lang.service';
import { ReplyModalService } from '../../core/services/reply-modal.service';
import { ShareMessageService } from '../../core/services/share-message.service';

const apiPost = {
  id: 'post-1',
  author: { id: 'p1', username: 'ada', displayName: 'Ada', avatarUrl: null },
  authorId: 'p1',
  authorUsername: 'ada',
  authorDisplayName: 'Ada',
  authorAvatarUrl: null,
  content: 'Hello',
  visibility: 'PUBLIC',
  tags: [],
  lang: 'fr',
  likeCount: 0,
  replyCount: 1,
  repostCount: 0,
  likedByMe: false,
  repostedByMe: false,
  bookmarkedByMe: false,
  parentId: null,
  createdAt: '2026-06-24T10:00:00Z',
  media: [],
};

describe('PostDetail', () => {
  let fixture: ComponentFixture<PostDetail>;
  let component: PostDetail;
  let http: any;
  let shareMsg: { open: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    vi.useFakeTimers();
    http = {
      get: vi.fn((url: string) => (url.includes('/replies') ? of({ posts: [] }) : of(apiPost))),
      post: vi.fn(() => of({})),
      delete: vi.fn(() => of({})),
    };
    shareMsg = { open: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [PostDetail],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: Router, useValue: { navigate: vi.fn() } },
        { provide: ActivatedRoute, useValue: { snapshot: { paramMap: { get: vi.fn(() => 'post-1') } } } },
        { provide: AuthService, useValue: { currentUser: signal({ id: 'u1', profileId: 'p1', username: 'ada', displayName: 'Ada' }).asReadonly() } },
        { provide: CensorService, useValue: { censorParts: vi.fn((text) => [{ text, censored: false }]) } },
        { provide: FlashService, useValue: { show: vi.fn() } },
        { provide: GuestService, useValue: { requireAuth: vi.fn(() => true) } },
        { provide: ShareMessageService, useValue: shareMsg },
        { provide: ReplyModalService, useValue: { open: vi.fn() } },
        { provide: LangService, useValue: { tr: () => ({ post: { bookmarkSaved: 'saved', bookmarkRemoved: 'removed' } }) } },
      ],
    })
      .overrideComponent(PostDetail, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(PostDetail);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('creates and loads the post', () => {
    expect(component).toBeTruthy();
    expect((component as any).post().id).toBe('post-1');
  });

  it('toggles like optimistically', () => {
    (component as any).toggleLike(new Event('click'));

    expect((component as any).post().isLiked).toBe(true);
    expect((component as any).post().likeCount).toBe(1);
  });

  it('opens share via message', () => {
    (component as any).sendViaMessage(new Event('click'));

    expect(shareMsg.open).toHaveBeenCalledWith('post-1', 'Hello', 'Ada', 'ada');
  });
});
