import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  HostListener,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { forkJoin } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { CensorService } from '../../core/services/censor.service';
import { FlashService } from '../../shared/flash/flash.service';
import { GuestService } from '../../core/services/guest.service';
import { ShareMessageService } from '../../core/services/share-message.service';
import { Post } from '../../core/models/post.model';
import { environment } from '../../../environments/environment';
import { mapApiPost, mapApiPosts } from '../../core/mappers/post.mapper';
import { ApiPost, ApiPostCollectionResponse } from '../../core/models/api-post.model';
import { MediaGallery } from '../../shared/media-gallery/media-gallery';
import { PostReply } from '../../shared/post-reply/post-reply';
import { ReplyModalService } from '../../core/services/reply-modal.service';
import { MentionLink } from '../../shared/mention-link/mention-link';
import { PollCard } from '../../shared/poll-card/poll-card';
import { Poll } from '../../core/models/post.model';
import { UserAvatar } from '../../shared/user-avatar/user-avatar';
import { LangService } from '../../core/services/lang.service';
import { TPipe } from '../../core/pipes/t.pipe';

interface ReplyNode {
  reply: Post;
  depth: number;
  parent: Post;
}

interface ReplyTreeNode extends ReplyNode {
  children: ReplyTreeNode[];
}

@Component({
  selector: 'app-post-detail',
  templateUrl: './post.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, DatePipe, MediaGallery, PostReply, MentionLink, PollCard, UserAvatar, TPipe],
})
export class PostDetail {
  protected readonly censor = inject(CensorService);
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly flash = inject(FlashService);
  private readonly shareMsg = inject(ShareMessageService);
  private readonly replyModal = inject(ReplyModalService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly lang = inject(LangService);
  protected readonly auth = inject(AuthService);
  private readonly guest = inject(GuestService);

  protected readonly post = signal<Post | null>(null);
  protected readonly replies = signal<Post[]>([]);

  protected readonly replyTrees = computed<ReplyTreeNode[]>(() => {
    const all = this.replies();
    const roots = all
      .filter((r) => r.parentId === this.postId)
      .sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
    const byParent = new Map<string, Post[]>();
    for (const r of all) {
      if (r.parentId && r.parentId !== this.postId) {
        const arr = byParent.get(r.parentId) ?? [];
        arr.push(r);
        byParent.set(r.parentId, arr);
      }
    }

    const collectChildren = (parent: Post, depth: number, visited: Set<string>): ReplyTreeNode[] => {
      if (visited.has(parent.id)) return [];
      visited.add(parent.id);

      return (byParent.get(parent.id) ?? [])
        .sort((a, b) => Date.parse(a.createdAt) - Date.parse(b.createdAt))
        .map((reply) => ({
          reply,
          depth,
          parent,
          children: collectChildren(reply, depth + 1, new Set(visited)),
        }));
    };

    const rootPost = this.post();
    if (!rootPost) return [];

    return roots.map((root) => ({
      reply: root,
      depth: 0,
      parent: rootPost,
      children: collectChildren(root, 1, new Set<string>()),
    }));
  });
  protected readonly expandedThreadIds = signal<Set<string>>(new Set());
  protected readonly visibleReplyNodes = computed(() => {
    const visible: ReplyTreeNode[] = [];
    const expandedIds = this.expandedThreadIds();

    const collectVisible = (node: ReplyTreeNode): void => {
      visible.push(node);
      if (expandedIds.has(node.reply.id)) {
        node.children.forEach(collectVisible);
      }
    };

    this.replyTrees().forEach(collectVisible);
    return visible;
  });
  protected readonly shareOpen = signal(false);
  protected readonly justReposted = signal(false);
  protected readonly justBookmarked = signal(false);
  protected readonly deletingReplyId = signal<string | null>(null);
  protected readonly revealedCensors = signal<Set<number>>(new Set());

  protected toggleCensor(index: number): void {
    this.revealedCensors.update((s) => {
      const next = new Set(s);
      next.has(index) ? next.delete(index) : next.add(index);
      return next;
    });
  }

  protected readonly hasNativeShare = typeof navigator !== 'undefined' && 'share' in navigator;

  private readonly postId = this.route.snapshot.paramMap.get('id') ?? '';

  constructor() {
    this.loadPost();
    effect(() => {
      const user = this.auth.currentUser();
      if (!user?.profileId) return;
      this.post.update((post) => (post ? this.applyCurrentUserAuthor(post) : post));
      this.replies.update((replies) => replies.map((reply) => this.applyCurrentUserAuthor(reply)));
    });
  }

  private loadPost(): void {
    forkJoin({
      post: this.http.get<Post | ApiPostCollectionResponse>(`${environment.apiBaseUrl}/posts/${this.postId}`),
      replies: this.http.get<ApiPostCollectionResponse>(`${environment.apiBaseUrl}/posts/${this.postId}/replies`),
    })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: ({ post, replies }) => {
          this.post.set(this.normalizeSinglePost(post));
          this.replies.set(mapApiPosts(replies, this.auth.currentUser()));
        },
        error: () => {
          this.post.set(null);
          this.replies.set([]);
          this.flash.show(this.lang.tr().post.loadDetailError, 'error');
        },
      });
  }

  private normalizeSinglePost(data: Post | ApiPostCollectionResponse): Post | null {
    if (!data) return null;
    if (Array.isArray(data)) {
      const first = data[0];
      return first ? mapApiPost(first, this.auth.currentUser()) : null;
    }
    const wrapper = data as { posts?: unknown };
    if (Array.isArray(wrapper.posts)) {
      const first = wrapper.posts[0] as ApiPost;
      return first ? mapApiPost(first, this.auth.currentUser()) : null;
    }
    return mapApiPost(data as ApiPost, this.auth.currentUser());
  }

  private applyCurrentUserAuthor(post: Post): Post {
    const user = this.auth.currentUser();
    if (!user) return post;
    if (post.author.id !== user.profileId && post.author.id !== user.id && post.author.username !== user.username) {
      return post;
    }

    return {
      ...post,
      author: {
        id: post.author.id,
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl,
      },
    };
  }

  protected openReplyModal(target?: Post): void {
    if (!this.guest.requireAuth()) return;
    const parent = target ?? this.post();
    if (!parent) return;

    this.replyModal.open(parent, (updatedParent, createdReply) => {
      if (parent.id === this.postId) {
        this.post.set(updatedParent);
      } else {
        this.replies.update((replies) =>
          replies.map((reply) => (reply.id === parent.id ? updatedParent : reply)),
        );
      }
      this.replies.update((replies) =>
        replies.some((reply) => reply.id === createdReply.id)
          ? replies
          : [...replies, createdReply],
      );
    });
  }

  protected hiddenReplyCount(node: ReplyTreeNode): number {
    return this.expandedThreadIds().has(node.reply.id) ? 0 : node.children.length;
  }

  protected showMoreReplies(threadId: string): void {
    this.expandedThreadIds.update((ids) => {
      const expanded = new Set(ids);
      expanded.add(threadId);
      return expanded;
    });
  }

  protected updateReply(updated: Post): void {
    this.replies.update((replies) =>
      replies.map((reply) => (reply.id === updated.id ? updated : reply)),
    );
  }

  protected updatePoll(updatedPoll: Poll): void {
    this.post.update((p) => (p ? { ...p, poll: updatedPoll } : p));
  }

  protected toggleRepost(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    const p = this.post();
    if (!p) return;
    const wasReposted = p.isReposted;
    this.post.set({ ...p, isReposted: !wasReposted, repostCount: wasReposted ? p.repostCount - 1 : p.repostCount + 1 });
    if (!wasReposted) {
      this.justReposted.set(true);
      setTimeout(() => this.justReposted.set(false), 500);
    }
    const req$ = wasReposted
      ? this.http.delete(`${environment.apiBaseUrl}/posts/${p.id}/repost`)
      : this.http.post(`${environment.apiBaseUrl}/posts/${p.id}/repost`, {});
    req$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({ error: () => this.post.set(p) });
  }

  protected toggleLike(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    const p = this.post();
    if (!p) return;

    const wasLiked = p.isLiked;
    this.post.set({ ...p, isLiked: !wasLiked, likeCount: wasLiked ? p.likeCount - 1 : p.likeCount + 1 });

    const req$ = wasLiked
      ? this.http.delete(`${environment.apiBaseUrl}/posts/${p.id}/like`)
      : this.http.post(`${environment.apiBaseUrl}/posts/${p.id}/like`, {});

    req$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      error: () => {
        this.post.set(p);
        this.flash.show(this.lang.tr().post.networkError, 'error');
      },
    });
  }

  protected toggleBookmark(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    const p = this.post();
    if (!p) return;
    const wasBookmarked = p.isBookmarked;
    this.post.set({ ...p, isBookmarked: !wasBookmarked });

    if (!wasBookmarked) {
      this.justBookmarked.set(true);
      setTimeout(() => this.justBookmarked.set(false), 500);
      this.flash.show(this.lang.tr().post.bookmarkSaved, 'success');
    } else {
      this.flash.show(this.lang.tr().post.bookmarkRemoved, 'info');
    }

    const req$ = wasBookmarked
      ? this.http.delete(`${environment.apiBaseUrl}/posts/${p.id}/bookmark`)
      : this.http.post(`${environment.apiBaseUrl}/posts/${p.id}/bookmark`, {});
    req$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({ error: () => this.post.set(p) });
  }

  @HostListener('document:click')
  protected onDocumentClick(): void {
    this.shareOpen.set(false);
  }

  protected toggleShare(event: Event): void {
    event.stopPropagation();
    this.shareOpen.update((v) => !v);
  }

  protected copyLink(): void {
    const url = `${window.location.origin}/home/post/${this.postId}`;
    navigator.clipboard.writeText(url).then(
      () => { this.flash.show(this.lang.tr().post.linkCopied, 'success'); this.shareOpen.set(false); },
      () => this.flash.show(this.lang.tr().post.linkCopyError, 'error'),
    );
  }

  protected nativeShare(): void {
    const p = this.post();
    if (!p || !this.hasNativeShare) return;
    const url = `${window.location.origin}/home/post/${p.id}`;
    navigator.share({
      title: `${this.lang.tr().post.postBy} ${p.author.displayName} sur Breezy`,
      text: p.content.slice(0, 120),
      url,
    }).then(() => this.shareOpen.set(false)).catch(() => {});
  }

  protected sendViaMessage(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    this.shareOpen.set(false);
    const p = this.post();
    if (p) this.shareMsg.open(p.id, p.content, p.author.displayName, p.author.username);
  }

  protected canDeleteOwnReply(reply: Post): boolean {
    const user = this.auth.currentUser();
    return (
      user?.profileId === reply.author.id ||
      user?.id === reply.author.id ||
      user?.username === reply.author.username ||
      user?.role === 'ADMIN' ||
      user?.role === 'MODERATOR'
    );
  }

  protected deleteReply(reply: Post): void {
    this.deletingReplyId.set(reply.id);
    this.http
      .delete(`${environment.apiBaseUrl}/posts/${reply.id}`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          const deletedIds = this.collectReplySubtreeIds(reply.id);
          this.replies.update((list) => {
            const remaining = list.filter((item) => !deletedIds.has(item.id));
            if (reply.parentId && reply.parentId !== this.postId) {
              return remaining.map((item) =>
                item.id === reply.parentId
                  ? { ...item, replyCount: Math.max(0, item.replyCount - 1) }
                  : item,
              );
            }
            return remaining;
          });
          if (reply.parentId === this.postId) {
            this.post.update((current) =>
              current ? { ...current, replyCount: Math.max(0, current.replyCount - 1) } : current,
            );
          }
          this.flash.show(this.lang.tr().post.replyDeleted, 'success');
          this.deletingReplyId.set(null);
        },
        error: () => {
          this.flash.show(this.lang.tr().post.replyDeleteError, 'error');
          this.deletingReplyId.set(null);
        },
      });
  }

  private collectReplySubtreeIds(replyId: string): Set<string> {
    const deletedIds = new Set<string>([replyId]);
    let foundChild = true;

    while (foundChild) {
      foundChild = false;
      for (const reply of this.replies()) {
        if (reply.parentId && deletedIds.has(reply.parentId) && !deletedIds.has(reply.id)) {
          deletedIds.add(reply.id);
          foundChild = true;
        }
      }
    }

    return deletedIds;
  }

  protected goBack(): void {
    if (window.history.length > 1) window.history.back();
    else void this.router.navigate(['/home/feed']);
  }
}
