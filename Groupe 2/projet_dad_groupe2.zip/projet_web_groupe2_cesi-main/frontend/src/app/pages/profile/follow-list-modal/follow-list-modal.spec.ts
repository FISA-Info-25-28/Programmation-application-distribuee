import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FollowListModal } from './follow-list-modal';
import { User } from '../../../core/models/user.model';

const user = (id: string, username = id): User =>
  ({
    id,
    profileId: `${id}-profile`,
    username,
    displayName: username,
    email: `${username}@example.com`,
    role: 'USER',
  }) as User;

describe('FollowListModal', () => {
  let fixture: ComponentFixture<FollowListModal>;
  let component: FollowListModal;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FollowListModal],
    })
      .overrideComponent(FollowListModal, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(FollowListModal);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('profile', {
      id: 'profile-1',
      username: 'ada',
      displayName: 'Ada',
      followersCount: 1,
      followingCount: 1,
    });
    fixture.componentRef.setInput('activeTab', 'followers');
    fixture.componentRef.setInput('followers', [user('u1')]);
    fixture.componentRef.setInput('following', [user('u2')]);
    fixture.detectChanges();
  });

  it('creates', () => {
    expect(component).toBeTruthy();
  });

  it('returns users for the selected tab', () => {
    expect((component as any).activeUsers()[0].id).toBe('u1');

    fixture.componentRef.setInput('activeTab', 'following');
    fixture.detectChanges();

    expect((component as any).activeUsers()[0].id).toBe('u2');
  });

  it('detects the current user from id or profile id', () => {
    fixture.componentRef.setInput('currentProfileId', 'u1-profile');
    fixture.detectChanges();

    expect((component as any).isCurrentUser(user('u1'))).toBe(true);
    expect((component as any).isCurrentUser(user('u2'))).toBe(false);
  });
});
