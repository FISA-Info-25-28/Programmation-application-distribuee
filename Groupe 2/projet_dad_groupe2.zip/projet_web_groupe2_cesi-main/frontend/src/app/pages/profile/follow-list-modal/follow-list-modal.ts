import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

import { User } from '../../../core/models/user.model';
import { UserRow } from '../../../shared/user-row/user-row';

export type FollowListTab = 'followers' | 'following';

export interface FollowListProfile {
  id: string;
  username: string;
  displayName: string;
  followersCount: number;
  followingCount: number;
}

@Component({
  selector: 'app-follow-list-modal',
  templateUrl: './follow-list-modal.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [UserRow],
})
export class FollowListModal {
  readonly profile = input.required<FollowListProfile>();
  readonly activeTab = input.required<FollowListTab>();
  readonly followers = input.required<User[]>();
  readonly following = input.required<User[]>();
  readonly loading = input(false);
  readonly currentProfileId = input<string | null>(null);

  readonly closed = output<void>();
  readonly tabChanged = output<FollowListTab>();

  protected activeUsers(): User[] {
    return this.activeTab() === 'followers' ? this.followers() : this.following();
  }

  protected isCurrentUser(user: User): boolean {
    const currentProfileId = this.currentProfileId();
    if (!currentProfileId) return false;
    return currentProfileId === user.profileId || currentProfileId === user.id;
  }
}
