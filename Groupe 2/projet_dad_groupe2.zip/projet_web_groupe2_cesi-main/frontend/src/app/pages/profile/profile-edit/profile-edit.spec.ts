import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { signal } from '@angular/core';
import { of, throwError } from 'rxjs';

import { ProfileEdit } from './profile-edit';
import { AuthService } from '../../../core/services/auth.service';
import { ProfileService } from '../../../core/services/profile.service';
import { FlashService } from '../../../shared/flash/flash.service';
import { LangService } from '../../../core/services/lang.service';

const user = {
  id: 'u1',
  profileId: 'p1',
  username: 'ada',
  displayName: 'Ada',
  bio: 'Hello',
  avatarUrl: null,
  role: 'USER',
};

describe('ProfileEdit', () => {
  let fixture: ComponentFixture<ProfileEdit>;
  let component: ProfileEdit;
  let profiles: { getMyProfile: ReturnType<typeof vi.fn>; updateMyProfile: ReturnType<typeof vi.fn> };
  let router: { navigate: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    profiles = {
      getMyProfile: vi.fn(() => of(user)),
      updateMyProfile: vi.fn(() => of(user)),
    };
    router = { navigate: vi.fn() };
    flash = { show: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [ProfileEdit],
      providers: [
        { provide: AuthService, useValue: { currentUser: signal(user).asReadonly() } },
        { provide: ProfileService, useValue: profiles },
        { provide: Router, useValue: router },
        { provide: FlashService, useValue: flash },
        { provide: LangService, useValue: { tr: () => ({ profileEdit: { success: 'ok', error: 'ko' } }) } },
      ],
    })
      .overrideComponent(ProfileEdit, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(ProfileEdit);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('creates and loads the current profile', () => {
    expect(component).toBeTruthy();
    expect((component as any).displayName()).toBe('Ada');
    expect((component as any).bio()).toBe('Hello');
  });

  it('saves the profile and navigates to it', () => {
    (component as any).displayName.set('Ada Lovelace');
    (component as any).bio.set('Math');

    (component as any).save();

    expect(profiles.updateMyProfile).toHaveBeenCalledWith({ displayName: 'Ada Lovelace', bio: 'Math' });
    expect(flash.show).toHaveBeenCalledWith('ok', 'success');
    expect(router.navigate).toHaveBeenCalledWith(['/home/profile', 'ada']);
  });

  it('shows an error when save fails', () => {
    profiles.updateMyProfile.mockReturnValueOnce(throwError(() => new Error('network')));

    (component as any).save();

    expect(flash.show).toHaveBeenCalledWith('ko', 'error');
    expect((component as any).isSubmitting()).toBe(false);
  });
});
