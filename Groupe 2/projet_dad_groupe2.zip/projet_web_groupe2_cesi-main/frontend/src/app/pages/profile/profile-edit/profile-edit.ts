import { ChangeDetectionStrategy, Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

import { AuthService } from '../../../core/services/auth.service';
import { ProfileService } from '../../../core/services/profile.service';
import { FlashService } from '../../../shared/flash/flash.service';
import { UserAvatar } from '../../../shared/user-avatar/user-avatar';
import { TPipe } from '../../../core/pipes/t.pipe';
import { LangService } from '../../../core/services/lang.service';

@Component({
  selector: 'app-profile-edit',
  templateUrl: './profile-edit.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, FormsModule, UserAvatar, TPipe],
})
export class ProfileEdit {
  private readonly auth = inject(AuthService);
  private readonly profiles = inject(ProfileService);
  private readonly router = inject(Router);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly lang = inject(LangService);

  protected readonly currentUser = this.auth.currentUser;

  protected readonly displayName = signal(this.currentUser()?.displayName ?? '');
  protected readonly bio = signal(this.currentUser()?.bio ?? '');
  protected readonly isSubmitting = signal(false);

  protected readonly MAX_BIO = 160;

  constructor() {
    // L'utilisateur courant (signal `auth.currentUser`) ne contient pas
    // toujours la bio à jour (ex: après un rafraîchissement de page) : on la
    // récupère depuis le profile-service pour préremplir le formulaire.
    this.profiles
      .getMyProfile()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((user) => {
        this.displayName.set(user.displayName);
        this.bio.set(user.bio ?? '');
      });
  }

  protected get bioCharsLeft(): number {
    return this.MAX_BIO - this.bio().length;
  }

  protected get canSubmit(): boolean {
    return (
      this.displayName().trim().length > 0 &&
      this.bio().length <= this.MAX_BIO &&
      !this.isSubmitting()
    );
  }

  // Sauvegarder les changements de profil (displayName et bio)
  protected save(): void {
    if (!this.canSubmit) return;

    this.isSubmitting.set(true);
    this.profiles
      .updateMyProfile({
        displayName: this.displayName().trim(),
        bio: this.bio().trim() || null,
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (user) => {
          this.isSubmitting.set(false);
          this.flash.show(this.lang.tr().profileEdit.success, 'success');
          void this.router.navigate(['/home/profile', user.username]);
        },
        error: () => {
          this.isSubmitting.set(false);
          this.flash.show(this.lang.tr().profileEdit.error, 'error');
        },
      });
  }
}
