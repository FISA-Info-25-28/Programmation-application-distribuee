import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { signal } from '@angular/core';
import { of, Subject } from 'rxjs';

import { Profile } from './profile';
import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../../shared/flash/flash.service';
import { MediaService } from '../../core/services/media.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { Post } from '../../core/models/post.model';

const profile = {
  id: 'p1',
  accountId: 'u1',
  username: 'ada',
  displayName: 'Ada',
  bio: 'Hello',
  avatarUrl: null,
  bannerUrl: null,
  followersCount: 1,
  followingCount: 2,
  postsCount: 1,
  isFollowing: false,
  requestPending: false,
  isPrivate: false,
  canViewContent: true,
  isBlocked: false,
  pinnedPostId: null,
  createdAt: '2026-06-24T10:00:00Z',
};
const apiPost = {
  id: 'post-1',
  author: { id: 'p1', username: 'ada', displayName: 'Ada', avatarUrl: null },
  authorId: 'p1',
  authorUsername: 'ada',
  authorDisplayName: 'Ada',
  authorAvatarUrl: null,
  content: 'Hello',
  visibility: 'PUBLIC',
  tags: [],
  lang: 'fr',
  likeCount: 0,
  replyCount: 0,
  repostCount: 0,
  likedByMe: false,
  repostedByMe: false,
  bookmarkedByMe: false,
  parentId: null,
  createdAt: '2026-06-24T10:00:00Z',
  media: [],
};

describe('Profile', () => {
  let fixture: ComponentFixture<Profile>;
  let component: Profile;
  let http: any;
  let params: Subject<any>;
  let auth: any;

  beforeEach(async () => {
    params = new Subject();
    auth = {
      currentUser: signal({ id: 'u1', profileId: 'p1', username: 'ada', displayName: 'Ada' }).asReadonly(),
      setUser: vi.fn(),
    };
    http = {
      get: vi.fn((url: string) => {
        if (url.includes('/profiles/')) return of(profile);
        if (url.includes('/users/')) return of({ users: [] });
        return of({ posts: [apiPost] });
      }),
      patch: vi.fn(() => of({ ...profile, displayName: 'Ada Lovelace' })),
      post: vi.fn(() => of({ blocked: true })),
      delete: vi.fn(() => of({ blocked: false })),
    };

    await TestBed.configureTestingModule({
      imports: [Profile],
      providers: [
        { provide: ActivatedRoute, useValue: { paramMap: params.asObservable() } },
        { provide: Router, useValue: { navigate: vi.fn() } },
        { provide: HttpClient, useValue: http },
        { provide: AuthService, useValue: auth },
        { provide: MediaService, useValue: { validate: vi.fn(() => null), upload: vi.fn(() => of({ url: '/a.png' })) } },
        { provide: FlashService, useValue: { show: vi.fn() } },
        { provide: ScrollStateService, useValue: { headerHidden: signal(false), update: vi.fn() } },
      ],
    })
      .overrideComponent(Profile, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Profile);
    component = fixture.componentInstance;
    params.next({ get: vi.fn(() => 'ada') });
    fixture.detectChanges();
  });

  it('creates and loads the profile', () => {
    expect(component).toBeTruthy();
    expect((component as any).profile().username).toBe('ada');
    expect((component as any).posts().length).toBe(1);
  });

  it('opens edit with the current profile draft', () => {
    (component as any).openEdit();

    expect((component as any).editOpen()).toBe(true);
    expect((component as any).draftDisplayName()).toBe('Ada');
  });

  it('updates and removes posts across profile tabs', () => {
    const updated = { ...(component as any).posts()[0], isLiked: true } as Post;

    (component as any).updatePost(updated);
    (component as any).removePost(updated.id);

    expect((component as any).posts()).toEqual([]);
    expect((component as any).profile().postsCount).toBe(0);
  });
});
