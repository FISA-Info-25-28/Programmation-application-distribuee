import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { forkJoin, of, switchMap } from 'rxjs';

import { environment } from '../../../environments/environment';
import { ApiPostCollectionResponse } from '../../core/models/api-post.model';
import { Post } from '../../core/models/post.model';
import { User } from '../../core/models/user.model';
import { mapApiPosts } from '../../core/mappers/post.mapper';
import { AuthService } from '../../core/services/auth.service';
import { MediaService } from '../../core/services/media.service';
import { refreshImageUrl, versionedImageUrl } from '../../core/utils/avatar';
import { FlashService } from '../../shared/flash/flash.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { ConfirmationDialog } from '../../shared/confirmation-dialog/confirmation-dialog';
import { FollowBtn, FollowState } from '../../shared/follow-btn/follow-btn';
import { PostCard } from '../../shared/post-card/post-card';
import { UserAvatar } from '../../shared/user-avatar/user-avatar';
import { FollowListModal, FollowListTab } from './follow-list-modal/follow-list-modal';

interface ProfileResponse {
  id: string;
  accountId: string;
  username: string;
  displayName: string;
  bio: string | null;
  avatarUrl: string | null;
  bannerUrl: string | null;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  isFollowing: boolean;
  requestPending: boolean;
  isPrivate: boolean;
  canViewContent: boolean;
  isBlocked: boolean;
  pinnedPostId: string | null;
  createdAt: string;
}

type ProfileTab = 'posts' | 'replies' | 'media' | 'reposts' | 'likes';

interface SocialUsersResponse {
  users: User[];
  page: number;
  limit: number;
  total: number;
}

@Component({
  selector: 'app-profile',
  templateUrl: './profile.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, RouterLink, FollowBtn, PostCard, ConfirmationDialog, UserAvatar, FollowListModal],
  styles: [`
    @media (max-width: 1023px) {
      .profile-sticky { transition: transform 300ms ease-in-out; }
      .profile-sticky.header-is-hidden { transform: translateY(-57px); }
    }
  `],
})
export class Profile {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly media = inject(MediaService);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);
  readonly scrollState = inject(ScrollStateService);

  protected readonly profile = signal<ProfileResponse | null>(null);
  protected readonly posts = signal<Post[]>([]);
  protected readonly replies = signal<Post[]>([]);
  protected readonly reposts = signal<Post[]>([]);
  protected readonly likedPosts = signal<Post[]>([]);
  protected readonly activeTab = signal<ProfileTab>('posts');
  protected readonly loading = signal(true);
  protected readonly notFound = signal(false);
  protected readonly editOpen = signal(false);
  protected readonly saving = signal(false);
  protected readonly blocking = signal(false);
  protected readonly blockConfirmOpen = signal(false);
  protected readonly pinReplaceOpen = signal(false);
  protected readonly pendingPinPost = signal<Post | null>(null);
  protected readonly uploadingAvatar = signal(false);
  protected readonly uploadingBanner = signal(false);
  protected readonly draftDisplayName = signal('');
  protected readonly draftBio = signal('');
  protected readonly draftAvatarUrl = signal<string | null>(null);
  protected readonly draftBannerUrl = signal<string | null>(null);
  protected readonly followModalOpen = signal(false);
  protected readonly followModalTab = signal<FollowListTab>('followers');
  protected readonly followers = signal<User[]>([]);
  protected readonly following = signal<User[]>([]);
  protected readonly followersLoaded = signal(false);
  protected readonly followingLoaded = signal(false);
  protected readonly followListLoading = signal(false);

  protected readonly versionedImageUrl = versionedImageUrl;
  protected readonly currentProfileId = computed(() => this.auth.currentUser()?.profileId ?? null);
  protected readonly isOwnProfile = computed(() => {
    const current = this.auth.currentUser();
    const profile = this.profile();
    return (
      !!current &&
      !!profile &&
      (current.profileId === profile.id ||
        current.id === profile.accountId ||
        current.username.toLowerCase() === profile.username.toLowerCase())
    );
  });
  protected readonly mediaCount = computed(() =>
    this.posts().reduce((count, post) => count + post.media.length, 0),
  );
  protected readonly mediaItems = computed(() =>
    this.posts().flatMap((post) =>
      post.media.map((media) => ({
        postId: post.id,
        authorName: post.author.displayName,
        media,
      })),
    ),
  );
  protected readonly reactionsCount = computed(() =>
    this.posts().reduce((count, post) => count + post.likeCount + post.repostCount, 0),
  );
  protected readonly pinnedPost = computed(() => {
    const pid = this.profile()?.pinnedPostId;
    if (!pid) return null;
    return this.posts().find((p) => p.id === pid) ?? null;
  });
  protected readonly hasProfileChanges = computed(() => {
    const profile = this.profile();
    if (!profile) return false;
    return (
      this.draftDisplayName().trim() !== profile.displayName ||
      this.draftBio().trim() !== (profile.bio ?? '') ||
      this.draftAvatarUrl() !== profile.avatarUrl ||
      this.draftBannerUrl() !== profile.bannerUrl
    );
  });

  constructor() {
    this.route.paramMap
      .pipe(
        switchMap((params) => {
          const username = params.get('username') ?? this.auth.currentUser()?.username ?? '';
          this.loading.set(true);
          this.notFound.set(false);
          return this.http
            .get<ProfileResponse>(
              `${environment.apiBaseUrl}/profiles/${encodeURIComponent(username)}`,
            )
            .pipe(
              switchMap((profile) => {
                if (!profile.canViewContent) {
                  return of({
                    profile,
                    posts: { posts: [] },
                    replies: { posts: [] },
                    reposts: { posts: [] },
                    likes: { posts: [] },
                  });
                }
                return forkJoin({
                  profile: of(profile),
                  posts: this.http.get<ApiPostCollectionResponse>(
                    `${environment.apiBaseUrl}/posts/author/${encodeURIComponent(username)}`,
                  ),
                  replies: this.http.get<ApiPostCollectionResponse>(
                    `${environment.apiBaseUrl}/posts/author/${encodeURIComponent(username)}/replies`,
                  ),
                  reposts: this.http.get<ApiPostCollectionResponse>(
                    `${environment.apiBaseUrl}/posts/author/${encodeURIComponent(username)}/reposts`,
                  ),
                  likes: this.http.get<ApiPostCollectionResponse>(
                    `${environment.apiBaseUrl}/posts/author/${encodeURIComponent(username)}/likes`,
                  ),
                });
              }),
            );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: ({ profile, posts, replies, reposts, likes }) => {
          this.profile.set(profile);
          this.posts.set(mapApiPosts(posts, this.auth.currentUser()));
          this.replies.set(mapApiPosts(replies, this.auth.currentUser()));
          this.reposts.set(mapApiPosts(reposts, this.auth.currentUser()));
          this.likedPosts.set(mapApiPosts(likes, this.auth.currentUser()));
          this.activeTab.set('posts');
          this.followModalOpen.set(false);
          this.followers.set([]);
          this.following.set([]);
          this.followersLoaded.set(false);
          this.followingLoaded.set(false);
          this.loading.set(false);
        },
        error: () => {
          this.profile.set(null);
          this.posts.set([]);
          this.replies.set([]);
          this.reposts.set([]);
          this.likedPosts.set([]);
          this.loading.set(false);
          this.notFound.set(true);
        },
      });
  }

  protected goBack(): void {
    if (typeof window !== 'undefined' && window.history.length > 1) {
      window.history.back();
      return;
    }
    void this.router.navigate(['/home/feed']);
  }

  protected openEdit(): void {
    const profile = this.profile();
    if (!profile) return;
    this.draftDisplayName.set(profile.displayName);
    this.draftBio.set(profile.bio ?? '');
    this.draftAvatarUrl.set(profile.avatarUrl);
    this.draftBannerUrl.set(profile.bannerUrl);
    this.editOpen.set(true);
  }

  protected closeEdit(): void {
    if (!this.saving()) this.editOpen.set(false);
  }

  protected selectAvatar(event: Event): void {
    this.uploadImage(event, 'avatar');
  }

  protected selectBanner(event: Event): void {
    this.uploadImage(event, 'banner');
  }

  protected saveProfile(): void {
    const currentProfile = this.profile();
    if (!currentProfile) return;
    const displayName = this.draftDisplayName().trim();
    if (!displayName) {
      this.flash.show('Le nom affiche est obligatoire.', 'error');
      return;
    }
    if (this.uploadingAvatar() || this.uploadingBanner()) {
      this.flash.show("Attends la fin de l'envoi des images.", 'info');
      return;
    }

    const payload: Partial<
      Pick<ProfileResponse, 'displayName' | 'bio' | 'avatarUrl' | 'bannerUrl'>
    > = {};
    const bio = this.draftBio().trim();
    if (displayName !== currentProfile.displayName) payload.displayName = displayName;
    if (bio !== (currentProfile.bio ?? '')) payload.bio = bio;
    if (this.draftAvatarUrl() !== currentProfile.avatarUrl) {
      payload.avatarUrl = this.draftAvatarUrl() ?? '';
    }
    if (this.draftBannerUrl() !== currentProfile.bannerUrl) {
      payload.bannerUrl = this.draftBannerUrl() ?? '';
    }
    if (Object.keys(payload).length === 0) {
      this.editOpen.set(false);
      return;
    }

    this.saving.set(true);
    this.http
      .patch<ProfileResponse>(`${environment.apiBaseUrl}/profiles/me`, payload)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (profile) => {
          refreshImageUrl(profile.avatarUrl);
          refreshImageUrl(profile.bannerUrl);
          this.profile.set(profile);
          this.syncCurrentUser(profile);
          this.posts.update((posts) =>
            posts.map((post) => ({
              ...post,
              author: {
                ...post.author,
                displayName: profile.displayName,
                avatarUrl: profile.avatarUrl,
              },
            })),
          );
          this.saving.set(false);
          this.editOpen.set(false);
          this.flash.show('Profil mis a jour.', 'success');
        },
        error: () => {
          this.saving.set(false);
          this.flash.show('Impossible de modifier le profil.', 'error');
        },
      });
  }

  protected onFollowChange(state: FollowState): void {
    const wasFollowing = this.profile()?.isFollowing ?? false;
    this.profile.update((profile) =>
      profile
        ? {
            ...profile,
            isFollowing: state.following,
            requestPending: state.requestPending,
            canViewContent: !profile.isPrivate || state.following,
            followersCount: Math.max(
              0,
              profile.followersCount +
                (wasFollowing === state.following ? 0 : state.following ? 1 : -1),
            ),
          }
        : profile,
    );
    const profile = this.profile();
    if (state.following && profile?.isPrivate) {
      this.loadProfileContent(profile.username);
    } else if (!state.following && profile?.isPrivate) {
      this.posts.set([]);
      this.replies.set([]);
      this.reposts.set([]);
      this.likedPosts.set([]);
      this.activeTab.set('posts');
    }
  }

  protected openFollowModal(tab: FollowListTab): void {
    this.followModalOpen.set(true);
    this.switchFollowModalTab(tab);
  }

  protected closeFollowModal(): void {
    this.followModalOpen.set(false);
  }

  protected switchFollowModalTab(tab: FollowListTab): void {
    this.followModalTab.set(tab);
    this.loadFollowList(tab);
  }

  protected toggleBlock(): void {
    const profile = this.profile();
    if (!profile || this.blocking()) return;

    if (!profile.isBlocked) {
      this.blockConfirmOpen.set(true);
      return;
    }

    this.updateBlockState(profile);
  }

  protected closeBlockConfirm(): void {
    if (!this.blocking()) this.blockConfirmOpen.set(false);
  }

  protected confirmBlock(): void {
    const profile = this.profile();
    if (!profile || profile.isBlocked || this.blocking()) return;
    this.updateBlockState(profile);
  }

  protected blockConfirmTitle(): string {
    return this.profile() ? `Bloquer @${this.profile()!.username} ?` : 'Bloquer cet utilisateur ?';
  }

  protected blockConfirmMessage(): string {
    const username = this.profile()?.username;
    return username
      ? `@${username} ne pourra plus voir ton profil ni ton activite. Tu pourras toujours voir ses publications publiques.`
      : "Cet utilisateur ne pourra plus voir ton profil ni ton activite.";
  }

  private updateBlockState(profile: ProfileResponse): void {
    const action = profile.isBlocked ? 'debloquer' : 'bloquer';

    this.blocking.set(true);
    const request = profile.isBlocked
      ? this.http.delete<{ blocked: boolean }>(
          `${environment.apiBaseUrl}/users/block/${profile.id}`,
        )
      : this.http.post<{ blocked: boolean }>(
          `${environment.apiBaseUrl}/users/block/${profile.id}`,
          {},
        );

    request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: ({ blocked }) => {
        this.profile.update((current) =>
          current
            ? {
                ...current,
                isBlocked: blocked,
                isFollowing: false,
                requestPending: false,
                canViewContent: !current.isPrivate,
              }
            : current,
        );
        this.posts.set([]);
        this.replies.set([]);
        this.reposts.set([]);
        this.likedPosts.set([]);
        this.blocking.set(false);
        this.blockConfirmOpen.set(false);
        this.flash.show(blocked ? 'Utilisateur bloque.' : 'Utilisateur debloque.', 'success');
        if (!profile.isPrivate) this.loadProfileContent(profile.username);
      },
      error: () => {
        this.blocking.set(false);
        this.flash.show(`Impossible de ${action} cet utilisateur.`, 'error');
      },
    });
  }

  private loadFollowList(tab: FollowListTab): void {
    const profile = this.profile();
    if (!profile) return;
    if (tab === 'followers' && this.followersLoaded()) return;
    if (tab === 'following' && this.followingLoaded()) return;

    this.followListLoading.set(true);
    this.http
      .get<SocialUsersResponse>(`${environment.apiBaseUrl}/users/${profile.id}/${tab}`, {
        params: { page: 1, limit: 100 },
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (response) => {
          if (tab === 'followers') {
            this.followers.set(response.users ?? []);
            this.followersLoaded.set(true);
          } else {
            this.following.set(response.users ?? []);
            this.followingLoaded.set(true);
          }
          this.followListLoading.set(false);
        },
        error: () => {
          this.followListLoading.set(false);
          this.flash.show('Impossible de charger la liste.', 'error');
        },
      });
  }

  protected updatePost(updated: Post): void {
    this.posts.update((posts) => posts.map((post) => (post.id === updated.id ? updated : post)));
    this.replies.update((posts) =>
      posts.map((post) => (post.id === updated.id ? updated : post)),
    );
    this.reposts.update((posts) => {
      if (this.isOwnProfile()) {
        const previous = posts.find((post) => post.id === updated.id);
        if (previous?.isReposted && !updated.isReposted) {
          return posts.filter((post) => post.id !== updated.id);
        }
      }
      return posts.map((post) => (post.id === updated.id ? updated : post));
    });
    this.likedPosts.update((posts) => {
      if (this.isOwnProfile()) {
        const previous = posts.find((post) => post.id === updated.id);
        if (previous?.isLiked && !updated.isLiked) {
          return posts.filter((post) => post.id !== updated.id);
        }
      }
      return posts.map((post) => (post.id === updated.id ? updated : post));
    });
  }

  protected removePost(postId: string): void {
    this.posts.update((posts) => posts.filter((post) => post.id !== postId));
    this.replies.update((posts) => posts.filter((post) => post.id !== postId));
    this.reposts.update((posts) => posts.filter((post) => post.id !== postId));
    this.likedPosts.update((posts) => posts.filter((post) => post.id !== postId));
    this.profile.update((profile) =>
      profile
        ? {
            ...profile,
            postsCount: Math.max(0, profile.postsCount - 1),
            pinnedPostId: profile.pinnedPostId === postId ? null : profile.pinnedPostId,
          }
        : profile,
    );
  }

  protected togglePin(post: Post): void {
    const profile = this.profile();
    if (!profile) return;
    const isCurrentlyPinned = profile.pinnedPostId === post.id;

    // Si on épingle un NOUVEAU post alors qu'il y en a déjà un → avertissement
    if (!isCurrentlyPinned && profile.pinnedPostId) {
      this.pendingPinPost.set(post);
      this.pinReplaceOpen.set(true);
      return;
    }

    this.doPin(post, isCurrentlyPinned);
  }

  protected confirmPinReplace(): void {
    const post = this.pendingPinPost();
    if (!post) return;
    this.pinReplaceOpen.set(false);
    this.doPin(post, false);
  }

  protected closePinReplace(): void {
    this.pinReplaceOpen.set(false);
    this.pendingPinPost.set(null);
  }

  private doPin(post: Post, isCurrentlyPinned: boolean): void {
    const req$ = isCurrentlyPinned
      ? this.http.delete(`${environment.apiBaseUrl}/profiles/me/pin`)
      : this.http.post(`${environment.apiBaseUrl}/profiles/me/pin/${post.id}`, {});

    req$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => {
        this.profile.update((p) =>
          p ? { ...p, pinnedPostId: isCurrentlyPinned ? null : post.id } : p,
        );
        this.pendingPinPost.set(null);
        this.flash.show(
          isCurrentlyPinned ? 'Post désépinglé.' : 'Post épinglé sur ton profil.',
          'success',
        );
      },
      error: () => this.flash.show("Impossible d'épingler ce post.", 'error'),
    });
  }

  protected joinedDate(createdAt: string): string {
    return new Intl.DateTimeFormat('fr-FR', {
      month: 'long',
      year: 'numeric',
    }).format(new Date(createdAt));
  }

  private uploadImage(event: Event, kind: 'avatar' | 'banner'): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      this.flash.show('Choisis une image.', 'error');
      return;
    }
    const error = this.media.validate(file);
    if (error) {
      this.flash.show(error, 'error');
      return;
    }

    const uploading = kind === 'avatar' ? this.uploadingAvatar : this.uploadingBanner;
    uploading.set(true);
    this.media
      .upload(file)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: ({ url }) => {
          refreshImageUrl(url);
          (kind === 'avatar' ? this.draftAvatarUrl : this.draftBannerUrl).set(url);
          uploading.set(false);
        },
        error: (uploadError: Error) => {
          uploading.set(false);
          this.flash.show(uploadError.message, 'error');
        },
      });
  }

  private syncCurrentUser(profile: ProfileResponse): void {
    const current = this.auth.currentUser();
    if (!current) return;
    const user: User = {
      ...current,
      profileId: profile.id,
      username: profile.username,
      displayName: profile.displayName,
      bio: profile.bio,
      avatarUrl: profile.avatarUrl,
      bannerUrl: profile.bannerUrl,
      followersCount: profile.followersCount,
      followingCount: profile.followingCount,
      postsCount: profile.postsCount,
      isPrivate: profile.isPrivate,
      createdAt: profile.createdAt,
    };
    this.auth.setUser(user);
  }

  // loadProfileContent recharge les contenus visibles d'un profil, dont les posts likes.
  // Entree : username.
  // Sortie : met a jour les signaux posts, replies, reposts et likedPosts.
  private loadProfileContent(username: string): void {
    forkJoin({
      posts: this.http.get<ApiPostCollectionResponse>(
        `${environment.apiBaseUrl}/posts/author/${encodeURIComponent(username)}`,
      ),
      replies: this.http.get<ApiPostCollectionResponse>(
        `${environment.apiBaseUrl}/posts/author/${encodeURIComponent(username)}/replies`,
      ),
      reposts: this.http.get<ApiPostCollectionResponse>(
        `${environment.apiBaseUrl}/posts/author/${encodeURIComponent(username)}/reposts`,
      ),
      likes: this.http.get<ApiPostCollectionResponse>(
        `${environment.apiBaseUrl}/posts/author/${encodeURIComponent(username)}/likes`,
      ),
    })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: ({ posts, replies, reposts, likes }) => {
          this.posts.set(mapApiPosts(posts, this.auth.currentUser()));
          this.replies.set(mapApiPosts(replies, this.auth.currentUser()));
          this.reposts.set(mapApiPosts(reposts, this.auth.currentUser()));
          this.likedPosts.set(mapApiPosts(likes, this.auth.currentUser()));
        },
        error: () => this.flash.show('Impossible de charger le contenu prive.', 'error'),
      });
  }
}
