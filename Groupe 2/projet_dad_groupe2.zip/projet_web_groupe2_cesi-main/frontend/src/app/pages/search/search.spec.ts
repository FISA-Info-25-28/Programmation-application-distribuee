import { ComponentFixture, TestBed } from '@angular/core/testing';
import { convertToParamMap, ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, of, throwError } from 'rxjs';
import { signal } from '@angular/core';
import { vi } from 'vitest';

import { Search } from './search';
import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../../shared/flash/flash.service';
import { LangService } from '../../core/services/lang.service';
import { PostBusService } from '../../core/services/post-bus.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { UserSuggestionsService } from '../../core/services/user-suggestions.service';
import { User } from '../../core/models/user.model';
import { ApiPost } from '../../core/models/api-post.model';
import { Post } from '../../core/models/post.model';

const user: User = {
  id: 'user-1',
  profileId: 'profile-1',
  username: 'ada',
  displayName: 'Ada',
  email: 'ada@example.test',
  role: 'USER',
  bio: null,
  avatarUrl: null,
  followersCount: 0,
  followingCount: 0,
  postsCount: 0,
  createdAt: '2026-01-01T00:00:00Z',
};

function apiPost(id: string, content = `Post ${id}`): ApiPost {
  return {
    id,
    authorId: 'profile-1',
    content,
    parentId: null,
    visibility: 'PUBLIC',
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z',
  };
}

describe('Search', () => {
  let fixture: ComponentFixture<Search>;
  let component: Search;
  let routeParams: BehaviorSubject<ReturnType<typeof convertToParamMap>>;
  let http: { get: ReturnType<typeof vi.fn> };
  let router: { navigate: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };
  let userSuggestions: { load: ReturnType<typeof vi.fn>; hide: ReturnType<typeof vi.fn> };
  let newPost = signal<Post | null>(null);

  beforeEach(async () => {
    vi.useFakeTimers();
    newPost = signal<Post | null>(null);
    routeParams = new BehaviorSubject(convertToParamMap({}));
    http = {
      get: vi.fn((url: string) => {
        if (url.includes('/tags/trending')) return of([{ tag: 'angular', postsCount: 4, likesCount: 8 }]);
        if (url.includes('/users/search')) return of([user]);
        if (url.includes('/posts/search')) return of({ posts: [apiPost('search-1', 'hello #Angular')] });
        return of({ posts: [] });
      }),
    };
    router = { navigate: vi.fn().mockResolvedValue(true) };
    flash = { show: vi.fn() };
    userSuggestions = {
      load: vi.fn().mockReturnValue(of([user])),
      hide: vi.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [Search],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: Router, useValue: router },
        { provide: ActivatedRoute, useValue: { paramMap: routeParams.asObservable() } },
        { provide: FlashService, useValue: flash },
        { provide: AuthService, useValue: { currentUser: vi.fn(() => user) } },
        { provide: LangService, useValue: { tr: () => ({ searchPage: { loadTagsError: 'Erreur tags' } }) } },
        { provide: PostBusService, useValue: { newPost: newPost.asReadonly() } },
        { provide: UserSuggestionsService, useValue: userSuggestions },
        { provide: ScrollStateService, useValue: { headerHidden: signal(false) } },
      ],
    })
      .overrideComponent(Search, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Search);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('loads trending tags and default suggestions when there is no route tag', () => {
    vi.advanceTimersByTime(300);

    expect((component as any).trendingTags()).toEqual([{ tag: 'angular', postsCount: 4, likesCount: 8 }]);
    expect(userSuggestions.load).toHaveBeenCalledWith(20);
    expect((component as any).userResults()).toEqual([user]);
    expect((component as any).postResults()).toEqual([]);
    expect((component as any).isLoading()).toBe(false);
  });

  it('searches users and posts after query debounce', () => {
    (component as any).onQueryChange(' angular ');

    vi.advanceTimersByTime(300);

    expect(http.get).toHaveBeenCalledWith(expect.stringContaining('/users/search'), {
      params: { q: 'angular' },
    });
    expect(http.get).toHaveBeenCalledWith(expect.stringContaining('/posts/search'), {
      params: { q: 'angular' },
    });
    expect((component as any).userResults()).toEqual([user]);
    expect((component as any).postResults()[0]).toEqual(
      expect.objectContaining({ id: 'search-1', tags: ['Angular'] }),
    );
  });

  it('navigates when toggling, clearing and querying active tags', () => {
    (component as any).toggleTag(' angular ');
    expect(router.navigate).toHaveBeenLastCalledWith(['/home/search/tag', 'angular']);

    (component as any).activeTags.set(['angular', 'front']);
    (component as any).toggleTag('angular');
    expect(router.navigate).toHaveBeenLastCalledWith(['/home/search/tag', 'front']);

    (component as any).clearTag();
    expect(router.navigate).toHaveBeenLastCalledWith(['/home/search']);

    (component as any).activeTags.set(['front']);
    (component as any).onQueryChange('ada');
    expect(router.navigate).toHaveBeenLastCalledWith(['/home/search']);
  });

  it('fetches the intersection of posts for multiple active tags', () => {
    http.get.mockImplementation((url: string) => {
      if (url.includes('/tags/trending')) return of([]);
      if (url.endsWith('/posts/tag/angular')) return of({ posts: [apiPost('common'), apiPost('angular-only')] });
      if (url.endsWith('/posts/tag/front')) return of({ posts: [apiPost('common'), apiPost('front-only')] });
      return of({ posts: [] });
    });

    routeParams.next(convertToParamMap({ tags: 'angular, front' }));

    expect((component as any).activeTags()).toEqual(['angular', 'front']);
    expect((component as any).activeTab()).toBe('posts');
    expect((component as any).postResults().map((post: Post) => post.id)).toEqual(['common']);
    expect((component as any).isLoading()).toBe(false);
  });

  it('shows a flash and clears posts when loading tagged posts fails', () => {
    http.get.mockImplementation((url: string) => {
      if (url.includes('/tags/trending')) return of([]);
      return throwError(() => new Error('network'));
    });

    routeParams.next(convertToParamMap({ tag: 'angular' }));

    expect((component as any).postResults()).toEqual([]);
    expect((component as any).isLoading()).toBe(false);
    expect(flash.show).toHaveBeenCalledWith('Erreur tags', 'error');
  });

  it('updates post results and hides followed suggestions only on empty search', () => {
    const post = {
      id: 'post-1',
      author: { id: 'user-1', username: 'ada', displayName: 'Ada', avatarUrl: null },
      content: 'Hello',
      lang: '',
      visibility: 'PUBLIC',
      tags: [],
      likeCount: 0,
      replyCount: 0,
      repostCount: 0,
      isLiked: false,
      isReposted: false,
      isBookmarked: false,
      parentId: null,
      createdAt: '2026-01-01T00:00:00Z',
      media: [],
    } satisfies Post;
    (component as any).postResults.set([post]);
    (component as any).userResults.set([user]);

    (component as any).updatePost({ ...post, content: 'Updated' });
    expect((component as any).postResults()[0].content).toBe('Updated');

    (component as any).removePost('post-1');
    expect((component as any).postResults()).toEqual([]);

    (component as any).hideSuggestedUser({ user, state: { following: true, requestPending: false } });
    expect(userSuggestions.hide).toHaveBeenCalledWith('user-1');
    expect((component as any).userResults()).toEqual([]);
  });
});
