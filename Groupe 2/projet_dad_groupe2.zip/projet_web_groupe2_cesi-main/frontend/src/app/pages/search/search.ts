import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { debounceTime, distinctUntilChanged, Subject, switchMap, of, forkJoin, interval, startWith } from 'rxjs';

import { FlashService } from '../../shared/flash/flash.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { UserFollowChange, UserRow } from '../../shared/user-row/user-row';
import { PostCard } from '../../shared/post-card/post-card';
import { User } from '../../core/models/user.model';
import { Post } from '../../core/models/post.model';
import { mapApiPosts } from '../../core/mappers/post.mapper';
import { ApiPostCollectionResponse } from '../../core/models/api-post.model';
import { AuthService } from '../../core/services/auth.service';
import { PostBusService } from '../../core/services/post-bus.service';
import { UserSuggestionsService } from '../../core/services/user-suggestions.service';
import { environment } from '../../../environments/environment';
import { TrendingTag } from '../../core/models/trending-tag.model';
import { TPipe } from '../../core/pipes/t.pipe';
import { LangService } from '../../core/services/lang.service';

type SearchTab = 'users' | 'posts';

@Component({
  selector: 'app-search',
  templateUrl: './search.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, UserRow, PostCard, TPipe],
  styles: [`
    @media (max-width: 1023px) {
      .search-sticky { transition: transform 300ms ease-in-out; }
      .search-sticky.header-is-hidden { transform: translateY(-57px); }
    }
  `],
})
export class Search {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly lang = inject(LangService);
  private readonly auth = inject(AuthService);
  private readonly postBus = inject(PostBusService);
  private readonly userSuggestions = inject(UserSuggestionsService);
  readonly scrollState = inject(ScrollStateService);

  protected readonly query = signal('');
  protected readonly activeTab = signal<SearchTab>('users');
  protected readonly userResults = signal<User[]>([]);
  protected readonly postResults = signal<Post[]>([]);
  protected readonly trendingTags = signal<TrendingTag[]>([]);
  protected readonly activeTags = signal<string[]>([]);
  protected readonly isLoading = signal(false);
  protected readonly hasActiveTags = computed(() => this.activeTags().length > 0);

  protected readonly search$ = new Subject<string>();

  constructor() {
    interval(10000)
      .pipe(
        startWith(0),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe(() => this.loadTrendingTags());

    this.search$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((q) => {
          this.isLoading.set(true);
          const trimmed = q.trim();
          if (!trimmed) {
            this.postResults.set([]);
            return this.userSuggestions.load(20).pipe(
              switchMap((users) => {
                this.userResults.set(users);
                this.isLoading.set(false);
                return of(null);
              }),
            );
          }
          return forkJoin({
            users: this.http.get<User[]>(`${environment.apiBaseUrl}/users/search`, { params: { q: trimmed } }),
            posts: this.http.get<ApiPostCollectionResponse>(`${environment.apiBaseUrl}/posts/search`, {
              params: { q: trimmed },
            }),
          }).pipe(
            switchMap(({ users, posts }) => {
              this.userResults.set(users);
              this.postResults.set(mapApiPosts(posts, this.auth.currentUser()));
              this.isLoading.set(false);
              return of(null);
            }),
          );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe();

    this.route.paramMap.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((params) => {
      const tagsParam = params.get('tags');
      const tag = params.get('tag');

      if (tagsParam) {
        this.setTags(tagsParam.split(',').map((value) => value.trim()).filter(Boolean));
        return;
      }

      if (tag) {
        this.setTags([tag]);
        return;
      }

      this.activeTags.set([]);
      this.activeTab.set('users');
      this.search$.next(this.query());
    });

    effect(() => {
      const post = this.postBus.newPost();
      if (post?.tags.length) {
        this.loadTrendingTags();
      }
      if (post?.tags.length && this.hasActiveTags()) {
        this.fetchPostsForTags(this.activeTags());
      }
    });
  }

  protected onQueryChange(q: string): void {
    this.query.set(q);
    if (this.hasActiveTags()) {
      void this.router.navigate(['/home/search']);
    }
    this.search$.next(q);
  }

  protected toggleTag(tag: string): void {
    const normalizedTag = tag.trim();
    if (!normalizedTag) return;

    const nextTags = this.activeTags().includes(normalizedTag)
      ? this.activeTags().filter((currentTag) => currentTag !== normalizedTag)
      : [...this.activeTags(), normalizedTag];

    void this.navigateToTags(nextTags);
  }

  protected clearTag(tag?: string): void {
    if (!tag) {
      void this.router.navigate(['/home/search']);
      return;
    }

    void this.navigateToTags(this.activeTags().filter((currentTag) => currentTag !== tag));
  }

  protected isTagActive(tag: string): boolean {
    return this.activeTags().includes(tag);
  }

  protected activeTagsLabel(): string {
    return this.activeTags().map((tag) => `#${tag}`).join(', ');
  }

  protected removePost(postId: string): void {
    this.postResults.update((posts) => posts.filter((post) => post.id !== postId));
  }

  protected updatePost(updated: Post): void {
    this.postResults.update((posts) =>
      posts.map((post) => (post.id === updated.id ? updated : post)),
    );
  }

  protected hideSuggestedUser(change: UserFollowChange): void {
    if (this.query().trim() || (!change.state.following && !change.state.requestPending)) {
      return;
    }
    this.userSuggestions.hide(change.user.id);
    this.userResults.update((users) => users.filter((user) => user.id !== change.user.id));
  }

  private setTags(tags: string[]): void {
    this.activeTags.set(tags);
    this.activeTab.set('posts');
    this.fetchPostsForTags(tags);
  }

  private fetchPostsForTags(tags: string[]): void {
    this.isLoading.set(true);
    forkJoin(
      tags.map((tag) =>
        this.http.get<ApiPostCollectionResponse>(`${environment.apiBaseUrl}/posts/tag/${tag}`),
      ),
    )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (responses) => {
          const postsByTag = responses.map((response) => mapApiPosts(response, this.auth.currentUser()));
          const commonPostIds = postsByTag.reduce<string[]>(
            (ids, posts, index) => {
              const currentIds = posts.map((post) => post.id);
              return index === 0 ? currentIds : ids.filter((id) => currentIds.includes(id));
            },
            [],
          );
          const mergedPosts = postsByTag[0]?.filter((post) => commonPostIds.includes(post.id)) ?? [];
          this.postResults.set(mergedPosts);
          this.isLoading.set(false);
        },
        error: () => {
          this.postResults.set([]);
          this.isLoading.set(false);
          this.flash.show(this.lang.tr().searchPage.loadTagsError, 'error');
        },
      });
  }

  private loadTrendingTags(): void {
    this.http
      .get<TrendingTag[]>(`${environment.apiBaseUrl}/tags/trending`, {
        params: { limit: 5 },
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (tags) => this.trendingTags.set(tags),
        error: () => undefined,
      });
  }

  private navigateToTags(tags: string[]): Promise<boolean> {
    if (tags.length === 0) {
      return this.router.navigate(['/home/search']);
    }
    if (tags.length === 1) {
      return this.router.navigate(['/home/search/tag', tags[0]]);
    }
    return this.router.navigate(['/home/search/tags', tags.join(',')]);
  }
}
