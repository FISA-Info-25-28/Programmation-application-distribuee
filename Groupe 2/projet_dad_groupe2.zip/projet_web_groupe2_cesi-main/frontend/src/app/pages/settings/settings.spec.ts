import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { PLATFORM_ID, signal } from '@angular/core';
import { Router } from '@angular/router';
import { of } from 'rxjs';

import { Settings } from './settings';
import { AuthService } from '../../core/services/auth.service';
import { CensorService } from '../../core/services/censor.service';
import { FlashService } from '../../shared/flash/flash.service';
import { GuestService } from '../../core/services/guest.service';
import { LangService } from '../../core/services/lang.service';
import { MessageSettingsService } from '../../core/services/message-settings.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { ThemeService } from '../../core/services/theme.service';
import { TokenService } from '../../core/services/token.service';

const section = new Proxy({}, { get: (_target, prop) => String(prop) });

describe('Settings', () => {
  let fixture: ComponentFixture<Settings>;
  let component: Settings;
  let auth: any;
  let router: { navigate: ReturnType<typeof vi.fn> };
  let theme: { theme: ReturnType<typeof signal<string>>; setTheme: ReturnType<typeof vi.fn>; refreshForCurrentUser: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    auth = {
      currentUser: signal({ id: 'u1', username: 'ada', displayName: 'Ada', isPrivate: false }).asReadonly(),
      setUser: vi.fn(),
      logout: vi.fn(),
    };
    router = { navigate: vi.fn() };
    theme = { theme: signal('system'), setTheme: vi.fn(), refreshForCurrentUser: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [Settings],
      providers: [
        { provide: HttpClient, useValue: { get: vi.fn(() => of({ isPrivate: false, users: [] })), patch: vi.fn(() => of({ isPrivate: true })), delete: vi.fn(() => of({})) } },
        { provide: PLATFORM_ID, useValue: 'browser' },
        { provide: AuthService, useValue: auth },
        { provide: GuestService, useValue: { isGuest: signal(false).asReadonly(), deactivate: vi.fn() } },
        { provide: TokenService, useValue: { getSession: vi.fn(() => ({ user: { id: 'u1' } })) } },
        { provide: FlashService, useValue: { show: vi.fn() } },
        { provide: Router, useValue: router },
        { provide: ThemeService, useValue: theme },
        { provide: MessageSettingsService, useValue: { retention: signal('forever'), refreshForCurrentUser: vi.fn(), loadFromApi: vi.fn(() => of({})), saveRetention: vi.fn(() => of({})) } },
        { provide: CensorService, useValue: { customWords: signal([]).asReadonly(), setCustomWords: vi.fn() } },
        { provide: ScrollStateService, useValue: { headerHidden: signal(false), update: vi.fn() } },
        { provide: LangService, useValue: { lang: signal('fr').asReadonly(), tr: () => ({ settings: section, auth: section }) } },
      ],
    })
      .overrideComponent(Settings, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(Settings);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('creates', () => {
    expect(component).toBeTruthy();
  });

  it('opens and closes dialogs', () => {
    (component as any).openPwModal();
    expect((component as any).showPwModal()).toBe(true);

    (component as any).closePwModal();
    expect((component as any).showPwModal()).toBe(false);
  });

  it('applies theme and logs out', () => {
    (component as any).setTheme('dark');
    (component as any).confirmLogout();

    expect(theme.setTheme).toHaveBeenCalledWith('dark');
    expect(auth.logout).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith(['/auth']);
  });
});
