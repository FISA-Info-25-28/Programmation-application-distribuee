﻿import { isPlatformBrowser } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  PLATFORM_ID,
  signal,
  WritableSignal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { GuestService } from '../../core/services/guest.service';
import { FlashService } from '../../shared/flash/flash.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { LangService } from '../../core/services/lang.service';
import { LangSwitcher } from '../../shared/lang-switcher/lang-switcher';
import { Theme, ThemeService } from '../../core/services/theme.service';
import {
  MessageRetention,
  MessageSettingsService,
} from '../../core/services/message-settings.service';
import { CensorService } from '../../core/services/censor.service';
import { TokenService } from '../../core/services/token.service';
import { environment } from '../../../environments/environment';
import { ConfirmationDialog } from '../../shared/confirmation-dialog/confirmation-dialog';
import { UserAvatar } from '../../shared/user-avatar/user-avatar';
import { UserRow } from '../../shared/user-row/user-row';
import { LegalDialog } from '../../shared/legal-dialog/legal-dialog';
import { SupportDialog } from '../../shared/support-dialog/support-dialog';
import { TPipe } from '../../core/pipes/t.pipe';
import { User } from '../../core/models/user.model';

type NotificationPreference = 'likes' | 'follows' | 'replies' | 'mentions';
type NotificationPreferences = Record<NotificationPreference, boolean>;
type NotificationLabelKey = 'notifLikes' | 'notifFollows' | 'notifReplies' | 'notifMentions';
type RetentionLabelKey = 'retentionForever';
interface SocialUsersResponse {
  users: User[];
  page: number;
  limit: number;
  total: number;
}

@Component({
  selector: 'app-settings',
  templateUrl: './settings.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [LangSwitcher, FormsModule, ConfirmationDialog, UserAvatar, UserRow, LegalDialog, SupportDialog, TPipe],
})
export class Settings {
  protected readonly auth = inject(AuthService);
  protected readonly guest = inject(GuestService);
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly token = inject(TokenService);
  private readonly flash = inject(FlashService);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);
  private readonly themeService = inject(ThemeService);
  private readonly messageSettings = inject(MessageSettingsService);
  protected readonly censor = inject(CensorService);
  protected readonly scrollState = inject(ScrollStateService);
  protected readonly lang = inject(LangService);
  private readonly isBrowser = isPlatformBrowser(this.platformId);

  protected readonly showPwModal = signal(false);
  protected readonly showLegalDialog = signal(false);
  protected readonly showFaqDialog = signal(false);
  protected readonly showUserDocDialog = signal(false);
  protected readonly pwCurrent = signal('');
  protected readonly pwNew = signal('');
  protected readonly pwConfirm = signal('');
  protected readonly pwShowCurrent = signal(false);
  protected readonly pwShowNew = signal(false);
  protected readonly pwShowConfirm = signal(false);
  protected readonly pwSubmitting = signal(false);
  protected readonly pwCurrentError = signal<string | null>(null);
  protected readonly pwNewError = signal<string | null>(null);

  protected readonly pwStrength = computed(() => {
    const v = this.pwNew();
    let score = 0;
    if (v.length >= 8) score++;
    if (/[A-Z]/.test(v)) score++;
    if (/[0-9]/.test(v)) score++;
    if (/[^A-Za-z0-9]/.test(v)) score++;
    return score;
  });

  protected readonly pwNewValid = computed(() => {
    const v = this.pwNew();
    return v.length >= 8 && /[A-Z]/.test(v) && /[0-9]/.test(v);
  });

  protected readonly pwConfirmValid = computed(
    () => this.pwConfirm().length > 0 && this.pwNew() === this.pwConfirm() && this.pwNewValid(),
  );

  protected passwordStrengthLabel(): string {
    switch (this.pwStrength()) {
      case 1:
        return this.lang.tr().settings.passwordWeak;
      case 2:
        return this.lang.tr().settings.passwordMedium;
      case 3:
        return this.lang.tr().settings.passwordStrong;
      case 4:
        return this.lang.tr().settings.passwordVeryStrong;
      default:
        return '';
    }
  }

  protected openPwModal(): void {
    this.pwCurrent.set('');
    this.pwNew.set('');
    this.pwConfirm.set('');
    this.pwCurrentError.set(null);
    this.pwNewError.set(null);
    this.pwShowCurrent.set(false);
    this.pwShowNew.set(false);
    this.pwShowConfirm.set(false);
    this.showPwModal.set(true);
  }

  protected closePwModal(): void {
    this.showPwModal.set(false);
  }

  protected openLegalDialog(): void {
    this.showLegalDialog.set(true);
  }

  protected closeLegalDialog(): void {
    this.showLegalDialog.set(false);
  }

  protected openFaqDialog(): void {
    this.showFaqDialog.set(true);
  }

  protected closeFaqDialog(): void {
    this.showFaqDialog.set(false);
  }

  protected openUserDocDialog(): void {
    this.showUserDocDialog.set(true);
  }

  protected closeUserDocDialog(): void {
    this.showUserDocDialog.set(false);
  }

  protected retentionLabel(option: { label?: string; labelKey?: RetentionLabelKey }): string {
    return option.labelKey ? this.lang.tr().settings[option.labelKey] : (option.label ?? '');
  }

  protected notificationLabel(option: { labelKey: NotificationLabelKey }): string {
    return this.lang.tr().settings[option.labelKey];
  }

  // Formate la date de derniere connexion pour l'afficher sous "Connecte en tant que".
  protected readonly lastLoginLabel = computed(() => {
    const raw = this.auth.currentUser()?.lastLoginAt;
    if (!raw) return null;
    const date = new Date(raw);
    if (Number.isNaN(date.getTime())) return null;
    const formatted = date.toLocaleString(this.lang.lang(), {
      dateStyle: 'medium',
      timeStyle: 'short',
    });
    return this.lang.tr().settings.lastLoginAt.replace('{date}', formatted);
  });

  protected readonly theme = this.themeService.theme;
  protected readonly messageRetention = this.messageSettings.retention;
  protected readonly retentionOptions: { value: MessageRetention; label?: string; labelKey?: RetentionLabelKey }[] = [
    { value: '1h', label: '1 h' },
    { value: '7d', label: '7 d' },
    { value: '30d', label: '30 d' },
    { value: 'forever', labelKey: 'retentionForever' },
  ];
  protected readonly notifLikes = signal(true);
  protected readonly notifFollows = signal(true);
  protected readonly notifReplies = signal(true);
  protected readonly notifMentions = signal(true);
  protected readonly censorInput = signal(this.censor.customWords().join(', '));
  protected readonly notificationOptions: {
    key: NotificationPreference;
    sig: WritableSignal<boolean>;
    labelKey: NotificationLabelKey;
  }[] = [
    { key: 'likes', sig: this.notifLikes, labelKey: 'notifLikes' },
    { key: 'follows', sig: this.notifFollows, labelKey: 'notifFollows' },
    { key: 'replies', sig: this.notifReplies, labelKey: 'notifReplies' },
    { key: 'mentions', sig: this.notifMentions, labelKey: 'notifMentions' },
  ];
  protected readonly showLogoutModal = signal(false);
  protected readonly profilePrivate = signal(false);
  protected readonly savingPrivacy = signal(false);
  protected readonly blockedProfiles = signal<User[]>([]);
  protected readonly blockedProfilesLoading = signal(false);
  protected readonly blockedProfilesError = signal(false);
  protected readonly unblockingProfileId = signal<string | null>(null);

  constructor() {
    this.themeService.refreshForCurrentUser();
    this.messageSettings.refreshForCurrentUser();
    this.loadNotificationPreferences();
    this.messageSettings.loadFromApi().subscribe({ error: () => undefined });
    this.loadPrivacy();
    this.loadBlockedProfiles();
  }

  protected changePassword(): void {
    this.pwCurrentError.set(null);
    this.pwNewError.set(null);

    const current = this.pwCurrent().trim();
    const newPw = this.pwNew();
    const confirm = this.pwConfirm();

    if (!current) { this.pwCurrentError.set(this.lang.tr().settings.currentPasswordRequired); return; }
    if (newPw.length < 8) { this.pwNewError.set(this.lang.tr().auth.pwMin8); return; }
    if (!/[A-Z]/.test(newPw)) { this.pwNewError.set(this.lang.tr().auth.pwUppercase); return; }
    if (!/[0-9]/.test(newPw)) { this.pwNewError.set(this.lang.tr().auth.pwDigit); return; }
    if (newPw !== confirm) { this.pwNewError.set(this.lang.tr().auth.pwMismatch); return; }

    this.pwSubmitting.set(true);
    this.http
      .patch(`${environment.apiBaseUrl}/auth/me/password`, { currentPassword: current, newPassword: newPw })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.pwCurrent.set('');
          this.pwNew.set('');
          this.pwConfirm.set('');
          this.pwSubmitting.set(false);
          this.flash.show(this.lang.tr().settings.passwordUpdated, 'success');
        },
        error: (err: HttpErrorResponse) => {
          this.pwSubmitting.set(false);
          if (err.status === 401) {
            this.pwCurrentError.set(this.lang.tr().settings.currentPasswordIncorrect);
            return;
          }
          this.flash.show(this.lang.tr().settings.passwordUpdateError, 'error');
        },
      });
  }

  protected closePwModalIfBackdrop(target: EventTarget | null): void {
    if (target === (target as Element)?.closest?.('[data-modal-backdrop]')) {
      this.closePwModal();
    }
  }

  protected setTheme(t: string): void {
    this.themeService.setTheme(t as Theme);
    this.flash.show(this.lang.tr().settings.themeApplied, 'success');
  }

  protected setMessageRetention(retention: MessageRetention): void {
    this.messageSettings.saveRetention(retention).subscribe({
      next: () => this.flash.show(this.lang.tr().settings.retentionUpdated, 'success'),
      error: () => this.flash.show(this.lang.tr().settings.retentionUpdateError, 'error'),
    });
  }

  protected toggleNotification(key: NotificationPreference): void {
    const option = this.notificationOptions.find((item) => item.key === key);
    if (!option) return;

    option.sig.update((value) => !value);
    this.saveNotificationPreferences();
  }

  protected saveCensoredWords(value: string): void {
    this.censorInput.set(value);
    this.censor.setCustomWords(value.split(','));
  }

  protected setProfilePrivacy(isPrivate: boolean): void {
    if (this.savingPrivacy() || this.profilePrivate() === isPrivate) return;
    const previous = this.profilePrivate();
    this.profilePrivate.set(isPrivate);
    this.savingPrivacy.set(true);

    this.http
      .patch<{ isPrivate: boolean }>(`${environment.apiBaseUrl}/profiles/me`, { isPrivate })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (profile) => {
          this.profilePrivate.set(profile.isPrivate);
          const user = this.auth.currentUser();
          if (user) this.auth.setUser({ ...user, isPrivate: profile.isPrivate });
          this.savingPrivacy.set(false);
          this.flash.show(
            profile.isPrivate
              ? this.lang.tr().settings.profileNowPrivate
              : this.lang.tr().settings.profileNowPublic,
            'success',
          );
        },
        error: () => {
          this.profilePrivate.set(previous);
          this.savingPrivacy.set(false);
          this.flash.show(this.lang.tr().settings.privacyUpdateError, 'error');
        },
      });
  }

  // loadBlockedProfiles recupere les profils bloques du compte courant.
  // Entree : aucune.
  // Sortie : met a jour les signaux blockedProfiles, blockedProfilesLoading et blockedProfilesError.
  protected loadBlockedProfiles(): void {
    if (this.guest.isGuest()) return;

    this.blockedProfilesLoading.set(true);
    this.blockedProfilesError.set(false);
    this.http
      .get<SocialUsersResponse>(`${environment.apiBaseUrl}/users/blocked`, {
        params: { page: 1, limit: 50 },
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (response) => {
          this.blockedProfiles.set(response.users);
          this.blockedProfilesLoading.set(false);
        },
        error: () => {
          this.blockedProfilesError.set(true);
          this.blockedProfilesLoading.set(false);
        },
      });
  }

  // unblockProfile retire un profil de la liste des profils bloques.
  // Entree : user.
  // Sortie : met a jour la liste locale et affiche un message de confirmation ou d'erreur.
  protected unblockProfile(user: User): void {
    const profileId = user.profileId || user.id;
    if (!profileId || this.unblockingProfileId()) return;

    this.unblockingProfileId.set(profileId);
    this.http
      .delete<{ blocked: boolean }>(`${environment.apiBaseUrl}/users/block/${profileId}`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.blockedProfiles.update((profiles) =>
            profiles.filter((profile) => (profile.profileId || profile.id) !== profileId),
          );
          this.unblockingProfileId.set(null);
          this.flash.show(this.lang.tr().settings.blockedUnblocked, 'success');
        },
        error: () => {
          this.unblockingProfileId.set(null);
          this.flash.show(this.lang.tr().settings.blockedUnblockError, 'error');
        },
      });
  }

  protected openLogoutModal(): void {
    this.showLogoutModal.set(true);
  }

  protected closeLogoutModal(): void {
    this.showLogoutModal.set(false);
  }

  protected confirmLogout(): void {
    this.showLogoutModal.set(false);
    this.auth.logout();
    void this.router.navigate(['/auth']);
  }

  protected goToAuth(): void {
    this.guest.deactivate();
    void this.router.navigate(['/auth']);
  }

  protected goToRegister(): void {
    this.guest.deactivate();
    void this.router.navigate(['/auth'], { queryParams: { tab: 'register' } });
  }

  private loadNotificationPreferences(): void {
    if (!this.isBrowser) return;

    const key = this.notificationStorageKey();
    if (!key) return;

    const raw = localStorage.getItem(key);
    if (!raw) return;

    try {
      const preferences = JSON.parse(raw) as Partial<NotificationPreferences>;
      this.notifLikes.set(preferences.likes ?? true);
      this.notifFollows.set(preferences.follows ?? true);
      this.notifReplies.set(preferences.replies ?? true);
      this.notifMentions.set(preferences.mentions ?? true);
    } catch {
      localStorage.removeItem(key);
    }
  }

  private loadPrivacy(): void {
    this.http
      .get<{ isPrivate: boolean }>(`${environment.apiBaseUrl}/profiles/me`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (profile) => this.profilePrivate.set(profile.isPrivate),
        error: () => undefined,
      });
  }

  private saveNotificationPreferences(): void {
    if (!this.isBrowser) return;

    const key = this.notificationStorageKey();
    if (!key) return;

    localStorage.setItem(
      key,
      JSON.stringify({
        likes: this.notifLikes(),
        follows: this.notifFollows(),
        replies: this.notifReplies(),
        mentions: this.notifMentions(),
      } satisfies NotificationPreferences),
    );
  }

  private notificationStorageKey(): string | null {
    const session = this.token.getSession();
    const userKey = session?.user?.id ?? session?.email;
    return userKey ? `breezy.users.${userKey}.notifications` : null;
  }
}
