import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationDialog } from './confirmation-dialog';

describe('ConfirmationDialog', () => {
  let fixture: ComponentFixture<ConfirmationDialog>;
  let component: ConfirmationDialog;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConfirmationDialog],
    })
      .overrideComponent(ConfirmationDialog, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(ConfirmationDialog);
    component = fixture.componentInstance;
  });

  it('uses default input values and emits actions', () => {
    const confirmed: void[] = [];
    const cancelled: void[] = [];
    component.confirmed.subscribe(() => confirmed.push(undefined));
    component.cancelled.subscribe(() => cancelled.push(undefined));

    component.confirmed.emit();
    component.cancelled.emit();

    expect(component.cancelLabel).toBe('Annuler');
    expect(component.busy).toBe(false);
    expect(confirmed.length).toBe(1);
    expect(cancelled.length).toBe(1);
  });
});
