import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmojiPicker } from './emoji-picker';

describe('EmojiPicker', () => {
  let fixture: ComponentFixture<EmojiPicker>;
  let component: EmojiPicker;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmojiPicker],
    })
      .overrideComponent(EmojiPicker, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(EmojiPicker);
    component = fixture.componentInstance;
  });

  it('shows the active category emojis and filters by category name', () => {
    const initialCount = (component as any).visibleEmojis().length;
    expect(initialCount).toBeGreaterThan(0);

    (component as any).search.set('coeurs');
    expect((component as any).visibleEmojis().length).toBeGreaterThan(0);

    (component as any).search.set('missing');
    expect((component as any).visibleEmojis()).toEqual([]);
  });

  it('emits selected emojis', () => {
    const selected: string[] = [];
    component.emojiSelected.subscribe((emoji) => selected.push(emoji));

    (component as any).select('x');

    expect(selected).toEqual(['x']);
  });
});
