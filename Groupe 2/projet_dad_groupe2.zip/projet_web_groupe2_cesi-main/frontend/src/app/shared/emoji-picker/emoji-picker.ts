import { ChangeDetectionStrategy, Component, computed, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

interface EmojiCategory {
  name: string;
  icon: string;
  emojis: string[];
}

const CATEGORIES: EmojiCategory[] = [
  {
    name: 'Visages',
    icon: '😊',
    emojis: ['😀','😃','😄','😁','😆','😅','😂','🤣','😊','😇','🙂','🙃','😉','😌','😍','🥰','😘','😗','😙','😚','😋','😛','😝','😜','🤪','🤨','🧐','🤓','😎','🥳','😏','😒','😞','😔','😟','😕','🙁','☹️','😣','😖','😫','😩','🥺','😢','😭','😤','😠','😡','🤬','🤯','😳','🥵','🥶','😱','😨','😰','😥','😓','🤗','🤔','🫣','🤭','🫢','🫡','🤫','🫠','😶','😐','😑','😬','🙄','😯','😦','😧','😮','😲','🥱','😴','🤤','😪','😵','🤐','🤢','🤮','🤧','😷','🤒','🤕'],
  },
  {
    name: 'Gestes',
    icon: '👍',
    emojis: ['👋','🤚','🖐️','✋','🖖','🫱','🫲','🫳','🫴','👌','🤌','🤏','✌️','🤞','🫰','🤟','🤘','🤙','👈','👉','👆','👇','☝️','🫵','👍','👎','✊','👊','🤛','🤜','👏','🙌','🫶','👐','🤲','🤝','🙏','✍️','💅','🤳','💪','🦾','🦵','🦶','👂','👃','🧠','🫀','🫁','👀','👁️','👅','👄'],
  },
  {
    name: 'Coeurs',
    icon: '❤️',
    emojis: ['❤️','🩷','🧡','💛','💚','💙','🩵','💜','🤎','🖤','🩶','🤍','💔','❤️‍🔥','❤️‍🩹','❣️','💕','💞','💓','💗','💖','💘','💝','💟','💋','💯','💢','💥','💫','💦','💨','🕳️','💬','👁️‍🗨️','🗨️','🗯️','💭','💤'],
  },
  {
    name: 'Activités',
    icon: '🎉',
    emojis: ['🎉','🎊','🎈','🎂','🎁','🎀','🎵','🎶','🎤','🎧','🎸','🎹','🥁','🎷','🎺','🎻','🎬','🎨','🎭','🎮','🕹️','🎲','♟️','⚽','🏀','🏈','⚾','🎾','🏐','🏉','🥏','🎱','🏓','🏸','🥊','🥋','⛳','⛸️','🎣','🤿','🎯','🪁','🛹','🛼','🏆','🥇','🥈','🥉'],
  },
  {
    name: 'Nourriture',
    icon: '🍕',
    emojis: ['🍏','🍎','🍐','🍊','🍋','🍌','🍉','🍇','🍓','🫐','🍈','🍒','🍑','🥭','🍍','🥥','🥝','🍅','🥑','🍆','🥦','🥬','🥒','🌶️','🫑','🌽','🥕','🫒','🧄','🧅','🥔','🍠','🥐','🥯','🍞','🥖','🥨','🧀','🥚','🍳','🥞','🧇','🥓','🍔','🍟','🍕','🌭','🥪','🌮','🌯','🥗','🍝','🍜','🍣','🍱','🍛','🍚','🍦','🍩','🍪','🍫','🍿','☕','🧋','🥤'],
  },
  {
    name: 'Symboles',
    icon: '✨',
    emojis: ['✨','⭐','🌟','💫','⚡','🔥','🌈','☀️','🌤️','⛅','🌙','🌍','🌎','🌏','🚀','🛸','💡','📌','📍','✅','❌','⭕','❗','❓','‼️','⁉️','➕','➖','➗','✖️','♻️','⚠️','🚫','🔞','⬆️','➡️','⬇️','⬅️','↗️','↘️','↙️','↖️','↔️','🔄','▶️','⏸️','⏹️','🔔','🔕','🎶','💬','📣','📢','🔒','🔓','🔑','🧩','🪄'],
  },
];

@Component({
  selector: 'app-emoji-picker',
  templateUrl: './emoji-picker.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  host: { class: 'block' },
})
export class EmojiPicker {
  readonly emojiSelected = output<string>();
  readonly closed = output<void>();

  protected readonly categories = CATEGORIES;
  protected readonly activeCategory = signal(CATEGORIES[0].name);
  protected readonly search = signal('');

  protected readonly visibleEmojis = computed(() => {
    const query = this.search().trim().toLowerCase();
    if (query) {
      return CATEGORIES
        .filter((category) => category.name.toLowerCase().includes(query))
        .flatMap((category) => category.emojis);
    }
    return CATEGORIES.find((category) => category.name === this.activeCategory())?.emojis ?? [];
  });

  protected select(emoji: string): void {
    this.emojiSelected.emit(emoji);
  }
}
