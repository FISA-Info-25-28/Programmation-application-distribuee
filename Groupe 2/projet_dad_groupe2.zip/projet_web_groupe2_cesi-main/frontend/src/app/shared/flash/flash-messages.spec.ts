import { ComponentFixture, TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';

import { FlashMessages } from './flash-messages';
import { FlashService } from './flash.service';

describe('FlashMessages', () => {
  let fixture: ComponentFixture<FlashMessages>;
  let component: FlashMessages;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FlashMessages],
      providers: [{ provide: FlashService, useValue: { messages: signal([]), dismiss: () => undefined } }],
    })
      .overrideComponent(FlashMessages, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(FlashMessages);
    component = fixture.componentInstance;
  });

  it('creates with the injected flash service', () => {
    expect(component).toBeTruthy();
  });
});
