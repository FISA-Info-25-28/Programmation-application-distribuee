import { Component } from '@angular/core';
import { FlashService } from './flash.service';

@Component({
  selector: 'app-flash-messages',
  templateUrl: './flash-messages.html',
})
export class FlashMessages {
  constructor(protected readonly flash: FlashService) {}
}
