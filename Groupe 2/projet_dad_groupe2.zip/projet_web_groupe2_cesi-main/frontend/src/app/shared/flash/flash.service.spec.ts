import { TestBed } from '@angular/core/testing';
import { FlashService } from './flash.service';
import { vi } from 'vitest';

describe('FlashService', () => {
  let service: FlashService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FlashService);
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('adds messages, dismisses them and auto-dismisses after a delay', () => {
    vi.useFakeTimers();

    service.show('Saved', 'success');
    service.show('Careful');

    expect(service.messages()).toEqual([
      { id: 1, text: 'Saved', type: 'success' },
      { id: 2, text: 'Careful', type: 'info' },
    ]);

    service.dismiss(1);
    expect(service.messages()).toEqual([{ id: 2, text: 'Careful', type: 'info' }]);

    vi.advanceTimersByTime(3500);
    expect(service.messages()).toEqual([]);
  });
});
