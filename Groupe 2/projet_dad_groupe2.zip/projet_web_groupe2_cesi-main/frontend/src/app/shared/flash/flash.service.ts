import { Injectable, signal } from '@angular/core';

export type FlashType = 'success' | 'info' | 'error';

export interface FlashMessage {
  id: number;
  text: string;
  type: FlashType;
}

@Injectable({
  providedIn: 'root',
})
export class FlashService {
  private nextId = 1;
  readonly messages = signal<FlashMessage[]>([]);

  show(text: string, type: FlashType = 'info'): void {
    const message: FlashMessage = {
      id: this.nextId++,
      text,
      type,
    };

    this.messages.update((messages) => [...messages, message]);

    window.setTimeout(() => {
      this.dismiss(message.id);
    }, 3500);
  }

  dismiss(id: number): void {
    this.messages.update((messages) => messages.filter((message) => message.id !== id));
  }
}
