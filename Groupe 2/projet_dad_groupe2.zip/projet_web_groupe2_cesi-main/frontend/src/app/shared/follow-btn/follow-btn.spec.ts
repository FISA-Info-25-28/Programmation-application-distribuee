import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { FollowBtn, FollowState } from './follow-btn';
import { FlashService } from '../flash/flash.service';
import { GuestService } from '../../core/services/guest.service';
import { LangService } from '../../core/services/lang.service';

describe('FollowBtn', () => {
  let fixture: ComponentFixture<FollowBtn>;
  let component: FollowBtn;
  let http: { post: ReturnType<typeof vi.fn>; delete: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };
  let guest: { requireAuth: ReturnType<typeof vi.fn> };
  let changes: FollowState[];

  beforeEach(async () => {
    http = {
      post: vi.fn().mockReturnValue(of({ following: true, requestPending: false })),
      delete: vi.fn().mockReturnValue(of({ following: false, requestPending: false })),
    };
    flash = { show: vi.fn() };
    guest = { requireAuth: vi.fn(() => true) };
    changes = [];

    await TestBed.configureTestingModule({
      imports: [FollowBtn],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: FlashService, useValue: flash },
        { provide: GuestService, useValue: guest },
        {
          provide: LangService,
          useValue: {
            tr: () => ({
              follow: {
                requestSentTo: 'Demande envoyee a',
                requestSent: 'Demande envoyee',
                followingUser: 'Abonnement ajoute a',
                followingAdded: 'Abonnement ajoute',
                requestCanceled: 'Demande annulee',
                followCanceled: 'Abonnement annule',
                networkError: 'Erreur reseau',
              },
            }),
          },
        },
      ],
    })
      .overrideComponent(FollowBtn, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(FollowBtn);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('userId', 'user-2');
    fixture.componentRef.setInput('displayName', 'Bob');
    (component as any).followChange.subscribe((state: FollowState) => changes.push(state));
    fixture.detectChanges();
  });

  it('follows a user and emits the new state', () => {
    const event = { stopPropagation: vi.fn() };

    (component as any).toggle(event);

    expect(event.stopPropagation).toHaveBeenCalled();
    expect(http.post).toHaveBeenCalledWith(expect.stringContaining('/users/follow/user-2'), {});
    expect((component as any).isFollowing()).toBe(true);
    expect((component as any).requestPending()).toBe(false);
    expect(changes).toEqual([{ following: true, requestPending: false }]);
    expect(flash.show).toHaveBeenCalledWith('Abonnement ajoute a Bob', 'success');
  });

  it('unfollows when already following', () => {
    fixture.componentRef.setInput('isFollowing', true);
    fixture.detectChanges();

    (component as any).toggle({ stopPropagation: vi.fn() });

    expect(http.delete).toHaveBeenCalledWith(expect.stringContaining('/users/follow/user-2'));
    expect((component as any).isFollowing()).toBe(false);
    expect(flash.show).toHaveBeenCalledWith('Abonnement annule', 'info');
  });

  it('does nothing when guest access is blocked', () => {
    guest.requireAuth.mockReturnValue(false);

    (component as any).toggle({ stopPropagation: vi.fn() });

    expect(http.post).not.toHaveBeenCalled();
    expect(http.delete).not.toHaveBeenCalled();
  });

  it('restores the previous state and flashes an error when the request fails', () => {
    http.delete.mockReturnValue(throwError(() => new Error('network')));
    fixture.componentRef.setInput('isFollowing', true);
    fixture.detectChanges();

    (component as any).toggle({ stopPropagation: vi.fn() });

    expect((component as any).isFollowing()).toBe(true);
    expect((component as any).requestPending()).toBe(false);
    expect(flash.show).toHaveBeenCalledWith('Erreur reseau', 'error');
  });
});
