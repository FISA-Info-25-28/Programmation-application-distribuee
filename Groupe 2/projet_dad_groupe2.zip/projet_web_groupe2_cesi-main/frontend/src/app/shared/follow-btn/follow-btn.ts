import { ChangeDetectionStrategy, Component, DestroyRef, inject, input, model, output } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { LangService } from '../../core/services/lang.service';
import { FlashService } from '../flash/flash.service';
import { GuestService } from '../../core/services/guest.service';

export interface FollowState {
  following: boolean;
  requestPending: boolean;
}

@Component({
  selector: 'app-follow-btn',
  templateUrl: './follow-btn.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FollowBtn {
  readonly userId = input.required<string>();
  readonly displayName = input('');
  readonly compact = input(false);
  readonly isFollowing = model(false);
  readonly requestPending = model(false);
  readonly followChange = output<FollowState>();

  private readonly http = inject(HttpClient);
  protected readonly lang = inject(LangService);
  private readonly flash = inject(FlashService);
  private readonly guest = inject(GuestService);
  private readonly destroyRef = inject(DestroyRef);

  protected toggle(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    const previous: FollowState = {
      following: this.isFollowing(),
      requestPending: this.requestPending(),
    };
    const removing = previous.following || previous.requestPending;
    const request$ = removing
      ? this.http.delete<FollowState>(
          `${environment.apiBaseUrl}/users/follow/${this.userId()}`,
        )
      : this.http.post<FollowState>(
          `${environment.apiBaseUrl}/users/follow/${this.userId()}`,
          {},
        );

    request$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (state) => {
        this.isFollowing.set(state.following);
        this.requestPending.set(state.requestPending);
        this.followChange.emit(state);

        const name = this.displayName();
        if (state.requestPending) {
          this.flash.show(
            name
              ? `${this.lang.tr().follow.requestSentTo} ${name}`
              : this.lang.tr().follow.requestSent,
            'success',
          );
        } else if (state.following) {
          this.flash.show(
            name
              ? `${this.lang.tr().follow.followingUser} ${name}`
              : this.lang.tr().follow.followingAdded,
            'success',
          );
        } else {
          this.flash.show(
            previous.requestPending
              ? this.lang.tr().follow.requestCanceled
              : this.lang.tr().follow.followCanceled,
            'info',
          );
        }
      },
      error: () => {
        this.isFollowing.set(previous.following);
        this.requestPending.set(previous.requestPending);
        this.flash.show(this.lang.tr().follow.networkError, 'error');
      },
    });
  }
}
