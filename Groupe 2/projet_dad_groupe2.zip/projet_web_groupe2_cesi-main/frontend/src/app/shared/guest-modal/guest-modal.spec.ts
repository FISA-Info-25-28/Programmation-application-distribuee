import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { vi } from 'vitest';

import { GuestModal } from './guest-modal';
import { GuestService } from '../../core/services/guest.service';

describe('GuestModal', () => {
  let fixture: ComponentFixture<GuestModal>;
  let component: GuestModal;
  let guest: { hideModal: ReturnType<typeof vi.fn>; deactivate: ReturnType<typeof vi.fn> };
  let router: { navigate: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    guest = { hideModal: vi.fn(), deactivate: vi.fn() };
    router = { navigate: vi.fn().mockResolvedValue(true) };

    await TestBed.configureTestingModule({
      imports: [GuestModal],
      providers: [
        { provide: GuestService, useValue: guest },
        { provide: Router, useValue: router },
      ],
    })
      .overrideComponent(GuestModal, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(GuestModal);
    component = fixture.componentInstance;
  });

  it('closes and routes to auth flows', () => {
    (component as any).close();
    expect(guest.hideModal).toHaveBeenCalled();

    (component as any).goToLogin();
    expect(guest.deactivate).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith(['/auth']);

    (component as any).goToRegister();
    expect(router.navigate).toHaveBeenCalledWith(['/auth'], { queryParams: { tab: 'register' } });
  });
});
