import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { GuestService } from '../../core/services/guest.service';
import { TPipe } from '../../core/pipes/t.pipe';

@Component({
  selector: 'app-guest-modal',
  templateUrl: './guest-modal.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [TPipe],
  host: { style: 'display: contents' },
})
export class GuestModal {
  protected readonly guest = inject(GuestService);
  private readonly router = inject(Router);

  protected close(): void {
    this.guest.hideModal();
  }

  protected goToLogin(): void {
    this.guest.deactivate();
    void this.router.navigate(['/auth']);
  }

  protected goToRegister(): void {
    this.guest.deactivate();
    void this.router.navigate(['/auth'], { queryParams: { tab: 'register' } });
  }
}
