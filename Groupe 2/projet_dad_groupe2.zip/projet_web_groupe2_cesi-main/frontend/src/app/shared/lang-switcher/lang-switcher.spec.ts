import { ComponentFixture, TestBed } from '@angular/core/testing';
import { vi } from 'vitest';

import { LangSwitcher } from './lang-switcher';
import { LangService } from '../../core/services/lang.service';

describe('LangSwitcher', () => {
  let fixture: ComponentFixture<LangSwitcher>;
  let component: LangSwitcher;
  let setLang: ReturnType<typeof vi.fn>;

  beforeEach(async () => {
    setLang = vi.fn();
    await TestBed.configureTestingModule({
      imports: [LangSwitcher],
      providers: [{ provide: LangService, useValue: { setLang } }],
    })
      .overrideComponent(LangSwitcher, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(LangSwitcher);
    component = fixture.componentInstance;
  });

  it('lists supported languages and updates the selected language', () => {
    expect((component as any).options.map((option: { value: string }) => option.value)).toEqual([
      'fr',
      'en',
      'es',
      'it',
      'de',
      'pt',
    ]);

    (component as any).select('en');

    expect(setLang).toHaveBeenCalledWith('en');
  });
});
