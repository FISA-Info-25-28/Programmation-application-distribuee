import { ChangeDetectionStrategy, Component, inject } from '@angular/core';

import { LangService, type Lang } from '../../core/services/lang.service';

@Component({
  selector: 'app-lang-switcher',
  templateUrl: './lang-switcher.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LangSwitcher {
  protected readonly lang = inject(LangService);

  protected readonly options: { value: Lang; code: string; label: string; region: string }[] = [
    { value: 'fr', code: 'FR', label: 'Français', region: 'France' },
    { value: 'en', code: 'EN', label: 'English', region: 'United States' },
    { value: 'es', code: 'ES', label: 'Español', region: 'España' },
    { value: 'it', code: 'IT', label: 'Italiano', region: 'Italia' },
    { value: 'de', code: 'DE', label: 'Deutsch', region: 'Deutschland' },
    { value: 'pt', code: 'PT', label: 'Portugues', region: 'Portugal' },
  ];

  protected select(l: Lang): void {
    this.lang.setLang(l);
  }
}
