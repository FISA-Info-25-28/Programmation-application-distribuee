import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LegalDialog } from './legal-dialog';

describe('LegalDialog', () => {
  let fixture: ComponentFixture<LegalDialog>;
  let component: LegalDialog;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LegalDialog],
    })
      .overrideComponent(LegalDialog, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(LegalDialog);
    component = fixture.componentInstance;
  });

  it('requires reaching the end before accepting', () => {
    const accepted: void[] = [];
    const closed: void[] = [];
    component.accepted.subscribe(() => accepted.push(undefined));
    component.closed.subscribe(() => closed.push(undefined));

    (component as any).accept();
    expect(accepted.length).toBe(0);

    (component as any).markReadIfAtEnd({
      target: { scrollTop: 90, clientHeight: 100, scrollHeight: 200 },
    } as unknown as Event);
    (component as any).accept();

    expect(accepted.length).toBe(1);
    expect(closed.length).toBe(1);
  });
});
