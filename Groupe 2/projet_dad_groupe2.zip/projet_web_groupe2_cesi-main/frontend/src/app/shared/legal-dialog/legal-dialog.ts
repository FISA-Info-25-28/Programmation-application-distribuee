import { AfterViewInit, Component, ElementRef, ViewChild, output, signal } from '@angular/core';
import { TPipe } from '../../core/pipes/t.pipe';

@Component({
  selector: 'app-legal-dialog',
  imports: [TPipe],
  templateUrl: './legal-dialog.html',
})
export class LegalDialog implements AfterViewInit {
  @ViewChild('legalBody') private legalBody?: ElementRef<HTMLElement>;

  readonly closed = output<void>();
  readonly accepted = output<void>();

  protected readonly reachedEnd = signal(false);

  ngAfterViewInit(): void {
    queueMicrotask(() => this.updateReachedEnd(this.legalBody?.nativeElement));
  }

  protected markReadIfAtEnd(event: Event): void {
    this.updateReachedEnd(event.target as HTMLElement);
  }

  protected accept(): void {
    if (!this.reachedEnd()) return;
    this.accepted.emit();
    this.closed.emit();
  }

  private updateReachedEnd(element: HTMLElement | undefined): void {
    if (!element) return;
    const hasReachedEnd = element.scrollTop + element.clientHeight >= element.scrollHeight - 16;
    this.reachedEnd.set(hasReachedEnd);
  }
}
