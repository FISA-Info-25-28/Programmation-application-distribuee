import { ComponentFixture, TestBed } from '@angular/core/testing';
import { vi } from 'vitest';

import { MediaGallery } from './media-gallery';
import { MediaAttachment } from '../../core/models/media.model';

const media: MediaAttachment[] = [
  { id: '1', type: 'IMAGE', url: '/1.png' },
  { id: '2', type: 'VIDEO', url: '/2.mp4' },
  { id: '3', type: 'IMAGE', url: '/3.png' },
  { id: '4', type: 'IMAGE', url: '/4.png' },
  { id: '5', type: 'IMAGE', url: '/5.png' },
];

describe('MediaGallery', () => {
  let fixture: ComponentFixture<MediaGallery>;
  let component: MediaGallery;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MediaGallery],
    })
      .overrideComponent(MediaGallery, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(MediaGallery);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('media', media);
    fixture.detectChanges();
  });

  it('shows up to four media and computes grid/item classes', () => {
    expect((component as any).visibleMedia().length).toBe(4);
    expect((component as any).gridClass()).toBe('grid-cols-2');

    fixture.componentRef.setInput('variant', 'message');
    expect((component as any).itemClass(0)).toContain('min-h-[150px]');
  });

  it('opens only images and navigates between image media', () => {
    const event = { stopPropagation: vi.fn() };

    (component as any).open(1, event);
    expect((component as any).activeIndex()).toBeNull();

    (component as any).open(0, event);
    expect((component as any).activeMedia()).toEqual(media[0]);

    (component as any).next(event);
    expect((component as any).activeMedia()).toEqual(media[2]);

    (component as any).previous(event);
    expect((component as any).activeMedia()).toEqual(media[0]);

    (component as any).close(event);
    expect((component as any).activeIndex()).toBeNull();
  });
});
