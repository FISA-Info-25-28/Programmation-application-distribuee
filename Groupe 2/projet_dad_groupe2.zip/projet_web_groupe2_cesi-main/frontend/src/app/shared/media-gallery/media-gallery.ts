import {
  ChangeDetectionStrategy,
  Component,
  computed,
  HostListener,
  input,
  signal,
} from '@angular/core';

import { MediaAttachment } from '../../core/models/media.model';

export type MediaGalleryVariant = 'post' | 'detail' | 'message';

@Component({
  selector: 'app-media-gallery',
  templateUrl: './media-gallery.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'block' },
})
export class MediaGallery {
  readonly media = input<MediaAttachment[]>([]);
  readonly variant = input<MediaGalleryVariant>('post');
  readonly label = input('Media de la publication');

  protected readonly visibleMedia = computed(() => this.media().slice(0, 4));
  protected readonly activeIndex = signal<number | null>(null);

  protected readonly activeMedia = computed(() => {
    const index = this.activeIndex();
    return index === null ? null : this.media()[index] ?? null;
  });

  protected gridClass(): string {
    return this.visibleMedia().length === 1 ? 'grid-cols-1' : 'grid-cols-2';
  }

  protected itemClass(index: number): string {
    const count = this.visibleMedia().length;
    const size =
      this.variant() === 'detail'
        ? 'min-h-[240px] max-h-[680px]'
        : this.variant() === 'message'
          ? 'min-h-[150px] max-h-[380px]'
          : 'min-h-[200px] max-h-[480px]';

    if (count === 3 && index === 0) return `${size} row-span-2`;
    return size;
  }

  protected open(index: number, event: Event): void {
    event.stopPropagation();
    if (this.media()[index]?.type === 'IMAGE') this.activeIndex.set(index);
  }

  protected close(event?: Event): void {
    event?.stopPropagation();
    this.activeIndex.set(null);
  }

  protected previous(event: Event): void {
    event.stopPropagation();
    this.move(-1);
  }

  protected next(event: Event): void {
    event.stopPropagation();
    this.move(1);
  }

  private move(direction: number): void {
    const images = this.media()
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => item.type === 'IMAGE');
    const current = images.findIndex(({ index }) => index === this.activeIndex());
    if (current < 0 || images.length < 2) return;
    const target = (current + direction + images.length) % images.length;
    this.activeIndex.set(images[target].index);
  }

  @HostListener('document:keydown.escape')
  protected onEscape(): void {
    this.activeIndex.set(null);
  }
}
