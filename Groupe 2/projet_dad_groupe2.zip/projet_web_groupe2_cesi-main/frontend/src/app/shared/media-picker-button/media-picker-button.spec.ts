import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MediaPickerButton } from './media-picker-button';

describe('MediaPickerButton', () => {
  let fixture: ComponentFixture<MediaPickerButton>;
  let component: MediaPickerButton;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MediaPickerButton],
    })
      .overrideComponent(MediaPickerButton, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(MediaPickerButton);
    component = fixture.componentInstance;
  });

  it('computes accepted mime types for each picker kind', () => {
    fixture.componentRef.setInput('kind', 'image');
    expect((component as any).accept()).toContain('image/png');
    expect((component as any).accept()).not.toContain('video/mp4');

    fixture.componentRef.setInput('kind', 'video');
    expect((component as any).accept()).toContain('video/mp4');
    expect((component as any).accept()).not.toContain('image/png');
  });

  it('emits selected files and clears the input value', () => {
    const selected: File[][] = [];
    const file = new File(['x'], 'image.png', { type: 'image/png' });
    component.filesSelected.subscribe((files) => selected.push(files));
    const input = {
      files: [file],
      value: 'C:\\fakepath\\image.png',
    };

    (component as any).select({ target: input } as unknown as Event);

    expect(selected).toEqual([[file]]);
    expect(input.value).toBe('');
  });
});
