import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

export type MediaPickerKind = 'image' | 'video' | 'mixed';

@Component({
  selector: 'app-media-picker-button',
  templateUrl: './media-picker-button.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MediaPickerButton {
  readonly kind = input<MediaPickerKind>('mixed');
  readonly multiple = input(false);
  readonly disabled = input(false);
  readonly filesSelected = output<File[]>();

  protected accept(): string {
    if (this.kind() === 'image') return 'image/jpeg,image/png,image/webp,image/gif';
    if (this.kind() === 'video') return 'video/mp4,video/webm,video/quicktime';
    return 'image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime';
  }

  protected select(event: Event): void {
    const input = event.target as HTMLInputElement;
    const files = Array.from(input.files ?? []);
    input.value = '';
    if (files.length) this.filesSelected.emit(files);
  }
}
