import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MediaPreview } from './media-preview';

describe('MediaPreview', () => {
  let fixture: ComponentFixture<MediaPreview>;
  let component: MediaPreview;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MediaPreview],
    })
      .overrideComponent(MediaPreview, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(MediaPreview);
    component = fixture.componentInstance;
  });

  it('exposes default inputs and emits removed indexes', () => {
    const removed: number[] = [];
    component.removed.subscribe((index) => removed.push(index));

    component.removed.emit(1);

    expect(component.media()).toEqual([]);
    expect(component.uploading()).toBe(false);
    expect(component.removable()).toBe(false);
    expect(removed).toEqual([1]);
  });
});
