import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

import { MediaAttachment } from '../../core/models/media.model';

@Component({
  selector: 'app-media-preview',
  templateUrl: './media-preview.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MediaPreview {
  readonly media = input<MediaAttachment[]>([]);
  readonly uploading = input(false);
  readonly removable = input(false);
  readonly compact = input(false);
  readonly removed = output<number>();
}
