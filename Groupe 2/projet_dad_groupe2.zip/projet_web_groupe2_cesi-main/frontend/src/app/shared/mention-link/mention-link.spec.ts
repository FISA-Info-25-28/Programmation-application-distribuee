import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { MentionLink } from './mention-link';

describe('MentionLink', () => {
  let fixture: ComponentFixture<MentionLink>;
  let component: MentionLink;
  let http: { get: ReturnType<typeof vi.fn> };
  let router: { navigate: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    http = { get: vi.fn().mockReturnValue(of({})) };
    router = { navigate: vi.fn().mockResolvedValue(true) };

    await TestBed.configureTestingModule({
      imports: [MentionLink],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: Router, useValue: router },
      ],
    })
      .overrideComponent(MentionLink, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(MentionLink);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('username', ' Ada ');
    fixture.componentRef.setInput('text', '@Ada');
    fixture.detectChanges();
  });

  it('checks profile existence and navigates to normalized usernames', () => {
    const event = { preventDefault: vi.fn(), stopPropagation: vi.fn() };

    (component as any).openProfile(event);

    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(http.get).toHaveBeenCalledWith(expect.stringContaining('/profiles/ada'));
    expect(router.navigate).toHaveBeenCalledWith(['/home/profile', 'ada']);
  });

  it('does not navigate when the profile lookup fails', () => {
    http.get.mockReturnValue(throwError(() => new Error('missing')));
    fixture.componentRef.setInput('username', 'unknown');
    fixture.detectChanges();

    (component as any).openProfile({ preventDefault: vi.fn(), stopPropagation: vi.fn() });

    expect(router.navigate).not.toHaveBeenCalled();
  });
});
