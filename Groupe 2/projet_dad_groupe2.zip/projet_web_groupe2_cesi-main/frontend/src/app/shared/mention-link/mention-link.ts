import { ChangeDetectionStrategy, Component, inject, input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, map, Observable, of, shareReplay, take } from 'rxjs';

import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-mention-link',
  templateUrl: './mention-link.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'contents' },
})
export class MentionLink {
  private static readonly profileChecks = new Map<string, Observable<boolean>>();

  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);

  readonly username = input.required<string>();
  readonly text = input.required<string>();

  protected openProfile(event: MouseEvent): void {
    event.preventDefault();
    event.stopPropagation();

    const username = this.username().trim().toLowerCase();
    if (!username) return;

    this.profileExists(username)
      .pipe(take(1))
      .subscribe((exists) => {
        if (exists) {
          void this.router.navigate(['/home/profile', username]);
        }
      });
  }

  private profileExists(username: string): Observable<boolean> {
    const cached = MentionLink.profileChecks.get(username);
    if (cached) return cached;

    const request = this.http
      .get(`${environment.apiBaseUrl}/profiles/${encodeURIComponent(username)}`)
      .pipe(
        map(() => true),
        catchError(() => of(false)),
        shareReplay({ bufferSize: 1, refCount: false }),
      );

    MentionLink.profileChecks.set(username, request);
    return request;
  }
}
