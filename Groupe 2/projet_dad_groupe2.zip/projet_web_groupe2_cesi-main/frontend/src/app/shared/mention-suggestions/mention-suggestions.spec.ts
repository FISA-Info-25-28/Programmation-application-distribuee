import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { MentionSuggestions } from './mention-suggestions';
import { User } from '../../core/models/user.model';

const users: User[] = Array.from({ length: 6 }, (_, index) => ({
  id: `user-${index}`,
  username: `user${index}`,
  displayName: `User ${index}`,
  email: `user${index}@example.test`,
  role: 'USER',
  bio: null,
  avatarUrl: null,
  followersCount: 0,
  followingCount: 0,
  postsCount: 0,
  createdAt: '2026-01-01T00:00:00Z',
}));

describe('MentionSuggestions', () => {
  let fixture: ComponentFixture<MentionSuggestions>;
  let component: MentionSuggestions;
  let http: { get: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    vi.useFakeTimers();
    http = { get: vi.fn().mockReturnValue(of(users)) };

    await TestBed.configureTestingModule({
      imports: [MentionSuggestions],
      providers: [{ provide: HttpClient, useValue: http }],
    })
      .overrideComponent(MentionSuggestions, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(MentionSuggestions);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('loads up to five suggestions for an active mention query', () => {
    fixture.componentRef.setInput('text', 'Hello @ad');
    fixture.detectChanges();
    vi.advanceTimersByTime(180);

    expect(http.get).toHaveBeenCalledWith(expect.stringContaining('/users/search'), {
      params: { q: 'ad' },
    });
    expect((component as any).users().length).toBe(5);
    expect((component as any).loading()).toBe(false);
  });

  it('clears users after selection and on failed lookup', () => {
    const selected: string[] = [];
    component.mentionSelected.subscribe((username) => selected.push(username));
    (component as any).users.set(users.slice(0, 2));

    (component as any).select('ada');

    expect(selected).toEqual(['ada']);
    expect((component as any).users()).toEqual([]);

    http.get.mockReturnValue(throwError(() => new Error('network')));
    fixture.componentRef.setInput('text', '@x');
    fixture.detectChanges();
    vi.advanceTimersByTime(180);

    expect((component as any).users()).toEqual([]);
  });
});
