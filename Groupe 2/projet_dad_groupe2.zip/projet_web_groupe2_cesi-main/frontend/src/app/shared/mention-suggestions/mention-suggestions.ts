import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, debounceTime, distinctUntilChanged, of, Subject, switchMap } from 'rxjs';

import { environment } from '../../../environments/environment';
import { User } from '../../core/models/user.model';
import { activeMentionQuery } from '../../core/utils/social-text';
import { UserAvatar } from '../user-avatar/user-avatar';

@Component({
  selector: 'app-mention-suggestions',
  templateUrl: './mention-suggestions.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [UserAvatar],
})
export class MentionSuggestions {
  private readonly http = inject(HttpClient);
  private readonly destroyRef = inject(DestroyRef);
  private readonly search$ = new Subject<string>();

  readonly text = input('');
  readonly placement = input<'above' | 'below'>('below');
  readonly mentionSelected = output<string>();

  protected readonly users = signal<User[]>([]);
  protected readonly loading = signal(false);
  protected readonly query = computed(() => activeMentionQuery(this.text()));

  constructor() {
    effect(() => {
      const query = this.query();
      if (query === null) {
        this.users.set([]);
        return;
      }
      this.search$.next(query);
    });

    this.search$
      .pipe(
        debounceTime(180),
        distinctUntilChanged(),
        switchMap((query) => {
          this.loading.set(true);
          const endpoint = query ? '/users/search' : '/users/suggestions';
          const options = query ? { params: { q: query } } : {};
          return this.http.get<User[]>(`${environment.apiBaseUrl}${endpoint}`, options).pipe(
            catchError(() => of([] as User[])),
          );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((users) => {
        this.users.set(users.slice(0, 5));
        this.loading.set(false);
      });
  }

  protected select(username: string): void {
    this.mentionSelected.emit(username);
    this.users.set([]);
  }
}
