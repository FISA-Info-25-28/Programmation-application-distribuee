import { ComponentFixture, TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';

import { MobileBottomNav } from './mobile-bottom-nav';
import { AuthService } from '../../core/services/auth.service';

describe('MobileBottomNav', () => {
  let fixture: ComponentFixture<MobileBottomNav>;
  let component: MobileBottomNav;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MobileBottomNav],
      providers: [{ provide: AuthService, useValue: { unreadMessageCount: signal(3) } }],
    })
      .overrideComponent(MobileBottomNav, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(MobileBottomNav);
    component = fixture.componentInstance;
  });

  it('exposes unread message count and emits publish clicks', () => {
    const clicks: void[] = [];
    component.publishClicked.subscribe(() => clicks.push(undefined));

    component.publishClicked.emit();

    expect((component as any).unreadMsg()).toBe(3);
    expect(clicks.length).toBe(1);
  });
});
