import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { TPipe } from '../../core/pipes/t.pipe';

@Component({
  selector: 'app-mobile-bottom-nav',
  templateUrl: './mobile-bottom-nav.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive, TPipe],
})
export class MobileBottomNav {
  readonly publishClicked = output<void>();

  private readonly auth = inject(AuthService);
  protected readonly unreadMsg = this.auth.unreadMessageCount;
}
