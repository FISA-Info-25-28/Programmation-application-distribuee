import { ComponentFixture, TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { vi } from 'vitest';

import { MobileTopbar } from './mobile-topbar';
import { AuthService } from '../../core/services/auth.service';
import { GuestService } from '../../core/services/guest.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';

describe('MobileTopbar', () => {
  let fixture: ComponentFixture<MobileTopbar>;
  let component: MobileTopbar;
  let guestState = signal(false);
  let showModal: ReturnType<typeof vi.fn>;

  beforeEach(async () => {
    guestState = signal(false);
    showModal = vi.fn();
    await TestBed.configureTestingModule({
      imports: [MobileTopbar],
      providers: [
        {
          provide: AuthService,
          useValue: {
            currentUser: signal({ username: 'ada' }).asReadonly(),
            unreadNotifCount: signal(2),
          },
        },
        { provide: GuestService, useValue: { isGuest: guestState.asReadonly(), showModal } },
        { provide: ScrollStateService, useValue: { headerHidden: signal(false) } },
      ],
    })
      .overrideComponent(MobileTopbar, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(MobileTopbar);
    component = fixture.componentInstance;
  });

  it('builds a profile link for authenticated users', () => {
    expect((component as any).profileLink()).toBe('/home/profile/ada');
  });

  it('blocks profile navigation for guests and opens the guest modal', () => {
    const event = { preventDefault: vi.fn() };
    guestState.set(true);

    (component as any).clickProfile(event);

    expect(event.preventDefault).toHaveBeenCalled();
    expect(showModal).toHaveBeenCalled();
    expect((component as any).profileLink()).toBeNull();
  });
});
