import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { GuestService } from '../../core/services/guest.service';
import { ScrollStateService } from '../../core/services/scroll-state.service';
import { TPipe } from '../../core/pipes/t.pipe';
import { UserAvatar } from '../user-avatar/user-avatar';

@Component({
  selector: 'app-mobile-topbar',
  templateUrl: './mobile-topbar.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive, TPipe, UserAvatar],
})
export class MobileTopbar {
  protected readonly auth = inject(AuthService);
  protected readonly guest = inject(GuestService);
  protected readonly scrollState = inject(ScrollStateService);

  protected readonly currentUser = this.auth.currentUser;
  protected readonly unreadNotif = this.auth.unreadNotifCount;

  protected readonly profileLink = computed(() => {
    const user = this.currentUser();
    if (!user || this.guest.isGuest()) return null;
    return `/home/profile/${user.username}`;
  });

  protected clickProfile(event: Event): void {
    if (this.guest.isGuest()) {
      event.preventDefault();
      this.guest.showModal();
    }
  }
}
