import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { ModerationActions } from './moderation-actions';
import { ModerationService } from '../../core/services/moderation.service';
import { ModerationBusService } from '../../core/services/moderation-bus.service';
import { FlashService } from '../flash/flash.service';
import { LangService } from '../../core/services/lang.service';

describe('ModerationActions', () => {
  let fixture: ComponentFixture<ModerationActions>;
  let component: ModerationActions;
  let mod: { ban: ReturnType<typeof vi.fn>; suspend: ReturnType<typeof vi.fn> };
  let bus: { announceSanction: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    mod = {
      ban: vi.fn().mockReturnValue(of({ status: 'BANNED' })),
      suspend: vi.fn().mockReturnValue(of({ status: 'SUSPENDED' })),
    };
    bus = { announceSanction: vi.fn() };
    flash = { show: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [ModerationActions],
      providers: [
        { provide: ModerationService, useValue: mod },
        { provide: ModerationBusService, useValue: bus },
        { provide: FlashService, useValue: flash },
        {
          provide: LangService,
          useValue: {
            tr: () => ({ mod: { banSuccess: 'banni', banError: 'ban ko', suspendSuccess: 'suspendu', suspendError: 'suspend ko' } }),
          },
        },
      ],
    })
      .overrideComponent(ModerationActions, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(ModerationActions);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('profileId', 'profile-2');
    fixture.componentRef.setInput('displayName', 'Bob');
    fixture.detectChanges();
  });

  it('navigates moderation views and selects suspension duration', () => {
    const event = { stopPropagation: vi.fn() };

    (component as any).showBan(event);
    expect((component as any).view()).toBe('ban');

    (component as any).backToMenu(event);
    expect((component as any).view()).toBe('menu');

    (component as any).showSuspend(event);
    (component as any).selectDuration(event, 168);
    expect((component as any).selectedStep()).toEqual({ hours: 168, label: '7j' });
  });

  it('confirms bans and suspensions', () => {
    const done: void[] = [];
    const event = { stopPropagation: vi.fn() };
    component.done.subscribe(() => done.push(undefined));

    (component as any).updateReason('spam');
    (component as any).confirmBan(event);

    expect(mod.ban).toHaveBeenCalledWith('profile-2', 'spam');
    expect(bus.announceSanction).toHaveBeenCalled();
    expect(done.length).toBe(1);

    (component as any).confirmSuspend(event);
    expect(mod.suspend).toHaveBeenCalledWith('profile-2', 24, 'spam');
  });

  it('flashes an error and resets submitting when moderation fails', () => {
    mod.ban.mockReturnValue(throwError(() => new Error('network')));

    (component as any).confirmBan({ stopPropagation: vi.fn() });

    expect((component as any).submitting()).toBe(false);
    expect(flash.show).toHaveBeenCalledWith('ban ko', 'error');
  });
});
