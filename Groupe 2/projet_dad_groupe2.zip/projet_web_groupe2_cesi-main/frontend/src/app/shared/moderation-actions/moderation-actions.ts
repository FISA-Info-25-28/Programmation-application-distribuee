import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { ModerationService } from '../../core/services/moderation.service';
import { ModerationBusService } from '../../core/services/moderation-bus.service';
import { FlashService } from '../flash/flash.service';
import { LangService } from '../../core/services/lang.service';
import { FormsModule } from '@angular/forms';
import { TPipe } from '../../core/pipes/t.pipe';

// Palier de durée de suspension (aligné sur la liste blanche du backend).
interface SuspensionStep {
  hours: number;
  label: string;
}

type View = 'menu' | 'ban' | 'suspend';

// Bloc d'actions de modération (suspendre / bannir) rendu DIRECTEMENT à
// l'intérieur d'un menu déroulant « ... » (post, réponse, profil). Pas d'overlay
// plein écran : tout se passe dans le petit popover ancré, déjà performant.
// Le parent doit gater l'affichage via ModerationService.canModerate() et fermer
// son menu sur l'évènement (done).
@Component({
  selector: 'app-moderation-actions',
  templateUrl: './moderation-actions.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, TPipe],
  host: { style: 'display: contents' },
})
export class ModerationActions {
  private readonly mod = inject(ModerationService);
  private readonly bus = inject(ModerationBusService);
  private readonly flash = inject(FlashService);
  private readonly lang = inject(LangService);
  private readonly destroyRef = inject(DestroyRef);

  readonly profileId = input.required<string>();
  readonly displayName = input.required<string>();
  // Émis après une action réussie : le parent ferme son menu déroulant.
  readonly done = output<void>();

  protected readonly steps: SuspensionStep[] = [
    { hours: 1, label: '1h' },
    { hours: 24, label: '1j' },
    { hours: 72, label: '3j' },
    { hours: 168, label: '7j' },
    { hours: 336, label: '14j' },
    { hours: 720, label: '30j' },
  ];

  protected readonly view = signal<View>('menu');
  protected readonly selectedHours = signal(24);
  protected readonly selectedStep = computed(
    () => this.steps.find((s) => s.hours === this.selectedHours()) ?? this.steps[1],
  );
  protected readonly reason = signal('');
  protected readonly submitting = signal(false);

  protected showBan(event: Event): void {
    event.stopPropagation();
    this.reason.set('');
    this.view.set('ban');
  }

  protected showSuspend(event: Event): void {
    event.stopPropagation();
    this.reason.set('');
    this.view.set('suspend');
  }

  protected backToMenu(event: Event): void {
    event.stopPropagation();
    if (this.submitting()) return;
    this.reason.set('');
    this.view.set('menu');
  }

  protected updateReason(value: string): void {
    this.reason.set(value);
  }

  protected selectDuration(event: Event, hours: number): void {
    event.stopPropagation();
    this.selectedHours.set(hours);
  }

  protected confirmBan(event: Event): void {
    event.stopPropagation();
    if (this.submitting()) return;
    this.submitting.set(true);
    const name = this.displayName();
    this.mod
      .ban(this.profileId(), this.reason())
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.submitting.set(false);
          this.flash.show(`${name} ${this.lang.tr().mod.banSuccess}`, 'success');
          this.bus.announceSanction();
          this.done.emit();
        },
        error: () => {
          this.submitting.set(false);
          this.flash.show(this.lang.tr().mod.banError, 'error');
        },
      });
  }

  protected confirmSuspend(event: Event): void {
    event.stopPropagation();
    if (this.submitting()) return;
    const step = this.selectedStep();
    const name = this.displayName();
    this.submitting.set(true);
    this.mod
      .suspend(this.profileId(), step.hours, this.reason())
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.submitting.set(false);
          this.flash.show(`${name} ${this.lang.tr().mod.suspendSuccess} (${step.label}).`, 'success');
          this.bus.announceSanction();
          this.done.emit();
        },
        error: () => {
          this.submitting.set(false);
          this.flash.show(this.lang.tr().mod.suspendError, 'error');
        },
      });
  }
}
