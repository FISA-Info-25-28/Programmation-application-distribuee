import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModerationReportCard } from './moderation-report-card';
import { LangService } from '../../core/services/lang.service';
import { Report } from '../../core/models/report.model';

const report: Report = {
  id: 'report-1',
  reporterId: 'reporter-1',
  targetType: 'POST',
  targetId: 'post-1',
  reason: 'spam',
  status: 'PENDING',
  createdAt: '2026-01-01T00:00:00Z',
};

describe('ModerationReportCard', () => {
  let fixture: ComponentFixture<ModerationReportCard>;
  let component: ModerationReportCard;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModerationReportCard],
      providers: [
        {
          provide: LangService,
          useValue: {
            tr: () => ({
              mod: {
                statusPending: 'En attente',
                statusReviewed: 'Vu',
                statusResolved: 'Resolue',
                statusRejected: 'Rejetee',
                actionPending: 'Attente',
                actionReviewed: 'Marquer vu',
                actionResolved: 'Resoudre',
                actionRejected: 'Rejeter',
              },
            }),
          },
        },
      ],
    })
      .overrideComponent(ModerationReportCard, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(ModerationReportCard);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('report', report);
    fixture.detectChanges();
  });

  it('maps statuses to labels, classes and available actions', () => {
    expect((component as any).statusLabel('PENDING')).toBe('En attente');
    expect((component as any).actionLabel('RESOLVED')).toBe('Resoudre');
    expect((component as any).availableActions()).toEqual(['RESOLVED', 'REJECTED']);
    expect((component as any).statusClass('RESOLVED')).toContain('text-win');
    expect((component as any).actionClass('REJECTED')).toContain('hover:bg-rim');
  });
});
