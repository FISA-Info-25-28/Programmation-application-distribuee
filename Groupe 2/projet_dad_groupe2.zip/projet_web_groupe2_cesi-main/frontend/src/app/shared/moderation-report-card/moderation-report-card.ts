import { ChangeDetectionStrategy, Component, inject, input, output } from '@angular/core';
import { RouterLink } from '@angular/router';

import { Report, ReportStatus } from '../../core/models/report.model';
import { LangService } from '../../core/services/lang.service';
import { timeAgo } from '../../core/utils/avatar';

@Component({
  selector: 'app-moderation-report-card',
  templateUrl: './moderation-report-card.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink],
})
export class ModerationReportCard {
  readonly report = input.required<Report>();
  readonly index = input(0);
  readonly statusChange = output<ReportStatus>();
  protected readonly lang = inject(LangService);

  protected readonly timeAgo = timeAgo;

  protected statusLabel(status: ReportStatus): string {
    const labels = this.lang.tr().mod;
    return {
      PENDING: labels.statusPending,
      REVIEWED: labels.statusReviewed,
      RESOLVED: labels.statusResolved,
      REJECTED: labels.statusRejected,
    }[status];
  }

  protected actionLabel(status: ReportStatus): string {
    const labels = this.lang.tr().mod;
    return {
      PENDING: labels.actionPending,
      REVIEWED: labels.actionReviewed,
      RESOLVED: labels.actionResolved,
      REJECTED: labels.actionRejected,
    }[status];
  }

  protected availableActions(): ReportStatus[] {
    const report = this.report();
    return (['RESOLVED', 'REJECTED'] as ReportStatus[]).filter((status) => status !== report.status);
  }

  protected statusClass(status: ReportStatus): string {
    switch (status) {
      case 'PENDING':
        return 'bg-[#fff8e1] text-[#b87511] dark:bg-[#241e08] dark:text-[#f4b84c]';
      case 'RESOLVED':
        return 'bg-[#e8faf4] text-win dark:bg-[#0e2a22] dark:text-[#2bc4a0]';
      case 'REVIEWED':
        return 'bg-brand-wash text-brand-deep dark:bg-[#0a2234] dark:text-[#3cc8d7]';
      case 'REJECTED':
        return 'bg-layer-soft text-ink-3 dark:bg-[#1a1a1a] dark:text-[#5e7a80]';
    }
  }

  protected actionClass(status: ReportStatus): string {
    if (status === 'RESOLVED') {
      return 'bg-[#e8faf4] text-win hover:bg-win hover:text-white dark:bg-[#0e2a22] dark:text-[#2bc4a0]';
    }

    return 'bg-layer-soft text-ink-2 hover:bg-rim dark:bg-[#1a1a2a] dark:text-[#7ea6b5] dark:hover:bg-[#25344b]';
  }
}
