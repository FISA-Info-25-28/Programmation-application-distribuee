import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { signal } from '@angular/core';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { PollCard } from './poll-card';
import { Poll } from '../../core/models/post.model';
import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../flash/flash.service';
import { LangService } from '../../core/services/lang.service';

const poll: Poll = {
  id: 'poll-1',
  options: [
    { id: 'option-1', text: 'A', voteCount: 1, position: 0 },
    { id: 'option-2', text: 'B', voteCount: 3, position: 1 },
  ],
  totalVotes: 4,
  endsAt: null,
  closedAt: null,
  isClosed: false,
  hasVoted: false,
  votedOptionId: null,
};

describe('PollCard', () => {
  let fixture: ComponentFixture<PollCard>;
  let component: PollCard;
  let http: { post: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    http = { post: vi.fn().mockReturnValue(of({ ...poll, hasVoted: true })) };
    flash = { show: vi.fn() };
    await TestBed.configureTestingModule({
      imports: [PollCard],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: AuthService, useValue: { currentUser: signal({ id: 'author-1', profileId: 'profile-1' }).asReadonly() } },
        { provide: FlashService, useValue: flash },
        {
          provide: LangService,
          useValue: {
            tr: () => ({
              poll: {
                finished: 'Termine',
                durationUnlimited: 'Illimite',
                expired: 'Expire',
                dayRemainingPlural: 'jours restants',
                dayRemainingSingular: 'jour restant',
                hourRemainingPlural: 'heures restantes',
                hourRemainingSingular: 'heure restante',
                minuteRemainingPlural: 'minutes restantes',
                minuteRemainingSingular: 'minute restante',
                alreadyVoted: 'Deja vote',
                voteError: 'Vote impossible',
                closed: 'Sondage clos',
                closeError: 'Cloture impossible',
              },
            }),
          },
        },
      ],
    })
      .overrideComponent(PollCard, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(PollCard);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('poll', poll);
    fixture.componentRef.setInput('postId', 'post-1');
    fixture.componentRef.setInput('authorId', 'profile-1');
    fixture.detectChanges();
  });

  it('computes ownership, voting state, percentages and time labels', () => {
    expect((component as any).isOwner()).toBe(true);
    expect((component as any).canVote()).toBe(true);
    expect((component as any).showResults()).toBe(false);
    expect((component as any).pct(poll.options[1])).toBe(75);
    expect((component as any).timeLabel()).toBe('Illimite');
  });

  it('votes and emits updated polls', () => {
    const changes: Poll[] = [];
    component.pollChange.subscribe((updated) => changes.push(updated));

    (component as any).vote({ stopPropagation: vi.fn() }, 'option-1');

    expect(http.post).toHaveBeenCalledWith(expect.stringContaining('/posts/post-1/poll/vote'), {
      optionId: 'option-1',
    });
    expect(changes[0]).toEqual({ ...poll, hasVoted: true });
    expect((component as any).voting()).toBe(false);
  });

  it('flashes vote and close errors', () => {
    http.post.mockReturnValue(throwError(() => ({ status: 409 })));

    (component as any).vote({ stopPropagation: vi.fn() }, 'option-1');
    expect(flash.show).toHaveBeenCalledWith('Deja vote', 'info');

    http.post.mockReturnValue(throwError(() => new Error('network')));
    (component as any).closePoll({ stopPropagation: vi.fn() });
    expect(flash.show).toHaveBeenCalledWith('Cloture impossible', 'error');
  });
});
