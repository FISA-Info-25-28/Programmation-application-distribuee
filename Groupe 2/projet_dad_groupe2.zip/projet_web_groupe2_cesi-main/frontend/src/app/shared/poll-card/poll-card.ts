import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';
import { Poll, PollOption } from '../../core/models/post.model';
import { AuthService } from '../../core/services/auth.service';
import { LangService } from '../../core/services/lang.service';
import { FlashService } from '../flash/flash.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-poll-card',
  templateUrl: './poll-card.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'block' },
})
export class PollCard {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  protected readonly lang = inject(LangService);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);

  readonly poll = input.required<Poll>();
  readonly postId = input.required<string>();
  readonly authorId = input.required<string>();
  readonly pollChange = output<Poll>();

  protected readonly voting = signal(false);
  protected readonly closing = signal(false);

  protected readonly isOwner = computed(() => {
    const user = this.auth.currentUser();
    if (!user) return false;
    return user.id === this.authorId() || user.profileId === this.authorId();
  });

  protected readonly canVote = computed(() => {
    const p = this.poll();
    return !p.isClosed && !p.hasVoted && !!this.auth.currentUser();
  });

  protected readonly showResults = computed(() => {
    const p = this.poll();
    return p.hasVoted || p.isClosed;
  });

  protected readonly timeLabel = computed(() => {
    const p = this.poll();
    if (p.isClosed) return this.lang.tr().poll.finished;
    if (!p.endsAt) return this.lang.tr().poll.durationUnlimited;

    const diff = new Date(p.endsAt).getTime() - Date.now();
    if (diff <= 0) return this.lang.tr().poll.expired;

    const h = Math.floor(diff / 3_600_000);
    const m = Math.floor((diff % 3_600_000) / 60_000);
    if (h >= 24) {
      const days = Math.floor(h / 24);
      return `${days} ${days > 1 ? this.lang.tr().poll.dayRemainingPlural : this.lang.tr().poll.dayRemainingSingular}`;
    }
    if (h > 0) {
      return `${h}h ${m}min ${h > 1 ? this.lang.tr().poll.hourRemainingPlural : this.lang.tr().poll.hourRemainingSingular}`;
    }
    return `${m} ${m > 1 ? this.lang.tr().poll.minuteRemainingPlural : this.lang.tr().poll.minuteRemainingSingular}`;
  });

  protected pct(option: PollOption): number {
    const total = this.poll().totalVotes;
    if (total === 0) return 0;
    return Math.round((option.voteCount / total) * 100);
  }

  protected vote(event: Event, optionId: string): void {
    event.stopPropagation();
    if (!this.canVote() || this.voting()) return;

    this.voting.set(true);
    this.http
      .post<Poll>(`${environment.apiBaseUrl}/posts/${this.postId()}/poll/vote`, { optionId })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (updated) => {
          this.voting.set(false);
          this.pollChange.emit(updated);
        },
        error: (err) => {
          this.voting.set(false);
          this.flash.show(
            err?.status === 409 ? this.lang.tr().poll.alreadyVoted : this.lang.tr().poll.voteError,
            err?.status === 409 ? 'info' : 'error',
          );
        },
      });
  }

  protected closePoll(event: Event): void {
    event.stopPropagation();
    if (this.closing()) return;

    this.closing.set(true);
    this.http
      .post<Poll>(`${environment.apiBaseUrl}/posts/${this.postId()}/poll/close`, {})
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (updated) => {
          this.closing.set(false);
          this.pollChange.emit(updated);
          this.flash.show(this.lang.tr().poll.closed, 'success');
        },
        error: () => {
          this.closing.set(false);
          this.flash.show(this.lang.tr().poll.closeError, 'error');
        },
      });
  }
}
