import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PollCreator, PollDraft } from './poll-creator';
import { LangService } from '../../core/services/lang.service';

describe('PollCreator', () => {
  let fixture: ComponentFixture<PollCreator>;
  let component: PollCreator;
  let emittedDrafts: Array<PollDraft | null>;
  let closed = 0;

  beforeEach(async () => {
    emittedDrafts = [];
    closed = 0;
    await TestBed.configureTestingModule({
      imports: [PollCreator],
      providers: [{ provide: LangService, useValue: {} }],
    })
      .overrideComponent(PollCreator, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(PollCreator);
    component = fixture.componentInstance;
    (component as any).draftChange.subscribe((draft: PollDraft | null) => emittedDrafts.push(draft));
    (component as any).closed.subscribe(() => closed++);
  });

  it('emits null until at least two non-empty options are present', () => {
    expect((component as any).isValid()).toBe(false);
    expect((component as any).hasTouchedAny()).toBe(false);

    (component as any).updateOption(0, 'Cats');

    expect((component as any).hasTouchedAny()).toBe(true);
    expect((component as any).isValid()).toBe(false);
    expect(emittedDrafts).toEqual([null]);
  });

  it('emits a trimmed draft and updates duration', () => {
    (component as any).updateOption(0, ' Cats ');
    (component as any).updateOption(1, ' Dogs ');
    (component as any).setDuration(null);

    expect(emittedDrafts.at(-1)).toEqual({
      options: ['Cats', 'Dogs'],
      durationHours: null,
    });
  });

  it('adds and removes options within bounds', () => {
    (component as any).addOption();
    (component as any).addOption();
    (component as any).addOption();

    expect((component as any).options().length).toBe(4);

    (component as any).removeOption(3);
    expect((component as any).options().length).toBe(3);

    (component as any).removeOption(2);
    (component as any).removeOption(1);
    expect((component as any).options().length).toBe(2);
  });

  it('emits null and closed when closing the creator', () => {
    (component as any).close();

    expect(emittedDrafts).toEqual([null]);
    expect(closed).toBe(1);
  });
});
