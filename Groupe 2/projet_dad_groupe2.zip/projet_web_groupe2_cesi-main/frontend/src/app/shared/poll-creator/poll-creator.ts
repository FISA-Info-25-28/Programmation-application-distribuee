import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  output,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { LangService } from '../../core/services/lang.service';
import type { Translations } from '../../core/i18n/types';

export interface PollDraft {
  options: string[];
  durationHours: number | null;
}

type PollDurationLabelKey = keyof Pick<
  Translations['poll'],
  | 'duration30m'
  | 'duration1h'
  | 'duration6h'
  | 'duration24h'
  | 'duration3d'
  | 'duration7d'
  | 'durationUnlimited'
>;

@Component({
  selector: 'app-poll-creator',
  templateUrl: './poll-creator.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  host: { class: 'block' },
})
export class PollCreator {
  readonly closed = output<void>();
  readonly draftChange = output<PollDraft | null>();
  protected readonly lang = inject(LangService);

  protected readonly options = signal<string[]>(['', '']);
  protected readonly durationHours = signal<number | null>(24);

  protected readonly isValid = computed(() => {
    const opts = this.options();
    return opts.length >= 2 && opts.every((o) => o.trim().length > 0);
  });

  protected readonly hasTouchedAny = computed(() =>
    this.options().some((o) => o.trim().length > 0),
  );

  protected readonly isOptionEmpty = computed(() =>
    this.options().map((o) => o.trim().length === 0),
  );

  protected readonly durations: { labelKey: PollDurationLabelKey; value: number | null }[] = [
    { labelKey: 'duration30m', value: 0.5 },
    { labelKey: 'duration1h', value: 1 },
    { labelKey: 'duration6h', value: 6 },
    { labelKey: 'duration24h', value: 24 },
    { labelKey: 'duration3d', value: 72 },
    { labelKey: 'duration7d', value: 168 },
    { labelKey: 'durationUnlimited', value: null },
  ];

  private emit(): void {
    if (!this.isValid()) {
      this.draftChange.emit(null);
      return;
    }
    this.draftChange.emit({
      options: this.options().map((o) => o.trim()),
      durationHours: this.durationHours(),
    });
  }

  protected updateOption(index: number, value: string): void {
    this.options.update((opts) => {
      const updated = [...opts];
      updated[index] = value;
      return updated;
    });
    this.emit();
  }

  protected addOption(): void {
    if (this.options().length >= 4) return;
    this.options.update((opts) => [...opts, '']);
  }

  protected removeOption(index: number): void {
    if (this.options().length <= 2) return;
    this.options.update((opts) => opts.filter((_, i) => i !== index));
    this.emit();
  }

  protected setDuration(value: number | null): void {
    this.durationHours.set(value);
    this.emit();
  }

  protected close(): void {
    this.draftChange.emit(null);
    this.closed.emit();
  }
}
