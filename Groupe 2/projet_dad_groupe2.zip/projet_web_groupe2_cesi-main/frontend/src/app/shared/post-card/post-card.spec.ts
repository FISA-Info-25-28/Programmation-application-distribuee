import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { signal } from '@angular/core';
import { of, throwError } from 'rxjs';

import { PostCard } from './post-card';
import { AuthService } from '../../core/services/auth.service';
import { CensorService } from '../../core/services/censor.service';
import { FlashService } from '../flash/flash.service';
import { GuestService } from '../../core/services/guest.service';
import { LangService } from '../../core/services/lang.service';
import { ModerationService } from '../../core/services/moderation.service';
import { PostTranslationService } from '../../core/services/post-translation.service';
import { ReplyModalService } from '../../core/services/reply-modal.service';
import { ShareMessageService } from '../../core/services/share-message.service';
import { Post } from '../../core/models/post.model';

const section = new Proxy({}, { get: (_target, prop) => String(prop) });
const lang = { tr: () => new Proxy({}, { get: () => section }), lang: signal('fr').asReadonly() };

const post = (overrides: Partial<Post> = {}): Post =>
  ({
    id: 'post-1',
    author: { id: 'p2', username: 'bob', displayName: 'Bob', avatarUrl: null },
    content: 'Hello',
    visibility: 'PUBLIC',
    tags: [],
    lang: 'fr',
    likeCount: 0,
    replyCount: 0,
    repostCount: 0,
    isLiked: false,
    isReposted: false,
    isBookmarked: false,
    parentId: null,
    createdAt: '2026-06-24T10:00:00Z',
    media: [],
    ...overrides,
  }) as Post;

describe('PostCard', () => {
  let fixture: ComponentFixture<PostCard>;
  let component: PostCard;
  let http: { post: ReturnType<typeof vi.fn>; delete: ReturnType<typeof vi.fn>; patch: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };
  let shareMsg: { open: ReturnType<typeof vi.fn> };
  let replyModal: { open: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    vi.useFakeTimers();
    http = {
      post: vi.fn(() => of({})),
      delete: vi.fn(() => of({})),
      patch: vi.fn(() => of(post({ visibility: 'FOLLOWERS' }))),
    };
    flash = { show: vi.fn() };
    shareMsg = { open: vi.fn() };
    replyModal = { open: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [PostCard],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: Router, useValue: { navigate: vi.fn() } },
        {
          provide: AuthService,
          useValue: {
            currentUser: signal({ id: 'u1', profileId: 'p1', username: 'ada', role: 'USER', isPrivate: false }).asReadonly(),
            refreshUnreadNotifications: vi.fn(() => of(0)),
          },
        },
        { provide: CensorService, useValue: { censorParts: vi.fn((text) => [{ text, censored: false }]) } },
        { provide: FlashService, useValue: flash },
        { provide: GuestService, useValue: { requireAuth: vi.fn(() => true) } },
        { provide: LangService, useValue: lang },
        { provide: ModerationService, useValue: { canModerate: vi.fn(() => false) } },
        { provide: PostTranslationService, useValue: { translate: vi.fn(() => of('Bonjour')) } },
        { provide: ReplyModalService, useValue: replyModal },
        { provide: ShareMessageService, useValue: shareMsg },
      ],
    })
      .overrideComponent(PostCard, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(PostCard);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('post', post());
    fixture.detectChanges();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('creates', () => {
    expect(component).toBeTruthy();
  });

  it('optimistically toggles likes', () => {
    const changes: Post[] = [];
    component.postChange.subscribe((value) => changes.push(value));

    (component as any).toggleLike(new Event('click'));

    expect(changes[0].isLiked).toBe(true);
    expect(changes[0].likeCount).toBe(1);
    expect(http.post).toHaveBeenCalled();
  });

  it('reverts a failed bookmark update', () => {
    const original = post();
    const changes: Post[] = [];
    http.post.mockReturnValueOnce(throwError(() => new Error('network')));
    fixture.componentRef.setInput('post', original);
    component.postChange.subscribe((value) => changes.push(value));

    (component as any).toggleBookmark(new Event('click'));

    expect(changes.at(-1)).toBe(original);
  });

  it('opens share via message', () => {
    (component as any).openViaMessage(new Event('click'));

    expect(shareMsg.open).toHaveBeenCalledWith('post-1', 'Hello', 'Bob', 'bob');
  });

  it('deletes a post and emits its id', () => {
    const deleted: string[] = [];
    component.postDeleted.subscribe((id) => deleted.push(id));

    (component as any).deletePost(new Event('click'));

    expect(http.delete).toHaveBeenCalled();
    expect(deleted).toEqual(['post-1']);
  });
});
