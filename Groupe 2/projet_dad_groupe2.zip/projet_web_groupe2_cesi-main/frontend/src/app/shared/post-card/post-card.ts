import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  effect,
  HostListener,
  inject,
  input,
  output,
  signal,
  untracked,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router, RouterLink } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { CensorService } from '../../core/services/censor.service';
import { LangService } from '../../core/services/lang.service';
import {
  PostTranslationService,
  SAME_LANGUAGE,
} from '../../core/services/post-translation.service';
import { ShareMessageService } from '../../core/services/share-message.service';
import { ModerationService } from '../../core/services/moderation.service';
import { TPipe } from '../../core/pipes/t.pipe';
import { ReplyModalService } from '../../core/services/reply-modal.service';
import { FlashService } from '../flash/flash.service';
import { Post } from '../../core/models/post.model';
import { environment } from '../../../environments/environment';
import { timeAgo } from '../../core/utils/avatar';
import { MediaGallery } from '../media-gallery/media-gallery';
import { ModerationActions } from '../moderation-actions/moderation-actions';
import { GuestService } from '../../core/services/guest.service';
import { mapApiPost } from '../../core/mappers/post.mapper';
import { MentionLink } from '../mention-link/mention-link';
import { PollCard } from '../poll-card/poll-card';
import { Poll } from '../../core/models/post.model';
import { UserAvatar } from '../user-avatar/user-avatar';

@Component({
  selector: 'app-post-card',
  templateUrl: './post-card.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    RouterLink,
    FormsModule,
    TPipe,
    MediaGallery,
    MentionLink,
    PollCard,
    UserAvatar,
    ModerationActions,
  ],
  host: { class: 'block' },
})
export class PostCard {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly auth = inject(AuthService);
  protected readonly censor = inject(CensorService);
  private readonly translation = inject(PostTranslationService);
  private readonly shareMsg = inject(ShareMessageService);
  protected readonly moderation = inject(ModerationService);
  protected readonly lang = inject(LangService);
  private readonly guest = inject(GuestService);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly replyModal = inject(ReplyModalService);

  readonly post = input.required<Post>();
  readonly index = input(0);
  readonly card = input(false);
  readonly canPin = input(false);
  readonly isPinned = input(false);
  readonly postChange = output<Post>();
  readonly postDeleted = output<string>();
  readonly pinToggle = output<void>();

  protected readonly justLiked = signal(false);
  protected readonly justReposted = signal(false);
  protected readonly justBookmarked = signal(false);
  protected readonly menuOpen = signal(false);
  protected readonly reportOpen = signal(false);
  protected readonly customReportOpen = signal(false);
  protected readonly customReportReason = signal('');
  protected readonly shareMenuOpen = signal(false);
  protected readonly isUpdatingVisibility = signal(false);
  protected readonly reportReasons = computed(() => [
    this.lang.tr().post.reportReasonSpam,
    this.lang.tr().post.reportReasonHarassment,
    this.lang.tr().post.reportReasonOffensive,
  ]);

  protected readonly translating = signal(false);
  protected readonly translatedText = signal<string | null>(null);
  protected readonly showTranslated = signal(false);
  protected readonly translationFailed = signal(false);
  protected readonly forceHideTranslate = signal(false);
  protected readonly revealedCensors = signal<Set<number>>(new Set());

  protected toggleCensor(index: number): void {
    this.revealedCensors.update((s) => {
      const next = new Set(s);
      next.has(index) ? next.delete(index) : next.add(index);
      return next;
    });
  }

  protected readonly isOwnRepost = computed(() => {
    const reposter = this.post().repostedBy;
    if (!reposter) return false;
    const user = this.auth.currentUser();
    if (!user) return false;
    return user.profileId === reposter.id || user.id === reposter.id;
  });

  protected readonly shouldShowTranslate = computed(() => {
    if (this.forceHideTranslate()) return false;
    const postLang = this.post().lang;
    if (!this.post().content.trim()) return false;
    return !postLang || postLang !== this.lang.lang();
  });

  protected readonly displayContent = computed(() =>
    this.showTranslated() && this.translatedText() ? this.translatedText()! : this.post().content,
  );

  protected readonly timeAgo = (iso: string) => timeAgo(iso, this.lang.lang());
  protected readonly hasNativeShare = typeof navigator !== 'undefined' && 'share' in navigator;

  constructor() {
    effect(() => {
      this.lang.lang();
      untracked(() => {
        this.showTranslated.set(false);
        this.translatedText.set(null);
        this.translationFailed.set(false);
        this.forceHideTranslate.set(false);
      });
    });
  }

  @HostListener('document:click')
  protected closeMenus(): void {
    this.menuOpen.set(false);
    this.shareMenuOpen.set(false);
  }

  @HostListener('document:breezy-close-dropdowns')
  protected onCloseAll(): void {
    this.menuOpen.set(false);
    this.shareMenuOpen.set(false);
  }

  protected navigate(): void {
    void this.router.navigate(['/home/post', this.post().id]);
  }

  protected openReply(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    this.replyModal.open(this.post(), (updated) => this.postChange.emit(updated));
  }

  protected toggleLike(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    const p = this.post();
    const wasLiked = p.isLiked;
    const updated: Post = {
      ...p,
      isLiked: !wasLiked,
      likeCount: wasLiked ? p.likeCount - 1 : p.likeCount + 1,
    };
    this.postChange.emit(updated);

    if (!wasLiked) {
      this.justLiked.set(true);
      setTimeout(() => this.justLiked.set(false), 500);
    }

    const req$ = wasLiked
      ? this.http.delete(`${environment.apiBaseUrl}/posts/${p.id}/like`)
      : this.http.post(`${environment.apiBaseUrl}/posts/${p.id}/like`, {});

    req$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      error: (err: unknown) => {
        this.postChange.emit(p);
        if (err instanceof HttpErrorResponse && err.status === 403) {
          this.flash.show(this.lang.tr().composer.suspendedError, 'error');
        }
      },
    });
  }

  protected toggleRepost(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    const p = this.post();
    const wasReposted = p.isReposted;
    const updated: Post = {
      ...p,
      isReposted: !wasReposted,
      repostCount: wasReposted ? p.repostCount - 1 : p.repostCount + 1,
    };
    this.postChange.emit(updated);

    if (!wasReposted) {
      this.justReposted.set(true);
      setTimeout(() => this.justReposted.set(false), 500);
    }

    const req$ = wasReposted
      ? this.http.delete(`${environment.apiBaseUrl}/posts/${p.id}/repost`)
      : this.http.post(`${environment.apiBaseUrl}/posts/${p.id}/repost`, {});

    req$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      error: () => this.postChange.emit(p),
    });
  }

  protected toggleMenu(event: Event): void {
    event.stopPropagation();
    if (!this.menuOpen()) document.dispatchEvent(new CustomEvent('breezy-close-dropdowns'));
    this.shareMenuOpen.set(false);
    this.menuOpen.update((v) => !v);
  }

  protected toggleShareMenu(event: Event): void {
    event.stopPropagation();
    if (!this.shareMenuOpen()) document.dispatchEvent(new CustomEvent('breezy-close-dropdowns'));
    this.menuOpen.set(false);
    this.shareMenuOpen.update((v) => !v);
  }

  protected openViaMessage(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    this.shareMenuOpen.set(false);
    const p = this.post();
    this.shareMsg.open(p.id, p.content, p.author.displayName, p.author.username);
  }

  protected copyLink(): void {
    const url = `${window.location.origin}/home/post/${this.post().id}`;
    navigator.clipboard.writeText(url).then(
      () => {
        this.flash.show(this.lang.tr().post.linkCopied, 'success');
        this.shareMenuOpen.set(false);
      },
      () => this.flash.show(this.lang.tr().post.linkCopyError, 'error'),
    );
  }

  protected nativeShare(): void {
    const p = this.post();
    if (!this.hasNativeShare) return;
    navigator
      .share({
        title: `Post de ${p.author.displayName} sur Breezy`,
        text: p.content.slice(0, 120),
        url: `${window.location.origin}/home/post/${p.id}`,
      })
      .then(() => this.shareMenuOpen.set(false))
      .catch(() => {});
  }

  protected canDeletePost(): boolean {
    const user = this.auth.currentUser();
    const author = this.post().author;
    return (
      user?.profileId === author.id ||
      user?.id === author.id ||
      user?.username === author.username ||
      user?.role === 'ADMIN' ||
      user?.role === 'MODERATOR'
    );
  }

  // Le moderateur/admin peut moderer l'auteur du post (sauf lui-meme).
  protected canModerate(): boolean {
    return this.moderation.canModerate(this.post().author.id);
  }

  protected canReportPost(): boolean {
    const user = this.auth.currentUser();
    const author = this.post().author;
    return (
      user?.profileId !== author.id && user?.id !== author.id && user?.username !== author.username
    );
  }

  protected canEditVisibility(): boolean {
    const user = this.auth.currentUser();
    const author = this.post().author;
    return (
      user?.profileId === author.id || user?.id === author.id || user?.username === author.username
    );
  }

  protected isCurrentUserPrivateProfile(): boolean {
    return this.auth.currentUser()?.isPrivate === true;
  }

  protected visibilityLabel(): string {
    switch (this.post().visibility) {
      case 'FOLLOWERS':
        return this.lang.tr().post.visibilityFollowers;
      case 'PRIVATE':
        return this.lang.tr().post.visibilityPrivate;
      default:
        return this.lang.tr().post.visibilityPublic;
    }
  }

  protected setVisibility(event: Event, visibility: 'PUBLIC' | 'FOLLOWERS' | 'PRIVATE'): void {
    event.stopPropagation();
    if (visibility === 'PUBLIC' && this.isCurrentUserPrivateProfile()) return;
    const p = this.post();
    if (this.isUpdatingVisibility() || p.visibility === visibility) return;

    this.isUpdatingVisibility.set(true);
    this.http
      .patch<Post>(`${environment.apiBaseUrl}/posts/${p.id}/visibility`, { visibility })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (updatedPost) => {
          this.postChange.emit(mapApiPost(updatedPost, this.auth.currentUser()));
          this.isUpdatingVisibility.set(false);
          this.menuOpen.set(false);
          this.flash.show(this.lang.tr().post.visibilityUpdated, 'success');
        },
        error: () => {
          this.isUpdatingVisibility.set(false);
          this.flash.show(this.lang.tr().post.visibilityUpdateError, 'error');
        },
      });
  }

  protected openReport(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    this.menuOpen.set(false);
    this.reportOpen.set(true);
    this.customReportOpen.set(false);
    this.customReportReason.set('');
  }

  protected closeReport(): void {
    this.reportOpen.set(false);
    this.customReportOpen.set(false);
    this.customReportReason.set('');
  }

  protected openCustomReport(): void {
    this.customReportOpen.set(true);
  }

  protected sendReport(reason: string): void {
    const trimmedReason = reason.trim();
    if (!trimmedReason) {
      this.flash.show(this.lang.tr().post.reportReasonRequired, 'error');
      return;
    }

    const p = this.post();
    this.reportOpen.set(false);
    this.customReportOpen.set(false);
    this.customReportReason.set('');
    this.menuOpen.set(false);

    this.http
      .post(`${environment.apiBaseUrl}/posts/${p.id}/report`, { reason: trimmedReason })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.flash.show(this.lang.tr().post.reportSent, 'success');
          this.auth.refreshUnreadNotifications().subscribe({ error: () => undefined });
        },
        error: (err: HttpErrorResponse) => {
          if (err.status === 409) {
            this.flash.show(this.lang.tr().post.reportAlreadySent, 'info');
            return;
          }
          this.flash.show(this.lang.tr().post.reportError, 'error');
        },
      });
  }

  protected translatePost(event: Event): void {
    event.stopPropagation();
    if (this.showTranslated()) {
      this.showTranslated.set(false);
      return;
    }
    if (this.translatedText()) {
      this.showTranslated.set(true);
      return;
    }
    this.translating.set(true);
    this.translationFailed.set(false);
    const p = this.post();
    this.translation.translate(p.id, p.content).subscribe({
      next: (result) => {
        this.translating.set(false);
        if (result === SAME_LANGUAGE) {
          this.flash.show(this.lang.tr().post.alreadyInLang, 'info');
          this.forceHideTranslate.set(true);
          return;
        }
        if (!result) {
          this.translationFailed.set(true);
          return;
        }
        this.translatedText.set(result);
        this.showTranslated.set(true);
      },
      error: () => {
        this.translating.set(false);
        this.translationFailed.set(true);
      },
    });
  }

  protected toggleBookmark(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    const p = this.post();
    const wasBookmarked = p.isBookmarked;
    const updated: Post = { ...p, isBookmarked: !wasBookmarked };
    this.postChange.emit(updated);

    if (!wasBookmarked) {
      this.justBookmarked.set(true);
      setTimeout(() => this.justBookmarked.set(false), 500);
      this.flash.show(this.lang.tr().post.bookmarkSaved, 'success');
    } else {
      this.flash.show(this.lang.tr().post.bookmarkRemoved, 'info');
    }

    const req$ = wasBookmarked
      ? this.http.delete(`${environment.apiBaseUrl}/posts/${p.id}/bookmark`)
      : this.http.post(`${environment.apiBaseUrl}/posts/${p.id}/bookmark`, {});

    req$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      error: (err: unknown) => {
        this.postChange.emit(p);
        if (err instanceof HttpErrorResponse && err.status === 403) {
          this.flash.show(this.lang.tr().composer.suspendedError, 'error');
        }
      },
    });
  }

  protected updatePoll(updatedPoll: Poll): void {
    const p = this.post();
    this.postChange.emit({ ...p, poll: updatedPoll });
  }

  protected onPinToggle(event: Event): void {
    event.stopPropagation();
    this.menuOpen.set(false);
    this.pinToggle.emit();
  }

  protected deletePost(event: Event): void {
    event.stopPropagation();
    const p = this.post();
    this.http
      .delete(`${environment.apiBaseUrl}/posts/${p.id}`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.flash.show(this.lang.tr().post.deleteSuccess, 'success');
          this.postDeleted.emit(p.id);
        },
        error: () => this.flash.show(this.lang.tr().post.deleteError, 'error'),
      });
    this.menuOpen.set(false);
  }
}
