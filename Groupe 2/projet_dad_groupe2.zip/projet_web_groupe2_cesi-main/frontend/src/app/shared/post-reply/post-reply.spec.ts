import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { PostReply } from './post-reply';
import { Post } from '../../core/models/post.model';
import { CensorService } from '../../core/services/censor.service';
import { FlashService } from '../flash/flash.service';
import { GuestService } from '../../core/services/guest.service';
import { LangService } from '../../core/services/lang.service';
import { ModerationService } from '../../core/services/moderation.service';
import { ShareMessageService } from '../../core/services/share-message.service';

const post: Post = {
  id: 'reply-1',
  author: { id: 'profile-2', username: 'bob', displayName: 'Bob', avatarUrl: null },
  content: 'Reply',
  lang: '',
  visibility: 'PUBLIC',
  tags: [],
  likeCount: 0,
  replyCount: 0,
  repostCount: 0,
  isLiked: false,
  isReposted: false,
  isBookmarked: false,
  parentId: 'post-1',
  createdAt: '2026-01-01T00:00:00Z',
  media: [],
};

describe('PostReply', () => {
  let fixture: ComponentFixture<PostReply>;
  let component: PostReply;
  let http: { post: ReturnType<typeof vi.fn>; delete: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };
  let share: { open: ReturnType<typeof vi.fn> };
  let guest: { requireAuth: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    vi.useFakeTimers();
    http = { post: vi.fn().mockReturnValue(of({})), delete: vi.fn().mockReturnValue(of({})) };
    flash = { show: vi.fn() };
    share = { open: vi.fn() };
    guest = { requireAuth: vi.fn(() => true) };

    await TestBed.configureTestingModule({
      imports: [PostReply],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: FlashService, useValue: flash },
        { provide: ShareMessageService, useValue: share },
        { provide: GuestService, useValue: guest },
        { provide: CensorService, useValue: { parse: vi.fn(() => []) } },
        { provide: ModerationService, useValue: { canModerate: vi.fn(() => true) } },
        {
          provide: LangService,
          useValue: {
            tr: () => ({
              comments: { likeError: 'Like ko', repostError: 'Repost ko' },
              post: { linkCopied: 'Copie', linkCopyError: 'Copie ko', postBy: 'Post de' },
            }),
          },
        },
      ],
    })
      .overrideComponent(PostReply, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(PostReply);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('reply', post);
    fixture.componentRef.setInput('parent', { ...post, id: 'post-1', parentId: null });
    fixture.detectChanges();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('emits reply requests and computes indentation/moderation', () => {
    const replies: Post[] = [];
    component.replyRequested.subscribe((item) => replies.push(item));

    (component as any).requestReply({ stopPropagation: vi.fn() }, post);

    expect(replies).toEqual([post]);
    expect((component as any).indent()).toBe(20);
    expect((component as any).canModerate()).toBe(true);
  });

  it('optimistically likes and rolls back on errors', () => {
    const changes: Post[] = [];
    component.replyChange.subscribe((item) => changes.push(item));

    (component as any).toggleLike({ stopPropagation: vi.fn() });
    expect(changes[0]).toEqual(expect.objectContaining({ isLiked: true, likeCount: 1 }));
    expect(http.post).toHaveBeenCalledWith(expect.stringContaining('/posts/reply-1/like'), {});

    http.post.mockReturnValue(throwError(() => new Error('network')));
    changes.length = 0;
    (component as any).toggleLike({ stopPropagation: vi.fn() });

    expect(changes.at(-1)).toEqual(post);
    expect(flash.show).toHaveBeenCalledWith('Like ko', 'error');
  });

  it('opens share menus and message sharing', () => {
    (component as any).toggleShare({ stopPropagation: vi.fn() });
    expect((component as any).shareOpen()).toBe(true);

    (component as any).sendViaMessage({ stopPropagation: vi.fn() });

    expect((component as any).shareOpen()).toBe(false);
    expect(share.open).toHaveBeenCalledWith('reply-1', 'Reply', 'Bob', 'bob');
  });
});
