import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  HostListener,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';

import { Post } from '../../core/models/post.model';
import { timeAgo } from '../../core/utils/avatar';
import { CensorService } from '../../core/services/censor.service';
import { ShareMessageService } from '../../core/services/share-message.service';
import { ModerationService } from '../../core/services/moderation.service';
import { FlashService } from '../flash/flash.service';
import { MediaGallery } from '../media-gallery/media-gallery';
import { MentionLink } from '../mention-link/mention-link';
import { ModerationActions } from '../moderation-actions/moderation-actions';
import { environment } from '../../../environments/environment';
import { UserAvatar } from '../user-avatar/user-avatar';
import { LangService } from '../../core/services/lang.service';
import { GuestService } from '../../core/services/guest.service';
import { TPipe } from '../../core/pipes/t.pipe';

@Component({
  selector: 'app-post-reply',
  templateUrl: './post-reply.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MediaGallery, RouterLink, UserAvatar, ModerationActions, MentionLink, TPipe],
  host: { class: 'block' },
})
export class PostReply {
  private readonly http = inject(HttpClient);
  private readonly shareMessage = inject(ShareMessageService);
  protected readonly moderation = inject(ModerationService);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);
  protected readonly censor = inject(CensorService);
  private readonly lang = inject(LangService);
  private readonly guest = inject(GuestService);

  readonly reply = input.required<Post>();
  readonly parent = input.required<Post>();
  readonly depth = input(0);
  readonly index = input(0);
  readonly canDelete = input(false);
  readonly deleting = input(false);

  readonly replyRequested = output<Post>();
  readonly deleteRequested = output<Post>();
  readonly replyChange = output<Post>();

  protected readonly timeAgo = timeAgo;
  protected readonly shareOpen = signal(false);
  protected readonly modMenuOpen = signal(false);
  protected readonly justLiked = signal(false);
  protected readonly justReposted = signal(false);
  protected readonly revealedCensors = signal<Set<number>>(new Set());

  protected toggleCensor(index: number): void {
    this.revealedCensors.update((s) => {
      const next = new Set(s);
      next.has(index) ? next.delete(index) : next.add(index);
      return next;
    });
  }
  protected readonly hasNativeShare = typeof navigator !== 'undefined' && 'share' in navigator;

  @HostListener('document:click')
  protected closeShareMenu(): void {
    this.shareOpen.set(false);
    this.modMenuOpen.set(false);
  }

  // Le moderateur/admin peut moderer l'auteur de la reponse (sauf lui-meme).
  protected canModerate(): boolean {
    return this.moderation.canModerate(this.reply().author.id);
  }

  protected toggleModMenu(event: Event): void {
    event.stopPropagation();
    this.modMenuOpen.update((open) => !open);
  }

  protected requestReply(event: Event, item: Post): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    this.replyRequested.emit(item);
  }

  protected indent(): number {
    return this.depth() === 0 ? 20 : Math.min(56 + (this.depth() - 1) * 28, 140);
  }

  protected toggleLike(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    const reply = this.reply();
    const updated = {
      ...reply,
      isLiked: !reply.isLiked,
      likeCount: Math.max(0, reply.likeCount + (reply.isLiked ? -1 : 1)),
    };
    this.replyChange.emit(updated);
    if (!reply.isLiked) {
      this.justLiked.set(true);
      setTimeout(() => this.justLiked.set(false), 500);
    }

    const request = reply.isLiked
      ? this.http.delete(`${environment.apiBaseUrl}/posts/${reply.id}/like`)
      : this.http.post(`${environment.apiBaseUrl}/posts/${reply.id}/like`, {});
    request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      error: () => {
        this.replyChange.emit(reply);
        this.flash.show(this.lang.tr().comments.likeError, 'error');
      },
    });
  }

  protected toggleRepost(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    const reply = this.reply();
    const updated = {
      ...reply,
      isReposted: !reply.isReposted,
      repostCount: Math.max(0, reply.repostCount + (reply.isReposted ? -1 : 1)),
    };
    this.replyChange.emit(updated);
    if (!reply.isReposted) {
      this.justReposted.set(true);
      setTimeout(() => this.justReposted.set(false), 500);
    }

    const request = reply.isReposted
      ? this.http.delete(`${environment.apiBaseUrl}/posts/${reply.id}/repost`)
      : this.http.post(`${environment.apiBaseUrl}/posts/${reply.id}/repost`, {});
    request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      error: () => {
        this.replyChange.emit(reply);
        this.flash.show(this.lang.tr().comments.repostError, 'error');
      },
    });
  }

  protected toggleShare(event: Event): void {
    event.stopPropagation();
    this.shareOpen.update((open) => !open);
  }

  protected sendViaMessage(event: Event): void {
    event.stopPropagation();
    if (!this.guest.requireAuth()) return;
    const reply = this.reply();
    this.shareOpen.set(false);
    this.shareMessage.open(
      reply.id,
      reply.content,
      reply.author.displayName,
      reply.author.username,
    );
  }

  protected copyLink(event: Event): void {
    event.stopPropagation();
    const url = `${window.location.origin}/home/post/${this.reply().id}`;
    navigator.clipboard.writeText(url).then(
      () => {
        this.flash.show(this.lang.tr().post.linkCopied, 'success');
        this.shareOpen.set(false);
      },
      () => this.flash.show(this.lang.tr().post.linkCopyError, 'error'),
    );
  }

  protected nativeShare(event: Event): void {
    event.stopPropagation();
    if (!this.hasNativeShare) return;
    const reply = this.reply();
    navigator
      .share({
        title: `${this.lang.tr().post.postBy} ${reply.author.displayName} sur Breezy`,
        text: reply.content.slice(0, 120),
        url: `${window.location.origin}/home/post/${reply.id}`,
      })
      .then(() => this.shareOpen.set(false))
      .catch(() => {});
  }
}
