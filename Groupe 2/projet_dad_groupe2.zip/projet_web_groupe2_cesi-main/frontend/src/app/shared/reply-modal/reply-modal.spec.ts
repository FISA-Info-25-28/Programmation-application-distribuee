import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { signal } from '@angular/core';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { ReplyModal } from './reply-modal';
import { ReplyModalService } from '../../core/services/reply-modal.service';
import { AuthService } from '../../core/services/auth.service';
import { FlashService } from '../flash/flash.service';
import { LangService } from '../../core/services/lang.service';
import { MediaService } from '../../core/services/media.service';
import { Post } from '../../core/models/post.model';

const parent: Post = {
  id: 'post-1',
  author: { id: 'user-1', username: 'ada', displayName: 'Ada', avatarUrl: null },
  content: 'Parent',
  lang: '',
  visibility: 'PUBLIC',
  tags: [],
  likeCount: 0,
  replyCount: 0,
  repostCount: 0,
  isLiked: false,
  isReposted: false,
  isBookmarked: false,
  parentId: null,
  createdAt: '2026-01-01T00:00:00Z',
  media: [],
};

describe('ReplyModal', () => {
  let fixture: ComponentFixture<ReplyModal>;
  let component: ReplyModal;
  let context = signal<any>(null);
  let http: { post: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };
  let modal: { context: ReturnType<typeof signal<any>>; close: ReturnType<typeof vi.fn> };
  let media: { validate: ReturnType<typeof vi.fn>; upload: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    context = signal(null);
    http = { post: vi.fn().mockReturnValue(of({ ...parent, id: 'reply-1', parentId: 'post-1' })) };
    flash = { show: vi.fn() };
    modal = { context, close: vi.fn() };
    media = {
      validate: vi.fn().mockReturnValue(null),
      upload: vi.fn().mockReturnValue(of({ mediaType: 'IMAGE', url: '/image.png' })),
    };

    await TestBed.configureTestingModule({
      imports: [ReplyModal],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: FlashService, useValue: flash },
        { provide: ReplyModalService, useValue: modal },
        { provide: AuthService, useValue: { currentUser: signal(null).asReadonly() } },
        { provide: MediaService, useValue: media },
        {
          provide: LangService,
          useValue: {
            tr: () => ({
              composer: { mediaLimitReached: 'Limite media' },
              comments: { replyPublished: 'Reponse publiee', replyForbidden: 'Interdit', replyError: 'Erreur' },
            }),
          },
        },
      ],
    })
      .overrideComponent(ReplyModal, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(ReplyModal);
    component = fixture.componentInstance;
  });

  it('updates text, mentions, emojis and close state', () => {
    (component as any).replyText.set('Hello @a');
    (component as any).addMention('ada');
    (component as any).addEmoji('!');

    expect((component as any).replyText()).toBe('Hello @ada !');
    expect((component as any).canReply()).toBe(true);

    (component as any).close();
    expect((component as any).replyText()).toBe('');
    expect(modal.close).toHaveBeenCalled();
  });

  it('uploads selected media and validates limits', () => {
    const file = new File(['x'], 'image.png', { type: 'image/png' });

    (component as any).selectMedia([file]);

    expect(media.upload).toHaveBeenCalledWith(file);
    expect((component as any).selectedMedia()).toEqual([{ type: 'IMAGE', url: '/image.png' }]);

    (component as any).removeMedia(0);
    expect((component as any).selectedMedia()).toEqual([]);
  });

  it('submits replies and calls the success callback', () => {
    const onSuccess = vi.fn();
    context.set({ post: parent, onSuccess });
    (component as any).replyText.set('Reply');

    (component as any).submit();

    expect(http.post).toHaveBeenCalledWith(expect.stringContaining('/posts'), {
      content: 'Reply',
      parentId: 'post-1',
      media: [],
    });
    expect(onSuccess).toHaveBeenCalledWith(expect.objectContaining({ replyCount: 1 }), expect.objectContaining({ id: 'reply-1' }));
    expect(flash.show).toHaveBeenCalledWith('Reponse publiee', 'success');
  });

  it('flashes forbidden errors and keeps the modal open', () => {
    http.post.mockReturnValue(throwError(() => ({ status: 403 })));
    context.set({ post: parent, onSuccess: vi.fn() });
    (component as any).replyText.set('Reply');

    (component as any).submit();

    expect(flash.show).toHaveBeenCalledWith('Interdit', 'error');
    expect((component as any).isReplying()).toBe(false);
  });
});
