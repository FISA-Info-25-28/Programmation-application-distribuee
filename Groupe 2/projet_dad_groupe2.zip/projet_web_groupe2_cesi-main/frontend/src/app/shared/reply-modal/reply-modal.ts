import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';
import { forkJoin } from 'rxjs';

import { ReplyModalService } from '../../core/services/reply-modal.service';
import { AuthService } from '../../core/services/auth.service';
import { LangService } from '../../core/services/lang.service';
import { FlashService } from '../flash/flash.service';
import { Post } from '../../core/models/post.model';
import { ApiPost } from '../../core/models/api-post.model';
import { MediaAttachment } from '../../core/models/media.model';
import { mapApiPost } from '../../core/mappers/post.mapper';
import { environment } from '../../../environments/environment';
import { UserAvatar } from '../user-avatar/user-avatar';
import { MediaService } from '../../core/services/media.service';
import { MediaPickerButton } from '../media-picker-button/media-picker-button';
import { MediaPreview } from '../media-preview/media-preview';
import { EmojiPicker } from '../emoji-picker/emoji-picker';
import { MentionSuggestions } from '../mention-suggestions/mention-suggestions';
import { insertMention } from '../../core/utils/social-text';

@Component({
  selector: 'app-reply-modal',
  templateUrl: './reply-modal.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [UserAvatar, MediaPickerButton, MediaPreview, EmojiPicker, MentionSuggestions],
  host: { style: 'display: contents' },
})
export class ReplyModal {
  private readonly http = inject(HttpClient);
  private readonly flash = inject(FlashService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly mediaService = inject(MediaService);
  protected readonly lang = inject(LangService);
  protected readonly modal = inject(ReplyModalService);
  protected readonly auth = inject(AuthService);

  protected readonly replyText = signal('');
  protected readonly selectedMedia = signal<MediaAttachment[]>([]);
  protected readonly isReplying = signal(false);
  protected readonly isUploading = signal(false);
  protected readonly emojiPickerOpen = signal(false);
  protected readonly charsLeft = computed(() => 280 - this.replyText().length);
  protected readonly canReply = computed(() => {
    const hasContent = this.replyText().trim().length > 0 || this.selectedMedia().length > 0;
    return hasContent && this.replyText().length <= 280 && !this.isReplying() && !this.isUploading();
  });

  protected close(): void {
    this.replyText.set('');
    this.selectedMedia.set([]);
    this.isUploading.set(false);
    this.emojiPickerOpen.set(false);
    this.modal.close();
  }

  protected addEmoji(emoji: string): void {
    this.replyText.update((value) => `${value}${emoji}`);
  }

  protected addMention(username: string): void {
    this.replyText.update((value) => insertMention(value, username));
  }

  protected selectMedia(files: File[]): void {
    if (!files.length) return;

    if (this.selectedMedia().length >= 4) {
      this.flash.show(this.lang.tr().composer.mediaLimitReached, 'info');
      return;
    }

    const remainingSlots = 4 - this.selectedMedia().length;
    if (files.length > remainingSlots) {
      this.flash.show(this.lang.tr().composer.mediaLimitReached, 'info');
    }

    const validFiles = files.slice(0, remainingSlots).filter((file) => {
      const error = this.mediaService.validate(file);
      if (error) {
        this.flash.show(error, 'error');
        return false;
      }
      return true;
    });
    if (!validFiles.length) return;

    this.isUploading.set(true);
    forkJoin(validFiles.map((file) => this.mediaService.upload(file)))
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (uploads) => {
          this.selectedMedia.update((items) => [
            ...items,
            ...uploads.map((uploaded) => ({ type: uploaded.mediaType, url: uploaded.url })),
          ]);
          this.isUploading.set(false);
        },
        error: (error: Error) => {
          this.isUploading.set(false);
          this.flash.show(error.message, 'error');
        },
      });
  }

  protected removeMedia(index: number): void {
    this.selectedMedia.update((items) => items.filter((_, itemIndex) => itemIndex !== index));
  }

  protected submit(): void {
    const ctx = this.modal.context();
    if (!ctx || !this.canReply()) return;

    this.isReplying.set(true);
    this.http
      .post<Post | ApiPost>(`${environment.apiBaseUrl}/posts`, {
        content: this.replyText().trim(),
        parentId: ctx.post.id,
        media: this.selectedMedia(),
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (reply) => {
          ctx.onSuccess(
            { ...ctx.post, replyCount: ctx.post.replyCount + 1 },
            mapApiPost(reply, this.auth.currentUser()),
          );
          this.flash.show(this.lang.tr().comments.replyPublished, 'success');
          this.replyText.set('');
          this.selectedMedia.set([]);
          this.emojiPickerOpen.set(false);
          this.modal.close();
        },
        error: (error) => {
          const message = error?.status === 403
            ? this.lang.tr().comments.replyForbidden
            : this.lang.tr().comments.replyError;
          this.flash.show(message, 'error');
          this.isReplying.set(false);
        },
        complete: () => this.isReplying.set(false),
      });
  }
}
