import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { ShareViaMessage } from './share-via-message';
import { FlashService } from '../flash/flash.service';
import { CryptoService } from '../../core/services/crypto.service';
import { User } from '../../core/models/user.model';
import { Conversation } from '../../core/models/conversation.model';

const user: User = {
  id: 'user-1',
  username: 'ada',
  displayName: 'Ada Lovelace',
  email: 'ada@example.test',
  role: 'USER',
  bio: null,
  avatarUrl: null,
  followersCount: 0,
  followingCount: 0,
  postsCount: 0,
  createdAt: '2026-01-01T00:00:00Z',
};

const conversation: Conversation = {
  id: 'conv-1',
  participant: { id: 'user-1', username: 'ada', displayName: 'Ada', avatarUrl: null, publicKey: 'key' },
  lastMessage: '',
  lastMessageAt: '2026-01-01T00:00:00Z',
  unreadCount: 0,
};

describe('ShareViaMessage', () => {
  let fixture: ComponentFixture<ShareViaMessage>;
  let component: ShareViaMessage;
  let http: { get: ReturnType<typeof vi.fn>; post: ReturnType<typeof vi.fn> };
  let flash: { show: ReturnType<typeof vi.fn> };
  let crypto: { ensureKeyPair: ReturnType<typeof vi.fn>; encrypt: ReturnType<typeof vi.fn> };

  beforeEach(async () => {
    vi.useFakeTimers();
    http = {
      get: vi.fn().mockReturnValue(of([user])),
      post: vi.fn((url: string) => (url.includes('/conversations/') ? of({}) : of(conversation))),
    };
    flash = { show: vi.fn() };
    crypto = {
      ensureKeyPair: vi.fn().mockResolvedValue(undefined),
      encrypt: vi.fn().mockReturnValue({ ciphertext: 'cipher', nonce: 'nonce' }),
    };

    await TestBed.configureTestingModule({
      imports: [ShareViaMessage],
      providers: [
        { provide: HttpClient, useValue: http },
        { provide: FlashService, useValue: flash },
        { provide: CryptoService, useValue: crypto },
      ],
    })
      .overrideComponent(ShareViaMessage, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(ShareViaMessage);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('postId', 'post-1');
    fixture.componentRef.setInput('postExcerpt', 'hello world');
    fixture.componentRef.setInput('postAuthorName', 'Ada');
    fixture.componentRef.setInput('postAuthorUsername', 'ada');
    fixture.detectChanges();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('loads contacts, debounces search and toggles selected users', () => {
    expect(http.get).toHaveBeenCalledWith(expect.stringContaining('/users/suggestions'));

    (component as any).onQueryChange('bob');
    vi.advanceTimersByTime(220);
    expect(http.get).toHaveBeenLastCalledWith(expect.stringContaining('/users/search?q=bob'));

    (component as any).toggleSelect(user);
    expect((component as any).isSelected('user-1')).toBe(true);
    expect((component as any).canSend).toBe(true);

    (component as any).toggleSelect(user);
    expect((component as any).isSelected('user-1')).toBe(false);
  });

  it('sends encrypted shared posts and closes on success', async () => {
    const closed: void[] = [];
    component.closed.subscribe(() => closed.push(undefined));
    (component as any).toggleSelect(user);

    (component as any).send();
    await Promise.resolve();

    expect(crypto.ensureKeyPair).toHaveBeenCalled();
    expect(crypto.encrypt).toHaveBeenCalledWith(expect.stringContaining('breezy:post:post-1'), 'key');
    expect(http.post).toHaveBeenCalledWith(expect.stringContaining('/conversations/conv-1/messages'), {
      content: 'cipher',
      nonce: 'nonce',
      kind: 'SHARED_POST',
    });
    expect(flash.show).toHaveBeenCalledWith(expect.stringContaining('Ada'), 'success');
    expect(closed.length).toBe(1);
  });

  it('flashes an error when sending fails', async () => {
    http.post.mockImplementation((url: string) =>
      url.includes('/conversations/') ? throwError(() => new Error('network')) : of(conversation),
    );
    (component as any).toggleSelect(user);

    (component as any).send();
    await Promise.resolve();

    expect(flash.show).toHaveBeenCalledWith("Erreur lors de l'envoi.", 'error');
    expect((component as any).isSending()).toBe(false);
  });
});
