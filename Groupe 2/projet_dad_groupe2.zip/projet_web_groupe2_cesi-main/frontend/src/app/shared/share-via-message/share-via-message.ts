import {
  ChangeDetectionStrategy,
  Component,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { forkJoin, switchMap, take } from 'rxjs';

import { FlashService } from '../flash/flash.service';
import { User } from '../../core/models/user.model';
import { Conversation } from '../../core/models/conversation.model';
import { environment } from '../../../environments/environment';
import { UserAvatar } from '../user-avatar/user-avatar';
import { CryptoService } from '../../core/services/crypto.service';

@Component({
  selector: 'app-share-via-message',
  templateUrl: './share-via-message.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, UserAvatar],
})
export class ShareViaMessage {
  private readonly http = inject(HttpClient);
  private readonly flash = inject(FlashService);
  private readonly crypto = inject(CryptoService);

  readonly postId = input<string>('');
  readonly postExcerpt = input<string>('');
  readonly postAuthorName = input<string>('');
  readonly postAuthorUsername = input<string>('');
  readonly closed = output<void>();

  protected readonly query = signal('');
  protected readonly contacts = signal<User[]>([]);
  protected readonly isLoading = signal(false);
  protected readonly selectedUsers = signal<Map<string, User>>(new Map());
  protected readonly isSending = signal(false);

  private searchTimer = 0;

  constructor() {
    this.fetchContacts('');
  }

  private fetchContacts(q: string): void {
    this.isLoading.set(true);
    const url = q.trim()
      ? `${environment.apiBaseUrl}/users/search?q=${encodeURIComponent(q.trim())}`
      : `${environment.apiBaseUrl}/users/suggestions`;
    this.http.get<User[]>(url).pipe(take(1)).subscribe((users) => {
      this.contacts.set(users);
      this.isLoading.set(false);
    });
  }

  protected onQueryChange(q: string): void {
    this.query.set(q);
    clearTimeout(this.searchTimer);
    this.searchTimer = window.setTimeout(() => this.fetchContacts(q), 220);
  }

  protected toggleSelect(user: User): void {
    this.selectedUsers.update((map) => {
      const next = new Map(map);
      if (next.has(user.id)) next.delete(user.id);
      else next.set(user.id, user);
      return next;
    });
  }

  protected isSelected(userId: string): boolean {
    return this.selectedUsers().has(userId);
  }

  protected selectedList(): User[] {
    return Array.from(this.selectedUsers().values());
  }

  protected get canSend(): boolean {
    return this.selectedUsers().size > 0 && !this.isSending();
  }

  protected send(): void {
    const recipients = this.selectedList();
    if (!recipients.length) return;

    const excerpt = this.postExcerpt().slice(0, 200);
    const postId = this.postId();
    const authorName = this.postAuthorName();
    const authorUsername = this.postAuthorUsername();
    const content = postId
      ? `breezy:post:${postId}\n${authorName}\n@${authorUsername}\n${excerpt}`
      : excerpt;

    this.isSending.set(true);

    void this.crypto.ensureKeyPair().then(() => {
      const sends$ = recipients.map((user) =>
        this.http
          .post<Conversation>(`${environment.apiBaseUrl}/conversations`, { username: user.username })
          .pipe(
            switchMap((conv) => {
              const recipientPublicKey = conv.participant.publicKey;
              const encrypted = recipientPublicKey ? this.crypto.encrypt(content, recipientPublicKey) : null;
              return this.http.post(`${environment.apiBaseUrl}/conversations/${conv.id}/messages`, {
                content: encrypted ? encrypted.ciphertext : content,
                nonce: encrypted?.nonce ?? '',
                kind: 'SHARED_POST',
              });
            }),
          ),
      );

      forkJoin(sends$).pipe(take(1)).subscribe({
        next: () => {
          const count = recipients.length;
          const names = recipients.slice(0, 2).map((u) => u.displayName.split(' ')[0]).join(', ');
          this.flash.show(
            count === 1
              ? `Post envoyé à ${names} !`
              : `Post envoyé à ${names}${count > 2 ? ` +${count - 2}` : ''} !`,
            'success',
          );
          this.isSending.set(false);
          this.closed.emit();
        },
        error: () => {
          this.flash.show('Erreur lors de l\'envoi.', 'error');
          this.isSending.set(false);
        },
      });
    });
  }
}
