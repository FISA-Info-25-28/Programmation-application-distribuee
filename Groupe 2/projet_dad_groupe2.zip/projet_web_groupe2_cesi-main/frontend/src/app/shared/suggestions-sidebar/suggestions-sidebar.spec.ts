import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuggestionsSidebar } from './suggestions-sidebar';
import { LangService } from '../../core/services/lang.service';
import { User } from '../../core/models/user.model';

const user: User = {
  id: 'user-1',
  username: 'ada',
  displayName: 'Ada',
  email: 'ada@example.test',
  role: 'USER',
  bio: null,
  avatarUrl: null,
  followersCount: 0,
  followingCount: 0,
  postsCount: 0,
  createdAt: '2026-01-01T00:00:00Z',
};

describe('SuggestionsSidebar', () => {
  let fixture: ComponentFixture<SuggestionsSidebar>;
  let component: SuggestionsSidebar;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SuggestionsSidebar],
      providers: [{ provide: LangService, useValue: { tr: () => ({ sidebar: {} }) } }],
    })
      .overrideComponent(SuggestionsSidebar, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(SuggestionsSidebar);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('users', [user]);
    fixture.detectChanges();
  });

  it('receives suggested users', () => {
    expect(component.users()).toEqual([user]);
  });
});
