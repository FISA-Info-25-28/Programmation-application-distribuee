import { ChangeDetectionStrategy, Component, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';

import { User } from '../../core/models/user.model';
import { LangService } from '../../core/services/lang.service';
import { UserRow } from '../user-row/user-row';

@Component({
  selector: 'app-suggestions-sidebar',
  templateUrl: './suggestions-sidebar.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, UserRow],
})
export class SuggestionsSidebar {
  readonly users = input.required<User[]>();
  protected readonly lang = inject(LangService);
}
