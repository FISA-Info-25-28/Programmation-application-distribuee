import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportDialog } from './support-dialog';
import { LangService } from '../../core/services/lang.service';

describe('SupportDialog', () => {
  let fixture: ComponentFixture<SupportDialog>;
  let component: SupportDialog;

  beforeEach(async () => {
    const doc = {
      brand: 'Breezy',
      title: 'Guide',
      close: 'Fermer',
      accept: 'OK',
      accountTitle: 'Compte',
      accountText: 'Texte compte',
      profileTitle: 'Profil',
      profileText: 'Texte profil',
      postsTitle: 'Posts',
      postsText: 'Texte posts',
      messagesTitle: 'Messages',
      messagesText: 'Texte messages',
      moderationTitle: 'Moderation',
      moderationText: 'Texte moderation',
      startTitle: 'Debut',
      startText: 'Texte debut',
      publishTitle: 'Publier',
      publishText: 'Texte publier',
      interactTitle: 'Interagir',
      interactText: 'Texte interagir',
      privacyTitle: 'Prive',
      privacyText: 'Texte prive',
      settingsTitle: 'Reglages',
      settingsText: 'Texte reglages',
    };

    await TestBed.configureTestingModule({
      imports: [SupportDialog],
      providers: [{ provide: LangService, useValue: { tr: () => ({ faq: doc, userDoc: doc }) } }],
    })
      .overrideComponent(SupportDialog, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(SupportDialog);
    component = fixture.componentInstance;
  });

  it('builds FAQ content', () => {
    fixture.componentRef.setInput('document', 'faq');
    fixture.detectChanges();

    expect((component as any).content()).toEqual(
      expect.objectContaining({
        labelledBy: 'faq-title',
        sections: expect.arrayContaining([expect.objectContaining({ title: 'Compte' })]),
      }),
    );
  });

  it('builds user documentation content', () => {
    fixture.componentRef.setInput('document', 'userDoc');
    fixture.detectChanges();

    expect((component as any).content()).toEqual(
      expect.objectContaining({
        labelledBy: 'user-doc-title',
        sections: expect.arrayContaining([expect.objectContaining({ title: 'Debut' })]),
      }),
    );
  });
});
