import { Component, computed, inject, input, output } from '@angular/core';
import { LangService } from '../../core/services/lang.service';

export type SupportDocument = 'faq' | 'userDoc';

@Component({
  selector: 'app-support-dialog',
  templateUrl: './support-dialog.html',
})
export class SupportDialog {
  protected readonly lang = inject(LangService);
  readonly document = input.required<SupportDocument>();
  readonly closed = output<void>();

  protected readonly content = computed(() => {
    const tr = this.lang.tr();

    if (this.document() === 'faq') {
      return {
        brand: tr.faq.brand,
        title: tr.faq.title,
        close: tr.faq.close,
        accept: tr.faq.accept,
        labelledBy: 'faq-title',
        sections: [
          { title: tr.faq.accountTitle, text: tr.faq.accountText },
          { title: tr.faq.profileTitle, text: tr.faq.profileText },
          { title: tr.faq.postsTitle, text: tr.faq.postsText },
          { title: tr.faq.messagesTitle, text: tr.faq.messagesText },
          { title: tr.faq.moderationTitle, text: tr.faq.moderationText },
        ],
      };
    }

    return {
      brand: tr.userDoc.brand,
      title: tr.userDoc.title,
      close: tr.userDoc.close,
      accept: tr.userDoc.accept,
      labelledBy: 'user-doc-title',
      sections: [
        { title: tr.userDoc.startTitle, text: tr.userDoc.startText },
        { title: tr.userDoc.publishTitle, text: tr.userDoc.publishText },
        { title: tr.userDoc.interactTitle, text: tr.userDoc.interactText },
        { title: tr.userDoc.privacyTitle, text: tr.userDoc.privacyText },
        { title: tr.userDoc.settingsTitle, text: tr.userDoc.settingsText },
      ],
    };
  });
}
