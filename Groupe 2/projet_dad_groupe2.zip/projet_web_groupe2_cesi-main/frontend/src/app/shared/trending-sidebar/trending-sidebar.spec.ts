import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrendingSidebar } from './trending-sidebar';
import { LangService } from '../../core/services/lang.service';

describe('TrendingSidebar', () => {
  let fixture: ComponentFixture<TrendingSidebar>;
  let component: TrendingSidebar;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TrendingSidebar],
      providers: [{ provide: LangService, useValue: { tr: () => ({ sidebar: {} }) } }],
    })
      .overrideComponent(TrendingSidebar, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(TrendingSidebar);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('tags', [{ tag: 'angular', postsCount: 2, likesCount: 4 }]);
    fixture.detectChanges();
  });

  it('receives trending tags', () => {
    expect(component.tags()).toEqual([{ tag: 'angular', postsCount: 2, likesCount: 4 }]);
  });
});
