import { ChangeDetectionStrategy, Component, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';

import { TrendingTag } from '../../core/models/trending-tag.model';
import { LangService } from '../../core/services/lang.service';

@Component({
  selector: 'app-trending-sidebar',
  templateUrl: './trending-sidebar.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink],
})
export class TrendingSidebar {
  readonly tags = input.required<TrendingTag[]>();
  protected readonly lang = inject(LangService);
}
