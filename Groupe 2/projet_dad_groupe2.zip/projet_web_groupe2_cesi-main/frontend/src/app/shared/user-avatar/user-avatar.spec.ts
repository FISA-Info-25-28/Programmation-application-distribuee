import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAvatar } from './user-avatar';

describe('UserAvatar', () => {
  let fixture: ComponentFixture<UserAvatar>;
  let component: UserAvatar;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserAvatar],
    })
      .overrideComponent(UserAvatar, { set: { template: '' } })
      .compileComponents();

    fixture = TestBed.createComponent(UserAvatar);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('userId', 'user-12');
    fixture.componentRef.setInput('displayName', 'Ada Lovelace');
    fixture.detectChanges();
  });

  it('exposes avatar utility helpers for the template', () => {
    expect((component as any).avatarClass(component.userId())).toBe('av-3');
    expect((component as any).initials(component.displayName())).toBe('AL');
    expect((component as any).versionedImageUrl(null)).toBeNull();
  });
});
