import { ChangeDetectionStrategy, Component, input } from '@angular/core';

import { avatarClass, initials, versionedImageUrl } from '../../core/utils/avatar';

@Component({
  selector: 'app-user-avatar',
  templateUrl: './user-avatar.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserAvatar {
  readonly userId = input.required<string>();
  readonly displayName = input.required<string>();
  readonly avatarUrl = input<string | null | undefined>(null);
  readonly className = input('');
  readonly imageClass = input('h-full w-full object-contain');

  protected readonly avatarClass = avatarClass;
  protected readonly initials = initials;
  protected readonly versionedImageUrl = versionedImageUrl;
}
