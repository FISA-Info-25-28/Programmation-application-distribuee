import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserRow } from './user-row';
import { User } from '../../core/models/user.model';

const user: User = {
  id: 'user-1',
  username: 'ada',
  displayName: 'Ada',
  email: 'ada@example.test',
  role: 'USER',
  bio: 'bio',
  avatarUrl: null,
  followersCount: 0,
  followingCount: 0,
  postsCount: 0,
  createdAt: '2026-01-01T00:00:00Z',
};

describe('UserRow', () => {
  let fixture: ComponentFixture<UserRow>;
  let component: UserRow;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserRow],
    })
      .overrideComponent(UserRow, { set: { template: '', imports: [] } })
      .compileComponents();

    fixture = TestBed.createComponent(UserRow);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('user', user);
    fixture.detectChanges();
  });

  it('exposes defaults and emits follow changes with the user', () => {
    const changes: unknown[] = [];
    component.followChange.subscribe((change) => changes.push(change));

    component.followChange.emit({ user, state: { following: true, requestPending: false } });

    expect(component.showFollow()).toBe(true);
    expect(component.showBio()).toBe(false);
    expect(changes).toEqual([{ user, state: { following: true, requestPending: false } }]);
  });
});
