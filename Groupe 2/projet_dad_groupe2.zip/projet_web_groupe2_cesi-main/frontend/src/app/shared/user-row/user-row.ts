import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { RouterLink } from '@angular/router';

import { FollowBtn, FollowState } from '../follow-btn/follow-btn';
import { User } from '../../core/models/user.model';
import { UserAvatar } from '../user-avatar/user-avatar';

export interface UserFollowChange {
  user: User;
  state: FollowState;
}

@Component({
  selector: 'app-user-row',
  templateUrl: './user-row.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FollowBtn, NgTemplateOutlet, RouterLink, UserAvatar],
  host: { class: 'flex items-center gap-3' },
})
export class UserRow {
  readonly user = input.required<User>();
  /** Affiche le bouton Suivre */
  readonly showFollow = input(true);
  /** Affiche la bio sous le username */
  readonly showBio = input(false);
  readonly compact = input(false);
  /** Conserve la compatibilite avec les appels existants. */
  readonly clickable = input(false);
  readonly followChange = output<UserFollowChange>();

}
