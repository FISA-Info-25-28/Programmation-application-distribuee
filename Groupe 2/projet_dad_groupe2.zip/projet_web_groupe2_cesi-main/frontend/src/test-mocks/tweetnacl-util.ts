export function encodeBase64(value: Uint8Array): string {
  return btoa(String.fromCharCode(...value));
}

export function decodeBase64(value: string): Uint8Array {
  return new Uint8Array(
    atob(value)
      .split('')
      .map((char) => char.charCodeAt(0)),
  );
}

export function decodeUTF8(value: string): Uint8Array {
  return new TextEncoder().encode(value);
}

export function encodeUTF8(value: Uint8Array): string {
  return new TextDecoder().decode(value);
}
