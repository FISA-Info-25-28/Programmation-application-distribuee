/* eslint-disable @typescript-eslint/no-namespace */
declare namespace nacl {
  export interface BoxKeyPair {
    publicKey: Uint8Array;
    secretKey: Uint8Array;
  }
}

function box(
  message: Uint8Array,
  nonce: Uint8Array,
  publicKey: Uint8Array,
  secretKey: Uint8Array,
): Uint8Array {
  void nonce;
  void publicKey;
  void secretKey;
  return message;
}

box.open = (
  ciphertext: Uint8Array,
  nonce: Uint8Array,
  publicKey: Uint8Array,
  secretKey: Uint8Array,
): Uint8Array => {
  void nonce;
  void publicKey;
  void secretKey;
  return ciphertext;
};
box.keyPair = (): nacl.BoxKeyPair => ({
  publicKey: new Uint8Array([1, 2, 3]),
  secretKey: new Uint8Array([4, 5, 6]),
});
box.nonceLength = 24;

const nacl = {
  box,
  randomBytes: (length: number) => new Uint8Array(length),
};

export default nacl;
